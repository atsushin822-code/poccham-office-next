//! ネイティブ (egui) のワークシート画面。
//!
//! WebView 版と同じ `poc-core::xlsx` を直接読み書きし、描画は egui の
//! ペインタ (= GPU の頂点バッファ) にまとめて流し込みます。
//!
//! 描画の考え方は WebView 版の部分描画と同じで、**見えている範囲だけ**を
//! 走査します (`visible_range`)。200×26 のうち画面に入るのは数千セル程度で、
//! スクロールしても走査量は画面サイズに比例したままです。

use eframe::egui;

use poc_core::xlsx::{Cell, CellValue, Workbook};

/// 描画するシートの上限 (メモリと相談して決めた固定グリッド)。
pub const ROWS: u32 = 200;
pub const COLS: u32 = 26;

const HEADER_W: f32 = 46.0;
const HEADER_H: f32 = 20.0;
const COL_W: f32 = 84.0;
const ROW_H: f32 = 20.0;

/// 表示範囲の計算 (純関数なのでテストできる)。
///
/// `scroll` は左上のスクロール量、`view` はグリッドの描画領域、
/// 戻り値は (先頭行, 末尾行, 先頭列, 末尾列) — 端は含む。
pub fn visible_range(scroll: (f32, f32), view: (f32, f32)) -> (u32, u32, u32, u32) {
    let (sx, sy) = (scroll.0.max(0.0), scroll.1.max(0.0));
    let (vw, vh) = (view.0.max(1.0), view.1.max(1.0));
    let r0 = (sy / ROW_H).floor() as u32;
    let c0 = (sx / COL_W).floor() as u32;
    let r1 = (((sy + vh) / ROW_H).ceil() as u32).min(ROWS.saturating_sub(1));
    let c1 = (((sx + vw) / COL_W).ceil() as u32).min(COLS.saturating_sub(1));
    (r0.min(r1), r1, c0.min(c1), c1)
}

/// セルの左上座標 (グリッド描画領域の左上を原点とする)。
pub fn cell_pos(r: u32, c: u32, scroll: (f32, f32)) -> (f32, f32) {
    (c as f32 * COL_W - scroll.0, r as f32 * ROW_H - scroll.1)
}

/// 0 → `A`, 25 → `Z`, 26 → `AA`。
pub fn col_name(mut c: u32) -> String {
    let mut out = String::new();
    loop {
        out.insert(0, (b'A' + (c % 26) as u8) as char);
        if c < 26 {
            break;
        }
        c = c / 26 - 1;
    }
    out
}

/// `A1` 形式。
pub fn addr(r: u32, c: u32) -> String {
    format!("{}{}", col_name(c), r + 1)
}

#[derive(Default)]
pub struct GridPanel {
    pub wb: Option<Workbook>,
    pub sheet: usize,
    pub sel: (u32, u32),
    pub scroll: (f32, f32),
    pub editing: bool,
    pub edit_buf: String,
    pub path: Option<String>,
    pub status: String,
    /// 直前のフレームで描いたセル数 (部分描画が効いていることの可視化)。
    pub painted: u32,
    /// 直前のフレームの描画時間 (ms)。
    pub frame_ms: f32,
}

impl GridPanel {
    pub fn new() -> Self {
        GridPanel {
            status: "「サンプル」で表を作るか、「開く」で .xlsx を読み込んでください".into(),
            ..GridPanel::default()
        }
    }

    /// 動作確認用の小さな表 (数式つき)。
    pub fn sample() -> Workbook {
        let mut wb = Workbook::new();
        {
            let sh = wb.sheet_mut();
            sh.name = "見積".into();
            for (c, h) in ["品目", "単価", "数量", "金額"].iter().enumerate() {
                sh.set(0, c as u32, Cell::text(*h));
            }
            let rows = [
                ("ノート PC", 158000.0, 2.0),
                ("外部モニタ", 32800.0, 3.0),
                ("キーボード", 12800.0, 4.0),
            ];
            for (i, (name, price, qty)) in rows.iter().enumerate() {
                let r = i as u32 + 1;
                sh.set(r, 0, Cell::text(*name));
                sh.set(r, 1, Cell::num(*price));
                sh.set(r, 2, Cell::num(*qty));
                let expr = format!("B{row}*C{row}", row = r + 1);
                sh.set(r, 3, Cell::formula(expr, None));
            }
            let total = format!("SUM(D2:D{})", rows.len() + 1);
            sh.set(rows.len() as u32 + 1, 0, Cell::text("合計"));
            sh.set(rows.len() as u32 + 1, 3, Cell::formula(total, None));
            sh.set(rows.len() as u32 + 2, 0, Cell::text("税込"));
            sh.set(rows.len() as u32 + 2, 3, Cell::formula("D5*1.1", None));
        }
        wb.recalculate();
        wb
    }

    pub fn load_sample(&mut self) {
        self.wb = Some(Self::sample());
        self.sheet = 0;
        self.sel = (0, 0);
        self.scroll = (0.0, 0.0);
        self.path = None;
        self.status = "サンプル (数式 4 セル) を読み込みました".into();
    }

    pub fn open(&mut self, path: &str) {
        match Workbook::open(path) {
            Ok(wb) => {
                let cells = wb.total_cells();
                self.wb = Some(wb);
                self.sheet = 0;
                self.sel = (0, 0);
                self.scroll = (0.0, 0.0);
                self.path = Some(path.to_string());
                self.status = format!("{path} — {cells} セルを読み込みました");
            }
            Err(e) => self.status = format!("{path} を開けませんでした: {e}"),
        }
    }

    pub fn save(&mut self) {
        let Some(path) = self.path.clone() else {
            self.status = "保存先がありません (開いたファイルのみ上書き保存できます)".into();
            return;
        };
        match self.wb.as_ref().map(|wb| wb.save(&path)) {
            Some(Ok(())) => self.status = format!("{path} に保存しました"),
            Some(Err(e)) => self.status = format!("保存できませんでした: {e}"),
            None => self.status = "ブックがありません".into(),
        }
    }

    pub fn recalc(&mut self) {
        if let Some(wb) = self.wb.as_mut() {
            wb.recalculate();
            self.status = "再計算しました".into();
        }
    }

    /// セルの**表示値** (数式なら計算結果)。
    pub fn display_text(&self) -> String {
        let Some(wb) = self.wb.as_ref() else {
            return String::new();
        };
        wb.sheets[self.sheet]
            .get(self.sel.0, self.sel.1)
            .map(|c| c.as_text())
            .unwrap_or_default()
    }

    /// 数式バーに出す**入力内容** (数式なら `=...` のまま)。
    pub fn current_text(&self) -> String {
        let Some(wb) = self.wb.as_ref() else {
            return String::new();
        };
        let sh = &wb.sheets[self.sheet];
        match sh.get(self.sel.0, self.sel.1) {
            None => String::new(),
            Some(cell) => match &cell.value {
                CellValue::Formula { expr, .. } => format!("={expr}"),
                _ => cell.as_text(),
            },
        }
    }

    /// 数式・数値・文字列を判別してセルに書き込み、再計算する。
    pub fn commit(&mut self, text: &str) {
        let Some(_) = self.wb else { return };
        let (r, c) = self.sel;
        let cell = if let Some(expr) = text.trim().strip_prefix('=') {
            Cell::formula(expr.trim().to_string(), None)
        } else if text.trim().is_empty() {
            Cell::empty()
        } else if let Ok(n) = text.trim().parse::<f64>() {
            Cell::num(n)
        } else {
            Cell::text(text)
        };
        let wb = self.wb.as_mut().unwrap();
        if self.sheet < wb.sheets.len() {
            wb.sheets[self.sheet].set(r, c, cell);
            wb.recalculate();
            let shown = wb.sheets[self.sheet]
                .get(r, c)
                .map(|x| x.as_text())
                .unwrap_or_default();
            self.status = format!("{} = {shown}", addr(r, c));
        }
        self.editing = false;
    }

    pub fn move_sel(&mut self, dr: i32, dc: i32) {
        let r = (self.sel.0 as i32 + dr).clamp(0, ROWS as i32 - 1) as u32;
        let c = (self.sel.1 as i32 + dc).clamp(0, COLS as i32 - 1) as u32;
        self.sel = (r, c);
        self.editing = false;
    }

    fn ensure_sel_visible(&mut self, view: (f32, f32)) {
        let (r, c) = self.sel;
        let (x, y) = cell_pos(r, c, self.scroll);
        if y < 0.0 {
            self.scroll.1 = r as f32 * ROW_H;
        } else if y + ROW_H > view.1 {
            self.scroll.1 = (r as f32 + 1.0) * ROW_H - view.1;
        }
        if x < 0.0 {
            self.scroll.0 = c as f32 * COL_W;
        } else if x + COL_W > view.0 {
            self.scroll.0 = (c as f32 + 1.0) * COL_W - view.0;
        }
        let max_x = (COLS as f32 * COL_W - view.0).max(0.0);
        let max_y = (ROWS as f32 * ROW_H - view.1).max(0.0);
        self.scroll.0 = self.scroll.0.clamp(0.0, max_x);
        self.scroll.1 = self.scroll.1.clamp(0.0, max_y);
    }

    pub fn ui(&mut self, ui: &mut egui::Ui, font_size: f32, zoom: f32) {
        let fs = (font_size * zoom).clamp(7.0, 34.0);
        let cw = COL_W * zoom;
        let rh = ROW_H * zoom;

        ui.horizontal(|ui| {
            if ui.button("サンプル").clicked() {
                self.load_sample();
            }
            if ui.button("開く…").clicked() {
                if let Some(p) = crate::pick_file() {
                    self.open(&p);
                }
            }
            if ui.button("保存").clicked() {
                self.save();
            }
            if ui.button("再計算").clicked() {
                self.recalc();
            }
            ui.separator();
            if let Some(wb) = self.wb.as_ref() {
                let names: Vec<String> = wb.sheets.iter().map(|s| s.name.clone()).collect();
                let mut sheet = self.sheet;
                egui::ComboBox::from_id_salt("sheet-pick")
                    .selected_text(names.get(sheet).cloned().unwrap_or_default())
                    .show_ui(ui, |ui| {
                        for (i, name) in names.iter().enumerate() {
                            ui.selectable_value(&mut sheet, i, name);
                        }
                    });
                if sheet != self.sheet {
                    self.sheet = sheet.min(names.len().saturating_sub(1));
                    self.sel = (0, 0);
                    self.scroll = (0.0, 0.0);
                }
            } else {
                ui.label(egui::RichText::new("ブック未読込").weak());
            }
        });

        ui.add_space(4.0);
        // 数式バー
        ui.horizontal(|ui| {
            ui.label(egui::RichText::new(addr(self.sel.0, self.sel.1)).strong());
            if !self.editing {
                self.edit_buf = self.current_text();
            }
            let resp = ui.add(
                egui::TextEdit::singleline(&mut self.edit_buf)
                    .desired_width(f32::INFINITY)
                    .hint_text("値または =数式"),
            );
            let entered = resp.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter));
            if entered {
                self.commit(&self.edit_buf.clone());
            }
        });
        ui.add_space(4.0);

        let view_rect = ui.available_rect_before_wrap();
        let resp = ui.allocate_rect(view_rect, egui::Sense::click_and_drag());
        let painter = ui.painter_at(view_rect);
        let visuals = ui.visuals().clone();

        // ---- スクロール ----
        if resp.hovered() {
            let d = ui.input(|i| i.raw_scroll_delta);
            self.scroll.0 -= d.x;
            self.scroll.1 -= d.y;
        }
        let grid_view = (
            (view_rect.width() - HEADER_W).max(1.0),
            (view_rect.height() - HEADER_H).max(1.0),
        );
        let max_x = (COLS as f32 * cw - grid_view.0).max(0.0);
        let max_y = (ROWS as f32 * rh - grid_view.1).max(0.0);
        self.scroll.0 = self.scroll.0.clamp(0.0, max_x);
        self.scroll.1 = self.scroll.1.clamp(0.0, max_y);
        let scroll_scaled = (self.scroll.0, self.scroll.1);

        // ---- 表示範囲 (ここが部分描画の本体) ----
        let (r0, r1, c0, c1) = visible_range(
            (scroll_scaled.0 / zoom, scroll_scaled.1 / zoom),
            (grid_view.0 / zoom, grid_view.1 / zoom),
        );

        // ---- キーボード ----
        let mut moved = None;
        ui.input(|i| {
            if i.key_pressed(egui::Key::ArrowDown) {
                moved = Some((1, 0));
            } else if i.key_pressed(egui::Key::ArrowUp) {
                moved = Some((-1, 0));
            } else if i.key_pressed(egui::Key::ArrowRight) && !self.editing {
                moved = Some((0, 1));
            } else if i.key_pressed(egui::Key::ArrowLeft) && !self.editing {
                moved = Some((0, -1));
            }
        });
        if let Some((dr, dc)) = moved {
            self.move_sel(dr, dc);
        }

        // ---- クリック選択 ----
        if resp.clicked() {
            if let Some(pos) = resp.interact_pointer_pos() {
                let gx = pos.x - view_rect.min.x - HEADER_W + scroll_scaled.0;
                let gy = pos.y - view_rect.min.y - HEADER_H + scroll_scaled.1;
                if gx >= 0.0 && gy >= 0.0 {
                    let r = (gy / rh).floor() as u32;
                    let c = (gx / cw).floor() as u32;
                    if r < ROWS && c < COLS {
                        self.sel = (r, c);
                        self.editing = false;
                    }
                }
            }
        }
        self.ensure_sel_visible(grid_view);

        let t0 = std::time::Instant::now();
        let origin = egui::pos2(view_rect.min.x + HEADER_W, view_rect.min.y + HEADER_H);
        let body_clip =
            egui::Rect::from_min_max(origin, egui::pos2(view_rect.max.x, view_rect.max.y));

        // 背景
        painter.rect_filled(
            body_clip,
            0.0,
            if visuals.dark_mode {
                egui::Color32::from_rgb(24, 26, 30)
            } else {
                egui::Color32::from_rgb(255, 255, 255)
            },
        );

        let sheet = self.wb.as_ref().and_then(|wb| wb.sheets.get(self.sheet));

        // ---- 罫線は 1 本ずつではなく Shape の束にして 1 回で流す ----
        let line_color = if visuals.dark_mode {
            egui::Color32::from_rgb(52, 56, 64)
        } else {
            egui::Color32::from_rgb(214, 218, 226)
        };
        let mut shapes: Vec<egui::Shape> =
            Vec::with_capacity(((r1 - r0 + c1 - c0) as usize) * 2 + 8);
        for r in r0..=r1 {
            let y = origin.y + r as f32 * rh - scroll_scaled.1;
            if y < origin.y || y > body_clip.max.y {
                continue;
            }
            shapes.push(egui::Shape::line_segment(
                [egui::pos2(origin.x, y), egui::pos2(body_clip.max.x, y)],
                egui::Stroke::new(1.0_f32, line_color),
            ));
        }
        for c in c0..=c1 + 1 {
            let x = origin.x + c as f32 * cw - scroll_scaled.0;
            if x < origin.x || x > body_clip.max.x {
                continue;
            }
            shapes.push(egui::Shape::line_segment(
                [egui::pos2(x, origin.y), egui::pos2(x, body_clip.max.y)],
                egui::Stroke::new(1.0_f32, line_color),
            ));
        }
        painter.extend(shapes);

        // ---- 選択範囲 ----
        let sel_fill = if visuals.dark_mode {
            egui::Color32::from_rgba_unmultiplied(70, 130, 220, 60)
        } else {
            egui::Color32::from_rgba_unmultiplied(70, 130, 220, 40)
        };
        let sel_rect = egui::Rect::from_min_size(
            egui::pos2(
                origin.x + self.sel.1 as f32 * cw - scroll_scaled.0,
                origin.y + self.sel.0 as f32 * rh - scroll_scaled.1,
            ),
            egui::vec2(cw, rh),
        )
        .intersect(body_clip);
        painter.rect_filled(sel_rect, 0.0, sel_fill);
        painter.rect_stroke(
            sel_rect,
            0.0,
            egui::Stroke::new(2.0_f32, egui::Color32::from_rgb(46, 110, 220)),
            egui::StrokeKind::Inside,
        );

        // ---- 文字 (見えている範囲だけ) ----
        let text_color = if visuals.dark_mode {
            egui::Color32::from_rgb(228, 232, 240)
        } else {
            egui::Color32::from_rgb(28, 32, 40)
        };
        let mut painted = 0u32;
        if let Some(sh) = sheet {
            for r in r0..=r1 {
                let y = origin.y + r as f32 * rh - scroll_scaled.1 + rh / 2.0;
                if y < origin.y || y > body_clip.max.y {
                    continue;
                }
                for c in c0..=c1 {
                    let x = origin.x + c as f32 * cw - scroll_scaled.0 + 4.0;
                    if x > body_clip.max.x {
                        break;
                    }
                    let Some(cell) = sh.get(r, c) else { continue };
                    let txt = cell.as_text();
                    if txt.is_empty() {
                        continue;
                    }
                    painted += 1;
                    let numeric =
                        matches!(cell.value, CellValue::Number(_) | CellValue::Formula { .. });
                    let galley =
                        painter.layout_no_wrap(txt, egui::FontId::proportional(fs), text_color);
                    let pos = if numeric {
                        egui::pos2(x + cw - 8.0 - galley.size().x, y - galley.size().y / 2.0)
                    } else {
                        egui::pos2(x, y - galley.size().y / 2.0)
                    };
                    painter.galley(pos, galley, text_color);
                }
            }
        }
        self.painted = painted;

        // ---- 見出し (行番号 / 列名) ----
        let hdr_fill = if visuals.dark_mode {
            egui::Color32::from_rgb(36, 39, 45)
        } else {
            egui::Color32::from_rgb(242, 244, 248)
        };
        let hdr_text = if visuals.dark_mode {
            egui::Color32::from_rgb(176, 182, 194)
        } else {
            egui::Color32::from_rgb(90, 96, 108)
        };
        painter.rect_filled(
            egui::Rect::from_min_max(
                egui::pos2(view_rect.min.x, view_rect.min.y),
                egui::pos2(view_rect.max.x, origin.y),
            ),
            0.0,
            hdr_fill,
        );
        painter.rect_filled(
            egui::Rect::from_min_max(
                egui::pos2(view_rect.min.x, origin.y),
                egui::pos2(origin.x, view_rect.max.y),
            ),
            0.0,
            hdr_fill,
        );
        for c in c0..=c1 {
            let x = origin.x + c as f32 * cw - scroll_scaled.0 + cw / 2.0;
            if x < origin.x || x > body_clip.max.x {
                continue;
            }
            painter.text(
                egui::pos2(x, view_rect.min.y + HEADER_H / 2.0),
                egui::Align2::CENTER_CENTER,
                col_name(c),
                egui::FontId::proportional((fs - 1.0).max(7.0)),
                hdr_text,
            );
        }
        for r in r0..=r1 {
            let y = origin.y + r as f32 * rh - scroll_scaled.1 + rh / 2.0;
            if y < origin.y || y > body_clip.max.y {
                continue;
            }
            painter.text(
                egui::pos2(view_rect.min.x + HEADER_W / 2.0, y),
                egui::Align2::CENTER_CENTER,
                (r + 1).to_string(),
                egui::FontId::proportional((fs - 1.0).max(7.0)),
                hdr_text,
            );
        }
        self.frame_ms = t0.elapsed().as_secs_f32() * 1000.0;

        // ---- 状態 ----
        ui.separator();
        ui.horizontal(|ui| {
            ui.label(egui::RichText::new(&self.status).weak());
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                ui.label(
                    egui::RichText::new(format!(
                        "描画セル {} ・ {:.1} ms/フレーム ・ 合計 {}",
                        self.painted,
                        self.frame_ms,
                        self.wb.as_ref().map(|w| w.total_cells()).unwrap_or(0)
                    ))
                    .weak(),
                );
            });
        });
    }
}

/// サンプルのセル内容をテキストで返す (動作確認用)。
pub fn sample_dump() -> Vec<String> {
    let wb = GridPanel::sample();
    let sh = &wb.sheets[0];
    let mut out = Vec::new();
    for r in 0..6u32 {
        let mut row = Vec::new();
        for c in 0..4u32 {
            row.push(sh.get(r, c).map(|x| x.as_text()).unwrap_or_default());
        }
        out.push(row.join("\t"));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn visible_range_only_covers_the_viewport() {
        // 800x600 の領域に 84x20 のセル → 約 10 列 30 行
        let (r0, r1, c0, c1) = visible_range((0.0, 0.0), (800.0, 600.0));
        assert_eq!((r0, c0), (0, 0));
        assert_eq!(r1, 30);
        assert_eq!(c1, 10);
        let cells = (r1 - r0 + 1) * (c1 - c0 + 1);
        assert!(cells < 400, "描画セル数が多すぎる: {cells}");
        assert!(cells * 10 < ROWS * COLS, "全セル描画になっている");
    }

    #[test]
    fn visible_range_follows_scroll() {
        let (r0, r1, c0, c1) = visible_range((168.0, 200.0), (800.0, 600.0));
        assert_eq!(r0, 10); // 200 / 20
        assert_eq!(c0, 2); // 168 / 84
        assert!(r1 > r0);
        assert!(c1 > c0);
        assert!(r1 < ROWS && c1 < COLS);
    }

    #[test]
    fn visible_range_clamps_at_the_edges() {
        let (r0, r1, c0, c1) = visible_range((99999.0, 99999.0), (800.0, 600.0));
        assert_eq!((r1, c1), (ROWS - 1, COLS - 1));
        assert!(r0 <= r1 && c0 <= c1);
    }

    #[test]
    fn addresses_match_a1() {
        assert_eq!(addr(0, 0), "A1");
        assert_eq!(addr(9, 25), "Z10");
        assert_eq!(col_name(26), "AA");
        assert_eq!(col_name(27), "AB");
    }

    #[test]
    fn sample_has_live_formulas() {
        let dump = sample_dump();
        assert_eq!(dump[0], "品目\t単価\t数量\t金額");
        assert_eq!(dump[1].split('\t').nth(3).unwrap(), "316000"); // 158000*2
        assert_eq!(dump[4].split('\t').nth(3).unwrap(), "465600"); // 合計
        assert_eq!(dump[5].split('\t').nth(3).unwrap(), "512160"); // 税込
    }

    #[test]
    fn commit_writes_formulas_and_numbers() {
        let mut p = GridPanel::new();
        p.load_sample();
        p.sel = (1, 1);
        p.commit("1000");
        assert_eq!(p.current_text(), "1000");
        assert_eq!(p.display_text(), "1000");
        p.sel = (1, 3);
        p.commit("=B2*10");
        // 数式バーは数式を、セルは計算結果を出す
        assert_eq!(p.current_text(), "=B2*10");
        assert_eq!(p.display_text(), "10000");
        p.sel = (0, 10);
        p.commit("メモ");
        assert_eq!(p.display_text(), "メモ");
        p.commit("");
        assert_eq!(p.display_text(), "");
    }

    #[test]
    fn editing_a_cell_updates_dependent_formulas() {
        let mut p = GridPanel::new();
        p.load_sample();
        assert_eq!(p.display_text(), "品目");
        p.sel = (1, 2); // C2 数量
        p.commit("5");
        p.sel = (1, 3); // D2 金額 = B2*C2
        assert_eq!(p.display_text(), "790000");
        p.sel = (4, 3); // D5 合計
        assert_eq!(p.display_text(), "939600"); // 790000 + 98400 + 51200
    }
}
