//! 日本語フォントの読み込み。
//!
//! egui の既定フォントはラテン文字だけなので、OS に入っている CJK フォントを
//! 実行時に読み込んでフォールバックに差し込む。見つからなくても起動はできる
//! (日本語が豆腐になるだけ)。

use eframe::egui;
use std::sync::atomic::{AtomicUsize, Ordering};

static LOADED: AtomicUsize = AtomicUsize::new(0);

/// 読み込んだ書体数 (ステータスバー表示用)。
pub fn loaded_faces() -> usize {
    LOADED.load(Ordering::Relaxed)
}

/// 候補フォント (太字は先に置かない — egui は最初に見つかったものを本文に使う)。
fn candidates() -> Vec<&'static str> {
    vec![
        // Windows
        "C:/Windows/Fonts/YuGothM.ttc",
        "C:/Windows/Fonts/meiryo.ttc",
        "C:/Windows/Fonts/msgothic.ttc",
        // macOS
        "/System/Library/Fonts/ヒラギノ角ゴシック W3.ttc",
        "/System/Library/Fonts/Hiragino Sans GB.ttc",
        "/Library/Fonts/Arial Unicode.ttf",
        // Linux
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc",
        "/usr/share/fonts/truetype/fonts-japanese-gothic.ttf",
        "/usr/share/fonts/opentype/ipaexfont-gothic/ipaexg.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
}

pub fn install(ctx: &egui::Context) {
    let mut fonts = egui::FontDefinitions::default();
    let mut loaded = 0usize;
    for path in candidates() {
        let Ok(bytes) = std::fs::read(path) else {
            continue;
        };
        let name = format!("cjk-{loaded}");
        fonts
            .font_data
            .insert(name.clone(), egui::FontData::from_owned(bytes).into());
        for family in [egui::FontFamily::Proportional, egui::FontFamily::Monospace] {
            fonts.families.entry(family).or_default().push(name.clone());
        }
        loaded += 1;
        if loaded >= 2 {
            break;
        }
    }
    LOADED.store(loaded, Ordering::Relaxed);
    ctx.set_fonts(fonts);
}
