//! Poccham Office Next — ネイティブ UI (egui + wgpu/glow)。
//!
//! この小さいバイナリは、WebView 版のアプリと同じ `poc-core` / `poc-vba` を
//! 共有する **ネイティブの設定・マクロ・情報画面** です。編集を伴わない画面を
//! egui に移す第一歩として作ってあり、`docs/NATIVE_UI.md` の方針に沿っています。
//!
//! ```bash
//! cargo run --manifest-path crates/poc-egui/Cargo.toml --release
//! ```
//!
//! - 描画は GPU (eframe の glow バックエンド = OpenGL / 各 OS のネイティブ API)
//! - 日本語表示のため、OS の CJK フォントを実行時に読み込む
//! - 設定は JSON に保存し、WebView 版と共有できる (同じキー名)

use std::path::{Path, PathBuf};

use eframe::egui;
use serde::{Deserialize, Serialize};

mod font;
mod grid_view;
mod macro_run;

const VERSION: &str = env!("CARGO_PKG_VERSION");

fn main() -> eframe::Result<()> {
    // 画面なしで検証する (CI / サンドボックス用)。
    if std::env::args().any(|a| a == "--selftest") {
        std::process::exit(run_selftest());
    }
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([980.0, 680.0])
            .with_min_inner_size([640.0, 460.0])
            .with_title("Poccham Office Next"),
        renderer: renderer_choice(),
        ..Default::default()
    };
    eframe::run_native(
        "poccham-egui",
        options,
        Box::new(|cc| {
            font::install(&cc.egui_ctx);
            Ok(Box::new(NativeApp::new()))
        }),
    )
}

/// `--selftest` — 画面なしで、設定・マクロ・グリッドの往復と描画枚数を検証する。
fn run_selftest() -> i32 {
    let mut fails = 0usize;
    let mut check = |name: &str, ok: bool, detail: String| {
        println!(
            "[{}] {name}{}",
            if ok { "OK  " } else { "FAIL" },
            if detail.is_empty() {
                String::new()
            } else {
                format!(" — {detail}")
            }
        );
        if !ok {
            fails += 1;
        }
    };

    // 1. 設定 JSON (WebView 版と同じキー名で読み書きできるか)
    let settings = Settings::default();
    let json = serde_json::to_string(&settings).unwrap();
    let back: Settings = serde_json::from_str(&json).unwrap();
    check(
        "設定 JSON の往復",
        back.theme == settings.theme
            && back.grid_renderer == settings.grid_renderer
            && json.contains("grid_renderer"),
        format!("{} バイト", json.len()),
    );
    check(
        "設定キーが WebView 版と一致",
        ["theme", "grid_renderer", "font_size", "zoom", "recent"]
            .iter()
            .all(|k| json.contains(&format!("\"{k}\""))),
        "theme/grid_renderer/font_size/zoom/recent".into(),
    );

    // 2. VBA マクロ (設定画面と同じ経路)
    let m = macro_run::selftest_run();
    check("VBA マクロの実行", m.0, m.1);

    // 3. グリッド: サンプル + 数式 + 編集
    let dump = grid_view::sample_dump();
    check(
        "グリッドのサンプル表",
        dump.len() == 6 && dump[4].contains("465600") && dump[5].contains("512160"),
        format!("合計 {} / 税込 {}", dump[4], dump[5]),
    );
    let mut g = grid_view::GridPanel::new();
    g.load_sample();
    g.sel = (1, 1);
    g.commit("2000");
    check(
        "数値の入力",
        g.display_text() == "2000",
        format!("B2 = {}", g.display_text()),
    );
    g.sel = (1, 3);
    g.commit("=B2*4");
    check(
        "数式の入力と連鎖再計算",
        g.display_text() == "8000" && g.current_text() == "=B2*4",
        format!("D2 = {} (数式バー {})", g.display_text(), g.current_text()),
    );
    g.sel = (4, 3);
    check(
        "合計行の再計算",
        g.display_text() == "157600",
        format!("D5 = {} (D2 を =B2*4 = 8000 にした)", g.display_text()),
    );

    // 4. 表示範囲 (部分描画の走査量)
    let (r0, r1, c0, c1) = grid_view::visible_range((0.0, 0.0), (900.0, 620.0));
    let cells = (r1 - r0 + 1) * (c1 - c0 + 1);
    check(
        "表示範囲の走査量",
        cells < 600,
        format!(
            "{cells} セル (全体 {} セルの {:.1}%)",
            grid_view::ROWS * grid_view::COLS,
            cells as f32 * 100.0 / (grid_view::ROWS * grid_view::COLS) as f32
        ),
    );

    // 5. 大規模ブックの速度 (3000 セル)
    let t = std::time::Instant::now();
    let mut wb = poc_core::xlsx::Workbook::new();
    {
        let sh = wb.sheet_mut();
        for r in 0..1000u32 {
            sh.set(r, 0, poc_core::xlsx::Cell::num(r as f64));
            sh.set(r, 1, poc_core::xlsx::Cell::num(2.0));
            let f = format!("A{}*B{}", r + 1, r + 1);
            sh.set(r, 2, poc_core::xlsx::Cell::formula(f, None));
        }
    }
    let build = t.elapsed().as_secs_f32() * 1000.0;
    let t = std::time::Instant::now();
    wb.recalculate();
    let recalc = t.elapsed().as_secs_f32() * 1000.0;
    let ok = wb.sheets[0]
        .get(999, 2)
        .map(|c| c.as_text() == "1998")
        .unwrap_or(false);
    check(
        "3000 セルの生成と再計算",
        ok,
        format!("生成 {build:.1} ms / 再計算 {recalc:.1} ms"),
    );

    println!(
        "{}",
        if fails == 0 {
            "poc-egui セルフテスト: すべて合格"
        } else {
            "poc-egui セルフテスト: 失敗あり"
        }
    );
    if fails == 0 {
        0
    } else {
        1
    }
}

/// WebView 版 (`crates/poc-ui/ui/index.html`) と共有する設定。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Settings {
    /// `light` / `dark` / `system`
    pub theme: String,
    /// グリッドの描画方式: `auto` (GPU があれば GPU) / `2d` / `gpu`
    pub grid_renderer: String,
    /// 既定フォントサイズ (pt)
    pub font_size: f32,
    /// 画面の拡大率
    pub zoom: f32,
    /// 最近開いたファイル
    pub recent: Vec<String>,
}

impl Default for Settings {
    fn default() -> Self {
        Settings {
            theme: "system".into(),
            grid_renderer: "auto".into(),
            font_size: 11.0,
            zoom: 1.0,
            recent: Vec::new(),
        }
    }
}

impl Settings {
    pub fn path() -> PathBuf {
        let base = std::env::var("XDG_CONFIG_HOME")
            .map(PathBuf::from)
            .or_else(|_| std::env::var("APPDATA").map(PathBuf::from))
            .unwrap_or_else(|_| {
                std::env::var("HOME")
                    .map(|h| PathBuf::from(h).join(".config"))
                    .unwrap_or_else(|_| PathBuf::from("."))
            });
        base.join("poccham-office-next").join("settings.json")
    }

    pub fn load() -> Self {
        std::fs::read_to_string(Self::path())
            .ok()
            .and_then(|s| serde_json::from_str(&s).ok())
            .unwrap_or_default()
    }

    pub fn save(&self) -> std::io::Result<()> {
        let path = Self::path();
        if let Some(dir) = path.parent() {
            std::fs::create_dir_all(dir)?;
        }
        std::fs::write(
            &path,
            serde_json::to_string_pretty(self).unwrap_or_default(),
        )
    }

    fn touch_recent(&mut self, path: &str) {
        self.recent.retain(|p| p != path);
        self.recent.insert(0, path.to_string());
        self.recent.truncate(8);
    }
}

#[derive(Debug, Clone, PartialEq)]
enum Tab {
    Sheet,
    Settings,
    Macro,
    About,
}

pub struct NativeApp {
    settings: Settings,
    tab: Tab,
    saved_note: Option<String>,
    macros: macro_run::MacroPanel,
    fonts_loaded: usize,
    grid: grid_view::GridPanel,
}

impl NativeApp {
    fn new() -> Self {
        let mut settings = Settings::load();
        if settings.recent.is_empty() {
            settings.recent = default_recent();
        }
        NativeApp {
            settings,
            tab: Tab::Settings,
            saved_note: None,
            macros: macro_run::MacroPanel::default(),
            fonts_loaded: font::loaded_faces(),
            grid: grid_view::GridPanel::new(),
        }
    }

    fn apply_theme(&self, ctx: &egui::Context) {
        let dark = match self.settings.theme.as_str() {
            "dark" => true,
            "light" => false,
            _ => ctx.style().visuals.dark_mode,
        };
        ctx.set_visuals(if dark {
            egui::Visuals::dark()
        } else {
            egui::Visuals::light()
        });
    }
}

fn default_recent() -> Vec<String> {
    let mut out = Vec::new();
    for name in ["report.xlsx", "memo.docx", "deck.pptx"] {
        let p = PathBuf::from(name);
        if p.exists() {
            out.push(p.display().to_string());
        }
    }
    out
}

impl eframe::App for NativeApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.apply_theme(ctx);
        egui::TopBottomPanel::top("tabs").show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.heading("Poccham Office Next");
                ui.separator();
                ui.selectable_value(&mut self.tab, Tab::Sheet, "シート");
                ui.selectable_value(&mut self.tab, Tab::Settings, "設定");
                ui.selectable_value(&mut self.tab, Tab::Macro, "マクロ");
                ui.selectable_value(&mut self.tab, Tab::About, "情報");
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    ui.label(format!("v{VERSION} ・ native (egui)"));
                });
            });
        });

        egui::TopBottomPanel::bottom("status").show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label(format!(
                    "描画: {} ・ フォント {} 書体 ・ 設定ファイル: {}",
                    backend_label(),
                    self.fonts_loaded,
                    Settings::path().display()
                ));
                if let Some(note) = &self.saved_note {
                    ui.separator();
                    ui.label(egui::RichText::new(note).weak());
                }
            });
        });

        egui::CentralPanel::default().show(ctx, |ui| match self.tab {
            Tab::Sheet => {
                let fs = self.settings.font_size;
                let zoom = self.settings.zoom;
                self.grid.ui(ui, fs, zoom);
            }
            Tab::Settings => self.settings_tab(ui),
            Tab::Macro => self.macro_tab(ctx, ui),
            Tab::About => self.about_tab(ui),
        });
    }
}

/// `--features wgpu` かつ `POC_EGUI_RENDERER=wgpu` のときだけ wgpu を使う。
fn renderer_choice() -> eframe::Renderer {
    #[cfg(feature = "wgpu")]
    {
        if std::env::var("POC_EGUI_RENDERER").as_deref() == Ok("wgpu") {
            return eframe::Renderer::Wgpu;
        }
    }
    eframe::Renderer::Glow
}

/// 実際に使う描画バックエンドを表示する。
fn backend_label() -> &'static str {
    #[cfg(feature = "wgpu")]
    {
        if std::env::var("POC_EGUI_RENDERER").as_deref() == Ok("wgpu") {
            return "egui + wgpu (GPU)";
        }
    }
    "egui + glow (GPU)"
}

impl NativeApp {
    fn settings_tab(&mut self, ui: &mut egui::Ui) {
        ui.heading("表示と動作");
        ui.add_space(6.0);
        egui::Grid::new("settings-grid")
            .num_columns(2)
            .spacing([18.0, 10.0])
            .show(ui, |ui| {
                ui.label("テーマ");
                ui.horizontal(|ui| {
                    for (key, label) in [
                        ("system", "システム"),
                        ("light", "ライト"),
                        ("dark", "ダーク"),
                    ] {
                        ui.selectable_value(&mut self.settings.theme, key.to_string(), label);
                    }
                });
                ui.end_row();

                ui.label("グリッドの描画");
                ui.horizontal(|ui| {
                    for (key, label) in [("auto", "自動"), ("gpu", "GPU"), ("2d", "2D")] {
                        ui.selectable_value(
                            &mut self.settings.grid_renderer,
                            key.to_string(),
                            label,
                        );
                    }
                });
                ui.end_row();

                ui.label("フォントサイズ");
                ui.add(egui::Slider::new(&mut self.settings.font_size, 8.0..=24.0).suffix(" pt"));
                ui.end_row();

                ui.label("拡大率");
                ui.add(egui::Slider::new(&mut self.settings.zoom, 0.5..=2.5).suffix(" x"));
                ui.end_row();
            });

        ui.add_space(10.0);
        ui.label(
            egui::RichText::new(
                "設定は WebView 版と同じキー名で保存します (自動同期はしません)。\
                 「GPU」を選ぶと、セルの背景・罫線・選択範囲を WebGL2 のインスタンス描画で、\
                 文字を 2D レイヤで描きます。GPU が無い環境では自動的に 2D に戻ります。",
            )
            .weak(),
        );

        ui.add_space(12.0);
        ui.horizontal(|ui| {
            if ui.button("保存").clicked() {
                self.saved_note = Some(match self.settings.save() {
                    Ok(()) => "設定を保存しました".into(),
                    Err(e) => format!("保存できませんでした: {e}"),
                });
            }
            if ui.button("既定に戻す").clicked() {
                self.settings = Settings::default();
                self.settings.recent = default_recent();
                self.saved_note = Some("既定値に戻しました (保存で確定)".into());
            }
            if ui.button("設定ファイルを開く場所を表示").clicked() {
                self.saved_note = Some(Settings::path().display().to_string());
            }
        });

        ui.add_space(14.0);
        ui.separator();
        ui.heading("最近のファイル");
        if self.settings.recent.is_empty() {
            ui.label(egui::RichText::new("まだありません").weak());
        }
        let mut open_now: Option<String> = None;
        for path in self.settings.recent.clone() {
            ui.horizontal(|ui| {
                if ui.button("シートで開く").clicked() {
                    open_now = Some(path.clone());
                }
                ui.label(&path);
            });
        }
        if let Some(path) = open_now {
            self.open_file(&path);
            self.grid.open(&path);
            self.tab = Tab::Sheet;
        }

        ui.add_space(10.0);
        ui.horizontal(|ui| {
            let mut picked: Option<String> = None;
            let response = ui.button("ファイルを選ぶ…");
            if response.clicked() {
                if let Some(path) = pick_file() {
                    picked = Some(path);
                }
            }
            if let Some(path) = picked {
                self.open_file(&path);
                self.grid.open(&path);
                self.tab = Tab::Sheet;
            }
            ui.label(egui::RichText::new("(対応: .xlsx / .docx / .pptx / .csv / .ods)").weak());
        });
    }

    fn open_file(&mut self, path: &str) {
        let p = Path::new(path);
        let mut note = match poc_core::detect::detect_file(path) {
            Ok(format) => format!("{path} — {format:?} を検出しました"),
            Err(_) => format!("{path} の形式を判定できませんでした"),
        };
        if p.exists() {
            if let Ok(pres) = poc_core::pptx::Presentation::open(p) {
                note = format!("{path} — スライド {} 枚", pres.slides.len());
            } else if let Ok(wb) = poc_core::xlsx::Workbook::open(p) {
                note = format!("{path} — シート {} 枚", wb.sheets.len());
            }
        } else {
            note.push_str(" (見つかりません)");
        }
        self.settings.touch_recent(path);
        let _ = self.settings.save();
        self.saved_note = Some(note);
    }

    fn macro_tab(&mut self, ctx: &egui::Context, ui: &mut egui::Ui) {
        ui.heading("VBA マクロ");
        ui.label(egui::RichText::new("poc-vba のインタプリタをそのまま呼び出します。").weak());
        ui.add_space(6.0);
        self.macros.ui(ctx, ui);
    }

    fn about_tab(&mut self, ui: &mut egui::Ui) {
        ui.heading("Poccham Office Next");
        ui.label(format!("バージョン {VERSION} — ネイティブ (egui) 画面"));
        ui.add_space(8.0);
        egui::Grid::new("about-grid")
            .num_columns(2)
            .spacing([18.0, 8.0])
            .show(ui, |ui| {
                ui.label("エンジン");
                ui.label("poc-core 0.9.0 (OOXML / ODF / CSV)");
                ui.end_row();
                ui.label("マクロ");
                ui.label("poc-vba 0.9.0");
                ui.end_row();
                ui.label("UI");
                ui.label("egui 0.31 + eframe (glow / wgpu)");
                ui.end_row();
                ui.label("WebView 版");
                ui.label("crates/poc-ui/ui/index.html (1 ファイル)");
                ui.end_row();
            });
        ui.add_space(12.0);
        ui.separator();
        ui.label("この画面の役割");
        ui.label(
            "「シート」タブは egui のペインタ (= GPU の頂点バッファ) で表を描きます。\
             見えている範囲のセルだけを走査するので、スクロールしても描画量は画面サイズに比例します。\
             WebView 版は IME・リッチテキスト・スライドを担当し、同じ poc-core を共有しています \
             — docs/NATIVE_UI.md に段階移行の計画があります。",
        );
        ui.add_space(12.0);
        if ui.button("保存場所を開く (パスを表示)").clicked() {
            self.saved_note = Some(Settings::path().display().to_string());
        }
    }
}

/// ファイル選択ダイアログ。rfd を依存に足さずに済むよう、OS のダイアログを
/// そのまま使う (Windows: PowerShell / macOS: osascript / Linux: zenity)。
pub fn pick_file() -> Option<String> {
    #[cfg(target_os = "windows")]
    {
        let script = "Add-Type -AssemblyName System.Windows.Forms; \
            $d = New-Object System.Windows.Forms.OpenFileDialog; \
            if ($d.ShowDialog() -eq 'OK') { $d.FileName }";
        let out = std::process::Command::new("powershell")
            .args(["-NoProfile", "-Command", script])
            .output()
            .ok()?;
        let path = String::from_utf8_lossy(&out.stdout).trim().to_string();
        return (!path.is_empty()).then_some(path);
    }
    #[cfg(target_os = "macos")]
    {
        let out = std::process::Command::new("osascript")
            .args([
                "-e",
                "POSIX path of (choose file with prompt \"開くファイル\" of type {\"xlsx\",\"docx\",\"pptx\",\"csv\",\"ods\"})",
            ])
            .output()
            .ok()?;
        let path = String::from_utf8_lossy(&out.stdout).trim().to_string();
        return (!path.is_empty()).then_some(path);
    }
    #[cfg(all(unix, not(target_os = "macos")))]
    {
        let out = std::process::Command::new("zenity")
            .args([
                "--file-selection",
                "--title=開くファイル",
                "--file-filter=Office ファイル | *.xlsx *.docx *.pptx *.csv *.ods",
            ])
            .output()
            .ok()?;
        let path = String::from_utf8_lossy(&out.stdout).trim().to_string();
        return (!path.is_empty()).then_some(path);
    }
    #[allow(unreachable_code)]
    None
}
