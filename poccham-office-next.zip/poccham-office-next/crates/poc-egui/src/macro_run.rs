//! VBA マクロの編集・構文チェック・実行 (egui パネル)。
//!
//! `poc-vba` の `parse_module` → `Engine::run` をそのまま呼ぶ。WebView 版の
//! マクロダイアログと同じ結果 (MsgBox / Debug.Print / ステップ数 / 実行時間) を
//! 返すので、どちらの画面から実行しても挙動は同じ。

use std::path::PathBuf;

use eframe::egui;
use poc_core::xlsx::Workbook;
use poc_vba::{parse_module, Engine, ExcelHost, Value as VbaValue};

const SAMPLE: &str = r#"Sub TotalSales()
    Dim r As Long
    Dim total As Double
    For r = 2 To 6
        total = total + Cells(r, 2).Value
    Next r
    MsgBox "合計: " & total
    Debug.Print "rows=" & (6 - 1)
End Sub
"#;

#[derive(Default)]
pub struct MacroPanel {
    source: String,
    book: String,
    output: Vec<String>,
    status: Option<(bool, String)>,
    initialized: bool,
}

impl MacroPanel {
    pub fn ui(&mut self, _ctx: &egui::Context, ui: &mut egui::Ui) {
        if !self.initialized {
            self.source = SAMPLE.to_string();
            self.initialized = true;
        }

        ui.horizontal(|ui| {
            ui.label("ブック");
            ui.add(
                egui::TextEdit::singleline(&mut self.book)
                    .hint_text("例: report.xlsx（存在しなければメモリ上で実行）")
                    .desired_width(320.0),
            );
            if ui.button("サンプルに戻す").clicked() {
                self.source = SAMPLE.to_string();
            }
        });
        ui.add_space(6.0);

        egui::ScrollArea::vertical()
            .id_salt("macro-source")
            .max_height(240.0)
            .show(ui, |ui| {
                ui.add(
                    egui::TextEdit::multiline(&mut self.source)
                        .code_editor()
                        .desired_rows(14)
                        .desired_width(f32::INFINITY),
                );
            });

        ui.add_space(6.0);
        ui.horizontal(|ui| {
            if ui.button("構文チェック").clicked() {
                self.check();
            }
            if ui.button("実行").clicked() {
                self.run();
            }
            if ui.button("出力を消す").clicked() {
                self.output.clear();
                self.status = None;
            }
        });

        if let Some((ok, message)) = &self.status {
            let color = if *ok {
                egui::Color32::from_rgb(0x1a, 0x7f, 0x37)
            } else {
                egui::Color32::from_rgb(0xb4, 0x23, 0x18)
            };
            ui.colored_label(color, message);
        }

        ui.add_space(8.0);
        ui.separator();
        ui.label("出力");
        egui::ScrollArea::vertical()
            .id_salt("macro-output")
            .max_height(160.0)
            .stick_to_bottom(true)
            .show(ui, |ui| {
                if self.output.is_empty() {
                    ui.label(egui::RichText::new("（まだ出力はありません）").weak());
                }
                for line in &self.output {
                    ui.monospace(line);
                }
            });
    }

    fn check(&mut self) {
        let module = parse_module(&self.source, "Module1");
        match module {
            Ok(m) => {
                let names: Vec<String> = m
                    .procs
                    .iter()
                    .map(|p| {
                        let kind = if p.kind == poc_vba::ProcKind::Sub {
                            "Sub"
                        } else {
                            "Function"
                        };
                        format!("{kind} {}", p.name)
                    })
                    .collect();
                self.status = Some((
                    true,
                    format!(
                        "構文 OK — {} 個のプロシージャ: {}",
                        names.len(),
                        names.join(", ")
                    ),
                ));
            }
            Err(e) => {
                self.status = Some((
                    false,
                    format!(
                        "構文エラー: {} ({} 行目)",
                        e.message,
                        e.line.map(|l| l.to_string()).unwrap_or_else(|| "?".into())
                    ),
                ));
            }
        }
    }

    fn run(&mut self) {
        self.output.clear();
        let module = match parse_module(&self.source, "Module1") {
            Ok(m) => m,
            Err(e) => {
                self.status = Some((
                    false,
                    format!(
                        "構文エラー: {} ({} 行目)",
                        e.message,
                        e.line.map(|l| l.to_string()).unwrap_or_else(|| "?".into())
                    ),
                ));
                return;
            }
        };
        let call = module
            .procs
            .iter()
            .find(|p| p.kind == poc_vba::ProcKind::Sub && p.is_public)
            .or_else(|| module.procs.first())
            .map(|p| p.name.clone())
            .unwrap_or_else(|| "Main".into());

        let mut wb = if self.book.trim().is_empty() {
            sample_book()
        } else {
            match Workbook::open(PathBuf::from(self.book.trim())) {
                Ok(wb) => wb,
                Err(e) => {
                    self.status = Some((false, format!("ブックを開けません: {e}")));
                    return;
                }
            }
        };

        let started = std::time::Instant::now();
        let args: Vec<VbaValue> = Vec::new();
        let outcome = {
            let mut host = ExcelHost::new(&mut wb);
            let mut engine = Engine::new(&module, &mut host);
            let result = engine.run(&call, args);
            for line in &host.printed {
                self.output.push(format!("[Debug] {line}"));
            }
            result
        };

        match outcome {
            Ok(outcome) => {
                for message in &outcome.messages {
                    self.output.push(format!("[MsgBox] {message}"));
                }
                for warning in &outcome.warnings {
                    self.output.push(format!("[警告] {warning}"));
                }
                if !matches!(outcome.return_value, VbaValue::Empty) {
                    self.output
                        .push(format!("[戻り値] {}", outcome.return_value.as_str()));
                }
                self.status = Some((
                    true,
                    format!(
                        "{call} を実行しました — {} ステップ / {:.2} ms",
                        outcome.steps,
                        started.elapsed().as_secs_f64() * 1000.0
                    ),
                ));
            }
            Err(e) => {
                let line = e.line.map(|l| format!(" ({l} 行目)")).unwrap_or_default();
                self.status = Some((false, format!("実行時エラー: {}{line}", e.message)));
            }
        }
    }
}

/// `--selftest` から呼ぶ、画面なしのマクロ実行。
/// 戻り値は (成否, 説明)。設定画面の「実行」と同じ経路を通る。
pub fn selftest_run() -> (bool, String) {
    const SRC: &str = r#"Sub Main()
    Dim total As Long
    Dim i As Long
    total = 0
    For i = 1 To 5
        total = total + i * 10
    Next i
    Debug.Print "total=" & total
End Sub
"#;
    let module = match parse_module(SRC, "Module1") {
        Ok(m) => m,
        Err(e) => return (false, format!("構文エラー: {}", e.message)),
    };
    let call = module
        .procs
        .iter()
        .find(|p| p.kind == poc_vba::ProcKind::Sub)
        .map(|p| p.name.clone())
        .unwrap_or_else(|| "Main".into());
    let mut wb = sample_book();
    let started = std::time::Instant::now();
    let (outcome, printed) = {
        let mut host = ExcelHost::new(&mut wb);
        let mut engine = Engine::new(&module, &mut host);
        let result = engine.run(&call, Vec::new());
        let printed = host.printed.clone();
        (result, printed)
    };
    match outcome {
        Ok(o) => {
            let ok = printed.iter().any(|l| l.contains("total=150"));
            (
                ok,
                format!(
                    "{} ステップ / {:.2} ms / 出力 {}",
                    o.steps,
                    started.elapsed().as_secs_f64() * 1000.0,
                    if printed.is_empty() {
                        "なし".to_string()
                    } else {
                        printed.join(" ")
                    }
                ),
            )
        }
        Err(e) => (false, format!("実行時エラー: {}", e.message)),
    }
}

/// ブック未指定のときの実行用サンプル。
fn sample_book() -> Workbook {
    use poc_core::xlsx::{Cell, Sheet};
    let mut wb = Workbook::new();
    wb.sheets.clear();
    let mut sheet = Sheet::new("売上");
    sheet.set(0, 0, Cell::text("月"));
    sheet.set(0, 1, Cell::text("売上"));
    for (i, (m, v)) in [
        ("4月", 1_200_000.0),
        ("5月", 900_000.0),
        ("6月", 1_500_000.0),
    ]
    .iter()
    .enumerate()
    {
        sheet.set(i as u32 + 1, 0, Cell::text(*m));
        sheet.set(i as u32 + 1, 1, Cell::num(*v));
    }
    wb.sheets.push(sheet);
    wb
}
