// Desktop shell (Tauri v2) — Windows / macOS / Linux.
//
// This file is deliberately tiny: each command is a one-line adapter that
// forwards to `poc-bridge`, which is compiled and unit-tested on every platform
// without needing WebView2 / WKWebView / WebKitGTK. No document logic lives
// here, so the CLI, the GUI and the tests can never diverge.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
#![forbid(unsafe_code)]

use serde_json::Value;

#[tauri::command]
fn app_info() -> Value {
    poc_bridge::app_info(env!("CARGO_PKG_VERSION"))
}

#[tauri::command]
fn open_document(path: String) -> Result<Value, String> {
    poc_bridge::open_document(path)
}

#[tauri::command]
fn save_workbook(path: String, payload: Value) -> Result<Value, String> {
    poc_bridge::save_workbook(path, payload)
}

#[tauri::command]
fn save_document(path: String, payload: Value) -> Result<Value, String> {
    poc_bridge::save_document(path, payload)
}

#[tauri::command]
fn save_presentation(path: String, payload: Value) -> Result<Value, String> {
    poc_bridge::save_presentation(path, payload)
}

#[tauri::command]
fn recalculate(payload: Value) -> Result<Value, String> {
    poc_bridge::recalculate(payload)
}

#[tauri::command]
fn run_macro(path: String, source: String, proc_name: String) -> Result<Value, String> {
    poc_bridge::run_macro(path, source, proc_name)
}

#[tauri::command]
fn macro_procedures(source: String) -> Result<Value, String> {
    poc_bridge::macro_procedures(source)
}

#[tauri::command]
fn check_macro(source: String) -> Result<Value, String> {
    poc_bridge::check_macro(source)
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            app_info,
            open_document,
            save_workbook,
            save_document,
            save_presentation,
            recalculate,
            run_macro,
            macro_procedures,
            check_macro
        ])
        .run(tauri::generate_context!())
        .expect("Poccham Office Next の起動に失敗しました");
}
