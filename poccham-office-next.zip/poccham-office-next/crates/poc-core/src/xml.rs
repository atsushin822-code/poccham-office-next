//! Minimal, allocation-conscious XML support.
//!
//! Writers build XML by appending to a `String` (no DOM, no tree, no
//! per-node allocation) and readers are a hand written pull parser that
//! understands exactly the subset of XML that OOXML/ODF packages contain:
//! elements, attributes, text with entity references, CDATA, comments,
//! processing instructions and the DOCTYPE declaration.

/// XML declaration used by every part we emit.
pub const DECL: &str = r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"#;

/// Escape text content (and attribute values — the same five characters
/// need escaping in both positions for our purposes).
#[inline]
pub fn esc(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 8);
    esc_into(&mut out, s);
    out
}

/// Append escaped text to `out`.
pub fn esc_into(out: &mut String, s: &str) {
    for c in s.chars() {
        match c {
            '&' => out.push_str("&amp;"),
            '<' => out.push_str("&lt;"),
            '>' => out.push_str("&gt;"),
            '"' => out.push_str("&quot;"),
            '\'' => out.push_str("&apos;"),
            // Control characters are illegal in XML 1.0; OOXML files that
            // contain them are unreadable by every consumer, so drop them.
            c if (c as u32) < 0x20 && c != '\t' && c != '\n' && c != '\r' => {}
            c => out.push(c),
        }
    }
}

/// Append `<name attr="v" ...>` or the self-closing form.
pub fn open_tag(out: &mut String, name: &str, attrs: &[(&str, &str)], self_closing: bool) {
    out.push('<');
    out.push_str(name);
    for (k, v) in attrs {
        out.push(' ');
        out.push_str(k);
        out.push_str("=\"");
        esc_into(out, v);
        out.push('"');
    }
    if self_closing {
        out.push_str("/>");
    } else {
        out.push('>');
    }
}

/// Append `</name>`.
pub fn close_tag(out: &mut String, name: &str) {
    out.push_str("</");
    out.push_str(name);
    out.push('>');
}

/// Append `<name ...>text</name>`.
pub fn text_tag(out: &mut String, name: &str, attrs: &[(&str, &str)], text: &str) {
    open_tag(out, name, attrs, false);
    esc_into(out, text);
    close_tag(out, name);
}

/// Strip a namespace prefix: `w:p` -> `p`.
#[inline]
pub fn local(name: &str) -> &str {
    match name.rfind(':') {
        Some(i) => &name[i + 1..],
        None => name,
    }
}

/// Decode the predefined XML entities plus numeric character references.
pub fn unescape(s: &str) -> String {
    if !s.contains('&') {
        return s.to_string();
    }
    let mut out = String::with_capacity(s.len());
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'&' {
            if let Some(semi) = s[i..].find(';') {
                let ent = &s[i + 1..i + semi];
                let rep = match ent {
                    "amp" => Some('&'),
                    "lt" => Some('<'),
                    "gt" => Some('>'),
                    "quot" => Some('"'),
                    "apos" => Some('\''),
                    _ => {
                        if let Some(hex) = ent.strip_prefix("#x").or_else(|| ent.strip_prefix("#X"))
                        {
                            u32::from_str_radix(hex, 16).ok().and_then(char::from_u32)
                        } else {
                            ent.strip_prefix('#')
                                .and_then(|d| d.parse::<u32>().ok())
                                .and_then(char::from_u32)
                        }
                    }
                };
                if let Some(c) = rep {
                    out.push(c);
                    i += semi + 1;
                    continue;
                }
            }
        }
        // Copy one whole UTF-8 scalar.
        let ch = s[i..].chars().next().unwrap();
        out.push(ch);
        i += ch.len_utf8();
    }
    out
}

/// One pull-parser event.
#[derive(Debug, Clone, PartialEq)]
pub enum Event {
    Start {
        name: String,
        attrs: Vec<(String, String)>,
        self_closing: bool,
    },
    End {
        name: String,
    },
    Text(String),
    Eof,
}

impl Event {
    /// Attribute lookup on a `Start` event (namespace-prefix agnostic).
    pub fn attr(&self, key: &str) -> Option<&str> {
        match self {
            Event::Start { attrs, .. } => attrs
                .iter()
                .find(|(k, _)| k == key || local(k) == key)
                .map(|(_, v)| v.as_str()),
            _ => None,
        }
    }

    /// Local element name without namespace prefix.
    pub fn name(&self) -> Option<&str> {
        match self {
            Event::Start { name, .. } | Event::End { name } => Some(local(name)),
            _ => None,
        }
    }
}

/// Hand written XML pull parser.
pub struct Reader<'a> {
    src: &'a str,
    pos: usize,
}

impl<'a> Reader<'a> {
    pub fn new(src: &'a str) -> Self {
        Reader { src, pos: 0 }
    }

    /// Byte offset of the cursor (handy for debugging).
    pub fn offset(&self) -> usize {
        self.pos
    }

    fn rest(&self) -> &'a str {
        &self.src[self.pos..]
    }

    fn skip_ws(&mut self) {
        while let Some(c) = self.rest().chars().next() {
            if c.is_whitespace() {
                self.pos += c.len_utf8();
            } else {
                break;
            }
        }
    }

    /// Consume a `<?...?>`, `<!--...-->`, `<![CDATA[...]]>` or `<!DOCTYPE ...>`.
    fn skip_misc(&mut self) -> Option<Event> {
        let rest = self.rest();
        if let Some(body) = rest.strip_prefix("<?") {
            if let Some(end) = body.find("?>") {
                self.pos += 2 + end + 2;
                return Some(Event::Text(String::new())); // ignored
            }
        }
        if let Some(body) = rest.strip_prefix("<!--") {
            if let Some(end) = body.find("-->") {
                self.pos += 4 + end + 3;
                return Some(Event::Text(String::new()));
            }
        }
        if let Some(body) = rest.strip_prefix("<![CDATA[") {
            if let Some(end) = body.find("]]>") {
                let text = body[..end].to_string();
                self.pos += 9 + end + 3;
                return Some(Event::Text(text));
            }
        }
        if let Some(body) = rest.strip_prefix("<!") {
            // DOCTYPE or similar: skip to matching '>' honouring one level of [ ].
            let mut depth = 0i32;
            for (i, c) in body.char_indices() {
                match c {
                    '[' => depth += 1,
                    ']' => depth -= 1,
                    '>' if depth <= 0 => {
                        self.pos += 2 + i + 1;
                        return Some(Event::Text(String::new()));
                    }
                    _ => {}
                }
            }
        }
        None
    }

    /// Next meaningful event.
    pub fn next_event(&mut self) -> Event {
        loop {
            if self.pos >= self.src.len() {
                return Event::Eof;
            }
            let rest = self.rest();
            if let Some(lt) = rest.find('<') {
                if lt > 0 {
                    let text = &rest[..lt];
                    self.pos += lt;
                    return Event::Text(unescape(text));
                }
            } else {
                let text = rest;
                self.pos = self.src.len();
                return Event::Text(unescape(text));
            }
            // We are at '<'.
            if let Some(ev) = self.skip_misc() {
                match ev {
                    Event::Text(s) if s.is_empty() => continue,
                    other => return other,
                }
            }
            return self.read_tag();
        }
    }

    fn read_tag(&mut self) -> Event {
        // self.src[self.pos] == '<'
        self.pos += 1;
        let closing = self.rest().starts_with('/');
        if closing {
            self.pos += 1;
        }
        let mut name = String::new();
        for c in self.rest().chars() {
            if c.is_whitespace() || c == '>' || c == '/' {
                break;
            }
            name.push(c);
            self.pos += c.len_utf8();
        }
        let mut attrs = Vec::new();
        let mut self_closing = false;
        loop {
            self.skip_ws();
            let rest = self.rest();
            if rest.is_empty() {
                break;
            }
            if rest.starts_with("/>") {
                self.pos += 2;
                self_closing = true;
                break;
            }
            if rest.starts_with('>') {
                self.pos += 1;
                break;
            }
            // attribute name
            let mut aname = String::new();
            for c in self.rest().chars() {
                if c == '=' || c.is_whitespace() {
                    break;
                }
                aname.push(c);
                self.pos += c.len_utf8();
            }
            self.skip_ws();
            if self.rest().starts_with('=') {
                self.pos += 1;
                self.skip_ws();
                let quote = self.rest().chars().next().unwrap_or('"');
                if quote == '"' || quote == '\'' {
                    self.pos += 1;
                    if let Some(end) = self.rest().find(quote) {
                        let raw = &self.rest()[..end];
                        attrs.push((aname, unescape(raw)));
                        self.pos += end + 1;
                        continue;
                    }
                }
            }
            if aname.is_empty() {
                // Malformed: consume one char to guarantee progress.
                if let Some(c) = self.rest().chars().next() {
                    self.pos += c.len_utf8();
                }
            } else {
                attrs.push((aname, String::new()));
            }
        }
        if closing {
            Event::End { name }
        } else {
            Event::Start {
                name,
                attrs,
                self_closing,
            }
        }
    }

    /// Read text content of the element that has just been opened, up to and
    /// including its end tag.
    pub fn read_text(&mut self) -> String {
        let mut out = String::new();
        let mut depth = 1usize;
        loop {
            match self.next_event() {
                Event::Text(t) => out.push_str(&t),
                Event::Start { self_closing, .. } => {
                    if !self_closing {
                        depth += 1
                    }
                }
                Event::End { .. } => {
                    depth -= 1;
                    if depth == 0 {
                        return out;
                    }
                }
                Event::Eof => return out,
            }
        }
    }

    /// Skip the element that has just been opened (including nested content).
    pub fn skip_element(&mut self) {
        let mut depth = 1usize;
        loop {
            match self.next_event() {
                Event::Start { self_closing, .. } => {
                    if !self_closing {
                        depth += 1
                    }
                }
                Event::End { .. } => {
                    depth -= 1;
                    if depth == 0 {
                        return;
                    }
                }
                Event::Eof => return,
                _ => {}
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn escapes_roundtrip() {
        let raw = "a<b&c\"d'e";
        assert_eq!(unescape(&esc(raw)), raw);
        assert_eq!(unescape("&#65;&#x42;"), "AB");
        assert_eq!(esc("\u{1}keep\ttab"), "keep\ttab");
    }

    #[test]
    fn parses_nested_document() {
        let src = r#"<?xml version="1.0"?>
<!-- comment -->
<root xmlns:w="urn:w">
  <w:p a="1" b='x&amp;y'><w:t>Héllo &lt;wörld&gt;</w:t></w:p>
  <empty/>
  <![CDATA[raw <stuff>]]>
</root>"#;
        let mut r = Reader::new(src);
        let mut text = String::new();
        let mut started = 0;
        loop {
            match r.next_event() {
                Event::Start { name, .. } => {
                    started += 1;
                    if local(&name) == "t" {
                        text.push_str(&r.read_text());
                    }
                }
                Event::Text(t) => text.push_str(&t),
                Event::Eof => break,
                _ => {}
            }
        }
        assert_eq!(started, 4); // root, w:p, w:t, empty (the CDATA section is text)
        assert!(text.contains("Héllo <wörld>"), "{text}");
        assert!(text.contains("raw <stuff>"), "{text}");
    }

    #[test]
    fn attributes_are_unescaped() {
        let mut r = Reader::new(r#"<c r="A1" s="2" t="s"/>"#);
        match r.next_event() {
            Event::Start {
                attrs,
                self_closing,
                ..
            } => {
                assert!(self_closing);
                assert_eq!(attrs.len(), 3);
            }
            other => panic!("unexpected {other:?}"),
        }
    }
}
