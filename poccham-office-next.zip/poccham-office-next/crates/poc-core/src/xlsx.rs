//! Spreadsheet engine: `.xlsx` (SpreadsheetML) reader/writer plus `.ods` and
//! `.csv` export.
//!
//! The writer emits the parts strictly in the order required by ECMA-376
//! (dimension → sheetViews → cols → sheetData → autoFilter → pageMargins) and
//! puts shared strings where every consumer expects them.  The reader accepts
//! both shared-string and inline-string cells, formulas with or without cached
//! values, boolean cells and error cells.

use std::collections::HashMap;
use std::fmt::Write as _;

use crate::error::{Error, Result};
use crate::pkg::{self, Package};
use crate::style::{Rgb, StyleSheet};
use crate::xlparts;
use crate::xml::{self, Event, Reader};

const NS_MAIN: &str = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
const NS_R: &str = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const CT_SHEET: &str = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml";
const CT_WORKSHEET: &str =
    "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml";
const CT_STYLES: &str = "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml";
const CT_SHARED: &str =
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml";
const RT_SHEET: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet";
const RT_STYLES: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles";
const RT_SHARED: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings";

/// An xlsx cell being assembled by the streaming reader:
/// `(row, col, type attribute, style index, value, formula)`.
type PendingCell = (u32, u32, String, u16, Option<String>, Option<String>);

/// Excel's limits, used for validation.
pub const MAX_ROWS: u32 = 1_048_576;
pub const MAX_COLS: u32 = 16_384;

/// `cellXfs` indices that the writer emits.  Consumers that only understand
/// built-in formats still render these correctly.
pub mod styles {
    pub const NORMAL: u16 = 0;
    pub const BOLD: u16 = 1;
    pub const ITALIC: u16 = 2;
    pub const BOLD_ITALIC: u16 = 3;
    pub const NUMBER_2DP: u16 = 4;
    pub const PERCENT: u16 = 5;
    pub const DATE: u16 = 6;
    pub const WRAP: u16 = 7;
    pub const HEADER: u16 = 8;
    pub const CURRENCY: u16 = 9;
}

/// The value held by a cell.
#[derive(Debug, Clone, PartialEq, Default)]
pub enum CellValue {
    #[default]
    Empty,
    Number(f64),
    Text(String),
    Bool(bool),
    /// Formula with an optional cached result (what a suite stores so that
    /// non-calculating viewers still show a number).
    Formula {
        expr: String,
        cached: Option<f64>,
        /// Cached string result (`t="str"` cells), e.g. `=UPPER(A1)`.
        text: Option<String>,
    },
    /// `#DIV/0!` and friends, preserved verbatim.
    Error(String),
}

/// A cell: a value plus a `cellXfs` style index.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Cell {
    pub value: CellValue,
    pub style: u16,
}

impl Cell {
    pub fn empty() -> Self {
        Cell::default()
    }
    pub fn num(n: impl Into<f64>) -> Self {
        Cell {
            value: CellValue::Number(n.into()),
            style: 0,
        }
    }
    pub fn text(s: impl Into<String>) -> Self {
        Cell {
            value: CellValue::Text(s.into()),
            style: 0,
        }
    }
    pub fn boolean(b: bool) -> Self {
        Cell {
            value: CellValue::Bool(b),
            style: 0,
        }
    }
    pub fn formula(expr: impl Into<String>, cached: Option<f64>) -> Self {
        Cell {
            value: CellValue::Formula {
                expr: expr.into(),
                cached,
                text: None,
            },
            style: 0,
        }
    }

    /// Formula with a cached *string* result.
    pub fn formula_text(expr: impl Into<String>, text: impl Into<String>) -> Self {
        Cell {
            value: CellValue::Formula {
                expr: expr.into(),
                cached: None,
                text: Some(text.into()),
            },
            style: 0,
        }
    }
    pub fn styled(mut self, style: u16) -> Self {
        self.style = style;
        self
    }

    pub fn is_empty(&self) -> bool {
        matches!(self.value, CellValue::Empty)
    }

    /// Numeric view of the cell (cached formula results included).
    pub fn as_number(&self) -> Option<f64> {
        match &self.value {
            CellValue::Number(n) => Some(*n),
            CellValue::Bool(b) => Some(if *b { 1.0 } else { 0.0 }),
            CellValue::Formula { cached, text, .. } => {
                cached.or_else(|| text.as_ref().and_then(|t| t.trim().parse().ok()))
            }
            CellValue::Text(t) => t.trim().parse().ok(),
            _ => None,
        }
    }

    /// Display text, following Excel's `General` formatting closely enough.
    pub fn as_text(&self) -> String {
        match &self.value {
            CellValue::Empty => String::new(),
            CellValue::Text(t) => t.clone(),
            CellValue::Bool(b) => {
                if *b {
                    "TRUE".into()
                } else {
                    "FALSE".into()
                }
            }
            CellValue::Number(n) => format_number(*n),
            CellValue::Formula { expr, cached, text } => match (cached, text) {
                (Some(n), _) => format_number(*n),
                (None, Some(t)) => t.clone(),
                (None, None) => format!("={expr}"),
            },
            CellValue::Error(e) => e.clone(),
        }
    }
}

/// Excel-like `General` number rendering: shortest round-trip form.
///
/// 表示用なので、浮動小数の計算誤差 (`=D5*1.1` が 512160.00000000006 になる等) は
/// 1e-9 の桁で丸めてから整形する。値そのものを書き出すときは
/// [`format_number_exact`] を使う。
pub fn format_number(n: f64) -> String {
    if !n.is_finite() {
        return if n.is_nan() {
            "#NUM!".to_string()
        } else if n > 0.0 {
            "∞".to_string()
        } else {
            "-∞".to_string()
        };
    }
    let rounded = if n.abs() < 1e15 {
        (n * 1e9).round() / 1e9
    } else {
        n
    };
    format_number_exact(rounded)
}

/// Shortest round-trip rendering, no display rounding — used when writing
/// values out so that stored precision is preserved bit-for-bit.
pub fn format_number_exact(n: f64) -> String {
    if n == n.trunc() && n.abs() < 1e15 {
        format!("{}", n as i64)
    } else {
        let mut s = format!("{n}");
        if s.contains('e') && s.len() > 12 {
            s = format!("{n:.10}");
            while s.ends_with('0') {
                s.pop();
            }
            if s.ends_with('.') {
                s.pop();
            }
        }
        s
    }
}

/// One worksheet.
#[derive(Debug, Clone, Default)]
pub struct Sheet {
    pub name: String,
    /// Row-major storage; `rows[r][c]`.
    pub rows: Vec<Vec<Cell>>,
    /// Column widths in Excel character units (`None` = default).
    pub col_widths: Vec<Option<f32>>,
    /// Frozen panes as (rows, cols).
    pub freeze: Option<(u32, u32)>,
    /// AutoFilter range, e.g. `A1:D20`.
    pub autofilter: Option<String>,
    /// Merged ranges.
    pub merges: Vec<Merge>,
    /// Height of individual rows in points.
    pub row_heights: Vec<Option<f32>>,
    /// Conditional-formatting rules.
    pub cf: Vec<ConditionalFormat>,
    /// Data-validation rules (「データの入力規則」).
    pub validations: Vec<DataValidation>,
    /// Cell notes.
    pub comments: Vec<CellComment>,
    /// Pictures anchored to cells.
    pub images: Vec<Image>,
    /// Embedded charts.
    pub charts: Vec<Chart>,
    /// Pivot tables summarising data on this (or another) sheet.
    pub pivots: Vec<PivotTable>,
    /// Cell hyperlinks.
    pub links: Vec<CellLink>,
}

impl Sheet {
    pub fn new(name: impl Into<String>) -> Self {
        Sheet {
            name: name.into(),
            rows: Vec::new(),
            col_widths: Vec::new(),
            freeze: None,
            autofilter: None,
            merges: Vec::new(),
            row_heights: Vec::new(),
            cf: Vec::new(),
            validations: Vec::new(),
            comments: Vec::new(),
            images: Vec::new(),
            charts: Vec::new(),
            pivots: Vec::new(),
            links: Vec::new(),
        }
    }

    pub fn row_count(&self) -> u32 {
        self.rows.len() as u32
    }

    pub fn col_count(&self) -> u32 {
        self.rows.iter().map(|r| r.len()).max().unwrap_or(0) as u32
    }

    pub fn get(&self, row: u32, col: u32) -> Option<&Cell> {
        self.rows.get(row as usize)?.get(col as usize)
    }

    /// Grow the sheet so that `(row, col)` exists, then return a mutable cell.
    pub fn cell_mut(&mut self, row: u32, col: u32) -> &mut Cell {
        let r = row as usize;
        if self.rows.len() <= r {
            self.rows.resize_with(r + 1, Vec::new);
        }
        let row_vec = &mut self.rows[r];
        if row_vec.len() <= col as usize {
            row_vec.resize_with(col as usize + 1, Cell::default);
        }
        &mut row_vec[col as usize]
    }

    pub fn set(&mut self, row: u32, col: u32, cell: Cell) {
        *self.cell_mut(row, col) = cell;
    }

    /// Set by A1 address (`"B3"`).
    pub fn set_a1(&mut self, addr: &str, cell: Cell) -> Result<()> {
        let (r, c) =
            parse_ref(addr).ok_or_else(|| Error::Format(format!("bad cell address: {addr:?}")))?;
        self.set(r, c, cell);
        Ok(())
    }

    pub fn get_a1(&self, addr: &str) -> Option<&Cell> {
        let (r, c) = parse_ref(addr)?;
        self.get(r, c)
    }

    /// Append a row of values (accepts anything convertible into a `Cell`).
    pub fn push_row(&mut self, values: impl IntoIterator<Item = Cell>) {
        self.rows.push(values.into_iter().collect());
    }

    /// Trim trailing empty rows/cells so that small documents stay small.
    pub fn trim(&mut self) {
        while matches!(self.rows.last(), Some(r) if r.iter().all(|c| c.is_empty())) {
            self.rows.pop();
        }
        for row in &mut self.rows {
            while matches!(row.last(), Some(c) if c.is_empty()) {
                row.pop();
            }
        }
    }
}

/// A merged cell range (`A1:B2`). Only the top-left cell keeps its value;
/// the others are covered by the merge in every viewer.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Merge {
    pub r1: u32,
    pub c1: u32,
    pub r2: u32,
    pub c2: u32,
}

impl Merge {
    pub fn new(r1: u32, c1: u32, r2: u32, c2: u32) -> Self {
        Merge {
            r1: r1.min(r2),
            c1: c1.min(c2),
            r2: r1.max(r2),
            c2: c1.max(c2),
        }
    }

    /// Parse an A1-style range. A single cell is a one-cell merge.
    pub fn parse(text: &str) -> Option<Self> {
        let (r1, c1, r2, c2) = parse_range(text)?;
        Some(Merge::new(r1, c1, r2, c2))
    }

    pub fn to_a1(self) -> String {
        format!(
            "{}{}:{}{}",
            col_letters(self.c1),
            self.r1 + 1,
            col_letters(self.c2),
            self.r2 + 1
        )
    }

    pub fn contains(&self, row: u32, col: u32) -> bool {
        row >= self.r1 && row <= self.r2 && col >= self.c1 && col <= self.c2
    }
}

/// Comparison used by `cellIs` conditional formats.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CfOp {
    GreaterThan,
    LessThan,
    GreaterThanOrEqual,
    LessThanOrEqual,
    Equal,
    NotEqual,
    Between,
    NotBetween,
}

/// What a conditional-format rule tests.
#[derive(Debug, Clone, PartialEq)]
pub enum CfKind {
    /// `A1 > 100` style comparisons.
    CellIs { op: CfOp, formula: String },
    /// Any formula that evaluates to TRUE.
    Expression(String),
    /// `text contains` (implemented as a `SEARCH` expression).
    ContainsText(String),
    /// The top (or bottom) `rank` values of a range.
    Top10 {
        rank: u32,
        percent: bool,
        bottom: bool,
    },
    /// In-cell bar (this is what "データ バー" inserts).
    DataBar { color: Rgb },
    /// Three-colour scale from `min` through `mid` to `max`.
    ColorScale {
        min: Rgb,
        mid: Option<Rgb>,
        max: Rgb,
    },
    /// Icon set such as `3TrafficLights1`.
    IconSet { name: String },
}

/// One conditional-formatting rule bound to a range.
#[derive(Debug, Clone, PartialEq)]
pub struct ConditionalFormat {
    pub range: String,
    pub kind: CfKind,
    /// Index into [`StyleSheet::dxfs`].
    pub dxf: u16,
    pub priority: u32,
}

impl ConditionalFormat {
    /// `range > value` → red fill, the canonical "highlight high values" rule.
    pub fn greater_than(range: impl Into<String>, value: f64, dxf: u16) -> Self {
        ConditionalFormat {
            range: range.into(),
            kind: CfKind::CellIs {
                op: CfOp::GreaterThan,
                formula: format!("{value}"),
            },
            dxf,
            priority: 1,
        }
    }

    pub fn data_bar(range: impl Into<String>, color: Rgb) -> Self {
        ConditionalFormat {
            range: range.into(),
            kind: CfKind::DataBar { color },
            dxf: 0,
            priority: 1,
        }
    }

    pub fn color_scale(range: impl Into<String>) -> Self {
        ConditionalFormat {
            range: range.into(),
            kind: CfKind::ColorScale {
                min: Rgb(0xF8, 0x69, 0x6B),
                mid: Some(Rgb(0xFF, 0xEB, 0x84)),
                max: Rgb(0x63, 0xBE, 0x7B),
            },
            dxf: 0,
            priority: 1,
        }
    }

    pub fn top10(range: impl Into<String>, rank: u32, dxf: u16) -> Self {
        ConditionalFormat {
            range: range.into(),
            kind: CfKind::Top10 {
                rank,
                percent: false,
                bottom: false,
            },
            dxf,
            priority: 1,
        }
    }
}

/// What a data-validation rule accepts.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ValidationKind {
    Any,
    Whole,
    Decimal,
    List,
    Date,
    Time,
    TextLength,
    Custom,
}

impl ValidationKind {
    pub fn as_str(self) -> &'static str {
        match self {
            ValidationKind::Any => "none",
            ValidationKind::Whole => "whole",
            ValidationKind::Decimal => "decimal",
            ValidationKind::List => "list",
            ValidationKind::Date => "date",
            ValidationKind::Time => "time",
            ValidationKind::TextLength => "textLength",
            ValidationKind::Custom => "custom",
        }
    }
    pub fn parse(s: &str) -> Self {
        match s {
            "whole" => ValidationKind::Whole,
            "decimal" => ValidationKind::Decimal,
            "list" => ValidationKind::List,
            "date" => ValidationKind::Date,
            "time" => ValidationKind::Time,
            "textLength" => ValidationKind::TextLength,
            "custom" => ValidationKind::Custom,
            _ => ValidationKind::Any,
        }
    }
}

/// 「データの入力規則」 — validation of what a user may type into a range.
#[derive(Debug, Clone, PartialEq)]
pub struct DataValidation {
    pub range: String,
    pub kind: ValidationKind,
    pub op: Option<String>,
    pub formula: Option<String>,
    pub allow_blank: bool,
    pub message: String,
    pub error: String,
}

impl DataValidation {
    /// A drop-down list from a comma separated string or a range reference.
    pub fn list(range: impl Into<String>, source: &str) -> Self {
        let formula = if source.contains(',') {
            format!("\"{source}\"")
        } else {
            source.to_string()
        };
        DataValidation {
            range: range.into(),
            kind: ValidationKind::List,
            op: None,
            formula: Some(formula),
            allow_blank: true,
            message: String::new(),
            error: "入力値が正しくありません".into(),
        }
    }

    pub fn whole_between(range: impl Into<String>, min: f64, max: f64) -> Self {
        DataValidation {
            range: range.into(),
            kind: ValidationKind::Whole,
            op: Some("between".into()),
            formula: Some(format!("{min},{max}")),
            allow_blank: true,
            message: String::new(),
            error: "整数を入力してください".into(),
        }
    }
}

/// A hyperlink attached to a cell (「リンクの挿入」).
#[derive(Debug, Clone, PartialEq)]
pub struct CellLink {
    pub row: u32,
    pub col: u32,
    /// URL, `mailto:` または `#シート!A1` 形式の内部リンク。
    pub url: String,
}

impl CellLink {
    pub fn new(row: u32, col: u32, url: impl Into<String>) -> Self {
        CellLink {
            row,
            col,
            url: url.into(),
        }
    }
}

/// A note attached to a cell.
#[derive(Debug, Clone, PartialEq)]
pub struct CellComment {
    pub row: u32,
    pub col: u32,
    pub author: String,
    pub text: String,
}

impl CellComment {
    pub fn new(row: u32, col: u32, author: impl Into<String>, text: impl Into<String>) -> Self {
        CellComment {
            row,
            col,
            author: author.into(),
            text: text.into(),
        }
    }
}

/// A picture anchored to a cell. The bytes are stored so that saving writes
/// the media part back verbatim (no re-encoding, no quality loss).
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Image {
    pub data: Vec<u8>,
    /// `png` or `jpeg`.
    pub ext: String,
    pub col: u32,
    pub row: u32,
    pub width_px: u32,
    pub height_px: u32,
    pub name: String,
}

impl Image {
    pub fn new(data: Vec<u8>, col: u32, row: u32, width_px: u32, height_px: u32) -> Self {
        let ext = if data.starts_with(b"\x89PNG") {
            "png"
        } else if data.starts_with(&[0xFF, 0xD8]) {
            "jpeg"
        } else {
            "png"
        };
        Image {
            data,
            ext: ext.into(),
            col,
            row,
            width_px,
            height_px,
            name: String::new(),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ChartKind {
    Bar,
    Line,
    Pie,
    Area,
}

#[derive(Debug, Clone, PartialEq)]
pub struct ChartSeries {
    pub name: String,
    /// `(r1, c1, r2, c2)` of the values on [`Chart::sheet`].
    pub values: (u32, u32, u32, u32),
}

impl ChartSeries {
    pub fn new(name: impl Into<String>, r1: u32, c1: u32, r2: u32, c2: u32) -> Self {
        ChartSeries {
            name: name.into(),
            values: (r1.min(r2), c1.min(c2), r1.max(r2), c1.max(c2)),
        }
    }
}

/// A chart embedded in a worksheet.
#[derive(Debug, Clone, PartialEq)]
pub struct Chart {
    pub kind: ChartKind,
    pub title: String,
    pub sheet: usize,
    pub categories: Option<(u32, u32, u32, u32)>,
    pub series: Vec<ChartSeries>,
    pub legend: bool,
}

impl Chart {
    pub fn new(kind: ChartKind, title: impl Into<String>, sheet: usize) -> Self {
        Chart {
            kind,
            title: title.into(),
            sheet,
            categories: None,
            series: Vec::new(),
            legend: true,
        }
    }

    pub fn with_categories(mut self, r1: u32, c1: u32, r2: u32, c2: u32) -> Self {
        self.categories = Some((r1, c1, r2, c2));
        self
    }

    pub fn with_series(mut self, series: ChartSeries) -> Self {
        self.series.push(series);
        self
    }
}

/// Where a pivot table's data comes from.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PivotSource {
    pub sheet: usize,
    pub range: (u32, u32, u32, u32),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PivotAgg {
    Sum,
    Count,
    Average,
    Max,
    Min,
}

/// A pivot table: rows, columns and aggregated values, computed at write time
/// and stored together with its cache so Excel can refresh it.
#[derive(Debug, Clone, PartialEq)]
pub struct PivotTable {
    pub name: String,
    pub source: PivotSource,
    /// Top-left cell of the summary on the target sheet.
    pub target: (u32, u32),
    /// Source column indices used as row fields.
    pub rows: Vec<u32>,
    /// Source column indices used as column fields.
    pub cols: Vec<u32>,
    /// `(source column, aggregation)` for each value field.
    pub values: Vec<(u32, PivotAgg)>,
}

impl PivotTable {
    pub fn new(name: impl Into<String>, sheet: usize, range: (u32, u32, u32, u32)) -> Self {
        PivotTable {
            name: name.into(),
            source: PivotSource { sheet, range },
            target: (0, 0),
            rows: Vec::new(),
            cols: Vec::new(),
            values: Vec::new(),
        }
    }

    pub fn rows(mut self, cols: &[u32]) -> Self {
        self.rows = cols.to_vec();
        self
    }

    pub fn cols(mut self, cols: &[u32]) -> Self {
        self.cols = cols.to_vec();
        self
    }

    pub fn values(mut self, values: &[(u32, PivotAgg)]) -> Self {
        self.values = values.to_vec();
        self
    }

    pub fn at(mut self, row: u32, col: u32) -> Self {
        self.target = (row, col);
        self
    }
}

/// A workbook.
#[derive(Debug, Clone)]
pub struct Workbook {
    pub sheets: Vec<Sheet>,
    pub title: String,
    pub creator: String,
    /// The workbook-wide style pool (`styles.xml`).
    pub styles: StyleSheet,
    /// RFC-3339 timestamp stamped into the document properties.
    pub created: String,
}

impl Default for Workbook {
    fn default() -> Self {
        Workbook::new()
    }
}

impl Workbook {
    pub fn new() -> Self {
        Workbook {
            sheets: vec![Sheet::new("Sheet1")],
            title: String::new(),
            creator: "Poccham Office Next".into(),
            styles: StyleSheet::with_builtins(),
            created: pkg::now_w3cdtf(),
        }
    }

    pub fn with_sheet_count(n: usize) -> Self {
        let mut wb = Workbook::new();
        wb.sheets.clear();
        for i in 0..n.max(1) {
            wb.sheets.push(Sheet::new(format!("Sheet{}", i + 1)));
        }
        wb
    }

    /// First sheet (panics only if the workbook was built inconsistently).
    pub fn sheet(&self) -> &Sheet {
        &self.sheets[0]
    }

    pub fn sheet_mut(&mut self) -> &mut Sheet {
        &mut self.sheets[0]
    }

    pub fn add_sheet(&mut self, name: impl Into<String>) -> usize {
        self.sheets.push(Sheet::new(name));
        self.sheets.len() - 1
    }

    /// Index of a sheet by (case-insensitive) name.
    pub fn sheet_index(&self, name: &str) -> Option<usize> {
        self.sheets
            .iter()
            .position(|s| s.name.eq_ignore_ascii_case(name))
    }

    pub fn total_cells(&self) -> usize {
        self.sheets
            .iter()
            .map(|s| s.rows.iter().map(|r| r.len()).sum::<usize>())
            .sum()
    }

    // ---- serialisation -------------------------------------------------

    /// Serialise to `.xlsx` bytes.
    pub fn to_bytes(&self) -> Result<Vec<u8>> {
        let mut pkg = Package::new();

        // 1. shared strings (deduplicated, insertion ordered)
        let mut shared: Vec<String> = Vec::new();
        let mut index: HashMap<&str, u32> = HashMap::new();
        let mut ref_count: u32 = 0;
        for sheet in &self.sheets {
            for row in &sheet.rows {
                for cell in row {
                    if let CellValue::Text(t) = &cell.value {
                        ref_count += 1;
                        if !index.contains_key(t.as_str()) {
                            index.insert(t.as_str(), shared.len() as u32);
                            shared.push(t.clone());
                        }
                    }
                }
            }
        }

        // 2. workbook.xml + rels
        let mut wb = String::with_capacity(512);
        wb.push_str(xml::DECL);
        let _ = write!(wb, r#"<workbook xmlns="{NS_MAIN}" xmlns:r="{NS_R}">"#);
        wb.push_str(r#"<fileVersion appName="Poccham Office Next"/>"#);
        wb.push_str("<workbookPr/>");
        wb.push_str(r#"<bookViews><workbookView xWindow="0" yWindow="0" windowWidth="28800" windowHeight="15600"/></bookViews>"#);
        wb.push_str("<sheets>");
        for (i, sheet) in self.sheets.iter().enumerate() {
            let id = format!("rId{}", i + 1);
            let sid = (i + 1).to_string();
            xml::open_tag(
                &mut wb,
                "sheet",
                &[("name", &sheet.name), ("sheetId", &sid), ("r:id", &id)],
                true,
            );
        }
        wb.push_str("</sheets>");
        // Repaired-by-Excel workbooks recalculate; so do we, on load.
        wb.push_str(r#"<calcPr calcId="191029" fullCalcOnLoad="1"/>"#);
        wb.push_str("</workbook>");
        pkg.insert_str("xl/workbook.xml", wb);

        let mut wb_rels: Vec<(String, String, String, bool)> = Vec::new();
        for i in 0..self.sheets.len() {
            wb_rels.push((
                format!("rId{}", i + 1),
                RT_SHEET.to_string(),
                format!("worksheets/sheet{}.xml", i + 1),
                false,
            ));
        }
        let styles_rid = format!("rId{}", self.sheets.len() + 1);
        let shared_rid = format!("rId{}", self.sheets.len() + 2);
        wb_rels.push((
            styles_rid,
            RT_STYLES.to_string(),
            "styles.xml".to_string(),
            false,
        ));
        if !shared.is_empty() {
            wb_rels.push((
                shared_rid,
                RT_SHARED.to_string(),
                "sharedStrings.xml".to_string(),
                false,
            ));
        }
        pkg.insert_str("xl/_rels/workbook.xml.rels", pkg::rels_xml(&wb_rels));

        // 3. worksheets, plus the parts they own: drawings (pictures and
        //    charts), comments (with the legacy VML Excel needs) and pivot
        //    tables with their caches.
        let mut media_no = 0usize;
        let mut chart_no = 0usize;
        let mut extra_overrides: Vec<(String, String)> = Vec::new();
        let mut defaults: Vec<(String, String)> = Vec::new();
        let mut pivot_caches: Vec<(u32, String)> = Vec::new();
        for (i, sheet) in self.sheets.iter().enumerate() {
            let mut sheet_rels: Vec<(String, String, String, bool)> = Vec::new();
            let mut parts = SheetParts::default();

            if !sheet.images.is_empty() || !sheet.charts.is_empty() {
                let d = i + 1;
                let rid = format!("rId{}", sheet_rels.len() + 1);
                parts.drawing_rid = Some(rid.clone());
                sheet_rels.push((
                    rid,
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing"
                        .into(),
                    format!("../drawings/drawing{d}.xml"),
                    false,
                ));
                let mut drawing_rels: Vec<(String, String, String, bool)> = Vec::new();
                let mut pictures = Vec::new();
                let mut drawing_charts = Vec::new();
                for img in &sheet.images {
                    media_no += 1;
                    let target = format!("../media/image{media_no}.{}", img.ext);
                    let prid = format!("rId{}", drawing_rels.len() + 1);
                    drawing_rels.push((
                        prid.clone(),
                        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"
                            .into(),
                        target.clone(),
                        false,
                    ));
                    pkg.insert(
                        &format!("xl/media/image{media_no}.{}", img.ext),
                        img.data.clone(),
                    );
                    let ext = img.ext.clone();
                    let ct = if ext == "jpeg" {
                        "image/jpeg"
                    } else {
                        "image/png"
                    };
                    if !defaults.iter().any(|(e, _)| *e == ext) {
                        defaults.push((ext, ct.into()));
                    }
                    pictures.push(xlparts::Picture {
                        rel_id: prid,
                        col: img.col,
                        row: img.row,
                        width_px: if img.width_px == 0 { 120 } else { img.width_px },
                        height_px: if img.height_px == 0 {
                            90
                        } else {
                            img.height_px
                        },
                        name: if img.name.is_empty() {
                            format!("Picture {media_no}")
                        } else {
                            img.name.clone()
                        },
                    });
                }
                for chart in &sheet.charts {
                    chart_no += 1;
                    let crid = format!("rId{}", drawing_rels.len() + 1);
                    drawing_rels.push((
                        crid.clone(),
                        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart"
                            .into(),
                        format!("../charts/chart{chart_no}.xml"),
                        false,
                    ));
                    pkg.insert_str(
                        &format!("xl/charts/chart{chart_no}.xml"),
                        xlparts::chart_xml(chart, self),
                    );
                    extra_overrides.push((
                        format!("/xl/charts/chart{chart_no}.xml"),
                        "application/vnd.openxmlformats-officedocument.drawingml.chart+xml".into(),
                    ));
                    drawing_charts.push((crid, chart_no - 1));
                }
                pkg.insert_str(
                    &format!("xl/drawings/drawing{d}.xml"),
                    xlparts::drawing_xml(&pictures, &drawing_charts),
                );
                pkg.insert_str(
                    &format!("xl/drawings/_rels/drawing{d}.xml.rels"),
                    pkg::rels_xml(&drawing_rels),
                );
                extra_overrides.push((
                    format!("/xl/drawings/drawing{d}.xml"),
                    "application/vnd.openxmlformats-officedocument.drawing+xml".into(),
                ));
            }

            if !sheet.comments.is_empty() {
                let d = i + 1;
                let rid = format!("rId{}", sheet_rels.len() + 1);
                parts.legacy_rid = Some(rid.clone());
                sheet_rels.push((
                    rid,
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing"
                        .into(),
                    format!("../drawings/vmlDrawing{d}.vml"),
                    false,
                ));
                let crid = format!("rId{}", sheet_rels.len() + 1);
                sheet_rels.push((
                    crid,
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
                        .into(),
                    format!("../comments{d}.xml"),
                    false,
                ));
                pkg.insert_str(&format!("xl/comments{d}.xml"), xlparts::comments_xml(sheet));
                pkg.insert_str(
                    &format!("xl/drawings/vmlDrawing{d}.vml"),
                    xlparts::vml_comments_xml(sheet),
                );
                extra_overrides.push((
                    format!("/xl/comments{d}.xml"),
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml"
                        .into(),
                ));
                if !defaults.iter().any(|(e, _)| e == "vml") {
                    defaults.push((
                        "vml".into(),
                        "application/vnd.openxmlformats-officedocument.vmlDrawing".into(),
                    ));
                }
            }

            for (pi, pivot) in sheet.pivots.iter().enumerate() {
                let n = pivot_caches.len() + 1;
                let cache_id = n as u32;
                let (def, rec) = xlparts::pivot_cache_parts(pivot, self);
                pkg.insert_str(&format!("xl/pivotCache/pivotCacheDefinition{n}.xml"), def);
                pkg.insert_str(&format!("xl/pivotCache/pivotCacheRecords{n}.xml"), rec);
                pkg.insert_str(
                    &format!("xl/pivotTables/pivotTable{n}.xml"),
                    xlparts::pivot_table_xml(pivot, self, cache_id),
                );
                // the cache definition hangs off the workbook, the table off the sheet
                pivot_caches.push((cache_id, format!("pivotCache/pivotCacheDefinition{n}.xml")));
                let crid = format!("rId{}", sheet_rels.len() + 1);
                sheet_rels.push((
                    crid,
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/pivotTable"
                        .into(),
                    format!("../pivotTables/pivotTable{n}.xml"),
                    false,
                ));
                extra_overrides.push((
                    format!("/xl/pivotCache/pivotCacheDefinition{n}.xml"),
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotCacheDefinition+xml".into(),
                ));
                extra_overrides.push((
                    format!("/xl/pivotCache/pivotCacheRecords{n}.xml"),
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotCacheRecords+xml".into(),
                ));
                extra_overrides.push((
                    format!("/xl/pivotTables/pivotTable{n}.xml"),
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotTable+xml"
                        .into(),
                ));
                let _ = pi;
            }

            // セルのハイパーリンクは外部リレーションとして登録する。
            for link in &sheet.links {
                let rid = format!("rId{}", sheet_rels.len() + 1);
                sheet_rels.push((
                    rid.clone(),
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink"
                        .into(),
                    link.url.clone(),
                    !link.url.starts_with('#'),
                ));
                parts.links.push((link.row, link.col, rid));
            }

            if !sheet_rels.is_empty() {
                pkg.insert_str(
                    &format!("xl/worksheets/_rels/sheet{}.xml.rels", i + 1),
                    pkg::rels_xml(&sheet_rels),
                );
            }
            let part = format!("xl/worksheets/sheet{}.xml", i + 1);
            pkg.insert_str(&part, write_sheet(sheet, i == 0, &index, &parts));
        }
        // pivot caches are workbook children
        if !pivot_caches.is_empty() {
            let mut rels: Vec<(String, String, String, bool)> = Vec::new();
            let base = self.sheets.len() + 3;
            for (k, (_, target)) in pivot_caches.iter().enumerate() {
                rels.push((
                    format!("rId{}", base + k),
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/pivotCacheDefinition"
                        .into(),
                    target.clone(),
                    false,
                ));
            }
            if let Some(existing) = pkg.get_str("xl/_rels/workbook.xml.rels") {
                let merged = merge_rels(existing, &rels);
                pkg.insert_str("xl/_rels/workbook.xml.rels", merged);
            }
            if let Some(wb_xml) = pkg.get_str("xl/workbook.xml") {
                let mut extra = String::from("<pivotCaches>");
                for (k, (cache_id, _)) in pivot_caches.iter().enumerate() {
                    let _ = write!(
                        extra,
                        r#"<pivotCache cacheId="{cache_id}" r:id="rId{}"/>"#,
                        base + k
                    );
                }
                extra.push_str("</pivotCaches>");
                let patched = wb_xml.replace("</workbook>", &format!("{extra}</workbook>"));
                pkg.insert_str("xl/workbook.xml", patched);
            }
        }

        // 4. styles / shared strings
        pkg.insert_str("xl/styles.xml", self.styles.to_xml());
        if !shared.is_empty() {
            let mut ss = String::with_capacity(64 + shared.len() * 12);
            ss.push_str(xml::DECL);
            let _ = write!(
                ss,
                r#"<sst xmlns="{NS_MAIN}" count="{ref_count}" uniqueCount="{}">"#,
                shared.len()
            );
            for s in &shared {
                ss.push_str("<si>");
                if s.is_empty() {
                    ss.push_str("<t/>");
                } else {
                    xml::open_tag(&mut ss, "t", &[("xml:space", "preserve")], false);
                    xml::esc_into(&mut ss, s);
                    xml::close_tag(&mut ss, "t");
                }
                ss.push_str("</si>");
            }
            ss.push_str("</sst>");
            pkg.insert_str("xl/sharedStrings.xml", ss);
        }

        // 5. package metadata
        let mut overrides: Vec<(String, String)> = self
            .sheets
            .iter()
            .enumerate()
            .map(|(i, _)| {
                (
                    format!("/xl/worksheets/sheet{}.xml", i + 1),
                    CT_WORKSHEET.into(),
                )
            })
            .collect();
        overrides.push(("/xl/styles.xml".into(), CT_STYLES.into()));
        if !shared.is_empty() {
            overrides.push(("/xl/sharedStrings.xml".into(), CT_SHARED.into()));
        }
        overrides.push((
            "/docProps/core.xml".into(),
            "application/vnd.openxmlformats-package.core-properties+xml".into(),
        ));
        overrides.push((
            "/docProps/app.xml".into(),
            "application/vnd.openxmlformats-officedocument.extended-properties+xml".into(),
        ));
        overrides.extend(extra_overrides);
        pkg.insert_str(
            "[Content_Types].xml",
            pkg::content_types_xml_full("/xl/workbook.xml", CT_SHEET, &defaults, &overrides),
        );
        pkg.insert_str("_rels/.rels", pkg::root_rels("xl/workbook.xml", CT_SHEET));
        pkg.insert_str(
            "docProps/core.xml",
            pkg::core_xml(&self.title, &self.creator, &self.created),
        );
        pkg.insert_str(
            "docProps/app.xml",
            pkg::app_xml(
                &crate::producer(),
                &[("DocSecurity", "0"), ("ScaleCrop", "false")],
            ),
        );

        pkg.to_bytes()
    }

    pub fn save(&self, path: impl AsRef<std::path::Path>) -> Result<()> {
        std::fs::write(path, self.to_bytes()?)?;
        Ok(())
    }

    /// Parse `.xlsx` (or `.xlsm`) bytes.
    pub fn from_bytes(bytes: &[u8]) -> Result<Self> {
        let pkg = Package::from_bytes(bytes)?;
        // ODF keeps its type in an uncompressed `mimetype` part; fall back to
        // the presence of `content.xml` + a `office:spreadsheet` body.
        let is_ods = pkg
            .get_str("mimetype")
            .map(|m| m.contains("opendocument.spreadsheet"))
            .unwrap_or(false)
            || (pkg.contains("content.xml")
                && pkg
                    .get_str("content.xml")
                    .map(|c| c.contains("office:spreadsheet"))
                    .unwrap_or(false));
        if is_ods {
            return Self::from_ods_content(&pkg);
        }
        let wb_xml = pkg
            .get_str("xl/workbook.xml")
            .ok_or_else(|| Error::Format("missing xl/workbook.xml".into()))?;

        // rId -> target part
        let mut targets: HashMap<String, String> = HashMap::new();
        if let Some(rels) = pkg.get_str("xl/_rels/workbook.xml.rels") {
            let mut r = Reader::new(rels);
            loop {
                match r.next_event() {
                    Event::Start { name, attrs, .. } if xml::local(&name) == "Relationship" => {
                        let mut id = String::new();
                        let mut target = String::new();
                        for (k, v) in attrs {
                            match xml::local(&k) {
                                "Id" => id = v,
                                "Target" => target = v,
                                _ => {}
                            }
                        }
                        targets.insert(id, pkg::resolve("xl", &target));
                    }
                    Event::Eof => break,
                    _ => {}
                }
            }
        }

        let mut wb = Workbook::new();
        wb.sheets.clear();
        if let Some(styles) = pkg.get_str("xl/styles.xml") {
            wb.styles = StyleSheet::from_xml(styles);
        }
        let mut r = Reader::new(wb_xml);
        loop {
            match r.next_event() {
                Event::Start { name, attrs, .. } if xml::local(&name) == "sheet" => {
                    let mut sname = String::from("Sheet");
                    let mut rid = String::new();
                    for (k, v) in attrs {
                        match xml::local(&k) {
                            "name" => sname = v,
                            "id" => rid = v,
                            _ => {}
                        }
                    }
                    let mut sheet = Sheet::new(sname);
                    if let Some(part) = targets.get(&rid) {
                        if let Some(data) = pkg.get_str(part) {
                            read_sheet(data, &mut sheet, &pkg)?;
                            xlparts::read_sheet_extras(data, &mut sheet);
                            read_sheet_relations(&pkg, part, &mut sheet);
                        }
                    }
                    wb.sheets.push(sheet);
                }
                Event::Eof => break,
                _ => {}
            }
        }
        if wb.sheets.is_empty() {
            wb.sheets.push(Sheet::new("Sheet1"));
        }
        if let Some(core) = pkg.get_str("docProps/core.xml") {
            let mut r = Reader::new(core);
            loop {
                match r.next_event() {
                    Event::Start { name, .. } if xml::local(&name) == "title" => {
                        wb.title = r.read_text();
                    }
                    Event::Start { name, .. } if xml::local(&name) == "creator" => {
                        wb.creator = r.read_text();
                    }
                    Event::Eof => break,
                    _ => {}
                }
            }
        }
        Ok(wb)
    }

    /// Import an `.ods` package (the `content.xml` body).
    ///
    /// Supports the parts that matter for interchange: repeated rows/columns,
    /// typed values (float / string / boolean / date / percentage / currency),
    /// multi-paragraph cells, `table:formula` (converted from OpenFormula to
    /// the A1 syntax the engine speaks) and sheet names.
    fn from_ods_content(pkg: &Package) -> Result<Self> {
        let content = pkg
            .get_str("content.xml")
            .ok_or_else(|| Error::Format("missing content.xml".into()))?;
        let mut wb = Workbook::new();
        wb.sheets.clear();

        let mut r = Reader::new(content);
        let mut sheet: Option<Sheet> = None;
        let mut row: Option<Vec<Cell>> = None;
        let mut cell: Option<(Cell, u32, u32)> = None; // (value, colspan, repeat)
        let mut text = String::new();
        let mut in_table = 0u32;
        loop {
            match r.next_event() {
                Event::Start {
                    name,
                    attrs,
                    self_closing,
                } => {
                    let local = xml::local(&name).to_string();
                    match local.as_str() {
                        "table" => {
                            in_table += 1;
                            if in_table == 1 {
                                let mut sname = String::from("Sheet1");
                                for (k, v) in &attrs {
                                    if xml::local(k) == "name" {
                                        sname = v.clone();
                                    }
                                }
                                sheet = Some(Sheet::new(sname));
                            }
                        }
                        "table-row" if sheet.is_some() => {
                            let repeat = attr_u32(&attrs, "number-rows-repeated").unwrap_or(1);
                            row = Some(Vec::new());
                            // remember the repeat count on the row vector capacity
                            REPEAT.with(|c| c.set(repeat.min(MAX_ODS_REPEAT)));
                        }
                        "table-cell" | "covered-table-cell" if row.is_some() => {
                            let repeat = attr_u32(&attrs, "number-columns-repeated").unwrap_or(1);
                            let mut value = Cell::empty();
                            let vtype = attr(&attrs, "value-type").unwrap_or_default();
                            let formula = attr(&attrs, "formula");
                            value.value = if vtype == "float"
                                || vtype == "percentage"
                                || vtype == "currency"
                            {
                                match attr(&attrs, "value").and_then(|v| v.parse::<f64>().ok()) {
                                    Some(n) => CellValue::Number(n),
                                    None => CellValue::Empty,
                                }
                            } else if vtype == "boolean" {
                                CellValue::Bool(
                                    attr(&attrs, "boolean-value").as_deref() == Some("true"),
                                )
                            } else if vtype == "date" {
                                match attr(&attrs, "date-value")
                                    .and_then(|v| ods_date_to_serial(&v))
                                {
                                    Some(serial) => CellValue::Number(serial),
                                    None => CellValue::Empty,
                                }
                            } else {
                                CellValue::Empty
                            };
                            if let Some(f) = formula {
                                let expr = odf_formula_to_a1(&f);
                                let cached = match &value.value {
                                    CellValue::Number(n) => Some(*n),
                                    _ => None,
                                };
                                value.value = CellValue::Formula {
                                    expr,
                                    cached,
                                    text: None,
                                };
                            }
                            text.clear();
                            cell = Some((value, repeat.min(MAX_ODS_REPEAT), 0));
                            REPEAT.with(|c| c.set(repeat.min(MAX_ODS_REPEAT)));
                            if self_closing {
                                flush_ods_cell(&mut row, &mut cell, &text);
                                text.clear();
                            }
                        }
                        "p" | "h" if cell.is_some() && !text.is_empty() => text.push('\n'),
                        _ => {}
                    }
                }
                Event::Text(t) => {
                    if cell.is_some() {
                        text.push_str(&t);
                    }
                }
                Event::End { name } => match xml::local(&name) {
                    "table-cell" | "covered-table-cell" => {
                        flush_ods_cell(&mut row, &mut cell, &text);
                        text.clear();
                    }
                    "table-row" => {
                        if let (Some(sh), Some(mut cells)) = (sheet.as_mut(), row.take()) {
                            let repeat = REPEAT.with(|c| c.get()).max(1);
                            for _ in 0..repeat {
                                sh.rows.push(cells.clone());
                            }
                            cells.clear();
                        }
                    }
                    "table" => {
                        in_table = in_table.saturating_sub(1);
                        if in_table == 0 {
                            if let Some(sh) = sheet.take() {
                                wb.sheets.push(sh);
                            }
                        }
                    }
                    _ => {}
                },
                Event::Eof => break,
            }
        }
        if wb.sheets.is_empty() {
            wb.sheets.push(Sheet::new("Sheet1"));
        }
        for sh in &mut wb.sheets {
            sh.trim();
        }
        Ok(wb)
    }

    pub fn open(path: impl AsRef<std::path::Path>) -> Result<Self> {
        let bytes = std::fs::read(path)?;
        Workbook::from_bytes(&bytes)
    }

    /// Recalculate every formula (see [`crate::formula`]).
    pub fn recalculate(&mut self) {
        crate::formula::recalculate(self);
    }

    /// Called by the macro host after a write; the current engine recalculates
    /// eagerly, so this is a named hook rather than a dirty flag.
    pub fn recalculate_dirty(&mut self) {
        let has_formulas = self.sheets.iter().any(|s| {
            s.rows.iter().any(|r| {
                r.iter()
                    .any(|c| matches!(c.value, CellValue::Formula { .. }))
            })
        });
        if has_formulas {
            self.recalculate();
        }
    }

    /// CSV rendering of one sheet (RFC 4180, CRLF line endings).
    pub fn to_csv(&self, sheet: usize) -> Result<String> {
        let sheet = self
            .sheets
            .get(sheet)
            .ok_or_else(|| Error::Format(format!("no sheet #{sheet}")))?;
        Ok(crate::csv::write(
            &sheet
                .rows
                .iter()
                .map(|row| row.iter().map(|c| c.as_text()).collect())
                .collect::<Vec<Vec<String>>>(),
        ))
    }

    /// ODF 1.3 `.ods` rendering (export only).
    pub fn to_ods_bytes(&self) -> Result<Vec<u8>> {
        let mut content = String::with_capacity(4096);
        content.push_str(xml::DECL);
        content.push_str(
            r#"<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:calcext="urn:org:documentfoundation:names:experimental:calc:xmlns:calcext:1.0" office:version="1.3">"#,
        );
        content.push_str("<office:automatic-styles>");
        for (i, sheet) in self.sheets.iter().enumerate() {
            for (c, width) in sheet.col_widths.iter().enumerate() {
                if let Some(w) = width {
                    let name = format!("co{}_{}", i + 1, c + 1);
                    let style_name = format!("co{i}_{}", c + 1);
                    let _ = write!(
                        content,
                        r#"<style:style style:name="{style_name}" style:family="table-column"><style:table-column-properties style:column-width="{w}in"/></style:style>"#,
                        style_name = xml::esc(&style_name),
                        w = (*w as f64 * 0.09)
                    );
                    let _ = name;
                }
            }
        }
        content.push_str("</office:automatic-styles>");
        content.push_str("<office:body><office:spreadsheet>");
        for sheet in &self.sheets {
            xml::open_tag(
                &mut content,
                "table:table",
                &[("table:name", &sheet.name)],
                false,
            );
            for row in &sheet.rows {
                content.push_str("<table:table-row>");
                for cell in row {
                    match &cell.value {
                        CellValue::Empty => content.push_str("<table:table-cell/>"),
                        CellValue::Number(n) => {
                            let mut attrs =
                                vec![("office:value-type", "float"), ("office:value", "")];
                            let num = format_number(*n);
                            attrs[1].1 = &num;
                            xml::open_tag(&mut content, "table:table-cell", &attrs, false);
                            content.push_str("<text:p>");
                            xml::esc_into(&mut content, &num);
                            content.push_str("</text:p></table:table-cell>");
                        }
                        CellValue::Bool(b) => {
                            let v = if *b { "true" } else { "false" };
                            xml::open_tag(
                                &mut content,
                                "table:table-cell",
                                &[
                                    ("office:value-type", "boolean"),
                                    ("office:boolean-value", v),
                                ],
                                false,
                            );
                            content.push_str("<text:p>");
                            content.push_str(if *b { "TRUE" } else { "FALSE" });
                            content.push_str("</text:p></table:table-cell>");
                        }
                        CellValue::Text(t) => {
                            xml::open_tag(
                                &mut content,
                                "table:table-cell",
                                &[("office:value-type", "string")],
                                false,
                            );
                            content.push_str("<text:p>");
                            xml::esc_into(&mut content, t);
                            content.push_str("</text:p></table:table-cell>");
                        }
                        CellValue::Formula { expr, cached, text } => {
                            let mut attrs = vec![
                                ("table:formula", "of:="),
                                ("office:value-type", "float"),
                                ("office:value", "0"),
                            ];
                            let f = format!("of:={expr}");
                            attrs[0].1 = &f;
                            let n = match (cached, text) {
                                (Some(n), _) => format_number(*n),
                                (None, Some(t)) => t.clone(),
                                (None, None) => String::new(),
                            };
                            attrs[2].1 = &n;
                            xml::open_tag(&mut content, "table:table-cell", &attrs, false);
                            content.push_str("<text:p>");
                            xml::esc_into(&mut content, &n);
                            content.push_str("</text:p></table:table-cell>");
                        }
                        CellValue::Error(e) => {
                            xml::open_tag(
                                &mut content,
                                "table:table-cell",
                                &[("office:value-type", "string")],
                                false,
                            );
                            content.push_str("<text:p>");
                            xml::esc_into(&mut content, e);
                            content.push_str("</text:p></table:table-cell>");
                        }
                    }
                }
                content.push_str("</table:table-row>");
            }
            content.push_str("</table:table>");
        }
        content.push_str("</office:spreadsheet></office:body></office:document-content>");

        let manifest = format!(
            r#"{decl}<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.3"><manifest:file-entry manifest:full-path="/" manifest:version="1.3" manifest:media-type="application/vnd.oasis.opendocument.spreadsheet"/><manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/><manifest:file-entry manifest:full-path="meta.xml" manifest:media-type="text/xml"/><manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/></manifest:manifest>"#,
            decl = xml::DECL
        );
        let meta = format!(
            r#"{decl}<office:document-meta xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:dc="http://purl.org/dc/elements/1.1/" office:version="1.3"><office:meta><dc:title>{title}</dc:title><meta:generator>{gen}</meta:generator></office:meta></office:document-meta>"#,
            decl = xml::DECL,
            title = xml::esc(&self.title),
            gen = xml::esc(&crate::producer())
        );
        let styles = format!(
            r#"{decl}<office:document-styles xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" office:version="1.3"><office:styles/></office:document-styles>"#,
            decl = xml::DECL
        );

        let mut pkg = Package::new();
        pkg.insert_stored("mimetype", "application/vnd.oasis.opendocument.spreadsheet");
        pkg.insert_str("content.xml", content);
        pkg.insert_str("styles.xml", styles);
        pkg.insert_str("meta.xml", meta);
        pkg.insert_str("META-INF/manifest.xml", manifest);
        pkg.to_bytes()
    }
}

/// Append `col` as spread-sheet letters without allocating.
fn push_col_letters(out: &mut String, mut col: u32) {
    let mut buf = [0u8; 8];
    let mut n = 0;
    loop {
        buf[n] = b'A' + (col % 26) as u8;
        n += 1;
        if col < 26 {
            break;
        }
        col = col / 26 - 1;
    }
    for i in (0..n).rev() {
        out.push(buf[i] as char);
    }
}

/// Append an unsigned integer without allocating a `String`.
fn push_u32(out: &mut String, n: u32) {
    let mut buf = [0u8; 10];
    let mut i = buf.len();
    let mut n = n;
    loop {
        i -= 1;
        buf[i] = b'0' + (n % 10) as u8;
        n /= 10;
        if n == 0 {
            break;
        }
    }
    out.push_str(std::str::from_utf8(&buf[i..]).unwrap_or("0"));
}

/// Append an unsigned 64-bit integer without allocating.
fn push_u64(out: &mut String, n: u64) {
    let mut buf = [0u8; 20];
    let mut i = buf.len();
    let mut n = n;
    loop {
        i -= 1;
        buf[i] = b'0' + (n % 10) as u8;
        n /= 10;
        if n == 0 {
            break;
        }
    }
    out.push_str(std::str::from_utf8(&buf[i..]).unwrap_or("0"));
}

/// Append a number the way Excel's `General` format shows it: integral values
/// have no decimal part, everything else uses the shortest round-trip form.
fn push_number(out: &mut String, n: f64) {
    if n == n.trunc() && n.abs() < 1e15 {
        if n < 0.0 {
            out.push('-');
        }
        push_u64(out, n.abs() as u64);
        return;
    }
    out.push_str(&format_number_exact(n));
}

/// `<worksheet>` part for one sheet.
/// Relationship ids a worksheet needs to point at its own extra parts.
#[derive(Debug, Clone, Default)]
struct SheetParts {
    drawing_rid: Option<String>,
    legacy_rid: Option<String>,
    /// (row, col, rId) — `<hyperlinks>` の各項目。
    links: Vec<(u32, u32, String)>,
}

fn write_sheet(
    sheet: &Sheet,
    first: bool,
    shared: &HashMap<&str, u32>,
    parts: &SheetParts,
) -> String {
    let mut s = String::with_capacity(512 + sheet.rows.len() * 64);
    s.push_str(xml::DECL);
    let _ = write!(s, r#"<worksheet xmlns="{NS_MAIN}" xmlns:r="{NS_R}">"#);

    let rows = sheet.row_count();
    let cols = sheet.col_count();
    let dim = format!("A1:{}{}", col_letters(cols.saturating_sub(1)), rows.max(1));
    xml::open_tag(&mut s, "dimension", &[("ref", &dim)], true);

    // sheetViews (frozen panes / selected tab)
    s.push_str("<sheetViews>");
    let tab_sel = if first { r#" tabSelected="1""# } else { "" };
    match sheet.freeze {
        Some((fr, fc)) if fr > 0 || fc > 0 => {
            let top_left = format!("{}{}", col_letters(fc), fr + 1);
            let (pane, active) = match (fr > 0, fc > 0) {
                (true, true) => ("bottomRight", "bottomRight"),
                (true, false) => ("bottomLeft", "bottomLeft"),
                _ => ("topRight", "topRight"),
            };
            let _ = write!(
                s,
                r#"<sheetView{tab_sel} workbookViewId="0"><pane xSplit="{fc}" ySplit="{fr}" topLeftCell="{top_left}" activePane="{pane}" state="frozen"/><selection pane="{active}" activeCell="{top_left}" sqref="{top_left}"/></sheetView>"#
            );
        }
        _ => {
            let _ = write!(s, r#"<sheetView{tab_sel} workbookViewId="0"/>"#);
        }
    }
    s.push_str("</sheetViews>");
    s.push_str(r#"<sheetFormatPr defaultRowHeight="15"/>"#);

    if sheet.col_widths.iter().any(|w| w.is_some()) {
        s.push_str("<cols>");
        for (i, w) in sheet.col_widths.iter().enumerate() {
            if let Some(width) = w {
                let n = (i + 1).to_string();
                let width = format!("{width:.2}");
                let idx = n.as_str();
                xml::open_tag(
                    &mut s,
                    "col",
                    &[
                        ("min", idx),
                        ("max", idx),
                        ("width", &width),
                        ("customWidth", "1"),
                    ],
                    true,
                );
            }
        }
        s.push_str("</cols>");
    }

    s.push_str("<sheetData>");
    for (r, row) in sheet.rows.iter().enumerate() {
        if row.iter().all(|c| c.is_empty()) {
            continue;
        }
        s.push_str("<row r=\"");
        push_u32(&mut s, (r + 1) as u32);
        s.push('"');
        if let Some(Some(h)) = sheet.row_heights.get(r) {
            let _ = write!(s, r#" ht="{h:.2}" customHeight="1""#);
        }
        s.push('>');
        for (c, cell) in row.iter().enumerate() {
            if cell.is_empty() {
                continue;
            }
            s.push_str("<c r=\"");
            push_col_letters(&mut s, c as u32);
            push_u32(&mut s, (r + 1) as u32);
            s.push('"');
            match &cell.value {
                CellValue::Text(t) => {
                    s.push_str(" t=\"s\"");
                    if cell.style != 0 {
                        s.push_str(" s=\"");
                        push_u32(&mut s, cell.style as u32);
                        s.push('"');
                    }
                    s.push_str("><v>");
                    push_u32(&mut s, shared.get(t.as_str()).copied().unwrap_or(0));
                    s.push_str("</v></c>");
                }
                CellValue::Bool(b) => {
                    s.push_str(" t=\"b\"");
                    if cell.style != 0 {
                        s.push_str(" s=\"");
                        push_u32(&mut s, cell.style as u32);
                        s.push('"');
                    }
                    s.push_str(if *b { "><v>1</v></c>" } else { "><v>0</v></c>" });
                }
                CellValue::Number(n) => {
                    if cell.style != 0 {
                        s.push_str(" s=\"");
                        push_u32(&mut s, cell.style as u32);
                        s.push('"');
                    }
                    s.push_str("><v>");
                    push_number(&mut s, *n);
                    s.push_str("</v></c>");
                }
                CellValue::Formula { expr, cached, text } => {
                    if text.is_some() {
                        s.push_str(" t=\"str\"");
                    }
                    if cell.style != 0 {
                        s.push_str(" s=\"");
                        push_u32(&mut s, cell.style as u32);
                        s.push('"');
                    }
                    s.push_str("><f>");
                    xml::esc_into(&mut s, expr);
                    s.push_str("</f>");
                    match (cached, text) {
                        (Some(n), _) => {
                            s.push_str("<v>");
                            push_number(&mut s, *n);
                            s.push_str("</v>");
                        }
                        (None, Some(t)) => {
                            s.push_str("<v>");
                            xml::esc_into(&mut s, t);
                            s.push_str("</v>");
                        }
                        (None, None) => {}
                    }
                    s.push_str("</c>");
                }
                CellValue::Error(e) => {
                    s.push_str(" t=\"e\"");
                    if cell.style != 0 {
                        s.push_str(" s=\"");
                        push_u32(&mut s, cell.style as u32);
                        s.push('"');
                    }
                    s.push_str("><v>");
                    xml::esc_into(&mut s, e);
                    s.push_str("</v></c>");
                }
                CellValue::Empty => {}
            }
        }
        s.push_str("</row>");
    }
    s.push_str("</sheetData>");

    if let Some(range) = &sheet.autofilter {
        xml::open_tag(&mut s, "autoFilter", &[("ref", range)], true);
    }
    s.push_str(&xlparts::merges_xml(&sheet.merges));
    s.push_str(&xlparts::conditional_formatting_xml(&sheet.cf));
    s.push_str(&xlparts::data_validation_xml(&sheet.validations));
    if !parts.links.is_empty() {
        s.push_str("<hyperlinks>");
        for (row, col, rid) in &parts.links {
            let reference = format!("{}{}", col_letters(*col), row + 1);
            let _ = write!(s, r#"<hyperlink ref="{reference}" r:id="{rid}"/>"#);
        }
        s.push_str("</hyperlinks>");
    }
    s.push_str(
        r#"<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>"#,
    );
    s.push_str(r#"<pageSetup orientation="portrait" paperSize="9"/>"#);
    if let Some(rid) = &parts.drawing_rid {
        xml::open_tag(&mut s, "drawing", &[("r:id", rid)], true);
    }
    if let Some(rid) = &parts.legacy_rid {
        xml::open_tag(&mut s, "legacyDrawing", &[("r:id", rid)], true);
    }
    s.push_str("</worksheet>");
    s
}

/// Follow a worksheet's relationships to pick up the comment parts.
/// `<hyperlinks>` を読み、rId を URL に解決する。
fn read_hyperlinks(pkg: &Package, sheet_part: &str, rels: &[(String, String)], sheet: &mut Sheet) {
    let Some(src) = pkg.get_str(sheet_part) else {
        return;
    };
    let mut in_links = false;
    let mut r = Reader::new(src);
    loop {
        match r.next_event() {
            Event::Start { name, attrs, .. } => match xml::local(&name) {
                "hyperlinks" => in_links = true,
                "hyperlink" if in_links => {
                    let mut row = 0u32;
                    let mut col = 0u32;
                    let mut rid = String::new();
                    let mut location = String::new();
                    for (k, v) in attrs {
                        match xml::local(&k) {
                            "ref" => {
                                if let Some((r0, c0)) = parse_ref(&v) {
                                    row = r0;
                                    col = c0;
                                }
                            }
                            "id" => rid = v,
                            "location" => location = v,
                            _ => {}
                        }
                    }
                    let url = rels
                        .iter()
                        .find(|(id, _)| *id == rid)
                        .map(|(_, t)| t.clone())
                        .or_else(|| {
                            if location.is_empty() {
                                None
                            } else {
                                Some(format!("#{location}"))
                            }
                        });
                    if let Some(url) = url {
                        sheet.links.retain(|l| l.row != row || l.col != col);
                        sheet.links.push(CellLink::new(row, col, url));
                    }
                }
                _ => {}
            },
            Event::End { name } => {
                if xml::local(&name) == "hyperlinks" {
                    in_links = false;
                }
            }
            Event::Eof => break,
            _ => {}
        }
    }
}

fn read_sheet_relations(pkg: &Package, sheet_part: &str, sheet: &mut Sheet) {
    let (dir, file) = match sheet_part.rsplit_once('/') {
        Some(_) => {
            let dir = sheet_part.rsplit_once('/').map(|(d, _)| d).unwrap_or("");
            let file = sheet_part
                .rsplit_once('/')
                .map(|(_, f)| f)
                .unwrap_or(sheet_part);
            (dir.to_string(), file.to_string())
        }
        None => (String::new(), sheet_part.to_string()),
    };
    let rels_part = if dir.is_empty() {
        format!("_rels/{file}.rels")
    } else {
        format!("{dir}/_rels/{file}.rels")
    };
    let Some(rels) = pkg.get_str(&rels_part) else {
        return;
    };
    let mut r = Reader::new(rels);
    let mut map: Vec<(String, String)> = Vec::new();
    loop {
        match r.next_event() {
            Event::Eof => break,
            Event::Start { name, attrs, .. } if xml::local(&name) == "Relationship" => {
                let mut target = String::new();
                let mut ty = String::new();
                let mut id = String::new();
                let mut external = false;
                for (k, v) in attrs {
                    match xml::local(&k) {
                        "Target" => target = v,
                        "Type" => ty = v,
                        "Id" => id = v,
                        "TargetMode" => external = v == "External",
                        _ => {}
                    }
                }
                if !id.is_empty() && !target.is_empty() {
                    let resolved = if external {
                        target.clone()
                    } else {
                        pkg::resolve(&dir, &target)
                    };
                    map.push((id, resolved));
                }
                if ty.ends_with("/comments") {
                    let part = pkg::resolve(&dir, &target);
                    if let Some(src) = pkg.get_str(&part) {
                        read_comments(src, sheet);
                    }
                }
                if ty.ends_with("/drawing") {
                    // セルに貼られた画像 (Excel の「図の挿入」と同じもの)
                    let part = pkg::resolve(&dir, &target);
                    read_drawings(pkg, &part, sheet);
                }
            }
            _ => {}
        }
    }
    read_hyperlinks(pkg, sheet_part, &map, sheet);
}

/// 1 EMU = 1/914400 inch。ピクセルは 96 dpi として換算する。
const EMU_PER_PX: f64 = 9525.0;

/// `<xdr:wsDr>` から画像を取り出す。位置はセル (col/row)、大きさは EMU。
fn read_drawings(pkg: &Package, drawing_part: &str, sheet: &mut Sheet) {
    let Some(src) = pkg.get_str(drawing_part) else {
        return;
    };
    // drawing 側の rels: rId -> media (例 ../media/image1.png)
    let (dir, file) = match drawing_part.rsplit_once('/') {
        Some((d, f)) => (d.to_string(), f.to_string()),
        None => (String::new(), drawing_part.to_string()),
    };
    let rels_part = if dir.is_empty() {
        format!("_rels/{file}.rels")
    } else {
        format!("{dir}/_rels/{file}.rels")
    };
    let mut rels: Vec<(String, String)> = Vec::new();
    if let Some(rels_src) = pkg.get_str(&rels_part) {
        let mut r = Reader::new(rels_src);
        loop {
            match r.next_event() {
                Event::Eof => break,
                Event::Start { name, attrs, .. } if xml::local(&name) == "Relationship" => {
                    let get = |key: &str| {
                        attrs
                            .iter()
                            .find(|(k, _)| xml::local(k) == key)
                            .map(|(_, v)| v.clone())
                            .unwrap_or_default()
                    };
                    let (id, target) = (get("Id"), get("Target"));
                    if !id.is_empty() && !target.is_empty() {
                        rels.push((id, pkg::resolve(&dir, &target)));
                    }
                }
                _ => {}
            }
        }
    }

    let mut r = Reader::new(src);
    let mut in_from = false;
    let mut col = 0u32;
    let mut row = 0u32;
    let mut cx = 0f64;
    let mut cy = 0f64;
    let mut embed = String::new();
    let mut name = String::new();
    // <xdr:col>2</xdr:col> のように値が「文字」で来る要素を取りこぼさない
    let mut text_target = String::new();
    loop {
        match r.next_event() {
            Event::Eof => break,
            Event::Text(t) => {
                let v = t.trim();
                if !v.is_empty() {
                    if text_target == "col" {
                        col = v.parse::<u32>().unwrap_or(col);
                    } else if text_target == "row" {
                        row = v.parse::<u32>().unwrap_or(row);
                    }
                }
            }
            Event::Start {
                name: n,
                attrs,
                self_closing,
            } => {
                let key = |k: &str| {
                    attrs
                        .iter()
                        .find(|(kk, _)| xml::local(kk) == k)
                        .map(|(_, v)| v.as_str())
                };
                match xml::local(&n) {
                    "from" => {
                        in_from = true;
                        if self_closing {
                            in_from = false;
                        }
                    }
                    "col" if in_from => {
                        if let Some(v) = key("val") {
                            col = v.trim().parse::<u32>().unwrap_or(0);
                        } else {
                            text_target = "col".to_string();
                        }
                    }
                    "row" if in_from => {
                        if let Some(v) = key("val") {
                            row = v.trim().parse::<u32>().unwrap_or(0);
                        } else {
                            text_target = "row".to_string();
                        }
                    }
                    // 画像の大きさは図形の ext (EMU)
                    "ext" => {
                        cx = key("cx")
                            .and_then(|v| v.trim().parse::<f64>().ok())
                            .unwrap_or(0.0);
                        cy = key("cy")
                            .and_then(|v| v.trim().parse::<f64>().ok())
                            .unwrap_or(0.0);
                    }
                    "blip" => {
                        embed = key("embed")
                            .or_else(|| key("link"))
                            .unwrap_or_default()
                            .to_string()
                    }
                    "cNvPr" => name = key("name").unwrap_or_default().to_string(),
                    _ => {}
                }
            }
            Event::End { name: n } => match xml::local(&n) {
                "col" | "row" => text_target.clear(),
                "from" => in_from = false,
                "pic" | "graphicFrame" => {
                    if !embed.is_empty() {
                        if let Some((_, part)) = rels.iter().find(|(id, _)| *id == embed) {
                            if let Some(bytes) = pkg.get(part) {
                                let ext = part
                                    .rsplit_once('.')
                                    .map(|(_, e)| e.to_ascii_lowercase())
                                    .filter(|e| e == "png" || e == "jpeg" || e == "jpg")
                                    .map(|e| if e == "jpg" { "jpeg".to_string() } else { e })
                                    .unwrap_or_else(|| "png".to_string());
                                let width_px = if cx > 0.0 {
                                    (cx / EMU_PER_PX).round() as u32
                                } else {
                                    0
                                };
                                let height_px = if cy > 0.0 {
                                    (cy / EMU_PER_PX).round() as u32
                                } else {
                                    0
                                };
                                sheet.images.push(Image {
                                    data: bytes.to_vec(),
                                    ext,
                                    col,
                                    row,
                                    width_px,
                                    height_px,
                                    name: if name.is_empty() {
                                        "画像".to_string()
                                    } else {
                                        name.clone()
                                    },
                                });
                            }
                        }
                    }
                    embed.clear();
                    name.clear();
                    cx = 0.0;
                    cy = 0.0;
                }
                _ => {}
            },
        }
    }
}

fn read_comments(src: &str, sheet: &mut Sheet) {
    let mut authors: Vec<String> = Vec::new();
    let mut body = false;
    let mut cur_row = 0u32;
    let mut cur_col = 0u32;
    let mut cur_author = 0usize;
    let mut text = String::new();
    let mut in_comment = false;
    let mut r = Reader::new(src);
    loop {
        match r.next_event() {
            Event::Eof => break,
            Event::Start {
                name,
                attrs,
                self_closing,
            } => match xml::local(&name) {
                "author" => {
                    if !self_closing {
                        authors.push(r.read_text());
                    }
                }
                "comment" => {
                    in_comment = true;
                    text.clear();
                    for (k, v) in &attrs {
                        match xml::local(k) {
                            "ref" => {
                                if let Some((row, col)) = parse_ref(v) {
                                    cur_row = row;
                                    cur_col = col;
                                }
                            }
                            "authorId" => cur_author = v.trim().parse().unwrap_or(0),
                            _ => {}
                        }
                    }
                }
                "t" if in_comment && !self_closing => {
                    text.push_str(&r.read_text());
                }
                _ => {}
            },
            Event::End { name } => {
                if xml::local(&name) == "comment" && in_comment {
                    in_comment = false;
                    body = true;
                    sheet.comments.push(CellComment::new(
                        cur_row,
                        cur_col,
                        authors.get(cur_author).cloned().unwrap_or_default(),
                        text.clone(),
                    ));
                }
            }
            Event::Text(_) => {}
        }
    }
    let _ = body;
}

/// Append relationships to an existing `_rels` part.
fn merge_rels(existing: &str, extra: &[(String, String, String, bool)]) -> String {
    let mut rels: Vec<(String, String, String, bool)> = Vec::new();
    let mut r = Reader::new(existing);
    loop {
        match r.next_event() {
            Event::Eof => break,
            Event::Start { name, attrs, .. } if xml::local(&name) == "Relationship" => {
                let get = |k: &str| {
                    attrs
                        .iter()
                        .find(|(key, _)| key == k)
                        .map(|(_, v)| v.clone())
                        .unwrap_or_default()
                };
                rels.push((
                    get("Id"),
                    get("Type"),
                    get("Target"),
                    get("TargetMode") == "External",
                ));
            }
            _ => {}
        }
    }
    rels.extend_from_slice(extra);
    pkg::rels_xml(&rels)
}

fn read_sheet(data: &str, sheet: &mut Sheet, pkg: &Package) -> Result<()> {
    let shared = read_shared_strings(pkg);
    let mut r = Reader::new(data);
    let mut row_idx: u32 = 0;
    // current cell state
    let mut cur: Option<PendingCell> = None;
    let mut in_is = false;
    let mut is_text = String::new();
    // openpyxl (and some exporters) write `<c t="inlineStr"><is><t>…</t></is></c>`
    let mut had_inline = false;

    loop {
        match r.next_event() {
            Event::Start {
                name,
                attrs,
                self_closing,
            } => match xml::local(&name) {
                "sheetFormatPr" => {}
                "pane" => {
                    let get = |k: &str| -> f32 {
                        attrs
                            .iter()
                            .find(|(a, _)| xml::local(a) == k)
                            .and_then(|(_, v)| v.parse::<f32>().ok())
                            .unwrap_or(0.0)
                    };
                    let (ys, xs) = (get("ySplit"), get("xSplit"));
                    if ys > 0.0 || xs > 0.0 {
                        sheet.freeze = Some((ys as u32, xs as u32));
                    }
                }
                "col" => {
                    let get = |k: &str| -> Option<&str> {
                        attrs
                            .iter()
                            .find(|(a, _)| xml::local(a) == k)
                            .map(|(_, v)| v.as_str())
                    };
                    let min: usize = get("min").and_then(|v| v.parse().ok()).unwrap_or(0);
                    let max: usize = get("max").and_then(|v| v.parse().ok()).unwrap_or(0);
                    let width: f32 = get("width").and_then(|v| v.parse().ok()).unwrap_or(0.0);
                    if min > 0 && max >= min && width > 0.0 {
                        if sheet.col_widths.len() < max {
                            sheet.col_widths.resize(max, None);
                        }
                        for idx in min..=max {
                            sheet.col_widths[idx - 1] = Some(width);
                        }
                    }
                }
                "autoFilter" => {
                    if let Some((_, ref_v)) = attrs.iter().find(|(a, _)| xml::local(a) == "ref") {
                        sheet.autofilter = Some(ref_v.clone());
                    }
                }
                "row" => {
                    row_idx = attrs
                        .iter()
                        .find(|(k, _)| xml::local(k) == "r")
                        .and_then(|(_, v)| v.parse().ok())
                        .map(|n: u32| n - 1)
                        .unwrap_or(row_idx + 1);
                    if !self_closing {
                        row_idx = attrs
                            .iter()
                            .find(|(k, _)| xml::local(k) == "r")
                            .and_then(|(_, v)| v.parse().ok())
                            .map(|n: u32| n - 1)
                            .unwrap_or(row_idx);
                    }
                }
                "c" => {
                    let r_ref = attrs
                        .iter()
                        .find(|(k, _)| xml::local(k) == "r")
                        .map(|(_, v)| v.clone())
                        .unwrap_or_default();
                    let t = attrs
                        .iter()
                        .find(|(k, _)| xml::local(k) == "t")
                        .map(|(_, v)| v.clone())
                        .unwrap_or_else(|| "n".into());
                    let style = attrs
                        .iter()
                        .find(|(k, _)| xml::local(k) == "s")
                        .and_then(|(_, v)| v.parse().ok())
                        .unwrap_or(0);
                    let (cr, cc) = parse_ref(&r_ref).unwrap_or((row_idx, 0));
                    cur = Some((cr, cc, t, style, None, None));
                    is_text.clear();
                    had_inline = false;
                    if self_closing {
                        if let Some((cr, cc, t, style, v, f)) = cur.take() {
                            store(sheet, cr, cc, &t, style, v, f, &shared);
                        }
                    }
                }
                "v" => {
                    let text = r.read_text();
                    if let Some(c) = cur.as_mut() {
                        c.4 = Some(text);
                    }
                }
                "f" => {
                    let text = r.read_text();
                    if let Some(c) = cur.as_mut() {
                        c.5 = Some(text);
                    }
                }
                "is" => {
                    in_is = true;
                    is_text.clear();
                    had_inline = true;
                    if self_closing {
                        in_is = false;
                    }
                }
                "t" if in_is => {
                    is_text.push_str(&r.read_text());
                }
                "r" if in_is => {}
                _ => {}
            },
            Event::End { name } => match xml::local(&name) {
                "c" => {
                    if let Some((cr, cc, t, style, v, f)) = cur.take() {
                        let v = if had_inline { Some(is_text.clone()) } else { v };
                        store(sheet, cr, cc, &t, style, v, f, &shared);
                    }
                }
                "is" => in_is = false,
                _ => {}
            },
            Event::Text(_) => {}
            Event::Eof => break,
        }
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn store(
    sheet: &mut Sheet,
    row: u32,
    col: u32,
    t: &str,
    style: u16,
    raw: Option<String>,
    formula: Option<String>,
    shared: &[String],
) {
    let (row, col) = (row.min(MAX_ROWS - 1), col.min(MAX_COLS - 1));
    let value = match formula {
        Some(f) => {
            let raw_ref = raw.as_deref();
            let cached = raw_ref.and_then(|v| v.parse::<f64>().ok());
            let text = if t == "str" && cached.is_none() {
                raw_ref.map(|s| s.to_string())
            } else {
                None
            };
            CellValue::Formula {
                expr: f.trim_start_matches('=').to_string(),
                cached,
                text,
            }
        }
        None => {
            let raw = raw.unwrap_or_default();
            match t {
                "s" => {
                    let idx: usize = raw.trim().parse().unwrap_or(usize::MAX);
                    CellValue::Text(shared.get(idx).cloned().unwrap_or_default())
                }
                "str" => CellValue::Text(raw),
                "inlineStr" => CellValue::Text(raw),
                "b" => CellValue::Bool(raw.trim() == "1" || raw.eq_ignore_ascii_case("true")),
                "e" => CellValue::Error(raw),
                _ => match raw.trim().parse::<f64>() {
                    Ok(n) => CellValue::Number(n),
                    Err(_) if raw.is_empty() => CellValue::Empty,
                    Err(_) => CellValue::Text(raw),
                },
            }
        }
    };
    if matches!(value, CellValue::Empty) && style == 0 {
        return;
    }
    sheet.set(row, col, Cell { value, style });
}

fn read_shared_strings(pkg: &Package) -> Vec<String> {
    let mut out = Vec::new();
    let Some(xml_src) = pkg.get_str("xl/sharedStrings.xml") else {
        return out;
    };
    let mut r = Reader::new(xml_src);
    let mut cur = String::new();
    let mut in_si = false;
    loop {
        match r.next_event() {
            Event::Start {
                name, self_closing, ..
            } => match xml::local(&name) {
                "si" => {
                    cur.clear();
                    in_si = !self_closing;
                    if self_closing {
                        out.push(String::new());
                    }
                }
                "t" if in_si => cur.push_str(&r.read_text()),
                _ => {}
            },
            Event::End { name } => {
                if xml::local(&name) == "si" {
                    out.push(std::mem::take(&mut cur));
                    in_si = false;
                }
            }
            Event::Eof => break,
            _ => {}
        }
    }
    out
}

// ---- A1 addressing ------------------------------------------------------

/// 0-based column index to letters: `0 -> A`, `26 -> AA`.
pub fn col_letters(mut col: u32) -> String {
    let mut buf = [0u8; 8];
    let mut n = 0;
    loop {
        buf[n] = b'A' + (col % 26) as u8;
        n += 1;
        if col < 26 {
            break;
        }
        col = col / 26 - 1;
    }
    buf[..n].iter().rev().map(|&b| b as char).collect()
}

/// Letters to 0-based column index.
pub fn letters_to_col(s: &str) -> Option<u32> {
    if s.is_empty() {
        return None;
    }
    let mut n: u32 = 0;
    for c in s.chars() {
        let u = c.to_ascii_uppercase();
        if !u.is_ascii_uppercase() {
            return None;
        }
        n = n
            .checked_mul(26)?
            .checked_add((u as u32) - ('A' as u32) + 1)?;
    }
    n.checked_sub(1)
}

/// `"B3"` -> `(2, 1)` (0-based row, col).
///
/// Allocation free: the reader calls this once per cell, so it must not build
/// temporary strings.  Accepts `$B$3`, `Sheet1!B3` and lower case.
pub fn parse_ref(addr: &str) -> Option<(u32, u32)> {
    let a = match addr.rfind('!') {
        Some(i) => &addr[i + 1..],
        None => addr,
    };
    let mut col: u32 = 0;
    let mut row: u32 = 0;
    let mut letters = 0u32;
    let mut digits = 0u32;
    for b in a.trim().bytes() {
        match b {
            b'$' => {}
            b'A'..=b'Z' | b'a'..=b'z' => {
                if digits > 0 {
                    return None;
                }
                col = col
                    .checked_mul(26)?
                    .checked_add((b.to_ascii_uppercase() - b'A') as u32 + 1)?;
                letters += 1;
            }
            b'0'..=b'9' => {
                row = row.checked_mul(10)?.checked_add((b - b'0') as u32)?;
                digits += 1;
            }
            _ => return None,
        }
    }
    if letters == 0 || digits == 0 || row == 0 {
        return None;
    }
    Some((row - 1, col - 1))
}

/// `"A1:C3"` -> `(0,0,2,2)`.
pub fn parse_range(addr: &str) -> Option<(u32, u32, u32, u32)> {
    let addr = addr.trim();
    match addr.split_once(':') {
        Some((a, b)) => {
            let (r1, c1) = parse_ref(a)?;
            let (r2, c2) = parse_ref(b)?;
            Some((r1.min(r2), c1.min(c2), r1.max(r2), c1.max(c2)))
        }
        None => {
            let (r, c) = parse_ref(addr)?;
            Some((r, c, r, c))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn column_letters_roundtrip() {
        for (col, letters) in [
            (0, "A"),
            (25, "Z"),
            (26, "AA"),
            (51, "AZ"),
            (701, "ZZ"),
            (702, "AAA"),
        ] {
            assert_eq!(col_letters(col), letters);
            assert_eq!(letters_to_col(letters), Some(col));
        }
    }

    #[test]
    fn refs() {
        assert_eq!(parse_ref("A1"), Some((0, 0)));
        assert_eq!(parse_ref("B3"), Some((2, 1)));
        assert_eq!(parse_ref("$AA$10"), Some((9, 26)));
        assert_eq!(parse_ref("1A"), None);
        assert_eq!(parse_range("A1:C3"), Some((0, 0, 2, 2)));
        assert_eq!(parse_range("B2"), Some((1, 1, 1, 1)));
    }

    #[test]
    fn write_then_read() {
        let mut wb = Workbook::with_sheet_count(2);
        wb.sheets[0].name = "売上".into();
        wb.sheets[0].push_row(vec![
            Cell::text("月").styled(styles::HEADER),
            Cell::text("金額").styled(styles::HEADER),
        ]);
        wb.sheets[0].push_row(vec![Cell::text("1月"), Cell::num(1200)]);
        wb.sheets[0].push_row(vec![Cell::text("2月"), Cell::num(1800)]);
        wb.sheets[0].push_row(vec![
            Cell::text("合計").styled(styles::BOLD),
            Cell::formula("SUM(B2:B3)", Some(3000.0)).styled(styles::BOLD),
        ]);
        wb.sheets[0].freeze = Some((1, 0));
        wb.sheets[0].autofilter = Some("A1:B3".into());
        wb.sheets[1].set_a1("C3", Cell::boolean(true)).unwrap();

        let bytes = wb.to_bytes().unwrap();
        let back = Workbook::from_bytes(&bytes).unwrap();
        assert_eq!(back.sheets.len(), 2);
        assert_eq!(back.sheets[0].name, "売上");
        assert_eq!(back.sheets[0].get(1, 0).unwrap().as_text(), "1月");
        assert_eq!(back.sheets[0].get(1, 1).unwrap().as_number(), Some(1200.0));
        match &back.sheets[0].get(3, 1).unwrap().value {
            CellValue::Formula { expr, cached, .. } => {
                assert_eq!(expr, "SUM(B2:B3)");
                assert_eq!(*cached, Some(3000.0));
            }
            other => panic!("expected formula, got {other:?}"),
        }
        assert_eq!(back.sheets[1].get(2, 2).unwrap().as_text(), "TRUE");
        // styles survive
        assert_eq!(back.sheets[0].get(0, 0).unwrap().style, styles::HEADER);
    }

    #[test]
    fn csv_export_quotes() {
        let mut wb = Workbook::new();
        wb.sheet_mut().push_row(vec![
            Cell::text("a,b"),
            Cell::num(1),
            Cell::text("say \"hi\""),
        ]);
        let csv = wb.to_csv(0).unwrap();
        assert_eq!(csv, "\"a,b\",1,\"say \"\"hi\"\"\"\r\n");
    }

    #[test]
    fn ods_is_a_zip_with_mimetype_first() {
        let wb = Workbook::new();
        let bytes = wb.to_ods_bytes().unwrap();
        assert_eq!(&bytes[0..2], b"PK");
        let pkg = Package::from_bytes(&bytes).unwrap();
        assert_eq!(pkg.names()[0], "mimetype");
        assert!(pkg
            .get_str("content.xml")
            .unwrap()
            .contains("<table:table "));
    }

    #[test]
    fn rejects_non_zip() {
        assert!(Workbook::from_bytes(b"not a zip").is_err());
    }
}

// ---------------------------------------------------------------- ODF import

/// Upper bound for `table:number-*-repeated` so a hostile file cannot make us
/// allocate gigabytes.
const MAX_ODS_REPEAT: u32 = 4096;

thread_local! {
    static REPEAT: std::cell::Cell<u32> = const { std::cell::Cell::new(1) };
}

fn attr(attrs: &[(String, String)], name: &str) -> Option<String> {
    attrs
        .iter()
        .find(|(k, _)| xml::local(k) == name)
        .map(|(_, v)| v.clone())
}

fn attr_u32(attrs: &[(String, String)], name: &str) -> Option<u32> {
    attr(attrs, name).and_then(|v| v.parse::<u32>().ok())
}

fn flush_ods_cell(row: &mut Option<Vec<Cell>>, cell: &mut Option<(Cell, u32, u32)>, text: &str) {
    let Some((mut value, repeat, _)) = cell.take() else {
        return;
    };
    if value.is_empty() && !text.is_empty() {
        value.value = CellValue::Text(text.trim_end_matches('\n').to_string());
    } else if !text.is_empty() {
        // keep the displayed string for formula cells so viewers agree
        if let CellValue::Formula {
            text: cached_text, ..
        } = &mut value.value
        {
            *cached_text = Some(text.to_string());
        }
    }
    if let Some(cells) = row.as_mut() {
        for _ in 0..repeat.max(1) {
            cells.push(value.clone());
        }
    }
}

/// `YYYY-MM-DD[THH:MM[:SS]]Z?` → Excel serial day number (1900 date system).
fn ods_date_to_serial(s: &str) -> Option<f64> {
    let s = s.trim_end_matches('Z');
    let (date, time) = match s.split_once('T') {
        Some((d, t)) => (d, t),
        None => (s, ""),
    };
    let mut it = date.split('-');
    let y: i64 = it.next()?.parse().ok()?;
    let m: i64 = it.next()?.parse().ok()?;
    let d: i64 = it.next()?.parse().ok()?;
    if !(1..=12).contains(&m) || !(1..=31).contains(&d) {
        return None;
    }
    // days since 1970-01-01 (Howard Hinnant's algorithm)
    let y2 = if m <= 2 { y - 1 } else { y };
    let era = if y2 >= 0 { y2 } else { y2 - 399 } / 400;
    let yoe = y2 - era * 400;
    let mp = (m + 9) % 12;
    let doy = (153 * mp + 2) / 5 + d - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    let days_1970 = era * 146_097 + doe - 719_468;
    // 1970-01-01 is serial 25569 in the 1900 date system
    let mut serial = (days_1970 + 25_569) as f64;
    if !time.is_empty() {
        let mut t = time.split(':');
        let hh: f64 = t.next().and_then(|v| v.parse().ok()).unwrap_or(0.0);
        let mm: f64 = t.next().and_then(|v| v.parse().ok()).unwrap_or(0.0);
        let ss: f64 = t.next().and_then(|v| v.parse().ok()).unwrap_or(0.0);
        serial += (hh * 3600.0 + mm * 60.0 + ss) / 86_400.0;
    }
    Some(serial)
}

/// Convert an OpenFormula expression (`of:=SUM([.B2:.B5])`) to A1 syntax.
fn odf_formula_to_a1(f: &str) -> String {
    let body = f.trim_start_matches("of:=").trim_start_matches('=');
    let mut out = String::with_capacity(body.len());
    let mut chars = body.chars().peekable();
    while let Some(c) = chars.next() {
        match c {
            '[' => {
                let mut ref_text = String::new();
                for d in chars.by_ref() {
                    if d == ']' {
                        break;
                    }
                    ref_text.push(d);
                }
                // `[.Sheet2.B2:.B5]` → `Sheet2!B2:B5`, `[.B2]` → `B2`
                let mut endpoints = ref_text.trim().split(':');
                if let Some(first) = endpoints.next() {
                    out.push_str(&ods_endpoint(first));
                }
                if let Some(last) = endpoints.next() {
                    out.push(':');
                    out.push_str(&ods_endpoint(last));
                }
            }
            // ODF separates arguments with ';'
            ';' => out.push(','),
            _ => out.push(c),
        }
    }
    out
}

/// One end of an ODF cell reference: `'.Sheet 1'.B2` → `Sheet 1!B2`, `.B2` → `B2`.
fn ods_endpoint(raw: &str) -> String {
    let raw = raw.trim().trim_start_matches('.');
    match raw.rsplit_once('.') {
        Some((sheet, addr)) if !addr.is_empty() => {
            let sheet = sheet.trim_matches('\'').replace("''", "'");
            format!("{sheet}!{addr}")
        }
        _ => raw.replace('\'', ""),
    }
}

#[cfg(test)]
mod odf_tests {
    use super::*;

    #[test]
    fn formula_conversion() {
        assert_eq!(odf_formula_to_a1("of:=SUM([.B2:.B5])"), "SUM(B2:B5)");
        assert_eq!(
            odf_formula_to_a1("of:=SUM([.Sheet2.B2:.B5])"),
            "SUM(Sheet2!B2:B5)"
        );
        assert_eq!(odf_formula_to_a1("of:=IF([.A1]>0;1;2)"), "IF(A1>0,1,2)");
    }
}
