//! Format detection from a path or from the first bytes of a file.

use crate::error::{Error, Result};

/// The document families Poccham Office Next understands.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Format {
    Docx,
    Docm,
    Xlsx,
    Xlsm,
    Pptx,
    Pptm,
    Odt,
    Ods,
    Odp,
    Csv,
    Tsv,
    PlainText,
    Markdown,
    Unknown,
}

impl Format {
    pub fn from_extension(path: &str) -> Format {
        let ext = path.rsplit('.').next().unwrap_or("").to_ascii_lowercase();
        match ext.as_str() {
            "docx" => Format::Docx,
            "docm" | "dotm" => Format::Docm,
            "xlsx" => Format::Xlsx,
            "xlsm" | "xltm" => Format::Xlsm,
            "pptx" => Format::Pptx,
            "pptm" | "potm" => Format::Pptm,
            "odt" | "ott" | "fodt" => Format::Odt,
            "ods" | "ots" | "fods" => Format::Ods,
            "odp" | "otp" | "fodp" => Format::Odp,
            "csv" => Format::Csv,
            "tsv" | "tab" => Format::Tsv,
            "md" | "markdown" => Format::Markdown,
            "txt" => Format::PlainText,
            _ => Format::Unknown,
        }
    }

    /// Friendly, menu-ready name.
    pub fn label(self) -> &'static str {
        match self {
            Format::Docx => "Word 文書 (.docx)",
            Format::Docm => "Word マクロ有効文書 (.docm)",
            Format::Xlsx => "Excel ブック (.xlsx)",
            Format::Xlsm => "Excel マクロ有効ブック (.xlsm)",
            Format::Pptx => "PowerPoint プレゼンテーション (.pptx)",
            Format::Pptm => "PowerPoint マクロ有効 (.pptm)",
            Format::Odt => "OpenDocument 文書 (.odt)",
            Format::Ods => "OpenDocument 表計算 (.ods)",
            Format::Odp => "OpenDocument プレゼンテーション (.odp)",
            Format::Csv => "CSV (.csv)",
            Format::Tsv => "TSV (.tsv)",
            Format::PlainText => "テキスト (.txt)",
            Format::Markdown => "Markdown (.md)",
            Format::Unknown => "不明な形式",
        }
    }

    /// Office Open XML documents are the "working" formats of this suite.
    pub fn is_ooxml(self) -> bool {
        matches!(
            self,
            Format::Docx | Format::Docm | Format::Xlsx | Format::Xlsm | Format::Pptx | Format::Pptm
        )
    }

    pub fn is_spreadsheet(self) -> bool {
        matches!(
            self,
            Format::Xlsx | Format::Xlsm | Format::Ods | Format::Csv | Format::Tsv
        )
    }
}

/// Detect from a path (extension) — cheap, used before reading anything.
pub fn from_path(path: &str) -> Format {
    Format::from_extension(path)
}

/// Detect from content: ZIP magic + a look at the package parts.
pub fn sniff(bytes: &[u8]) -> Format {
    if bytes.len() >= 4 && &bytes[0..2] == b"PK" {
        // ODF keeps the media type in an uncompressed `mimetype` part.
        if let Some(mt) = odf_mimetype(bytes) {
            return match mt.as_str() {
                "application/vnd.oasis.opendocument.text" => Format::Odt,
                "application/vnd.oasis.opendocument.spreadsheet" => Format::Ods,
                "application/vnd.oasis.opendocument.presentation" => Format::Odp,
                _ => Format::Unknown,
            };
        }
        // OOXML: the main part tells us everything (parts are compressed, so
        // scanning raw bytes would not work).
        if let Ok(pkg) = crate::pkg::Package::from_bytes(bytes) {
            let macro_enabled = pkg
                .get_str("[Content_Types].xml")
                .map(|ct| ct.contains("macroEnabled"))
                .unwrap_or(false);
            if pkg.contains("word/document.xml") {
                return if macro_enabled {
                    Format::Docm
                } else {
                    Format::Docx
                };
            }
            if pkg.contains("xl/workbook.xml") {
                return if macro_enabled {
                    Format::Xlsm
                } else {
                    Format::Xlsx
                };
            }
            if pkg.contains("ppt/presentation.xml") {
                return if macro_enabled {
                    Format::Pptm
                } else {
                    Format::Pptx
                };
            }
            if pkg.contains("content.xml") {
                return Format::Ods;
            }
        }
        return Format::Unknown;
    }
    // OLE2 / Compound File Binary (legacy .xls / .doc / .ppt) and any other
    // binary container: refuse to treat these as text.
    if bytes.starts_with(&[0xD0, 0xCF, 0x11, 0xE0]) {
        return Format::Unknown;
    }
    let head = &bytes[..bytes.len().min(4096)];
    if head.contains(&0) {
        return Format::Unknown;
    }
    // Text formats.
    let text = String::from_utf8_lossy(head);
    if text.contains('\t') && !text.contains(',') {
        return Format::Tsv;
    }
    if text.contains(',') || text.lines().count() > 1 {
        return Format::Csv;
    }
    Format::PlainText
}

fn odf_mimetype(bytes: &[u8]) -> Option<String> {
    // Local file header: 30 bytes, then name, then (stored) payload.
    if bytes.len() < 32 {
        return None;
    }
    let name_len = u16::from_le_bytes([bytes[26], bytes[27]]) as usize;
    let extra_len = u16::from_le_bytes([bytes[28], bytes[29]]) as usize;
    let start = 30 + name_len + extra_len;
    if name_len != 8 || &bytes[30..38] != b"mimetype" || start >= bytes.len() {
        return None;
    }
    // Stored entry: the uncompressed size in the local header bounds the payload.
    let size = u32::from_le_bytes([bytes[22], bytes[23], bytes[24], bytes[25]]) as usize;
    let end = (start + size).min(bytes.len());
    let mt = String::from_utf8_lossy(&bytes[start..end]).to_string();
    Some(mt)
}

/// Read a file and detect its format, resolving extension/content conflicts
/// in favour of the content.
pub fn detect_file(path: &str) -> Result<Format> {
    let bytes = std::fs::read(path)?;
    let by_content = sniff(&bytes);
    let by_ext = from_path(path);
    Ok(match (by_ext, by_content) {
        (_, Format::Unknown) => by_ext,
        (ext, content) if ext.is_ooxml() || ext != content => content,
        (ext, _) => ext,
    })
}

/// Consistency check used by conversion.
pub fn ensure(actual: Format, expected: &[Format], what: &str) -> Result<()> {
    if expected.contains(&actual) {
        Ok(())
    } else {
        Err(Error::Format(format!(
            "{what}: expected {}, found {}",
            expected
                .iter()
                .map(|f| f.label())
                .collect::<Vec<_>>()
                .join(" / "),
            actual.label()
        )))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn extensions() {
        assert_eq!(from_path("/tmp/a.XLSX"), Format::Xlsx);
        assert_eq!(from_path("a.tar.gz"), Format::Unknown);
        assert!(Format::Docx.label().contains("docx"));
    }

    #[test]
    fn sniffs_generated_ooxml() {
        use crate::xlsx::Workbook;
        let bytes = Workbook::new().to_bytes().unwrap();
        assert_eq!(sniff(&bytes), Format::Xlsx);
    }

    #[test]
    fn sniffs_generated_ods() {
        use crate::xlsx::Workbook;
        let bytes = Workbook::new().to_ods_bytes().unwrap();
        assert_eq!(sniff(&bytes), Format::Ods);
    }
}
