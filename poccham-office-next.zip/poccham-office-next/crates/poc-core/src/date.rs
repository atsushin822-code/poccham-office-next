//! Date and time values.
//!
//! Spreadsheets store dates as *serial day numbers* in the 1900 date system:
//! day 1 is 1900-01-01, and because Lotus 1-2-3 wrongly treated 1900 as a leap
//! year, serial 60 is the non-existent 1900-02-29. Every implementation must
//! reproduce that quirk or dates shift by one day, so it lives here once and
//! the readers, writers, `TEXT()` and the date functions all share it.

/// A calendar date and optional time of day.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DateTime {
    pub year: i32,
    pub month: u32,
    pub day: u32,
    pub hour: u32,
    pub minute: u32,
    pub second: u32,
    pub millis: u32,
}

impl DateTime {
    pub const fn new(year: i32, month: u32, day: u32) -> Self {
        DateTime {
            year,
            month,
            day,
            hour: 0,
            minute: 0,
            second: 0,
            millis: 0,
        }
    }

    /// Days since 1970-01-01 (proleptic Gregorian, Howard Hinnant's algorithm).
    fn days_from_civil(self) -> i64 {
        let (y, m, d) = (self.year as i64, self.month as i64, self.day as i64);
        let y = if m <= 2 { y - 1 } else { y };
        let era = if y >= 0 { y } else { y - 399 } / 400;
        let yoe = y - era * 400;
        let mp = (m + 9) % 12;
        let doy = (153 * mp + 2) / 5 + d - 1;
        let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
        era * 146_097 + doe - 719_468
    }

    fn from_days(days: i64) -> (i32, u32, u32) {
        let z = days + 719_468;
        let era = if z >= 0 { z } else { z - 146_096 } / 146_097;
        let doe = z - era * 146_097;
        let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146_096) / 365;
        let y = yoe + era * 400;
        let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
        let mp = (5 * doy + 2) / 153;
        let d = doy - (153 * mp + 2) / 5 + 1;
        let m = if mp < 10 { mp + 3 } else { mp - 9 };
        ((if m <= 2 { y + 1 } else { y }) as i32, m as u32, d as u32)
    }

    /// Days since the Excel epoch. Serial 0 is the (fictional) 1900-01-00, so
    /// 1900-01-01 is serial 1 and 1899-12-31 is the zero point.
    pub fn excel_serial(self) -> f64 {
        let days = self.days_from_civil() - (DateTime::new(1899, 12, 31).days_from_civil());
        let mut serial = days as f64;
        // 1900 is (wrongly) a leap year in the 1900 date system.
        if serial >= 60.0 {
            serial += 1.0;
        }
        serial
            + (self.hour as f64 * 3600.0 + self.minute as f64 * 60.0 + self.second as f64)
                / 86_400.0
            + self.millis as f64 / 86_400_000.0
    }

    /// Inverse of [`DateTime::excel_serial`].
    pub fn from_serial(serial: f64) -> Self {
        let mut days = serial.floor() as i64;
        if days >= 60 {
            days -= 1; // undo the 1900 leap-year bug
        }
        let (year, month, day) =
            DateTime::from_days(days + DateTime::new(1899, 12, 31).days_from_civil());
        let frac = serial - serial.floor();
        let total = (frac * 86_400.0).round() as u32;
        DateTime {
            year,
            month,
            day,
            hour: (total / 3600).min(23),
            minute: (total / 60 % 60).min(59),
            second: total % 60,
            millis: 0,
        }
    }

    pub fn weekday_sun0(&self) -> u32 {
        // 1899-12-31 was a Sunday, so serial 1 (1900-01-01) is a Monday.
        let days = self.days_from_civil() - DateTime::new(1899, 12, 31).days_from_civil();
        (days.rem_euclid(7)) as u32
    }

    pub fn is_valid(&self) -> bool {
        (1..=12).contains(&self.month)
            && (1..=31).contains(&self.day)
            && self.hour < 24
            && self.minute < 60
            && self.second < 60
            && days_in_month(self.year, self.month) >= self.day
    }

    pub fn add_days(self, days: i64) -> Self {
        DateTime::from_serial(self.excel_serial() + days as f64)
    }

    pub fn add_months(self, months: i32) -> Self {
        if months == 0 {
            return self;
        }
        let total = self.year * 12 + (self.month as i32 - 1) + months;
        let year = total.div_euclid(12);
        let month = (total.rem_euclid(12) + 1) as u32;
        let day = self.day.min(days_in_month(year, month));
        let mut out = DateTime {
            year,
            month,
            day,
            ..self
        };
        // keep the time of day
        let frac = self.excel_serial().fract();
        out.hour = (frac * 24.0) as u32;
        let rem = frac * 24.0 - out.hour as f64;
        out.minute = (rem * 60.0) as u32;
        out.second = ((rem * 60.0 - out.minute as f64) * 60.0).round() as u32;
        out
    }

    /// `2026-11-17`
    pub fn to_iso_date(self) -> String {
        format!("{:04}-{:02}-{:02}", self.year, self.month, self.day)
    }

    /// `2026-11-17T09:05:00`
    pub fn to_iso_datetime(self) -> String {
        format!(
            "{}T{:02}:{:02}:{:02}",
            self.to_iso_date(),
            self.hour,
            self.minute,
            self.second
        )
    }

    /// Parse `YYYY-MM-DD`, `YYYY/MM/DD`, `YYYY-MM-DDTHH:MM[:SS]` or
    /// `YYYY-MM-DD HH:MM[:SS]`.
    pub fn parse(text: &str) -> Option<Self> {
        let text = text.trim();
        let (date_part, time_part) = match text.find(['T', ' ']) {
            Some(i) => (&text[..i], &text[i + 1..]),
            None => (text, ""),
        };
        let sep = if date_part.contains('-') {
            '-'
        } else if date_part.contains('/') {
            '/'
        } else if date_part.contains('.') {
            '.'
        } else {
            return None;
        };
        let mut it = date_part.split(sep);
        let y: i32 = it.next()?.trim().parse().ok()?;
        let m: u32 = it.next()?.trim().parse().ok()?;
        let d: u32 = it.next()?.trim().parse().ok()?;
        let mut dt = DateTime::new(y, m, d);
        let time_part = time_part.trim().trim_end_matches('Z');
        if !time_part.is_empty() {
            let mut t = time_part.split(':');
            dt.hour = t.next().and_then(|v| v.trim().parse().ok()).unwrap_or(0);
            dt.minute = t.next().and_then(|v| v.trim().parse().ok()).unwrap_or(0);
            let sec = t.next().unwrap_or("0");
            dt.second = sec
                .split('.')
                .next()
                .and_then(|v| v.trim().parse().ok())
                .unwrap_or(0);
        }
        if dt.is_valid() {
            Some(dt)
        } else {
            None
        }
    }

    /// Today's date in UTC (`TODAY()`); the UI passes a local override.
    pub fn today_utc() -> Self {
        let secs = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_secs() as i64)
            .unwrap_or(0);
        let days = secs.div_euclid(86_400);
        let (year, month, day) = DateTime::from_days(days);
        DateTime::new(year, month, day)
    }

    /// Now in UTC (`NOW()`).
    pub fn now_utc() -> Self {
        let secs = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_secs() as i64)
            .unwrap_or(0);
        let days = secs.div_euclid(86_400);
        let rem = secs.rem_euclid(86_400);
        let (year, month, day) = DateTime::from_days(days);
        DateTime {
            year,
            month,
            day,
            hour: (rem / 3600) as u32,
            minute: (rem / 60 % 60) as u32,
            second: (rem % 60) as u32,
            millis: 0,
        }
    }
}

pub fn is_leap(year: i32) -> bool {
    (year % 4 == 0 && year % 100 != 0) || year % 400 == 0
}

pub fn days_in_month(year: i32, month: u32) -> u32 {
    match month {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        2 => {
            if is_leap(year) {
                29
            } else {
                28
            }
        }
        _ => 0,
    }
}

/// Parse a cell's text as a date, accepting the formats Excel accepts for
/// `DATEVALUE`-style coercion.
pub fn parse_date(text: &str) -> Option<DateTime> {
    if let Some(dt) = DateTime::parse(text) {
        return Some(dt);
    }
    // `2026年11月17日` / `11/17/2026`-style short forms are deliberately not
    // guessed: ambiguous formats are a compatibility trap.
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn serials_match_excel() {
        // the canonical anchors
        assert_eq!(DateTime::new(1900, 1, 1).excel_serial(), 1.0);
        assert_eq!(DateTime::new(1900, 3, 1).excel_serial(), 61.0); // 1900-02-29 does not exist
        assert_eq!(DateTime::new(2024, 1, 1).excel_serial(), 45292.0);
        assert_eq!(DateTime::new(2026, 11, 17).excel_serial(), 46343.0);
        assert_eq!(
            DateTime::new(2026, 11, 17).excel_serial() - DateTime::new(2026, 11, 16).excel_serial(),
            1.0
        );
    }

    #[test]
    fn serials_round_trip() {
        for serial in [1.0, 59.0, 61.0, 45292.0, 46343.5, 45000.25] {
            let dt = DateTime::from_serial(serial);
            assert!(
                (dt.excel_serial() - serial).abs() < 1e-9,
                "{serial} -> {dt:?}"
            );
        }
    }

    #[test]
    fn time_of_day_is_kept() {
        let dt = DateTime::from_serial(46353.75);
        assert_eq!((dt.hour, dt.minute), (18, 0));
    }

    #[test]
    fn weekday_is_correct() {
        // 2026-11-17 is a Tuesday
        assert_eq!(DateTime::new(2026, 11, 17).weekday_sun0(), 2);
        assert_eq!(DateTime::new(2026, 11, 15).weekday_sun0(), 0);
    }

    #[test]
    fn month_arithmetic_clamps_the_day() {
        let dt = DateTime::new(2024, 1, 31).add_months(1);
        assert_eq!((dt.year, dt.month, dt.day), (2024, 2, 29));
        let dt = DateTime::new(2024, 3, 31).add_months(-1);
        assert_eq!((dt.year, dt.month, dt.day), (2024, 2, 29));
        let dt = DateTime::new(2026, 12, 15).add_months(1);
        assert_eq!((dt.year, dt.month, dt.day), (2027, 1, 15));
    }

    #[test]
    fn parses_iso_and_slash_dates() {
        assert_eq!(DateTime::parse("2026-11-17").unwrap().month, 11);
        assert_eq!(DateTime::parse("2026/1/5").unwrap().day, 5);
        let dt = DateTime::parse("2026-11-17T09:05:30").unwrap();
        assert_eq!((dt.hour, dt.minute, dt.second), (9, 5, 30));
        assert!(DateTime::parse("2026-02-30").is_none());
    }

    #[test]
    fn days_in_month_handles_leap_years() {
        assert_eq!(days_in_month(2024, 2), 29);
        assert_eq!(days_in_month(1900, 2), 28);
        assert_eq!(days_in_month(2000, 2), 29);
    }
}
