//! Presentation engine: `.pptx` (PresentationML) reader/writer.
//!
//! The writer emits a complete, theme-backed package (master + one layout +
//! theme + per-slide text) because PowerPoint refuses files that reference
//! missing masters or themes.  Slides use plain text boxes rather than
//! placeholders: every consumer renders them, and they survive round trips
//! through Google Slides / Keynote / LibreOffice without repair prompts.

use std::fmt::Write as _;

use crate::error::{Error, Result};
use crate::pkg::{self, Package};
use crate::xml::{self, Event, Reader};

const NS_P: &str = "http://schemas.openxmlformats.org/presentationml/2006/main";
const NS_A: &str = "http://schemas.openxmlformats.org/drawingml/2006/main";
const NS_R: &str = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

const CT_PRES: &str =
    "application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml";
const CT_SLIDE: &str = "application/vnd.openxmlformats-officedocument.presentationml.slide+xml";
const CT_LAYOUT: &str =
    "application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml";
const CT_MASTER: &str =
    "application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml";
const CT_THEME: &str = "application/vnd.openxmlformats-officedocument.theme+xml";
const CT_PRESPROPS: &str =
    "application/vnd.openxmlformats-officedocument.presentationml.presProps+xml";
const CT_VIEWPROPS: &str =
    "application/vnd.openxmlformats-officedocument.presentationml.viewProps+xml";
const CT_TABLESTYLES: &str =
    "application/vnd.openxmlformats-officedocument.presentationml.tableStyles+xml";

const RT_PRESENTATION: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument";
const RT_SLIDE: &str = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide";
const RT_LAYOUT: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout";
const RT_MASTER: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster";
const RT_THEME: &str = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme";
const RT_PRESPROPS: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/presProps";
const RT_VIEWPROPS: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/viewProps";
const RT_TABLESTYLES: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/tableStyles";
const RT_HYPERLINK: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink";

/// A bullet (or plain) line on a slide.
#[derive(Debug, Clone, PartialEq)]
pub struct Bullet {
    pub text: String,
    /// 0 = top level, 1+ = nested.
    pub level: u8,
    /// ハイパーリンク先 (URL / mailto:)。`<a:hlinkClick>` として保存される。
    pub link: Option<String>,
}

impl Bullet {
    pub fn new(text: impl Into<String>) -> Self {
        Bullet {
            text: text.into(),
            level: 0,
            link: None,
        }
    }
    pub fn level(mut self, level: u8) -> Self {
        self.level = level;
        self
    }
    /// 行全体をリンクにする。
    pub fn link(mut self, url: impl Into<String>) -> Self {
        self.link = Some(url.into());
        self
    }
}

/// A picture placed on a slide, in EMU (English Metric Units, 914400 = inch).
#[derive(Debug, Clone, PartialEq, Default)]
pub struct SlideImage {
    pub data: Vec<u8>,
    /// `png` or `jpeg`.
    pub ext: String,
    pub x: i64,
    pub y: i64,
    pub cx: i64,
    pub cy: i64,
    pub name: String,
    /// 画像をクリックしたときのリンク先。
    pub link: Option<String>,
}

impl SlideImage {
    /// Place a picture using millimetres, which is what a human thinks in.
    pub fn new(data: Vec<u8>, x_mm: f32, y_mm: f32, w_mm: f32, h_mm: f32) -> Self {
        let emu = |mm: f32| (mm * 36_000.0).round() as i64;
        let ext = if data.starts_with(b"\x89PNG") {
            "png"
        } else if data.starts_with(&[0xFF, 0xD8]) {
            "jpeg"
        } else {
            "png"
        };
        SlideImage {
            data,
            ext: ext.into(),
            x: emu(x_mm),
            y: emu(y_mm),
            cx: emu(w_mm),
            cy: emu(h_mm),
            name: String::new(),
            link: None,
        }
    }

    /// 画像にリンクを付ける。
    pub fn link(mut self, url: impl Into<String>) -> Self {
        self.link = Some(url.into());
        self
    }
}

/// Preset geometry for a drawn shape.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum ShapeKind {
    #[default]
    Rect,
    RoundedRect,
    Ellipse,
    Triangle,
    RightArrow,
    Line,
    Star5,
    Chevron,
    Diamond,
}

impl ShapeKind {
    fn prst(self) -> &'static str {
        match self {
            ShapeKind::Rect => "rect",
            ShapeKind::RoundedRect => "roundRect",
            ShapeKind::Ellipse => "ellipse",
            ShapeKind::Triangle => "triangle",
            ShapeKind::RightArrow => "rightArrow",
            ShapeKind::Line => "line",
            ShapeKind::Star5 => "star5",
            ShapeKind::Chevron => "chevron",
            ShapeKind::Diamond => "diamond",
        }
    }
}

/// A drawn shape (図形) with optional text inside it.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Shape {
    pub kind: ShapeKind,
    pub x: i64,
    pub y: i64,
    pub cx: i64,
    pub cy: i64,
    pub text: String,
    /// Fill colour; `None` keeps the theme fill.
    pub fill: Option<String>,
    /// Outline colour (six hex digits).
    pub line: Option<String>,
    /// 図形をクリックしたときのリンク先。
    pub link: Option<String>,
}

impl Shape {
    pub fn new(kind: ShapeKind, x_mm: f32, y_mm: f32, w_mm: f32, h_mm: f32) -> Self {
        let emu = |mm: f32| (mm * 36_000.0).round() as i64;
        Shape {
            kind,
            x: emu(x_mm),
            y: emu(y_mm),
            cx: emu(w_mm),
            cy: emu(h_mm),
            text: String::new(),
            fill: None,
            line: None,
            link: None,
        }
    }

    pub fn text(mut self, text: impl Into<String>) -> Self {
        self.text = text.into();
        self
    }

    pub fn fill(mut self, hex: impl Into<String>) -> Self {
        self.fill = Some(hex.into());
        self
    }

    pub fn line(mut self, hex: impl Into<String>) -> Self {
        self.line = Some(hex.into());
        self
    }

    /// 図形にリンクを付ける (クリックで URL を開く)。
    pub fn link(mut self, url: impl Into<String>) -> Self {
        self.link = Some(url.into());
        self
    }
}

/// Slide transition (画面切り替え) — the animation side of a deck.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum Transition {
    #[default]
    None,
    Fade,
    Push,
    Wipe,
    Split,
    Cover,
}

impl Transition {
    fn xml(self) -> Option<&'static str> {
        Some(match self {
            Transition::None => return None,
            Transition::Fade => r#"<p:fade/>"#,
            Transition::Push => r#"<p:push dir="u"/>"#,
            Transition::Wipe => r#"<p:wipe dir="l"/>"#,
            Transition::Split => r#"<p:split orient="horz" dir="out"/>"#,
            Transition::Cover => r#"<p:cover dir="l"/>"#,
        })
    }
}

/// Colour and font scheme applied to the whole deck.
#[derive(Debug, Clone, PartialEq)]
pub struct Theme {
    pub name: String,
    pub dk1: String,
    pub lt1: String,
    pub accents: [String; 6],
    pub font: String,
}

impl Default for Theme {
    fn default() -> Self {
        Theme::office()
    }
}

impl Theme {
    /// The default blue-grey palette the writer uses when nothing is chosen.
    pub fn office() -> Self {
        Theme {
            name: "Poccham".into(),
            dk1: "262626".into(),
            lt1: "FFFFFF".into(),
            accents: [
                "2E5496".into(),
                "C55A11".into(),
                "2F7D6D".into(),
                "7C4DA0".into(),
                "B8902B".into(),
                "4A6FA5".into(),
            ],
            font: "Yu Gothic UI".into(),
        }
    }

    /// A theme from six accent colours.
    pub fn from_accents(accents: [&str; 6]) -> Self {
        let mut theme = Theme::office();
        for (slot, value) in theme.accents.iter_mut().zip(accents) {
            *slot = value.to_string();
        }
        theme
    }

    pub fn font(mut self, font: impl Into<String>) -> Self {
        self.font = font.into();
        self
    }

    pub fn name(mut self, name: impl Into<String>) -> Self {
        self.name = name.into();
        self
    }
}

/// One slide: a title, body lines, pictures, shapes and notes.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Slide {
    pub title: String,
    pub bullets: Vec<Bullet>,
    /// Pictures on the slide.
    pub images: Vec<SlideImage>,
    /// Drawn shapes.
    pub shapes: Vec<Shape>,
    /// 発表者ノート.
    pub notes: String,
    /// Slide transition.
    pub transition: Transition,
    /// Fade the title, body, then each shape in on click.
    pub animate: bool,
}

impl Slide {
    pub fn new(title: impl Into<String>) -> Self {
        Slide {
            title: title.into(),
            bullets: Vec::new(),
            images: Vec::new(),
            shapes: Vec::new(),
            notes: String::new(),
            transition: Transition::None,
            animate: false,
        }
    }

    /// Add a picture.
    pub fn image(mut self, image: SlideImage) -> Self {
        self.images.push(image);
        self
    }

    /// Add a drawn shape.
    pub fn shape(mut self, shape: Shape) -> Self {
        self.shapes.push(shape);
        self
    }

    /// Speaker notes.
    pub fn notes(mut self, notes: impl Into<String>) -> Self {
        self.notes = notes.into();
        self
    }

    /// Set the slide transition.
    pub fn transition(mut self, transition: Transition) -> Self {
        self.transition = transition;
        self
    }

    /// Animate the slide's content on click.
    pub fn animate(mut self) -> Self {
        self.animate = true;
        self
    }
    pub fn bullet(mut self, text: impl Into<String>) -> Self {
        self.bullets.push(Bullet::new(text));
        self
    }
    pub fn sub_bullet(mut self, text: impl Into<String>) -> Self {
        self.bullets.push(Bullet::new(text).level(1));
        self
    }
    pub fn para(mut self, text: impl Into<String>) -> Self {
        self.bullets.push(Bullet::new(text));
        self
    }

    /// 行を 1 つ追加し、同時にハイパーリンクを張る。
    pub fn para_link(mut self, text: impl Into<String>, url: impl Into<String>) -> Self {
        self.bullets.push(Bullet::new(text).link(url));
        self
    }
}

/// A presentation.
#[derive(Debug, Clone)]
pub struct Presentation {
    pub slides: Vec<Slide>,
    pub title: String,
    pub creator: String,
    pub created: String,
    /// 16:9 (default, like modern Office) or 4:3.
    pub wide: bool,
    /// Colour and font scheme for the whole deck.
    pub theme: Theme,
}

impl Default for Presentation {
    fn default() -> Self {
        Presentation::new()
    }
}

impl Presentation {
    pub fn new() -> Self {
        Presentation {
            slides: Vec::new(),
            title: String::new(),
            creator: "Poccham Office Next".into(),
            created: pkg::now_w3cdtf(),
            wide: true,
            theme: Theme::office(),
        }
    }

    pub fn add(&mut self, slide: Slide) -> &mut Self {
        self.slides.push(slide);
        self
    }

    pub fn from_markdown(md: &str) -> Self {
        // `# Title` starts a slide, `- item` adds a bullet, anything else is text.
        let mut pres = Presentation::new();
        for line in md.lines() {
            let line = line.trim_end();
            if let Some(rest) = line.strip_prefix("## ") {
                pres.add(Slide::new(rest.trim()));
            } else if let Some(rest) = line.strip_prefix("# ") {
                pres.add(Slide::new(rest.trim()));
            } else if let Some(rest) = line.strip_prefix("  - ") {
                if let Some(s) = pres.slides.last_mut() {
                    s.bullets.push(Bullet::new(rest.trim()).level(1));
                }
            } else if let Some(rest) = line.strip_prefix("- ") {
                if let Some(s) = pres.slides.last_mut() {
                    s.bullets.push(Bullet::new(rest.trim()));
                }
            } else if !line.trim().is_empty() {
                if let Some(s) = pres.slides.last_mut() {
                    s.bullets.push(Bullet::new(line.trim()));
                }
            }
        }
        pres
    }

    pub fn to_markdown(&self) -> String {
        let mut out = String::new();
        for (i, slide) in self.slides.iter().enumerate() {
            let _ = writeln!(out, "## Slide {}: {}", i + 1, slide.title);
            for b in &slide.bullets {
                out.push_str(if b.level == 0 { "- " } else { "    - " });
                out.push_str(&b.text);
                out.push('\n');
            }
            out.push('\n');
        }
        out.trim_end().to_string() + "\n"
    }

    // ---- serialisation -------------------------------------------------

    pub fn to_bytes(&self) -> Result<Vec<u8>> {
        let mut pkg = Package::new();
        let n = self.slides.len();

        // presentation.xml -------------------------------------------------
        let mut pres = String::with_capacity(1024);
        pres.push_str(xml::DECL);
        let _ = write!(
            pres,
            r#"<p:presentation xmlns:a="{NS_A}" xmlns:r="{NS_R}" xmlns:p="{NS_P}" saveSubsetFonts="1">"#
        );
        pres.push_str(
            r#"<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>"#,
        );
        pres.push_str("<p:sldIdLst>");
        for i in 0..n {
            let id = 256 + i;
            let rid = format!("rId{}", 6 + i);
            let _ = write!(pres, r#"<p:sldId id="{id}" r:id="{rid}"/>"#);
        }
        pres.push_str("</p:sldIdLst>");
        let (cx, cy) = if self.wide {
            (12_192_000, 6_858_000)
        } else {
            (9_144_000, 6_858_000)
        };
        let _ = write!(
            pres,
            r#"<p:sldSz cx="{cx}" cy="{cy}"/><p:notesSz cx="6858000" cy="9144000"/>"#
        );
        pres.push_str(r#"<p:defaultTextStyle><a:defPPr><a:defRPr lang="ja-JP"/></a:defPPr></p:defaultTextStyle>"#);
        pres.push_str("</p:presentation>");
        pkg.insert_str("ppt/presentation.xml", pres);

        let mut pres_rels: Vec<(String, String, String, bool)> = vec![
            (
                "rId1".into(),
                RT_MASTER.into(),
                "slideMasters/slideMaster1.xml".into(),
                false,
            ),
            (
                "rId2".into(),
                RT_THEME.into(),
                "theme/theme1.xml".into(),
                false,
            ),
            (
                "rId3".into(),
                RT_PRESPROPS.into(),
                "presProps.xml".into(),
                false,
            ),
            (
                "rId4".into(),
                RT_VIEWPROPS.into(),
                "viewProps.xml".into(),
                false,
            ),
            (
                "rId5".into(),
                RT_TABLESTYLES.into(),
                "tableStyles.xml".into(),
                false,
            ),
        ];
        for i in 0..n {
            pres_rels.push((
                format!("rId{}", 6 + i),
                RT_SLIDE.into(),
                format!("slides/slide{}.xml", i + 1),
                false,
            ));
        }
        pkg.insert_str("ppt/_rels/presentation.xml.rels", pkg::rels_xml(&pres_rels));

        // slides -----------------------------------------------------------
        let mut media_no = 0usize;
        let mut defaults: Vec<(String, String)> = Vec::new();
        let mut extra_overrides: Vec<(String, String)> = Vec::new();
        for (i, slide) in self.slides.iter().enumerate() {
            // リンク先 → rId を先に決めてから、スライド本体と rels の両方で使う。
            let link_rels = slide_link_rels(slide);
            pkg.insert_str(
                &format!("ppt/slides/slide{}.xml", i + 1),
                write_slide(slide, i + 1, self.wide, &link_rels),
            );
            let mut slide_rels: Vec<(String, String, String, bool)> = vec![(
                "rId1".into(),
                RT_LAYOUT.into(),
                "../slideLayouts/slideLayout1.xml".into(),
                false,
            )];
            for (k, img) in slide.images.iter().enumerate() {
                media_no += 1;
                let target = format!("../media/image{media_no}.{}", img.ext);
                slide_rels.push((
                    format!("rId{}", 10 + k),
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"
                        .into(),
                    target,
                    false,
                ));
                pkg.insert(
                    &format!("ppt/media/image{media_no}.{}", img.ext),
                    img.data.clone(),
                );
                let ct = if img.ext == "jpeg" {
                    "image/jpeg"
                } else {
                    "image/png"
                };
                if !defaults.iter().any(|(e, _)| *e == img.ext) {
                    defaults.push((img.ext.clone(), ct.into()));
                }
            }
            for (url, rid) in &link_rels {
                slide_rels.push((rid.clone(), RT_HYPERLINK.into(), url.clone(), true));
            }
            if !slide.notes.is_empty() {
                let nrid = format!("rId{}", slide_rels.len() + 1);
                slide_rels.push((
                    nrid,
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesSlide"
                        .into(),
                    format!("../notesSlides/notesSlide{}.xml", i + 1),
                    false,
                ));
                pkg.insert_str(
                    &format!("ppt/notesSlides/notesSlide{}.xml", i + 1),
                    write_notes(slide, i + 1),
                );
                pkg.insert_str(
                    &format!("ppt/notesSlides/_rels/notesSlide{}.xml.rels", i + 1),
                    pkg::rels_xml(&[
                        (
                            "rId1".into(),
                            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesMaster"
                                .into(),
                            "../notesMasters/notesMaster1.xml".into(),
                            false,
                        ),
                        (
                            "rId2".into(),
                            RT_SLIDE.into(),
                            format!("../slides/slide{}.xml", i + 1),
                            false,
                        ),
                    ]),
                );
                extra_overrides.push((
                    format!("/ppt/notesSlides/notesSlide{}.xml", i + 1),
                    "application/vnd.openxmlformats-officedocument.presentationml.notesSlide+xml"
                        .into(),
                ));
            }
            pkg.insert_str(
                &format!("ppt/slides/_rels/slide{}.xml.rels", i + 1),
                pkg::rels_xml(&slide_rels),
            );
        }
        let has_notes = self.slides.iter().any(|s| !s.notes.is_empty());
        if has_notes {
            pkg.insert_str("ppt/notesMasters/notesMaster1.xml", NOTES_MASTER_XML);
            pkg.insert_str(
                "ppt/notesMasters/_rels/notesMaster1.xml.rels",
                pkg::rels_xml(&[
                    (
                        "rId1".into(),
                        RT_THEME.into(),
                        "../theme/theme1.xml".into(),
                        false,
                    ),
                    (
                        "rId2".into(),
                        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme"
                            .into(),
                        "../theme/theme1.xml".into(),
                        false,
                    ),
                ]),
            );
            extra_overrides.push((
                "/ppt/notesMasters/notesMaster1.xml".into(),
                "application/vnd.openxmlformats-officedocument.presentationml.notesMaster+xml"
                    .into(),
            ));
        }

        // master / layout / theme -----------------------------------------
        pkg.insert_str("ppt/slideMasters/slideMaster1.xml", SLIDE_MASTER_XML);
        pkg.insert_str(
            "ppt/slideMasters/_rels/slideMaster1.xml.rels",
            pkg::rels_xml(&[
                (
                    "rId1".into(),
                    RT_LAYOUT.into(),
                    "../slideLayouts/slideLayout1.xml".into(),
                    false,
                ),
                (
                    "rId2".into(),
                    RT_THEME.into(),
                    "../theme/theme1.xml".into(),
                    false,
                ),
            ]),
        );
        pkg.insert_str("ppt/slideLayouts/slideLayout1.xml", SLIDE_LAYOUT_XML);
        pkg.insert_str(
            "ppt/slideLayouts/_rels/slideLayout1.xml.rels",
            pkg::rels_xml(&[(
                "rId1".into(),
                RT_MASTER.into(),
                "../slideMasters/slideMaster1.xml".into(),
                false,
            )]),
        );
        pkg.insert_str("ppt/theme/theme1.xml", theme_xml(&self.theme));
        pkg.insert_str("ppt/presProps.xml", PRES_PROPS_XML);
        pkg.insert_str("ppt/viewProps.xml", VIEW_PROPS_XML);
        pkg.insert_str("ppt/tableStyles.xml", TABLE_STYLES_XML);

        // package metadata -------------------------------------------------
        let mut overrides: Vec<(String, String)> = vec![
            (
                "/ppt/slideMasters/slideMaster1.xml".into(),
                CT_MASTER.into(),
            ),
            (
                "/ppt/slideLayouts/slideLayout1.xml".into(),
                CT_LAYOUT.into(),
            ),
            ("/ppt/theme/theme1.xml".into(), CT_THEME.into()),
            ("/ppt/presProps.xml".into(), CT_PRESPROPS.into()),
            ("/ppt/viewProps.xml".into(), CT_VIEWPROPS.into()),
            ("/ppt/tableStyles.xml".into(), CT_TABLESTYLES.into()),
            (
                "/docProps/core.xml".into(),
                "application/vnd.openxmlformats-package.core-properties+xml".into(),
            ),
            (
                "/docProps/app.xml".into(),
                "application/vnd.openxmlformats-officedocument.extended-properties+xml".into(),
            ),
        ];
        for i in 0..n {
            overrides.push((format!("/ppt/slides/slide{}.xml", i + 1), CT_SLIDE.into()));
        }
        overrides.extend(extra_overrides);
        pkg.insert_str(
            "[Content_Types].xml",
            pkg::content_types_xml_full("/ppt/presentation.xml", CT_PRES, &defaults, &overrides),
        );
        pkg.insert_str(
            "_rels/.rels",
            pkg::root_rels("ppt/presentation.xml", RT_PRESENTATION),
        );
        pkg.insert_str(
            "docProps/core.xml",
            pkg::core_xml(&self.title, &self.creator, &self.created),
        );
        pkg.insert_str(
            "docProps/app.xml",
            pkg::app_xml(
                &crate::producer(),
                &[
                    (
                        "PresentationFormat",
                        if self.wide {
                            "On-screen Show (16:9)"
                        } else {
                            "On-screen Show (4:3)"
                        },
                    ),
                    ("Slides", &n.to_string()),
                ],
            ),
        );

        pkg.to_bytes()
    }

    pub fn save(&self, path: impl AsRef<std::path::Path>) -> Result<()> {
        std::fs::write(path, self.to_bytes()?)?;
        Ok(())
    }

    pub fn from_bytes(bytes: &[u8]) -> Result<Self> {
        let pkg = Package::from_bytes(bytes)?;
        if !pkg.contains("ppt/presentation.xml") {
            return Err(Error::Format("missing ppt/presentation.xml".into()));
        }
        // Resolve slide order from the presentation relationships.
        let mut order: Vec<String> = Vec::new();
        if let Some(rels) = pkg.get_str("ppt/_rels/presentation.xml.rels") {
            let mut r = Reader::new(rels);
            loop {
                match r.next_event() {
                    Event::Start { name, attrs, .. } if xml::local(&name) == "Relationship" => {
                        let mut ty = String::new();
                        let mut target = String::new();
                        for (k, v) in attrs {
                            match xml::local(&k) {
                                "Type" => ty = v,
                                "Target" => target = v,
                                _ => {}
                            }
                        }
                        if ty.ends_with("/slide") {
                            order.push(pkg::resolve("ppt", &target));
                        }
                    }
                    Event::Eof => break,
                    _ => {}
                }
            }
        }
        if order.is_empty() {
            let mut names: Vec<&str> = pkg
                .names()
                .into_iter()
                .filter(|n| n.starts_with("ppt/slides/slide") && n.ends_with(".xml"))
                .collect();
            names.sort_by_key(|n| {
                n.rsplit("slide")
                    .next()
                    .and_then(|s| s.split('.').next())
                    .and_then(|s| s.parse::<u32>().ok())
                    .unwrap_or(0)
            });
            order = names.into_iter().map(|s| s.to_string()).collect();
        }
        let mut pres = Presentation::new();
        for part in order {
            if let Some(src) = pkg.get_str(&part).map(str::to_string) {
                let rels = slide_rels(&pkg, &part);
                pres.slides.push(read_slide(&src, &pkg, &rels));
            }
        }
        if let Some(core) = pkg.get_str("docProps/core.xml") {
            let mut r = Reader::new(core);
            loop {
                match r.next_event() {
                    Event::Start { name, .. } if xml::local(&name) == "title" => {
                        pres.title = r.read_text()
                    }
                    Event::Eof => break,
                    _ => {}
                }
            }
        }
        Ok(pres)
    }

    pub fn open(path: impl AsRef<std::path::Path>) -> Result<Self> {
        Presentation::from_bytes(&std::fs::read(path)?)
    }
}

/// スライド中のリンク先を重複なく並べ、`rId1000` から順に rId を割り当てる。
fn slide_link_rels(slide: &Slide) -> Vec<(String, String)> {
    let mut out: Vec<(String, String)> = Vec::new();
    fn add(out: &mut Vec<(String, String)>, url: &Option<String>) {
        let Some(url) = url.as_deref() else { return };
        if url.is_empty() || out.iter().any(|(u, _)| u == url) {
            return;
        }
        let rid = format!("rId{}", 1000 + out.len());
        out.push((url.to_string(), rid));
    }
    for b in &slide.bullets {
        add(&mut out, &b.link);
    }
    for img in &slide.images {
        add(&mut out, &img.link);
    }
    for sh in &slide.shapes {
        add(&mut out, &sh.link);
    }
    out
}

/// URL から rId を引く。
fn link_rid<'a>(links: &'a [(String, String)], url: Option<&str>) -> Option<&'a str> {
    let url = url?;
    if url.is_empty() {
        return None;
    }
    links
        .iter()
        .find(|(u, _)| u == url)
        .map(|(_, rid)| rid.as_str())
}

fn write_slide(slide: &Slide, index: usize, wide: bool, links: &[(String, String)]) -> String {
    let (cx, cy) = if wide {
        (12_192_000_i64, 6_858_000_i64)
    } else {
        (9_144_000_i64, 6_858_000_i64)
    };
    let mut s = String::with_capacity(1024);
    s.push_str(xml::DECL);
    let _ = write!(
        s,
        r#"<p:sld xmlns:a="{NS_A}" xmlns:r="{NS_R}" xmlns:p="{NS_P}">"#
    );
    s.push_str("<p:cSld>");
    s.push_str(r#"<p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg>"#);
    s.push_str("<p:spTree>");
    s.push_str(r#"<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>"#);
    s.push_str(r#"<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>"#);

    // Title text box
    let title_h = 1_200_000_i64;
    let margin = 700_000_i64;
    s.push_str(r#"<p:sp><p:nvSpPr>"#);
    let _ = write!(
        s,
        r#"<p:cNvPr id="2" name="Title {index}"/><p:cNvSpPr txBox="1"/><p:nvPr/>"#
    );
    s.push_str("</p:nvSpPr><p:spPr>");
    let _ = write!(
        s,
        r#"<a:xfrm><a:off x="{margin}" y="{y}"/><a:ext cx="{w}" cy="{title_h}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/>"#,
        y = 500_000,
        w = cx - margin * 2
    );
    s.push_str("</p:spPr><p:txBody>");
    s.push_str(r#"<a:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="t"><a:normAutofit/></a:bodyPr><a:lstStyle/>"#);
    s.push_str(r#"<a:p><a:pPr algn="l"/><a:r><a:rPr lang="ja-JP" altLang="en-US" sz="3200" b="1" dirty="0"><a:solidFill><a:srgbClr val="1F3864"/></a:solidFill><a:latin typeface="Yu Gothic UI"/><a:ea typeface="Yu Gothic UI"/></a:rPr>"#);
    s.push_str("<a:t>");
    xml::esc_into(&mut s, &slide.title);
    s.push_str("</a:t></a:r></a:p></p:txBody></p:sp>");

    // Body text box
    if !slide.bullets.is_empty() {
        let top = 500_000 + title_h + 200_000;
        let body_h = (cy - top - 500_000).max(500_000);
        s.push_str(r#"<p:sp><p:nvSpPr>"#);
        let _ = write!(
            s,
            r#"<p:cNvPr id="3" name="Body {index}"/><p:cNvSpPr txBox="1"/><p:nvPr/>"#
        );
        s.push_str("</p:nvSpPr><p:spPr>");
        let _ = write!(
            s,
            r#"<a:xfrm><a:off x="{margin}" y="{top}"/><a:ext cx="{w}" cy="{body_h}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/>"#,
            w = cx - margin * 2
        );
        s.push_str("</p:spPr><p:txBody>");
        s.push_str(r#"<a:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="t"><a:normAutofit/></a:bodyPr><a:lstStyle/>"#);
        for b in &slide.bullets {
            let level = b.level.min(4) as i64;
            let mar = 342_900 + level * 342_900;
            let _ = write!(
                s,
                r#"<a:p><a:pPr lvl="{lvl}" marL="{mar}" indent="-342900"><a:spcBef><a:spcPts val="600"/></a:spcBef><a:buFont typeface="Arial"/><a:buChar char="•"/></a:pPr><a:r><a:rPr lang="ja-JP" altLang="en-US" sz="{sz}" dirty="0"><a:solidFill><a:srgbClr val="262626"/></a:solidFill><a:latin typeface="Yu Gothic UI"/><a:ea typeface="Yu Gothic UI"/>"#,
                lvl = level,
                sz = if level == 0 { 2200 } else { 1800 }
            );
            // hlinkClick は a:rPr の子要素の「最後」(ea/cs の後) に置く必要がある。
            if let Some(rid) = link_rid(links, b.link.as_deref()) {
                let _ = write!(s, r#"<a:hlinkClick r:id="{rid}"/>"#);
            }
            s.push_str("</a:rPr><a:t>");
            xml::esc_into(&mut s, &b.text);
            s.push_str("</a:t></a:r></a:p>");
        }
        s.push_str("</p:txBody></p:sp>");
    }

    // Pictures ------------------------------------------------------------
    for (i, img) in slide.images.iter().enumerate() {
        let id = 10 + i;
        let name = if img.name.is_empty() {
            format!("Picture {i}")
        } else {
            img.name.clone()
        };
        s.push_str("<p:pic><p:nvPicPr>");
        match link_rid(links, img.link.as_deref()) {
            Some(rid) => {
                let _ = write!(
                    s,
                    r#"<p:cNvPr id="{id}" name="{}"><a:hlinkClick r:id="{rid}"/></p:cNvPr>"#,
                    xml::esc(&name)
                );
            }
            None => {
                let _ = write!(s, r#"<p:cNvPr id="{id}" name="{}"/>"#, xml::esc(&name));
            }
        }
        let _ = write!(
            s,
            r#"<p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="rId{}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>"#,
            10 + i,
            x = img.x,
            y = img.y,
            cx = img.cx.max(1),
            cy = img.cy.max(1)
        );
    }

    // Shapes --------------------------------------------------------------
    for (i, shape) in slide.shapes.iter().enumerate() {
        let id = 50 + i;
        s.push_str("<p:sp><p:nvSpPr>");
        match link_rid(links, shape.link.as_deref()) {
            Some(rid) => {
                let _ = write!(
                    s,
                    r#"<p:cNvPr id="{id}" name="図形 {n}"><a:hlinkClick r:id="{rid}"/></p:cNvPr>"#,
                    n = i + 1
                );
            }
            None => {
                let _ = write!(s, r#"<p:cNvPr id="{id}" name="図形 {n}"/>"#, n = i + 1);
            }
        }
        let _ = write!(
            s,
            r#"<p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="{prst}"><a:avLst/></a:prstGeom>"#,
            x = shape.x,
            y = shape.y,
            cx = shape.cx.max(1),
            cy = shape.cy.max(1),
            prst = shape.kind.prst()
        );
        match &shape.fill {
            Some(hex) => {
                let _ = write!(
                    s,
                    r#"<a:solidFill><a:srgbClr val="{}"/></a:solidFill>"#,
                    xml::esc(hex)
                );
            }
            None => s.push_str(r#"<a:solidFill><a:schemeClr val="accent1"/></a:solidFill>"#),
        }
        match &shape.line {
            Some(hex) => {
                let _ = write!(
                    s,
                    r#"<a:ln w="19050"><a:solidFill><a:srgbClr val="{}"/></a:solidFill></a:ln>"#,
                    xml::esc(hex)
                );
            }
            None => s.push_str(r#"<a:ln><a:noFill/></a:ln>"#),
        }
        s.push_str("</p:spPr><p:txBody><a:bodyPr anchor=\"ctr\" lIns=\"91440\" rIns=\"91440\"><a:normAutofit/></a:bodyPr><a:lstStyle/><a:p><a:pPr algn=\"ctr\"/>");
        if !shape.text.is_empty() {
            s.push_str(r#"<a:r><a:rPr lang="ja-JP" altLang="en-US" sz="1600" dirty="0"><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill></a:rPr><a:t>"#);
            xml::esc_into(&mut s, &shape.text);
            s.push_str("</a:t></a:r>");
        }
        s.push_str("</a:p></p:txBody></p:sp>");
    }

    s.push_str("</p:spTree></p:cSld>");
    s.push_str(r#"<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>"#);
    if let Some(t) = slide.transition.xml() {
        let _ = write!(s, r#"<p:transition spd="med">{t}</p:transition>"#);
    }
    if slide.animate {
        s.push_str(&timing_xml(index, slide));
    }
    s.push_str("</p:sld>");
    s
}

/// `<p:timing>`: fade the title in, then **one bullet paragraph at a time**,
/// then every picture / shape — one click per step, exactly like PowerPoint's
/// 「アニメーション」.
fn timing_xml(index: usize, slide: &Slide) -> String {
    /// 1 ステップ分の `<p:par>` を書く。
    fn step(out: &mut String, id: u32, target: u32, para: Option<usize>) {
        let p_rg = match para {
            Some(i) => format!(r#"<p:txEl><p:pRg st="{i}" end="{i}"/></p:txEl>"#),
            None => String::new(),
        };
        let _ = write!(
            out,
            r#"<p:par><p:cTn id="{id}" fill="hold"><p:stCondLst><p:cond delay="indefinite"/></p:stCondLst><p:childTnLst><p:par><p:cTn id="{i1}" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst><p:animEffect transition="in" filter="fade"><p:cBhvr><p:cTn id="{i2}" dur="500"/><p:tgtEl><p:spTgt spid="{target}">{p_rg}</p:spTgt></p:tgtEl></p:cBhvr></p:animEffect></p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn></p:par>"#,
            i1 = id + 1,
            i2 = id + 2
        );
    }

    let mut steps: Vec<(u32, Option<usize>)> = vec![(2, None)];
    for i in 0..slide.bullets.len() {
        steps.push((3, Some(i)));
    }
    for i in 0..slide.images.len() {
        steps.push((10 + i as u32, None));
    }
    for i in 0..slide.shapes.len() {
        steps.push((50 + i as u32, None));
    }

    let mut s = String::with_capacity(512 + steps.len() * 380);
    s.push_str(
        r#"<p:timing><p:tnLst><p:par><p:cTn id="1" dur="indefinite" restart="never" nodeType="tmRoot"><p:childTnLst><p:seq concurrent="1" nextAc="seek"><p:cTn id="2" dur="indefinite" nodeType="mainSeq"><p:childTnLst>"#,
    );
    let mut id = 3;
    for (target, para) in &steps {
        step(&mut s, id, *target, *para);
        id += 3;
    }
    s.push_str(
        r#"</p:childTnLst></p:cTn><p:prevCondLst><p:cond evt="onPrev" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:prevCondLst><p:nextCondLst><p:cond evt="onNext" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:nextCondLst></p:seq></p:childTnLst></p:cTn></p:par></p:tnLst><p:bldLst>"#,
    );
    // 本文テキストボックスは「段落ごと」に build する。
    if !slide.bullets.is_empty() {
        s.push_str(r#"<p:bldP spid="3" grpId="0" build="p"/>"#);
    }
    s.push_str(r#"<p:bldP spid="2" grpId="0"/>"#);
    for i in 0..slide.images.len() {
        let _ = write!(s, r#"<p:bldP spid="{}" grpId="0"/>"#, 10 + i);
    }
    for i in 0..slide.shapes.len() {
        let _ = write!(s, r#"<p:bldP spid="{}" grpId="0"/>"#, 50 + i);
    }
    s.push_str("</p:bldLst></p:timing>");
    let _ = index;
    s
}

/// `notesSlideN.xml` — the 発表者ノート pane.
fn write_notes(slide: &Slide, index: usize) -> String {
    let mut s = String::with_capacity(512);
    s.push_str(xml::DECL);
    let _ = write!(
        s,
        r#"<p:notes xmlns:a="{NS_A}" xmlns:r="{NS_R}" xmlns:p="{NS_P}"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>"#
    );
    s.push_str(r#"<p:sp><p:nvSpPr><p:cNvPr id="2" name="Notes Placeholder"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/>"#);
    let _ = write!(
        s,
        r#"<a:p><a:r><a:rPr lang="ja-JP" altLang="en-US" dirty="0"/><a:t>"#
    );
    xml::esc_into(&mut s, &slide.notes);
    s.push_str("</a:t></a:r></a:p></p:txBody></p:sp>");
    s.push_str("</p:spTree></p:cSld>");
    let _ = index;
    s.push_str("</p:notes>");
    s
}

/// 1 スライド分のリレーション (`rId` → 解決済みターゲット)。
fn slide_rels(pkg: &Package, slide_part: &str) -> Vec<(String, String)> {
    let base = match slide_part.rfind('/') {
        Some(i) => &slide_part[..i],
        None => "ppt/slides",
    };
    let file = slide_part.rsplit('/').next().unwrap_or(slide_part);
    let rels_name = format!("{base}/_rels/{file}.rels");
    let Some(src) = pkg.get_str(&rels_name) else {
        return Vec::new();
    };
    let mut out: Vec<(String, String)> = Vec::new();
    let mut r = Reader::new(src);
    loop {
        match r.next_event() {
            Event::Start { name, attrs, .. } if xml::local(&name) == "Relationship" => {
                let mut id = String::new();
                let mut target = String::new();
                let mut external = false;
                for (k, v) in attrs {
                    match xml::local(&k) {
                        "Id" => id = v,
                        "Target" => target = v,
                        "TargetMode" => external = v == "External",
                        _ => {}
                    }
                }
                if id.is_empty() || target.is_empty() {
                    continue;
                }
                let resolved = if external {
                    target
                } else {
                    pkg::resolve(base, &target)
                };
                out.push((id, resolved));
            }
            Event::Eof => break,
            _ => {}
        }
    }
    out
}

fn rel_target<'a>(rels: &'a [(String, String)], rid: &str) -> Option<&'a str> {
    rels.iter()
        .find(|(id, _)| id == rid)
        .map(|(_, t)| t.as_str())
}

/// `<p:sp>` / `<p:pic>` など、名前で指定した要素のバイト範囲を列挙する
/// (入れ子は無いので素直なスキャンで足りる)。
fn element_ranges(src: &str, tag: &str) -> Vec<(usize, usize)> {
    let open = format!("<p:{tag}");
    let close = format!("</p:{tag}>");
    let mut out = Vec::new();
    let mut pos = 0usize;
    while let Some(i) = src[pos..].find(&open) {
        let start = pos + i;
        let after = start + open.len();
        let next = src[after..].chars().next();
        if !matches!(
            next,
            Some('>') | Some(' ') | Some('\t') | Some('\n') | Some('\r')
        ) {
            pos = after;
            continue;
        }
        let Some(gt) = src[start..].find('>') else {
            break;
        };
        if src[start..start + gt].trim_end().ends_with('/') {
            pos = start + gt + 1;
            continue;
        }
        let Some(j) = src[start..].find(&close) else {
            break;
        };
        let end = start + j + close.len();
        out.push((start, end));
        pos = end;
    }
    out
}

/// 図形 / 画像 1 個分の読み取り結果。
#[derive(Debug, Default)]
struct RawShape {
    name: String,
    prst: String,
    x: i64,
    y: i64,
    cx: i64,
    cy: i64,
    fill: Option<String>,
    line: Option<String>,
    text: String,
    /// `rId` (rels で解決する)
    link: Option<String>,
    blip: Option<String>,
    placeholder: bool,
    /// 塗り (solidFill) を持つか = 本物の図形かどうかの判定に使う。
    solid: bool,
}

fn attr<'a>(attrs: &'a [(String, String)], name: &str) -> Option<&'a str> {
    attrs
        .iter()
        .find(|(k, _)| xml::local(k) == name)
        .map(|(_, v)| v.as_str())
}

fn num_attr(attrs: &[(String, String)], name: &str) -> i64 {
    attr(attrs, name)
        .and_then(|v| v.parse::<i64>().ok())
        .unwrap_or(0)
}

fn parse_element(src: &str) -> RawShape {
    let mut o = RawShape::default();
    let mut r = Reader::new(src);
    let mut solid_depth = 0u32;
    // 図形の「塗り」は p:spPr の中だけ。a:rPr の solidFill は文字色なので混同しない。
    let mut in_sp_pr = 0u32;
    let mut in_ln = 0u32;
    loop {
        match r.next_event() {
            Event::Start { name, attrs, .. } => match xml::local(&name) {
                "cNvPr" => {
                    if let Some(n) = attr(&attrs, "name") {
                        o.name = n.to_string();
                    }
                }
                "hlinkClick" => {
                    if let Some(id) = attr(&attrs, "id") {
                        o.link = Some(id.to_string());
                    }
                }
                "off" => {
                    o.x = num_attr(&attrs, "x");
                    o.y = num_attr(&attrs, "y");
                }
                "ext" => {
                    o.cx = num_attr(&attrs, "cx");
                    o.cy = num_attr(&attrs, "cy");
                }
                "prstGeom" => {
                    if let Some(p) = attr(&attrs, "prst") {
                        o.prst = p.to_string();
                    }
                }
                "spPr" => in_sp_pr += 1,
                "ln" => in_ln += 1,
                "solidFill" => {
                    if in_sp_pr > 0 {
                        solid_depth += 1;
                    }
                }
                "srgbClr" => {
                    if in_sp_pr > 0 && solid_depth > 0 {
                        if let Some(v) = attr(&attrs, "val") {
                            let hex = v.to_ascii_uppercase();
                            if in_ln > 0 {
                                o.line = Some(hex);
                            } else {
                                o.solid = true;
                                if o.fill.is_none() {
                                    o.fill = Some(hex);
                                }
                            }
                        }
                    }
                }
                "blip" => {
                    if let Some(e) = attr(&attrs, "embed") {
                        o.blip = Some(e.to_string());
                    }
                }
                "ph" => o.placeholder = true,
                "t" => o.text.push_str(&r.read_text()),
                _ => {}
            },
            Event::End { name } => match xml::local(&name) {
                "solidFill" => solid_depth = solid_depth.saturating_sub(1),
                "spPr" => in_sp_pr = in_sp_pr.saturating_sub(1),
                "ln" => in_ln = in_ln.saturating_sub(1),
                _ => {}
            },
            Event::Eof => break,
            _ => {}
        }
    }
    o
}

fn shape_kind_from(prst: &str) -> ShapeKind {
    match prst {
        "roundRect" => ShapeKind::RoundedRect,
        "ellipse" | "circle" => ShapeKind::Ellipse,
        "triangle" => ShapeKind::Triangle,
        "rightArrow" => ShapeKind::RightArrow,
        "line" | "straightConnector1" => ShapeKind::Line,
        "star5" => ShapeKind::Star5,
        "chevron" => ShapeKind::Chevron,
        "diamond" => ShapeKind::Diamond,
        _ => ShapeKind::Rect,
    }
}

/// 画面切り替え要素 (`<p:fade/>` など) から `Transition` へ。
fn transition_from_element(local: &str) -> Option<Transition> {
    Some(match local {
        "fade" => Transition::Fade,
        "push" => Transition::Push,
        "wipe" => Transition::Wipe,
        "split" => Transition::Split,
        "cover" => Transition::Cover,
        _ => return None,
    })
}

fn read_slide(src: &str, pkg: &Package, rels: &[(String, String)]) -> Slide {
    // ---- 図形 / 画像を先に切り出し、本文テキストの走査対象から外す --------
    let mut shapes: Vec<Shape> = Vec::new();
    let mut images: Vec<SlideImage> = Vec::new();
    let mut skip: Vec<(usize, usize)> = Vec::new();

    for (a, b) in element_ranges(src, "sp") {
        let raw = parse_element(&src[a..b]);
        // タイトル / 本文のテキストボックスは塗りを持たない → 本文として読む。
        let is_text_box = raw.placeholder || !raw.solid;
        if is_text_box {
            continue;
        }
        let mut shape = Shape {
            kind: shape_kind_from(&raw.prst),
            x: raw.x,
            y: raw.y,
            cx: raw.cx,
            cy: raw.cy,
            text: raw.text,
            fill: raw.fill,
            line: raw.line,
            link: raw
                .link
                .as_deref()
                .and_then(|rid| rel_target(rels, rid))
                .map(str::to_string),
        };
        let _ = &mut shape;
        shapes.push(shape);
        skip.push((a, b));
    }

    for (a, b) in element_ranges(src, "pic") {
        let raw = parse_element(&src[a..b]);
        skip.push((a, b));
        let Some(part) = raw.blip.as_deref().and_then(|rid| rel_target(rels, rid)) else {
            continue;
        };
        let Some(bytes) = pkg.get(part) else { continue };
        let ext = part.rsplit('.').next().unwrap_or("png").to_string();
        images.push(SlideImage {
            data: bytes.to_vec(),
            ext,
            x: raw.x,
            y: raw.y,
            cx: raw.cx,
            cy: raw.cy,
            name: raw.name,
            link: raw
                .link
                .as_deref()
                .and_then(|rid| rel_target(rels, rid))
                .map(str::to_string),
        });
    }

    // 図形・画像のサブツリーを除いた本文だけを段落走査する。
    let mut clean = String::with_capacity(src.len());
    skip.sort_by_key(|(a, _)| *a);
    let mut cursor = 0usize;
    for (a, b) in &skip {
        if *a < cursor {
            continue;
        }
        clean.push_str(&src[cursor..*a]);
        cursor = *b;
    }
    clean.push_str(&src[cursor..]);

    // ---- 本文段落 --------------------------------------------------------
    struct Para {
        text: String,
        level: u8,
        is_title: bool,
        link: Option<String>,
    }
    let mut paras: Vec<Para> = Vec::new();
    let mut cur = String::new();
    let mut cur_level: u8 = 0;
    let mut cur_is_title = false;
    let mut cur_link: Option<String> = None;
    let mut transition = Transition::None;
    let mut animate = false;
    let mut in_transition = false;
    let mut r = Reader::new(&clean);
    loop {
        match r.next_event() {
            Event::Start { name, attrs, .. } => match xml::local(&name) {
                "sp" => cur_is_title = false,
                "ph" => {
                    if attr(&attrs, "type")
                        .map(|v| v == "title" || v == "ctrTitle")
                        .unwrap_or(false)
                    {
                        cur_is_title = true;
                    }
                }
                "pPr" => {
                    cur_level = attr(&attrs, "lvl")
                        .and_then(|v| v.parse::<u8>().ok())
                        .unwrap_or(0)
                        .min(8);
                }
                "p" => {
                    cur.clear();
                    cur_level = 0;
                    cur_link = None;
                }
                "hlinkClick" => {
                    if let Some(id) = attr(&attrs, "id") {
                        cur_link = rel_target(rels, id).map(str::to_string);
                    }
                }
                "transition" => in_transition = true,
                "timing" => animate = true,
                other => {
                    if in_transition {
                        if let Some(t) = transition_from_element(other) {
                            transition = t;
                        }
                    }
                }
            },
            Event::End { name } => match xml::local(&name) {
                "p" => {
                    let text = cur.trim().to_string();
                    if !text.is_empty() {
                        paras.push(Para {
                            text,
                            level: cur_level,
                            is_title: cur_is_title,
                            link: cur_link.clone(),
                        });
                    }
                    cur.clear();
                    cur_is_title = false;
                    cur_link = None;
                }
                "sp" => cur_is_title = false,
                "transition" => in_transition = false,
                _ => {}
            },
            Event::Text(t) => cur.push_str(&t),
            Event::Eof => break,
        }
    }
    let _ = &mut cur;

    let mut slide = Slide {
        transition,
        animate,
        ..Slide::default()
    };
    slide.shapes = shapes;
    slide.images = images;
    let mut first_body = true;
    for p in paras {
        if p.is_title && slide.title.is_empty() {
            slide.title = p.text;
            continue;
        }
        if slide.title.is_empty() && first_body && p.level == 0 {
            slide.title = p.text;
        } else {
            slide.bullets.push(Bullet {
                text: p.text,
                level: p.level,
                link: p.link,
            });
        }
        first_body = false;
    }
    slide
}

const SLIDE_MASTER_XML: &str = concat!(
    r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"#,
    r#"<p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">"#,
    r#"<p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree>"#,
    r#"<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>"#,
    r#"<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>"#,
    r#"<p:sp><p:nvSpPr><p:cNvPr id="2" name="Title Placeholder 1"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr>"#,
    r#"<p:spPr><a:xfrm><a:off x="700000" y="500000"/><a:ext cx="10792000" cy="1200000"/></a:xfrm></p:spPr>"#,
    r#"<p:txBody><a:bodyPr anchor="t"/><a:lstStyle/><a:p><a:r><a:rPr lang="ja-JP"/><a:t>タイトル</a:t></a:r></a:p></p:txBody></p:sp>"#,
    r#"<p:sp><p:nvSpPr><p:cNvPr id="3" name="Text Placeholder 2"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr>"#,
    r#"<p:spPr><a:xfrm><a:off x="700000" y="1900000"/><a:ext cx="10792000" cy="4458000"/></a:xfrm></p:spPr>"#,
    r#"<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="ja-JP"/></a:p></p:txBody></p:sp>"#,
    r#"</p:spTree></p:cSld>"#,
    r#"<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>"#,
    r#"<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>"#,
    r#"<p:txStyles>"#,
    r#"<p:titleStyle><a:lvl1pPr algn="l"><a:defRPr sz="3200" b="1"><a:solidFill><a:schemeClr val="tx2"/></a:solidFill><a:latin typeface="+mj-lt"/></a:defRPr></a:lvl1pPr></p:titleStyle>"#,
    r#"<p:bodyStyle><a:lvl1pPr marL="342900" indent="-342900"><a:spcBef><a:spcPts val="600"/></a:spcBef><a:buFont typeface="Arial"/><a:buChar char="•"/><a:defRPr sz="2200"/></a:lvl1pPr><a:lvl2pPr marL="742950" indent="-285750"><a:buFont typeface="Arial"/><a:buChar char="–"/><a:defRPr sz="2000"/></a:lvl2pPr></p:bodyStyle>"#,
    r#"<p:otherStyle><a:defPPr><a:defRPr lang="ja-JP"/></a:defPPr></p:otherStyle>"#,
    r#"</p:txStyles></p:sldMaster>"#
);

const SLIDE_LAYOUT_XML: &str = concat!(
    r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"#,
    r#"<p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" type="obj" preserve="1">"#,
    r#"<p:cSld name="Title and Content"><p:spTree>"#,
    r#"<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>"#,
    r#"<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>"#,
    r#"<p:sp><p:nvSpPr><p:cNvPr id="2" name="Title 1"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr>"#,
    r#"<p:spPr><a:xfrm><a:off x="700000" y="500000"/><a:ext cx="10792000" cy="1200000"/></a:xfrm></p:spPr>"#,
    r#"<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="ja-JP"/><a:t>タイトル</a:t></a:r></a:p></p:txBody></p:sp>"#,
    r#"<p:sp><p:nvSpPr><p:cNvPr id="3" name="Content 2"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph idx="1"/></p:nvPr></p:nvSpPr>"#,
    r#"<p:spPr><a:xfrm><a:off x="700000" y="1900000"/><a:ext cx="10792000" cy="4458000"/></a:xfrm></p:spPr>"#,
    r#"<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="ja-JP"/></a:p></p:txBody></p:sp>"#,
    r#"</p:spTree></p:cSld>"#,
    r#"<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>"#
);

const PRES_PROPS_XML: &str = concat!(
    r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"#,
    r#"<p:presentationPr xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"/>"#
);

const VIEW_PROPS_XML: &str = concat!(
    r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"#,
    r#"<p:viewPr xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:normalViewPr><p:restoredLeft sz="15620"/><p:restoredTop sz="94660"/></p:normalViewPr><p:gridSpacing cx="76200" cy="76200"/></p:viewPr>"#
);

const TABLE_STYLES_XML: &str = concat!(
    r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"#,
    r#"<a:tblStyleLst xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" def="{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}"/>"#
);

/// The theme part for this deck: the shipped palette with the colours and
/// fonts the caller chose substituted in.
pub fn theme_xml(theme: &Theme) -> String {
    let base = Theme::office();
    let mut out = THEME_XML.to_string();
    out = out.replace(
        r#"name="Poccham""#,
        &format!(r#"name="{}""#, xml::esc(&theme.name)),
    );
    out = out.replace(
        &format!(r#"<a:dk1><a:srgbClr val="{}"/>"#, base.dk1),
        &format!(r#"<a:dk1><a:srgbClr val="{}"/>"#, xml::esc(&theme.dk1)),
    );
    out = out.replace(
        &format!(r#"<a:lt1><a:srgbClr val="{}"/>"#, base.lt1),
        &format!(r#"<a:lt1><a:srgbClr val="{}"/>"#, xml::esc(&theme.lt1)),
    );
    for (i, (old, new)) in base.accents.iter().zip(theme.accents.iter()).enumerate() {
        out = out.replace(
            &format!(r#"<a:accent{}><a:srgbClr val="{}"/>"#, i + 1, old),
            &format!(r#"<a:accent{}><a:srgbClr val="{}"/>"#, i + 1, xml::esc(new)),
        );
    }
    out = out.replace(
        r#"typeface="Yu Gothic UI""#,
        &format!(r#"typeface="{}""#, xml::esc(&theme.font)),
    );
    out
}

const NOTES_MASTER_XML: &str = concat!(
    r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"#,
    r#"<p:notesMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">"#,
    r#"<p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>"#,
    r#"<p:sp><p:nvSpPr><p:cNvPr id="2" name="Slide Image Placeholder 1"/><p:cNvSpPr><a:spLocks noGrp="1" noRot="1" noChangeAspect="1"/></p:cNvSpPr><p:nvPr><p:ph type="sldImg" idx="2"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="381000" y="685800"/><a:ext cx="6096000" cy="3429000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln w="12700"><a:solidFill><a:prstClr val="black"/></a:solidFill></a:ln></p:spPr></p:sp>"#,
    r#"<p:sp><p:nvSpPr><p:cNvPr id="3" name="Notes Placeholder 2"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" sz="quarter" idx="3"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="381000" y="4343400"/><a:ext cx="6096000" cy="4114800"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr lvl="0"/><a:r><a:rPr lang="ja-JP" altLang="en-US"/><a:t>クリックしてメモを入力</a:t></a:r></a:p></p:txBody></p:sp>"#,
    r#"</p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/><p:notesStyle><a:lvl1pPr marL="0" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1200" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl1pPr></p:notesStyle></p:notesMaster>"#
);

const THEME_XML: &str = concat!(
    r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"#,
    r#"<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Poccham">"#,
    r#"<a:themeElements>"#,
    r#"<a:clrScheme name="Poccham"><a:dk1><a:srgbClr val="262626"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="1F3864"/></a:dk2><a:lt2><a:srgbClr val="F4F5F7"/></a:lt2>"#,
    r#"<a:accent1><a:srgbClr val="2E5496"/></a:accent1><a:accent2><a:srgbClr val="C55A11"/></a:accent2><a:accent3><a:srgbClr val="2F7D6D"/></a:accent3><a:accent4><a:srgbClr val="7C4DA0"/></a:accent4><a:accent5><a:srgbClr val="B8902B"/></a:accent5><a:accent6><a:srgbClr val="4A6FA5"/></a:accent6>"#,
    r#"<a:hlink><a:srgbClr val="0F62C6"/></a:hlink><a:folHlink><a:srgbClr val="7C4DA0"/></a:folHlink></a:clrScheme>"#,
    r#"<a:fontScheme name="Poccham"><a:majorFont><a:latin typeface="Yu Gothic UI"/><a:ea typeface="Yu Gothic UI"/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Yu Gothic UI"/><a:ea typeface="Yu Gothic UI"/><a:cs typeface=""/></a:minorFont></a:fontScheme>"#,
    r#"<a:fmtScheme name="Poccham">"#,
    r#"<a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"><a:tint val="45000"/><a:satMod val="150000"/></a:schemeClr></a:solidFill><a:solidFill><a:schemeClr val="phClr"><a:shade val="80000"/><a:satMod val="120000"/></a:schemeClr></a:solidFill></a:fillStyleLst>"#,
    r#"<a:lnStyleLst><a:ln w="6350" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln><a:ln w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln><a:ln w="19050" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln></a:lnStyleLst>"#,
    r#"<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst><a:outerShdw blurRad="57150" dist="19050" dir="5400000" algn="ctr" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="63000"/></a:srgbClr></a:outerShdw></a:effectLst></a:effectStyle></a:effectStyleLst>"#,
    r#"<a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"><a:tint val="95000"/><a:satMod val="170000"/></a:schemeClr></a:solidFill><a:solidFill><a:schemeClr val="phClr"><a:shade val="93000"/><a:satMod val="135000"/></a:schemeClr></a:solidFill></a:bgFillStyleLst>"#,
    r#"</a:fmtScheme></a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/></a:theme>"#
);

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn presentation_roundtrip() {
        let mut pres = Presentation::new();
        pres.title = "提案資料".into();
        pres.add(
            Slide::new("現状の課題")
                .bullet("起動が遅い")
                .sub_bullet("計測: 12 秒"),
        );
        pres.add(Slide::new("提案").bullet("Rust で置き換える"));

        let bytes = pres.to_bytes().unwrap();
        let back = Presentation::from_bytes(&bytes).unwrap();
        assert_eq!(back.slides.len(), 2);
        assert_eq!(back.slides[0].title, "現状の課題");
        assert_eq!(back.slides[0].bullets.len(), 2);
        assert_eq!(back.slides[1].title, "提案");
        // Required parts must be present.
        let pkg = Package::from_bytes(&bytes).unwrap();
        for part in [
            "ppt/slideMasters/slideMaster1.xml",
            "ppt/slideLayouts/slideLayout1.xml",
            "ppt/theme/theme1.xml",
            "ppt/presProps.xml",
            "ppt/viewProps.xml",
            "[Content_Types].xml",
        ] {
            assert!(pkg.contains(part), "missing {part}");
        }
    }

    #[test]
    fn markdown_becomes_slides() {
        let md = "# Q1\n- 売上 +12%\n## Q2\n- 施策 A\n  - 詳細\n";
        let pres = Presentation::from_markdown(md);
        assert_eq!(pres.slides.len(), 2);
        assert_eq!(pres.slides[0].title, "Q1");
        assert_eq!(pres.slides[1].bullets[1].level, 1);
        assert!(pres.to_markdown().contains("## Slide 1: Q1"));
    }

    #[test]
    fn rejects_wrong_package() {
        assert!(Presentation::from_bytes(b"PK\x03\x04nonsense").is_err());
    }
}
