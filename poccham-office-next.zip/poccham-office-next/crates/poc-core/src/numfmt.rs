//! Excel number-format codes (`0.00`, `#,##0;[Red]-#,##0`, `yyyy-mm-dd`,
//! `0.0%`, `¥#,##0`, `@"様"`, …).
//!
//! Used by `TEXT()` and by the grid's cell rendering, so a cell that says
//! `¥1,234,567` in Excel says the same thing here. A format has up to four
//! sections separated by `;`: positive; negative; zero; text.

use crate::date::DateTime;
use crate::xlsx::format_number;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Align {
    Left,
    Center,
    Right,
}

/// Render `value` with `code`. Numbers use the numeric sections, text the
/// fourth section (or is returned unchanged when there is none).
pub fn format_value(code: &str, value: &FormatValue) -> String {
    match value {
        FormatValue::Number(n) => format_number_code(code, *n),
        FormatValue::Text(t) => {
            let sections = split_sections(code);
            let section = match sections.get(3) {
                Some(sec) => Some(sec),
                None => sections.first().filter(|sec| sec.contains('@')),
            };
            match section {
                Some(sec) => fill_text_placeholder(sec, t),
                None => t.clone(),
            }
        }
        FormatValue::Bool(b) => {
            if *b {
                "TRUE".into()
            } else {
                "FALSE".into()
            }
        }
    }
}

/// Expand a text-section format (`@"様"` → `山田様`).
fn fill_text_placeholder(section: &str, value: &str) -> String {
    let mut out = String::new();
    let mut chars = section.chars().peekable();
    while let Some(c) = chars.next() {
        match c {
            '@' => out.push_str(value),
            '"' => {
                for n in chars.by_ref() {
                    if n == '"' {
                        break;
                    }
                    out.push(n);
                }
            }
            '\\' => {
                if let Some(n) = chars.next() {
                    out.push(n);
                }
            }
            '_' | '*' => {
                chars.next();
            }
            other => out.push(other),
        }
    }
    out
}

#[derive(Debug, Clone, PartialEq)]
pub enum FormatValue {
    Number(f64),
    Text(String),
    Bool(bool),
}

fn split_sections(code: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut in_quote = false;
    let mut chars = code.chars().peekable();
    while let Some(c) = chars.next() {
        match c {
            '"' => {
                in_quote = !in_quote;
                cur.push(c);
            }
            '\\' => {
                cur.push(c);
                if let Some(n) = chars.next() {
                    cur.push(n);
                }
            }
            ';' if !in_quote => {
                out.push(std::mem::take(&mut cur));
            }
            _ => cur.push(c),
        }
    }
    out.push(cur);
    out
}

/// Whether a format code describes a date/time rather than a number.
pub fn is_date_code(code: &str) -> bool {
    let lower = code.to_ascii_lowercase();
    let stripped: String = lower.chars().filter(|c| !matches!(c, '"' | '\\')).collect();
    stripped.contains('y')
        || stripped.contains('d')
        || stripped.contains("h")
        || stripped.contains('m') && !stripped.contains('0')
}

/// Whether `code` right-aligns its value (all numeric formats do).
pub fn alignment(code: &str) -> Option<Align> {
    if code.contains('*') || code.trim().is_empty() {
        return None;
    }
    None
}

pub fn format_number_code(code: &str, n: f64) -> String {
    let sections = split_sections(code);
    let (section, value) = pick_section(&sections, n);
    let Some(section) = section else {
        return format_number(n);
    };
    if section.trim().is_empty() {
        return if code.trim().is_empty() {
            format_number(n)
        } else {
            String::new() // an empty middle section prints nothing
        };
    }
    if is_date_section(&section) {
        return format_date_section(&section, n);
    }
    format_numeric_section(&section, value)
}

fn pick_section(sections: &[String], n: f64) -> (Option<String>, f64) {
    let has_neg = sections.len() >= 2 && !sections[1].trim().is_empty();
    if n < 0.0 && has_neg {
        (Some(sections[1].clone()), n.abs())
    } else if n == 0.0 && sections.len() >= 3 && !sections[2].trim().is_empty() {
        (Some(sections[2].clone()), n)
    } else {
        (sections.first().cloned(), n)
    }
}

fn is_date_section(section: &str) -> bool {
    let lower = section.to_ascii_lowercase();
    if lower.contains("general") {
        return false;
    }
    // strip quoted literals and `[Red]`-style groups so they cannot be
    // mistaken for date tokens
    let mut out = String::new();
    let mut in_quote = false;
    let mut in_bracket = false;
    for c in lower.chars() {
        match c {
            '"' => in_quote = !in_quote,
            '[' if !in_quote => in_bracket = true,
            ']' if in_bracket => in_bracket = false,
            _ if !in_quote && !in_bracket => out.push(c),
            _ => {}
        }
    }
    out.contains('y') || out.contains('d') || out.contains("h:") || out.contains(":m")
}

fn format_date_section(section: &str, serial: f64) -> String {
    let dt = DateTime::from_serial(serial);
    let lower = section.to_ascii_lowercase();
    let ampm = lower.contains("am/pm") || lower.contains("a/p");
    let mut out = String::new();
    let chars: Vec<char> = section.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i].to_ascii_lowercase();
        let run = chars[i..]
            .iter()
            .take_while(|x| x.to_ascii_lowercase() == c)
            .count();
        match c {
            'y' => out.push_str(&match run {
                0..=1 => format!("{:02}", dt.year % 100),
                2 => format!("{:02}", dt.year % 100),
                _ => format!("{:04}", dt.year),
            }),
            'm' => {
                // `m` is minutes when it directly follows `h` or precedes `s`
                let prev_h = chars[..i]
                    .iter()
                    .rev()
                    .find(|x| x.is_alphabetic())
                    .map(|x| x.to_ascii_lowercase())
                    == Some('h');
                let next_s = chars[i..]
                    .iter()
                    .skip(1)
                    .find(|x| x.is_alphabetic())
                    .map(|x| x.to_ascii_lowercase())
                    == Some('s');
                if prev_h || next_s {
                    out.push_str(&match run {
                        1 => format!("{}", dt.minute),
                        _ => format!("{:02}", dt.minute),
                    });
                } else {
                    out.push_str(&match run {
                        1 => format!("{}", dt.month),
                        2 => format!("{:02}", dt.month),
                        3 => month_name(dt.month)[..3].to_string(),
                        _ => month_name(dt.month).to_string(),
                    });
                }
            }
            'd' => {
                out.push_str(&match run {
                    1 => format!("{}", dt.day),
                    2 => format!("{:02}", dt.day),
                    3 => weekday_name(dt.weekday_sun0())[..3].to_string(),
                    _ => weekday_name(dt.weekday_sun0()).to_string(),
                });
            }
            'h' => out.push_str(&match run {
                1 => format!("{}", if ampm { hour12(dt.hour) } else { dt.hour }),
                _ => format!("{:02}", if ampm { hour12(dt.hour) } else { dt.hour }),
            }),
            's' => out.push_str(&format!("{:02}", dt.second)),
            'a' => {
                if lower[i..].starts_with("am/pm") {
                    out.push_str(if dt.hour < 12 { "AM" } else { "PM" });
                    i += 5;
                    continue;
                } else if lower[i..].starts_with("a/p") {
                    out.push(if dt.hour < 12 { 'A' } else { 'P' });
                    i += 3;
                    continue;
                }
                out.push('a');
            }
            '"' => {
                // literal
                let mut j = i + 1;
                while j < chars.len() && chars[j] != '"' {
                    out.push(chars[j]);
                    j += 1;
                }
                i = j + 1;
                continue;
            }
            '\\' => {
                if let Some(n) = chars.get(i + 1) {
                    out.push(*n);
                    i += 2;
                    continue;
                }
                i += 1;
                continue;
            }
            '[' => {
                // [Red] / [$¥-804] / [<=100]; colour codes are ignored but
                // currency brackets carry a symbol we should keep.
                let mut j = i + 1;
                let mut inner = String::new();
                while j < chars.len() && chars[j] != ']' {
                    inner.push(chars[j]);
                    j += 1;
                }
                if let Some(stripped) = inner.strip_prefix('$') {
                    let symbol: String = stripped.chars().take_while(|c| *c != '-').collect();
                    out.push_str(&symbol);
                }
                i = j + 1;
                continue;
            }
            '_' | '*' => {
                // spacing / fill: skip the next char
                i += 2;
                continue;
            }
            _ => {
                let n = run.max(1);
                for _ in 0..n {
                    out.push(chars[i]);
                }
                i += n;
                continue;
            }
        }
        i += run;
    }
    out
}

fn hour12(h: u32) -> u32 {
    match h % 12 {
        0 => 12,
        v => v,
    }
}

fn month_name(m: u32) -> &'static str {
    const NAMES: [&str; 12] = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];
    NAMES
        .get((m as usize).saturating_sub(1))
        .copied()
        .unwrap_or("")
}

fn weekday_name(w: u32) -> &'static str {
    const NAMES: [&str; 7] = [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
    ];
    NAMES.get(w as usize).copied().unwrap_or("")
}

/// Render a number with a numeric format section (`0.00`, `#,##0`, `0.0%`, …).
pub fn format_numeric_section(section: &str, n: f64) -> String {
    let lower = section.to_ascii_lowercase();
    if lower.trim() == "general" {
        return format_number(n);
    }
    // percent scales first
    let percents = section.matches('%').count();
    let mut value = n * 100f64.powi(percents as i32);
    let negative_in_section = value < 0.0;
    if negative_in_section {
        value = value.abs();
    }
    // scientific notation: 0.00E+00
    if let Some(epos) = lower.find("e+").or_else(|| lower.find("e-")) {
        let mantissa_code = &section[..epos];
        let decimals = decimals_in(mantissa_code);
        let exp = if value == 0.0 {
            0
        } else {
            value.abs().log10().floor() as i32
        };
        let mantissa = value / 10f64.powi(exp);
        let sign = if lower[epos + 1..].starts_with('+') && exp >= 0 {
            "+"
        } else {
            ""
        };
        let prefix = literal_prefix(mantissa_code);
        let suffix = literal_suffix(&section[epos..]);
        return format!(
            "{prefix}{}E{sign}{:02}{suffix}",
            fixed_width(mantissa, decimals),
            exp.abs()
        );
    }

    // thousands separators: a comma between digit placeholders
    let (digits_code, prefix, suffix) = strip_literals(section);
    let use_grouping = has_grouping(&digits_code);
    let scale_commas = trailing_commas(&digits_code);
    if scale_commas > 0 {
        value /= 1000f64.powi(scale_commas as i32);
    }
    if !digits_code.chars().any(|c| matches!(c, '0' | '#' | '?')) {
        // e.g. the zero section `"ゼロ"` — literals only
        return format!("{prefix}{suffix}");
    }
    let core = &digits_code[..digits_code.len() - scale_commas];
    let decimals = decimals_in(core);
    let min_int = core
        .chars()
        .take_while(|c| *c != '.')
        .filter(|c| *c == '0')
        .count();
    let body = if use_grouping {
        group_thousands(value, decimals)
    } else {
        fixed_width(value, decimals)
    };
    // pad integer part to the number of required `0`s
    let (int_part, dec_part) = match body.split_once('.') {
        Some((i, d)) => (i.to_string(), Some(d.to_string())),
        None => (body.clone(), None),
    };
    let int_padded = if int_part.len() < min_int {
        format!("{}{}", "0".repeat(min_int - int_part.len()), int_part)
    } else {
        int_part
    };
    let mut out = String::new();
    out.push_str(&prefix);
    if negative_in_section && !prefix.contains('-') {
        out.push('-');
    }
    out.push_str(&int_padded);
    if let Some(d) = dec_part {
        if !d.is_empty() {
            out.push('.');
            out.push_str(&d);
        }
    }
    out.push_str(&suffix);
    out.push_str(&"%".repeat(percents));
    out
}

fn fixed_width(n: f64, decimals: usize) -> String {
    if decimals == 0 {
        format!("{}", n.round() as i64)
    } else {
        format!("{n:.decimals$}")
    }
}

fn group_thousands(n: f64, decimals: usize) -> String {
    let raw = fixed_width(n, decimals);
    let (int_part, dec_part) = match raw.split_once('.') {
        Some((i, d)) => (i, Some(d)),
        None => (raw.as_str(), None),
    };
    let (sign, digits) = match int_part.strip_prefix('-') {
        Some(rest) => ("-", rest),
        None => ("", int_part),
    };
    let mut grouped = String::new();
    for (i, ch) in digits.chars().rev().enumerate() {
        if i > 0 && i % 3 == 0 {
            grouped.push(',');
        }
        grouped.push(ch);
    }
    let int_out: String = grouped.chars().rev().collect();
    match dec_part {
        Some(d) => format!("{sign}{int_out}.{d}"),
        None => format!("{sign}{int_out}"),
    }
}

fn decimals_in(code: &str) -> usize {
    match code.split_once('.') {
        Some((_, frac)) => frac.chars().filter(|c| matches!(c, '0' | '#')).count(),
        None => 0,
    }
}

fn has_grouping(code: &str) -> bool {
    let chars: Vec<char> = code.chars().collect();
    chars
        .windows(3)
        .any(|w| matches!(w[0], '0' | '#') && w[1] == ',' && matches!(w[2], '0' | '#'))
}

fn trailing_commas(code: &str) -> usize {
    let trimmed = code.trim_end();
    let mut count = 0;
    for c in trimmed.chars().rev() {
        if c == ',' {
            count += 1;
        } else {
            break;
        }
    }
    count
}

/// Split a numeric section into (digit placeholders, prefix literals, suffix literals).
fn strip_literals(section: &str) -> (String, String, String) {
    let chars: Vec<char> = section.chars().collect();
    let mut digits = String::new();
    let mut prefix = String::new();
    let mut suffix = String::new();
    let mut seen_digit = false;
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        match c {
            '0' | '#' | '?' | ',' | '.' => {
                digits.push(c);
                seen_digit = true;
            }
            '%' => {}
            '"' => {
                let mut j = i + 1;
                let mut lit = String::new();
                while j < chars.len() && chars[j] != '"' {
                    lit.push(chars[j]);
                    j += 1;
                }
                if seen_digit {
                    suffix.push_str(&lit);
                } else {
                    prefix.push_str(&lit);
                }
                i = j;
            }
            '\\' => {
                if let Some(n) = chars.get(i + 1) {
                    if seen_digit {
                        suffix.push(*n);
                    } else {
                        prefix.push(*n);
                    }
                    i += 1;
                }
            }
            '[' => {
                let mut j = i + 1;
                let mut inner = String::new();
                while j < chars.len() && chars[j] != ']' {
                    inner.push(chars[j]);
                    j += 1;
                }
                if let Some(stripped) = inner.strip_prefix('$') {
                    let symbol: String = stripped.chars().take_while(|c| *c != '-').collect();
                    if seen_digit {
                        suffix.push_str(&symbol);
                    } else {
                        prefix.push_str(&symbol);
                    }
                }
                i = j;
            }
            '_' | '*' => {
                // spacing / fill: skip the following char
                i += 1;
            }
            other => {
                if seen_digit {
                    suffix.push(other);
                } else {
                    prefix.push(other);
                }
            }
        }
        i += 1;
    }
    (digits, prefix, suffix)
}

fn literal_prefix(code: &str) -> String {
    strip_literals(code).1
}

fn literal_suffix(code: &str) -> String {
    strip_literals(code).2
}

#[cfg(test)]
mod tests {
    use super::*;

    fn num(code: &str, n: f64) -> String {
        format_number_code(code, n)
    }

    #[test]
    fn integers_and_decimals() {
        assert_eq!(num("0", 3.7), "4");
        assert_eq!(num("0.00", 1.234_56), "1.23");
        assert_eq!(num("0.000", 1.5), "1.500");
        assert_eq!(num("#,##0", 1234567.0), "1,234,567");
        assert_eq!(num("#,##0.00", 1234.5), "1,234.50");
    }

    #[test]
    fn currency_and_percent() {
        assert_eq!(num("¥#,##0", 1234567.0), "¥1,234,567");
        assert_eq!(num("\"$\"#,##0.00", 9.5), "$9.50");
        assert_eq!(num("[$¥-804]#,##0", 1200.0), "¥1,200");
        assert_eq!(num("0.0%", 0.256), "25.6%");
        assert_eq!(num("0%", 0.5), "50%");
    }

    #[test]
    fn negative_and_zero_sections() {
        assert_eq!(num("0.00;[Red]-0.00", -3.5), "-3.50");
        assert_eq!(num("0;-0;\"ゼロ\"", 0.0), "ゼロ");
        assert_eq!(num("0.00", -2.5), "-2.50");
    }

    #[test]
    fn dates_and_times() {
        // 46343 = 2026-11-17 (a Tuesday)
        assert_eq!(num("yyyy-mm-dd", 46343.0), "2026-11-17");
        assert_eq!(num("yyyy/mm/dd", 46343.0), "2026/11/17");
        assert_eq!(num("yyyy年m月d日", 46343.0), "2026年11月17日");
        assert_eq!(num("hh:mm", 46343.75), "18:00");
        assert_eq!(num("h:mm AM/PM", 46343.75), "6:00 PM");
        assert_eq!(num("m/d", 46343.0), "11/17");
    }

    #[test]
    fn text_section_and_literals() {
        assert_eq!(
            format_value("\"〒\"000", &FormatValue::Number(123.0)),
            "〒123"
        );
        assert_eq!(
            format_value("@\"様\"", &FormatValue::Text("山田".into())),
            "山田様"
        );
        assert_eq!(format_value("0", &FormatValue::Text("abc".into())), "abc");
        assert_eq!(num("#,##0,", 12_345_678.0), "12,346"); // scaled by 1000
    }

    #[test]
    fn general_falls_back_to_shortest_form() {
        assert_eq!(num("General", 1234.5), "1234.5");
        assert_eq!(num("", 42.0), "42");
    }

    #[test]
    fn scientific_notation() {
        assert_eq!(num("0.00E+00", 12345.0), "1.23E+04");
    }
}
