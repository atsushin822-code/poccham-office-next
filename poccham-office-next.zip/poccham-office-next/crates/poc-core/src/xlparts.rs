//! The worksheet parts that live outside `sheetData`: merged cells,
//! conditional formatting, data validation, comments, drawings (pictures and
//! charts) and pivot-table caches.
//!
//! Everything here emits ECMA-376 XML. Element order matters — Excel refuses
//! files whose `<mergeCells>` follows `<dataValidations>` — so the helpers all
//! return snippets and `xlsx::write_sheet` places them in schema order.

use std::fmt::Write as _;

use crate::style::{HAlign, Line, LineStyle, Rgb, StyleSheet, VAlign, Xf};
use crate::xlsx::{
    col_letters, CellValue, CfKind, CfOp, Chart, ChartKind, ConditionalFormat, DataValidation,
    Merge, PivotAgg, PivotTable, Sheet, Workbook,
};
use crate::xml;

pub const NS_XDR: &str = "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing";
pub const NS_A: &str = "http://schemas.openxmlformats.org/drawingml/2006/main";
pub const NS_C: &str = "http://schemas.openxmlformats.org/drawingml/2006/chart";
pub const NS_R: &str = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

/// English Metric Units per pixel at 96 dpi (the drawing anchor unit).
pub const EMU_PER_PX: u64 = 9525;

fn a1(r: u32, c: u32) -> String {
    format!("{}{}", col_letters(c), r + 1)
}

// ---------------------------------------------------------------- merges

pub fn merges_xml(merges: &[Merge]) -> String {
    if merges.is_empty() {
        return String::new();
    }
    let mut s = String::new();
    let _ = write!(s, r#"<mergeCells count="{}">"#, merges.len());
    for m in merges {
        let ref_ = if m.r1 == m.r2 && m.c1 == m.c2 {
            a1(m.r1, m.c1)
        } else {
            format!("{}:{}", a1(m.r1, m.c1), a1(m.r2, m.c2))
        };
        xml::open_tag(&mut s, "mergeCell", &[("ref", &ref_)], true);
    }
    s.push_str("</mergeCells>");
    s
}

// ------------------------------------------------ conditional formatting

fn cf_attributes(kind: &CfKind, dxf: u16, priority: u32) -> String {
    let mut attrs: Vec<(String, String)> = Vec::new();
    let ty = match kind {
        CfKind::CellIs { .. } => "cellIs",
        CfKind::Expression(_) | CfKind::ContainsText(_) => "expression",
        CfKind::Top10 { .. } => "top10",
        CfKind::DataBar { .. } => "dataBar",
        CfKind::ColorScale { .. } => "colorScale",
        CfKind::IconSet { .. } => "iconSet",
    };
    attrs.push(("type".into(), ty.into()));
    if !matches!(
        kind,
        CfKind::DataBar { .. } | CfKind::ColorScale { .. } | CfKind::IconSet { .. }
    ) {
        attrs.push(("dxfId".into(), dxf.to_string()));
    }
    attrs.push(("priority".into(), priority.to_string()));
    if let CfKind::CellIs { op, .. } = kind {
        attrs.push((
            "operator".into(),
            match op {
                CfOp::GreaterThan => "greaterThan",
                CfOp::LessThan => "lessThan",
                CfOp::GreaterThanOrEqual => "greaterThanOrEqual",
                CfOp::LessThanOrEqual => "lessThanOrEqual",
                CfOp::Equal => "equal",
                CfOp::NotEqual => "notEqual",
                CfOp::Between => "between",
                CfOp::NotBetween => "notBetween",
            }
            .into(),
        ));
    }
    if let CfKind::Top10 {
        percent, bottom, ..
    } = kind
    {
        if *percent {
            attrs.push(("percent".into(), "1".into()));
        }
        if *bottom {
            attrs.push(("bottom".into(), "1".into()));
        }
    }
    let pair: Vec<(&str, &str)> = attrs
        .iter()
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    let mut out = String::new();
    xml::open_tag(&mut out, "cfRule", &pair, false);
    out
}

fn cf_rule_inner(kind: &CfKind) -> String {
    let mut s = String::new();
    match kind {
        CfKind::CellIs { formula, .. } | CfKind::Expression(formula) => {
            xml::text_tag(&mut s, "formula", &[], formula);
        }
        CfKind::ContainsText(text) => {
            let f = format!(r#"NOT(ISERROR(SEARCH("{text}",{})))"#, "A1");
            xml::text_tag(&mut s, "formula", &[], &f);
        }
        CfKind::Top10 { rank, .. } => {
            let _ = write!(s, r#"<top10Rank val="{rank}"/>"#);
        }
        CfKind::DataBar { color } => {
            let _ = write!(
                s,
                r#"<dataBar><cfvo type="min"/><cfvo type="max"/><color rgb="{}"/></dataBar>"#,
                color.argb()
            );
        }
        CfKind::ColorScale { min, mid, max } => {
            let _ = write!(s, "<colorScale><cfvo type=\"min\"/>");
            if mid.is_some() {
                let _ = write!(s, r#"<cfvo type="percentile" val="50"/>"#);
            }
            let _ = write!(s, r#"<cfvo type="max"/>"#);
            let _ = write!(s, r#"<color rgb="{}"/>"#, min.argb());
            if let Some(m) = mid {
                let _ = write!(s, r#"<color rgb="{}"/>"#, m.argb());
            }
            let _ = write!(s, r#"<color rgb="{}"/></colorScale>"#, max.argb());
        }
        CfKind::IconSet { name } => {
            for t in ["percent", "percent", "percent"] {
                let _ = write!(s, r#"<cfvo type="{t}" val="0"/>"#);
            }
            let _ = write!(s, r#"<iconSet iconSet="{name}"/>"#);
        }
    }
    s
}

pub fn conditional_formatting_xml(cf: &[ConditionalFormat]) -> String {
    let mut s = String::new();
    for (i, item) in cf.iter().enumerate() {
        let mut out = String::new();
        xml::open_tag(
            &mut out,
            "conditionalFormatting",
            &[("sqref", &item.range)],
            false,
        );
        out.push_str(&cf_attributes(
            &item.kind,
            item.dxf,
            item.priority.max(1) + i as u32,
        ));
        out.push_str(&cf_rule_inner(&item.kind));
        out.push_str("</cfRule></conditionalFormatting>");
        s.push_str(&out);
    }
    s
}

// ------------------------------------------------------ data validation

pub fn data_validation_xml(dv: &[DataValidation]) -> String {
    if dv.is_empty() {
        return String::new();
    }
    let mut s = String::new();
    let _ = write!(s, r#"<dataValidations count="{}">"#, dv.len());
    for v in dv {
        let formula = match &v.formula {
            Some(f) => f.clone(),
            None => String::new(),
        };
        let mut attrs: Vec<(&str, &str)> = vec![("type", v.kind.as_str()), ("sqref", &v.range)];
        if let Some(op) = &v.op {
            attrs.push(("operator", op));
        }
        if v.allow_blank {
            attrs.push(("allowBlank", "1"));
        }
        if !v.message.is_empty() {
            attrs.push(("prompt", &v.message));
            attrs.push(("showInputMessage", "1"));
        }
        if !v.error.is_empty() {
            attrs.push(("error", &v.error));
            attrs.push(("showErrorMessage", "1"));
        }
        xml::open_tag(&mut s, "dataValidation", &attrs, false);
        if formula.is_empty() {
            s.push_str("</dataValidation>");
        } else {
            xml::text_tag(&mut s, "formula1", &[], &formula);
            s.push_str("</dataValidation>");
        }
    }
    s.push_str("</dataValidations>");
    s
}

// ------------------------------------------------------------ drawings

pub struct Drawing {
    /// `(relationship id, target part, object)` in document order.
    pub pictures: Vec<Picture>,
    pub charts: Vec<(String, usize)>, // (rel id, chart index)
}

pub struct Picture {
    pub rel_id: String,
    pub col: u32,
    pub row: u32,
    pub width_px: u32,
    pub height_px: u32,
    pub name: String,
}

/// `<xdr:wsDr>` for a sheet that holds pictures and/or charts.
pub fn drawing_xml(pictures: &[Picture], charts: &[(String, usize)]) -> String {
    let mut s = String::with_capacity(512);
    s.push_str(xml::DECL);
    let _ = write!(
        s,
        r#"<xdr:wsDr xmlns:xdr="{NS_XDR}" xmlns:a="{NS_A}" xmlns:r="{NS_R}">"#
    );
    let mut id = 2u32;
    for p in pictures {
        let cx = p.width_px as u64 * EMU_PER_PX;
        let cy = p.height_px as u64 * EMU_PER_PX;
        s.push_str("<xdr:oneCellAnchor>");
        let _ = write!(
            s,
            "<xdr:from><xdr:col>{}</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>{}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>",
            p.col, p.row
        );
        let _ = write!(s, r#"<xdr:ext cx="{cx}" cy="{cy}"/>"#);
        s.push_str("<xdr:pic><xdr:nvPicPr>");
        let _ = write!(
            s,
            r#"<xdr:cNvPr id="{id}" name="{}"/><xdr:cNvPicPr><a:picLocks noChangeAspect="1"/></xdr:cNvPicPr>"#,
            xml::esc(&p.name)
        );
        s.push_str("</xdr:nvPicPr><xdr:blipFill>");
        let _ = write!(s, r#"<a:blip r:embed="{}"/>"#, p.rel_id);
        s.push_str("<a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr>");
        let _ = write!(
            s,
            r#"<a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>"#
        );
        s.push_str("</xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor>");
        id += 1;
    }
    for (rel_id, chart_idx) in charts {
        let _ = write!(
            s,
            r#"<xdr:twoCellAnchor><xdr:from><xdr:col>5</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>{}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:to><xdr:col>13</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>{}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>"#,
            chart_idx + 1,
            chart_idx + 16
        );
        let _ = write!(
            s,
            r#"<xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="{id}" name="Chart {n}"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr><xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm><a:graphic><a:graphicData uri="{NS_C}"><c:chart xmlns:c="{NS_C}" xmlns:r="{NS_R}" r:id="{rel_id}"/></a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/>"#,
            n = chart_idx + 1
        );
        s.push_str("</xdr:twoCellAnchor>");
        id += 1;
    }
    s.push_str("</xdr:wsDr>");
    s
}

// -------------------------------------------------------------- charts

fn quoted_sheet(name: &str) -> String {
    format!("'{}'", name.replace('\'', "''"))
}

fn str_cache(sheet: &Sheet, r1: u32, c1: u32, r2: u32, c2: u32) -> String {
    let mut s = String::new();
    let mut count = 0;
    let mut points = String::new();
    for r in r1..=r2 {
        for c in c1..=c2 {
            if let Some(cell) = sheet.get(r, c) {
                let text = match &cell.value {
                    CellValue::Text(t) => t.clone(),
                    CellValue::Number(n) => n.to_string(),
                    CellValue::Bool(b) => b.to_string(),
                    _ => continue,
                };
                let _ = write!(
                    points,
                    r#"<c:pt idx="{}"><c:v>{}</c:v></c:pt>"#,
                    count,
                    xml::esc(&text)
                );
            }
            count += 1;
        }
    }
    let _ = write!(s, r#"<c:ptCount val="{count}"/>{points}"#);
    s
}

fn num_cache(sheet: &Sheet, r1: u32, c1: u32, r2: u32, c2: u32) -> String {
    let mut points = String::new();
    let mut count = 0;
    for r in r1..=r2 {
        for c in c1..=c2 {
            let v = sheet.get(r, c).and_then(|cell| cell.as_number());
            if let Some(v) = v {
                let _ = write!(points, r#"<c:pt idx="{count}"><c:v>{v}</c:v></c:pt>"#);
            }
            count += 1;
        }
    }
    let mut s = String::new();
    let _ = write!(
        s,
        r#"<c:formatCode>General</c:formatCode><c:ptCount val="{count}"/>{points}"#
    );
    s
}

/// `<c:chartSpace>` for one chart, with cached values so viewers that do not
/// calculate still draw the bars.
pub fn chart_xml(chart: &Chart, wb: &Workbook) -> String {
    let sheet_name = wb
        .sheets
        .get(chart.sheet)
        .map(|s| s.name.clone())
        .unwrap_or_else(|| "Sheet1".into());
    let prefix = quoted_sheet(&sheet_name);
    let mut s = String::with_capacity(1024);
    s.push_str(xml::DECL);
    let _ = write!(
        s,
        r#"<c:chartSpace xmlns:c="{NS_C}" xmlns:a="{NS_A}" xmlns:r="{NS_R}"><c:roundedCorners val="0"/><c:chart>"#
    );
    if !chart.title.is_empty() {
        let _ = write!(
            s,
            r#"<c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr sz="1400" b="1"/></a:pPr><a:r><a:t>{}</a:t></a:r></a:p></c:rich></c:tx><c:overlay val="0"/></c:title><c:autoTitleDeleted val="0"/>"#,
            xml::esc(&chart.title)
        );
    }
    s.push_str("<c:plotArea><c:layout/>");
    let (tag, extra) = match chart.kind {
        ChartKind::Bar => (
            "barChart",
            r#"<c:barDir val="col"/><c:grouping val="clustered"/><c:varyColors val="0"/>"#,
        ),
        ChartKind::Line => (
            "lineChart",
            r#"<c:grouping val="standard"/><c:varyColors val="0"/>"#,
        ),
        ChartKind::Pie => ("pieChart", r#"<c:varyColors val="1"/>"#),
        ChartKind::Area => (
            "areaChart",
            r#"<c:grouping val="standard"/><c:varyColors val="0"/>"#,
        ),
    };
    let _ = write!(s, "<c:{tag}>{extra}");
    for (i, series) in chart.series.iter().enumerate() {
        let (r1, c1, r2, c2) = series.values;
        let values_ref = format!(
            "{prefix}!${}${}:${}${}",
            col_letters(c1),
            r1 + 1,
            col_letters(c2),
            r2 + 1
        );
        let _ = write!(s, r#"<c:ser><c:idx val="{i}"/><c:order val="{i}"/>"#);
        if !series.name.is_empty() {
            let _ = write!(s, r#"<c:tx><c:v>{}</c:v></c:tx>"#, xml::esc(&series.name));
        }
        if let Some((cr1, cc1, cr2, cc2)) = chart.categories {
            let cat_ref = format!(
                "{prefix}!${}${}:${}${}",
                col_letters(cc1),
                cr1 + 1,
                col_letters(cc2),
                cr2 + 1
            );
            let _ = write!(
                s,
                "<c:cat><c:strRef><c:f>{cat_ref}</c:f><c:strCache>{}</c:strCache></c:strRef></c:cat>",
                str_cache(&sheet_of(wb, chart.sheet), cr1, cc1, cr2, cc2)
            );
        }
        let _ = write!(
            s,
            "<c:val><c:numRef><c:f>{values_ref}</c:f><c:numCache>{}</c:numCache></c:numRef></c:val>",
            num_cache(&sheet_of(wb, chart.sheet), r1, c1, r2, c2)
        );
        if chart.kind == ChartKind::Line {
            s.push_str(r#"<c:marker><c:symbol val="none"/></c:marker>"#);
        }
        s.push_str("</c:ser>");
    }
    match chart.kind {
        ChartKind::Pie => {
            s.push_str(r#"<c:firstSliceAng val="0"/>"#);
        }
        _ => {
            s.push_str(r#"<c:gapWidth val="150"/>"#);
            if chart.kind != ChartKind::Bar {
                s.push_str(r#"<c:marker val="1"/>"#);
            }
            s.push_str(r#"<c:axId val="111111111"/><c:axId val="222222222"/>"#);
        }
    }
    let _ = write!(s, "</c:{tag}>");
    if chart.kind != ChartKind::Pie {
        s.push_str(
            r#"<c:catAx><c:axId val="111111111"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="b"/><c:majorTickMark val="out"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:crossAx val="222222222"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/><c:noMultiLvlLbl val="0"/></c:catAx><c:valAx><c:axId val="222222222"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="l"/><c:majorGridlines/><c:numFmt formatCode="General" sourceLinked="1"/><c:majorTickMark val="out"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:crossAx val="111111111"/><c:crosses val="autoZero"/><c:crossBetween val="between"/></c:valAx>"#,
        );
    }
    s.push_str("</c:plotArea>");
    if chart.legend && chart.kind != ChartKind::Pie {
        s.push_str(r#"<c:legend><c:legendPos val="b"/><c:overlay val="0"/></c:legend>"#);
    }
    s.push_str(r#"<c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/>"#);
    s.push_str("</c:chart></c:chartSpace>");
    s
}

fn sheet_of(wb: &Workbook, idx: usize) -> Sheet {
    wb.sheets.get(idx).cloned().unwrap_or_default()
}

// ------------------------------------------------------------ comments

pub fn comments_xml(sheet: &Sheet) -> String {
    let mut s = String::new();
    s.push_str(xml::DECL);
    s.push_str(r#"<comments xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">"#);
    s.push_str("<authors>");
    let mut authors: Vec<String> = Vec::new();
    for c in &sheet.comments {
        if !authors.contains(&c.author) {
            authors.push(c.author.clone());
        }
    }
    for a in &authors {
        xml::text_tag(&mut s, "author", &[], a);
    }
    s.push_str("</authors><commentList>");
    for c in &sheet.comments {
        let id = authors.iter().position(|a| *a == c.author).unwrap_or(0);
        let _ = write!(
            s,
            r#"<comment ref="{}" authorId="{id}"><text><r><t xml:space="preserve">{}</t></r></text></comment>"#,
            a1(c.row, c.col),
            xml::esc(&c.text)
        );
    }
    s.push_str("</commentList></comments>");
    s
}

/// The legacy VML part Excel needs to *show* comments.
pub fn vml_comments_xml(sheet: &Sheet) -> String {
    let mut s = String::with_capacity(512);
    s.push_str(xml::DECL);
    s.push_str(
        r#"<xml xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">"#,
    );
    s.push_str(
        r#"<o:shapelayout v:ext="edit"><o:idmap v:ext="edit" data="1"/></o:shapelayout><v:shapetype id="_x0000_t202" coordsize="21600,21600" o:spt="202" path="m,l,21600r21600,l21600,xe"><v:stroke joinstyle="miter"/><v:path gradientshapeok="t" o:connecttype="rect"/></v:shapetype>"#,
    );
    for (i, c) in sheet.comments.iter().enumerate() {
        let _ = write!(
            s,
            r##"<v:shape id="_x0000_s{}" type="#_x0000_t202" style="position:absolute;margin-left:59.25pt;margin-top:1.5pt;width:108pt;height:59.25pt;z-index:{};visibility:hidden" fillcolor="#ffffe1" o:insetmode="auto"><v:fill color2="#ffffe1"/><v:shadow on="t" color="black" obscured="t"/><v:path o:connecttype="none"/><v:textbox style="mso-direction-alt:auto"><div style="text-align:left"/></v:textbox><x:ClientData ObjectType="Note"><x:MoveWithCells/><x:SizeWithCells/><x:Anchor>1, 15, 0, 2, 3, 15, 4, 4</x:Anchor><x:AutoFill>False</x:AutoFill><x:Row>{}</x:Row><x:Column>{}</x:Column></x:ClientData></v:shape>"##,
            1025 + i,
            i + 1,
            c.row,
            c.col
        );
    }
    s.push_str("</xml>");
    s
}

// -------------------------------------------------------- pivot tables

/// `(cache definition, cache records)` for one pivot table.
pub fn pivot_cache_parts(pivot: &PivotTable, wb: &Workbook) -> (String, String) {
    let (r1, c1, r2, c2) = pivot.source.range;
    let source = wb
        .sheets
        .get(pivot.source.sheet)
        .cloned()
        .unwrap_or_default();
    let field_count = (c2 - c1 + 1) as usize;

    // header names + distinct values per column
    let mut headers: Vec<String> = Vec::with_capacity(field_count);
    let mut distinct: Vec<Vec<String>> = Vec::with_capacity(field_count);
    for c in 0..field_count {
        let name = match source.get(r1, c1 + c as u32) {
            Some(cell) => match &cell.value {
                CellValue::Text(t) => t.clone(),
                other => format!("{other:?}"),
            },
            None => format!("Field{}", c + 1),
        };
        headers.push(if name.is_empty() {
            format!("Field{}", c + 1)
        } else {
            name
        });
        let mut values: Vec<String> = Vec::new();
        for r in (r1 + 1)..=r2 {
            if let Some(cell) = source.get(r, c1 + c as u32) {
                let text = match &cell.value {
                    CellValue::Text(t) => t.clone(),
                    CellValue::Number(n) => n.to_string(),
                    CellValue::Bool(b) => b.to_string(),
                    _ => continue,
                };
                if !values.contains(&text) {
                    values.push(text);
                }
            }
        }
        distinct.push(values);
    }

    let mut def = String::with_capacity(1024);
    def.push_str(xml::DECL);
    let _ = write!(
        def,
        r#"<pivotCacheDefinition xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="{NS_R}" r:id="rId1" refreshOnLoad="1" recordCount="{}" createdVersion="6" refreshedVersion="6" minRefreshableVersion="3">"#,
        (r2 - r1) as usize
    );
    let ref_text = format!(
        "{}${}:${}${}",
        col_letters(c1),
        r1 + 1,
        col_letters(c2),
        r2 + 1
    );
    let _ = write!(
        def,
        r#"<cacheSource type="worksheet"><worksheetSource ref="{}" sheet="{}"/></cacheSource>"#,
        ref_text,
        xml::esc(&source.name)
    );
    let _ = write!(def, r#"<cacheFields count="{field_count}">"#);
    for (i, values) in distinct.iter().enumerate() {
        let _ = write!(
            def,
            r#"<cacheField name="{}" numFmtId="0"><sharedItems count="{}">"#,
            xml::esc(&headers[i]),
            values.len()
        );
        for v in values {
            if let Ok(n) = v.parse::<f64>() {
                let _ = write!(def, r#"<n v="{n}"/>"#);
            } else {
                let _ = write!(def, r#"<s v="{}"/>"#, xml::esc(v));
            }
        }
        def.push_str("</sharedItems></cacheField>");
    }
    def.push_str("</cacheFields></pivotCacheDefinition>");

    // records: one <r> per data row with a shared-item index per field
    let mut rec = String::with_capacity(256);
    rec.push_str(xml::DECL);
    rec.push_str(
        r#"<pivotCacheRecords xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count=""#,
    );
    let _ = write!(rec, r#"{}">"#, (r2 - r1) as usize);
    for r in (r1 + 1)..=r2 {
        rec.push_str("<r>");
        for (f, values) in distinct.iter().enumerate() {
            let Some(cell) = source.get(r, c1 + f as u32) else {
                rec.push_str("<m/>");
                continue;
            };
            let text = match &cell.value {
                CellValue::Text(t) => t.clone(),
                CellValue::Number(n) => n.to_string(),
                CellValue::Bool(b) => b.to_string(),
                _ => String::new(),
            };
            match values.iter().position(|v| *v == text) {
                Some(i) if text.parse::<f64>().is_ok() => {
                    let _ = write!(rec, r#"<n v="{i}"/>"#);
                }
                Some(i) => {
                    let _ = write!(rec, r#"<x v="{i}"/>"#);
                }
                None => rec.push_str("<m/>"),
            }
        }
        rec.push_str("</r>");
    }
    rec.push_str("</pivotCacheRecords>");
    (def, rec)
}

/// The aggregated grid a pivot table shows: `(row keys, column keys, cells)`.
pub struct PivotLayout {
    pub row_keys: Vec<String>,
    pub col_keys: Vec<String>,
    pub cells: Vec<Vec<Option<f64>>>,
}

pub fn pivot_layout(pivot: &PivotTable, wb: &Workbook) -> PivotLayout {
    let (r1, c1, r2, c2) = pivot.source.range;
    let source = wb
        .sheets
        .get(pivot.source.sheet)
        .cloned()
        .unwrap_or_default();
    let key_of = |row: u32, cols: &[u32]| -> String {
        cols.iter()
            .map(|c| {
                source
                    .get(row, c1 + *c)
                    .map(|cell| match &cell.value {
                        CellValue::Text(t) => t.clone(),
                        CellValue::Number(n) => n.to_string(),
                        _ => String::new(),
                    })
                    .unwrap_or_default()
            })
            .collect::<Vec<_>>()
            .join(" / ")
    };
    let data_rows: Vec<u32> = ((r1 + 1)..=r2).collect();

    // first pass: distinct row and column keys, in source order
    let mut row_keys: Vec<String> = Vec::new();
    let mut col_keys: Vec<String> = Vec::new();
    for r in &data_rows {
        let rk = key_of(*r, &pivot.rows);
        if !row_keys.contains(&rk) {
            row_keys.push(rk);
        }
        let ck = key_of(*r, &pivot.cols);
        if !col_keys.contains(&ck) {
            col_keys.push(ck);
        }
    }
    if row_keys.is_empty() {
        row_keys.push("Total".into());
    }
    if col_keys.is_empty() {
        col_keys.push("Total".into());
    }

    // second pass: aggregate
    let value_fields = pivot.values.len().max(1);
    let mut sums = vec![vec![0.0f64; col_keys.len() * value_fields]; row_keys.len()];
    let mut counts = vec![vec![0.0f64; col_keys.len() * value_fields]; row_keys.len()];
    for r in &data_rows {
        let rk = key_of(*r, &pivot.rows);
        let ck = key_of(*r, &pivot.cols);
        let Some(ri) = row_keys.iter().position(|k| *k == rk) else {
            continue;
        };
        let Some(ci) = col_keys.iter().position(|k| *k == ck) else {
            continue;
        };
        for (vi, (col, _)) in pivot.values.iter().enumerate() {
            let val = source
                .get(*r, c1 + *col)
                .and_then(|cell| cell.as_number())
                .unwrap_or(0.0);
            let stride = value_fields * ci + vi;
            sums[ri][stride] += val;
            counts[ri][stride] += 1.0;
        }
    }

    let mut cells: Vec<Vec<Option<f64>>> = Vec::with_capacity(row_keys.len());
    for (ri, row) in sums.iter().enumerate() {
        let mut out_row: Vec<Option<f64>> = Vec::with_capacity(col_keys.len() * value_fields);
        for ci in 0..col_keys.len() {
            for (vi, (_, agg)) in pivot.values.iter().enumerate() {
                let stride = value_fields * ci + vi;
                let sum = row.get(stride).copied().unwrap_or(0.0);
                let count = counts[ri].get(stride).copied().unwrap_or(0.0);
                let value = match agg {
                    PivotAgg::Sum => sum,
                    PivotAgg::Count => count,
                    PivotAgg::Average => {
                        if count > 0.0 {
                            sum / count
                        } else {
                            0.0
                        }
                    }
                    PivotAgg::Max | PivotAgg::Min => sum,
                };
                out_row.push(Some(value));
            }
        }
        cells.push(out_row);
    }
    let _ = c2;
    PivotLayout {
        row_keys,
        col_keys,
        cells,
    }
}

/// `<pivotTableDefinition>` for one pivot table at `pivot.target`.
pub fn pivot_table_xml(pivot: &PivotTable, wb: &Workbook, cache_id: u32) -> String {
    let layout = pivot_layout(pivot, wb);
    let field_count = (pivot.source.range.3 - pivot.source.range.1 + 1) as usize;
    let (tr, tc) = pivot.target;
    let header_rows = if pivot.cols.is_empty() { 1 } else { 2 };
    let value_cols = pivot.values.len().max(1) * layout.col_keys.len().max(1);
    let ref_ = format!(
        "{}:{}",
        a1(tr, tc),
        a1(
            tr + header_rows + layout.row_keys.len() as u32,
            tc + value_cols as u32
        )
    );
    let mut s = String::with_capacity(1024);
    s.push_str(xml::DECL);
    let _ = write!(
        s,
        r#"<pivotTableDefinition xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" name="{}" cacheId="{cache_id}" dataCaption="値" updatedVersion="6" minRefreshableVersion="3" createdVersion="6" applyWidthHeightFormats="1" useAutoFormatting="1" itemPrintTitles="1">"#,
        xml::esc(&pivot.name)
    );
    let core = format!(
        r#"<location ref="{ref_}" firstHeaderRow="1" firstDataRow="{header_rows}" firstDataCol="1" rowPageCount="0" colPageCount="0"/>"#
    );
    s.push_str(&core);
    // pivotFields
    let _ = write!(s, r#"<pivotFields count="{field_count}">"#);
    for f in 0..field_count {
        let is_row = pivot.rows.contains(&(f as u32));
        let is_col = pivot.cols.contains(&(f as u32));
        let is_data = pivot.values.iter().any(|(c, _)| *c == f as u32);
        let show_all = if is_row || is_col {
            r#" showAll="0""#
        } else {
            ""
        };
        let axis = if is_row {
            r#" axis="axisRow""#
        } else if is_col {
            r#" axis="axisCol""#
        } else {
            ""
        };
        if is_row || is_col {
            let _ = write!(
                s,
                r#"<pivotField{show_all}{axis} compact="0" outline="0" subtotalTop="0"><items count="1"><item t="default"/></items></pivotField>"#
            );
        } else if is_data {
            s.push_str(r#"<pivotField dataField="1" showAll="0"/>"#);
        } else {
            s.push_str(r#"<pivotField showAll="0"/>"#);
        }
    }
    s.push_str("</pivotFields>");
    if !pivot.rows.is_empty() {
        let _ = write!(s, r#"<rowFields count="{}">"#, pivot.rows.len());
        for r in &pivot.rows {
            let _ = write!(s, r#"<field x="{r}"/>"#);
        }
        s.push_str("</rowFields>");
        let _ = write!(s, r#"<rowItems count="{}">"#, layout.row_keys.len() + 1);
        for i in 0..layout.row_keys.len() {
            let _ = write!(s, r#"<i><x v="{i}"/></i>"#);
        }
        s.push_str(r#"<i t="grand"><x/></i>"#);
        s.push_str("</rowItems>");
    }
    if !pivot.cols.is_empty() {
        let _ = write!(s, r#"<colFields count="{}">"#, pivot.cols.len());
        for c in &pivot.cols {
            let _ = write!(s, r#"<field x="{c}"/>"#);
        }
        s.push_str("</colFields>");
        let _ = write!(s, r#"<colItems count="{}">"#, layout.col_keys.len() + 1);
        for i in 0..layout.col_keys.len() {
            let _ = write!(s, r#"<i><x v="{i}"/></i>"#);
        }
        s.push_str(r#"<i t="grand"><x/></i>"#);
        s.push_str("</colItems>");
    } else {
        s.push_str(r#"<colFields count="0"/>"#);
    }
    let _ = write!(s, r#"<dataFields count="{}">"#, pivot.values.len());
    for (col, agg) in &pivot.values {
        let subtotal = match agg {
            PivotAgg::Sum => "sum",
            PivotAgg::Count => "count",
            PivotAgg::Average => "average",
            PivotAgg::Max => "max",
            PivotAgg::Min => "min",
        };
        let _ = write!(
            s,
            r#"<dataField name="{}" fld="{col}" baseField="0" baseItem="0" subtotal="{subtotal}"/>"#,
            xml::esc(&format!("{}の{}", subtotal_jp(subtotal), ""))
        );
    }
    s.push_str("</dataFields>");
    s.push_str(r#"<pivotTableStyleInfo name="PivotStyleLight16" showRowHeaders="1" showColHeaders="1" showRowStripes="0" showColStripes="0" showLastColumn="1"/>"#);
    s.push_str("</pivotTableDefinition>");
    s
}

fn subtotal_jp(subtotal: &str) -> &'static str {
    match subtotal {
        "sum" => "合計",
        "count" => "データの個数",
        "average" => "平均",
        "max" => "最大値",
        "min" => "最小値",
        _ => "値",
    }
}

// ------------------------------------------------------------- reading

/// Read the parts of a worksheet that are not cell data.
pub fn read_sheet_extras(src: &str, sheet: &mut Sheet) {
    use crate::xml::{Event, Reader};
    let mut r = Reader::new(src);
    loop {
        match r.next_event() {
            Event::Eof => break,
            Event::Start { name, attrs, .. } => {
                let tag = xml::local(&name).to_string();
                let attr = |k: &str| -> Option<String> {
                    attrs
                        .iter()
                        .find(|(key, _)| key == k || xml::local(key) == k)
                        .map(|(_, v)| v.clone())
                };
                match tag.as_str() {
                    "mergeCell" => {
                        if let Some(ref_) = attr("ref") {
                            if let Some(m) = Merge::parse(&ref_) {
                                sheet.merges.push(m);
                            }
                        }
                    }
                    "row" => {
                        if let (Some(r_), Some(ht)) = (attr("r"), attr("ht")) {
                            if let (Ok(idx), Ok(h)) = (r_.parse::<u32>(), ht.parse::<f32>()) {
                                let i = idx.saturating_sub(1) as usize;
                                if sheet.row_heights.len() <= i {
                                    sheet.row_heights.resize(i + 1, None);
                                }
                                sheet.row_heights[i] = Some(h);
                            }
                        }
                    }
                    "conditionalFormatting" => {
                        if let Some(sqref) = attr("sqref") {
                            sheet.cf.push(ConditionalFormat {
                                range: sqref,
                                kind: CfKind::Expression(String::new()),
                                dxf: 0,
                                priority: (sheet.cf.len() + 1) as u32,
                            });
                        }
                    }
                    "cfRule" => {
                        let Some(last) = sheet.cf.last_mut() else {
                            continue;
                        };
                        last.dxf = attr("dxfId").and_then(|v| v.parse().ok()).unwrap_or(0);
                        last.priority = attr("priority").and_then(|v| v.parse().ok()).unwrap_or(1);
                        let ty = attr("type").unwrap_or_default();
                        last.kind = match ty.as_str() {
                            "cellIs" => CfKind::CellIs {
                                op: match attr("operator").as_deref() {
                                    Some("lessThan") => CfOp::LessThan,
                                    Some("greaterThanOrEqual") => CfOp::GreaterThanOrEqual,
                                    Some("lessThanOrEqual") => CfOp::LessThanOrEqual,
                                    Some("equal") => CfOp::Equal,
                                    Some("notEqual") => CfOp::NotEqual,
                                    Some("between") => CfOp::Between,
                                    Some("notBetween") => CfOp::NotBetween,
                                    _ => CfOp::GreaterThan,
                                },
                                formula: String::new(),
                            },
                            "top10" => CfKind::Top10 {
                                rank: 10,
                                percent: attr("percent").as_deref() == Some("1"),
                                bottom: attr("bottom").as_deref() == Some("1"),
                            },
                            "dataBar" => CfKind::DataBar {
                                color: Rgb(0x63, 0x8E, 0xC6),
                            },
                            "colorScale" => CfKind::ColorScale {
                                min: Rgb(0xF8, 0x69, 0x6B),
                                mid: Some(Rgb(0xFF, 0xEB, 0x84)),
                                max: Rgb(0x63, 0xBE, 0x7B),
                            },
                            "iconSet" => CfKind::IconSet {
                                name: attr("iconSet").unwrap_or_else(|| "3TrafficLights1".into()),
                            },
                            _ => CfKind::Expression(String::new()),
                        };
                    }
                    "formula" => {
                        if let Some(last) = sheet.cf.last_mut() {
                            let text = r.read_text();
                            last.kind = match last.kind {
                                CfKind::CellIs { ref op, .. } => CfKind::CellIs {
                                    op: *op,
                                    formula: text,
                                },
                                _ => CfKind::Expression(text),
                            };
                        }
                    }
                    "dataValidation" => {
                        sheet.validations.push(DataValidation {
                            range: attr("sqref").unwrap_or_default(),
                            kind: crate::xlsx::ValidationKind::parse(
                                attr("type").as_deref().unwrap_or("any"),
                            ),
                            op: attr("operator"),
                            formula: None,
                            allow_blank: attr("allowBlank").as_deref() == Some("1"),
                            message: attr("prompt").unwrap_or_default(),
                            error: attr("error").unwrap_or_default(),
                        });
                    }
                    "formula1" => {
                        if let Some(last) = sheet.validations.last_mut() {
                            if last.formula.is_none() {
                                last.formula = Some(r.read_text());
                            }
                        }
                    }
                    _ => {}
                }
            }
            Event::End { .. } | Event::Text(_) => {}
        }
    }
}

/// Build the `xf` a caller most likely wants for a "header cell".
pub fn header_xf() -> Xf {
    Xf {
        font: crate::style::Font::default()
            .bold()
            .color(crate::style::WHITE),
        fill: Some(Rgb::hex(0x1F_3864)),
        border: crate::style::Border::boxed(Line::new(LineStyle::Thin, crate::style::BLACK)),
        halign: HAlign::Center,
        valign: VAlign::Center,
        wrap: true,
        ..Xf::default()
    }
}

/// Intern a header format, returning the cell-format index.
pub fn header_style(styles: &mut StyleSheet) -> u16 {
    styles.intern(header_xf())
}
