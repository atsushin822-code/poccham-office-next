//! Spreadsheet formula engine.
//!
//! A small, allocation-light evaluator for the formula language that business
//! workbooks actually contain.  It is used by `poc calc`, by the desktop grid
//! (via the Tauri command) and by the macro host so that
//! `Range("C1").Value` returns a real number right after a macro writes
//! `Range("C1").Formula = "=SUM(A1:B1)"`.
//!
//! Supported: arithmetic, `^`, `%`, `&`, comparisons, parentheses, cell and
//! range references (including `Sheet2!A1`), and the functions
//! `SUM AVERAGE MIN MAX COUNT COUNTA COUNTBLANK IF IFERROR AND OR NOT ROUND
//!  ROUNDUP ROUNDDOWN ABS INT MOD POWER SQRT EXP LN LOG10 CONCATENATE TEXTJOIN?
//!  LEN LEFT RIGHT MID TRIM UPPER LOWER PROPER CONCAT SUMPRODUCT? ISBLANK
//!  ISNUMBER ISTEXT VALUE`.
//!
//! Not supported (returns `#NAME?`): lookup functions, array formulas, pivot
//! references, volatile functions.  See `docs/COMPATIBILITY.md`.

use crate::xlsx::{Cell, CellValue, Workbook};

/// A value produced by formula evaluation.
#[derive(Debug, Clone, PartialEq)]
pub enum CValue {
    Empty,
    Number(f64),
    Str(String),
    Bool(bool),
    Error(&'static str),
}

impl CValue {
    pub fn to_number(&self) -> Result<f64, &'static str> {
        match self {
            CValue::Empty => Ok(0.0),
            CValue::Number(n) => Ok(*n),
            CValue::Bool(b) => Ok(if *b { 1.0 } else { 0.0 }),
            CValue::Str(s) => s.trim().parse::<f64>().map_err(|_| "#VALUE!"),
            CValue::Error(e) => Err(e),
        }
    }
    pub fn to_bool(&self) -> Result<bool, &'static str> {
        match self {
            CValue::Empty => Ok(false),
            CValue::Bool(b) => Ok(*b),
            CValue::Number(n) => Ok(*n != 0.0),
            CValue::Str(s) => Ok(!s.is_empty() && !s.eq_ignore_ascii_case("false")),
            CValue::Error(e) => Err(e),
        }
    }
    pub fn to_text(&self) -> String {
        match self {
            CValue::Empty => String::new(),
            CValue::Number(n) => crate::xlsx::format_number(*n),
            CValue::Str(s) => s.clone(),
            CValue::Bool(b) => if *b { "TRUE" } else { "FALSE" }.to_string(),
            CValue::Error(e) => (*e).to_string(),
        }
    }
    /// Convert a computed value into a cell (used by "paste values").
    pub fn into_cell(self) -> Cell {
        match self {
            CValue::Empty => Cell::empty(),
            CValue::Number(n) => Cell::num(n),
            CValue::Str(s) => Cell::text(s),
            CValue::Bool(b) => Cell::boolean(b),
            CValue::Error(e) => Cell {
                value: CellValue::Error(e.to_string()),
                style: 0,
            },
        }
    }
}

/// Recalculate every formula in the workbook (iterative fixed point).
pub fn recalculate(wb: &mut Workbook) {
    const MAX_PASSES: usize = 12;
    for pass in 0..MAX_PASSES {
        let mut changed = false;
        for s in 0..wb.sheets.len() {
            let rows = wb.sheets[s].rows.len();
            for r in 0..rows {
                let cols = wb.sheets[s].rows[r].len();
                for c in 0..cols {
                    let expr = match &wb.sheets[s].rows[r][c].value {
                        CellValue::Formula { expr, .. } => expr.clone(),
                        _ => continue,
                    };
                    let value = evaluate(wb, s, &expr);
                    let (new_cached, new_text) = match &value {
                        CValue::Number(n) => (Some(*n), None),
                        CValue::Str(t) => (None, Some(t.clone())),
                        CValue::Bool(b) => (Some(if *b { 1.0 } else { 0.0 }), None),
                        _ => (None, None),
                    };
                    let (cur_cached, cur_text) = match &wb.sheets[s].rows[r][c].value {
                        CellValue::Formula { cached, text, .. } => (*cached, text.clone()),
                        _ => (None, None),
                    };
                    let same = match (&new_cached, &cur_cached) {
                        (Some(a), Some(b)) => (a - b).abs() < 1e-12,
                        (None, None) => new_text == cur_text,
                        _ => false,
                    };
                    if !same {
                        changed = true;
                        if let CellValue::Formula { cached, text, .. } =
                            &mut wb.sheets[s].rows[r][c].value
                        {
                            *cached = new_cached;
                            *text = new_text;
                        }
                    }
                }
            }
        }
        if !changed && pass > 0 {
            break;
        }
    }
}

/// Evaluate one formula against the current workbook state.
pub fn evaluate(wb: &Workbook, sheet: usize, expr: &str) -> CValue {
    let tokens = match lex(expr) {
        Ok(t) => t,
        Err(e) => return CValue::Error(e),
    };
    let mut p = CalcParser {
        toks: tokens,
        pos: 0,
        wb,
        sheet,
    };
    match p.parse_expr(0) {
        Ok(Arg::Value(v)) => v,
        Ok(Arg::Range {
            r1,
            c1,
            r2,
            c2,
            sheet,
        }) => p.read_cell(sheet, r1, c1, r2, c2),
        Err(e) => CValue::Error(e),
    }
}

#[derive(Debug, Clone, PartialEq)]
enum Tok {
    Num(f64),
    Str(String),
    Ident(String),
    Ref {
        sheet: Option<String>,
        r: u32,
        c: u32,
    },
    Range {
        sheet: Option<String>,
        r1: u32,
        c1: u32,
        r2: u32,
        c2: u32,
    },
    Op(String),
}

fn lex(src: &str) -> Result<Vec<Tok>, &'static str> {
    let chars: Vec<char> = src.chars().collect();
    let mut out = Vec::new();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if c.is_whitespace() {
            i += 1;
            continue;
        }
        if c == '"' {
            i += 1;
            let mut s = String::new();
            loop {
                match chars.get(i) {
                    None => return Err("#VALUE!"),
                    Some('"') => {
                        if chars.get(i + 1) == Some(&'"') {
                            s.push('"');
                            i += 2;
                        } else {
                            i += 1;
                            break;
                        }
                    }
                    Some(ch) => {
                        s.push(*ch);
                        i += 1;
                    }
                }
            }
            out.push(Tok::Str(s));
            continue;
        }
        if c.is_ascii_digit()
            || (c == '.'
                && chars
                    .get(i + 1)
                    .map(|d| d.is_ascii_digit())
                    .unwrap_or(false))
        {
            let start = i;
            while i < chars.len()
                && (chars[i].is_ascii_digit()
                    || chars[i] == '.'
                    || chars[i].is_ascii_alphabetic() && (chars[i] == 'E' || chars[i] == 'e'))
            {
                i += 1;
            }
            let text: String = chars[start..i].iter().collect();
            out.push(Tok::Num(text.parse().map_err(|_| "#VALUE!")?));
            continue;
        }
        if c.is_alphabetic() || c == '$' || c == '_' {
            let start = i;
            while i < chars.len()
                && (chars[i].is_alphanumeric() || matches!(chars[i], '$' | '_' | '.' | '!'))
            {
                i += 1;
            }
            let raw: String = chars[start..i].iter().collect();
            // `A1`, `$A$1`, `Sheet2!A1`, `A1:B2`, `Sheet2!A1:B9`
            if let Some(tok) = try_reference(&raw) {
                out.push(tok);
                continue;
            }
            // A range written with whitespace or one half quoted is not
            // supported; plain identifiers are function names or booleans.
            out.push(Tok::Ident(raw));
            continue;
        }
        if c == ':' {
            // `A1:B2` where the left half was already lexed as a reference.
            if let Some(Tok::Ref { sheet, r, c }) = out.pop() {
                i += 1;
                let start = i;
                while i < chars.len()
                    && (chars[i].is_alphanumeric() || matches!(chars[i], '$' | '_' | '!'))
                {
                    i += 1;
                }
                let raw: String = chars[start..i].iter().collect();
                match try_reference(&raw) {
                    Some(Tok::Ref {
                        sheet: s2,
                        r: r2,
                        c: c2,
                    }) => {
                        out.push(Tok::Range {
                            sheet: s2.or(sheet),
                            r1: r.min(r2),
                            c1: c.min(c2),
                            r2: r.max(r2),
                            c2: c.max(c2),
                        });
                        continue;
                    }
                    _ => return Err("#REF!"),
                }
            }
            return Err("#REF!");
        }
        let two: String = chars[i..(i + 2).min(chars.len())].iter().collect();
        if matches!(two.as_str(), "<=" | ">=" | "<>") {
            out.push(Tok::Op(two));
            i += 2;
            continue;
        }
        if "+-*/^&%=<>(),".contains(c) {
            out.push(Tok::Op(c.to_string()));
            i += 1;
            continue;
        }
        return Err("#VALUE!");
    }
    Ok(out)
}

fn try_reference(raw: &str) -> Option<Tok> {
    let (sheet, addr) = match raw.rsplit_once('!') {
        Some((s, a)) => (Some(s.trim_matches('\'').to_string()), a),
        None => (None, raw),
    };
    let (r, c) = crate::xlsx::parse_ref(addr)?;
    // Reject things that are clearly not references (e.g. `LOG10`).
    if !addr.chars().any(|ch| ch.is_ascii_digit()) || addr.starts_with('.') {
        return None;
    }
    Some(Tok::Ref { sheet, r, c })
}

#[derive(Debug, Clone)]
enum Arg {
    Value(CValue),
    Range {
        sheet: Option<usize>,
        r1: u32,
        c1: u32,
        r2: u32,
        c2: u32,
    },
}

struct CalcParser<'a> {
    toks: Vec<Tok>,
    pos: usize,
    wb: &'a Workbook,
    sheet: usize,
}

impl<'a> CalcParser<'a> {
    fn peek(&self) -> Option<&Tok> {
        self.toks.get(self.pos)
    }
    fn bump(&mut self) -> Option<Tok> {
        let t = self.toks.get(self.pos).cloned();
        self.pos += 1;
        t
    }
    fn eat_op(&mut self, op: &str) -> bool {
        if matches!(self.peek(), Some(Tok::Op(o)) if o == op) {
            self.pos += 1;
            true
        } else {
            false
        }
    }

    fn read_cell(&self, sheet: Option<usize>, r1: u32, c1: u32, r2: u32, c2: u32) -> CValue {
        // A single cell yields its value; a multi-cell range yields its
        // top-left value (Excel would spill an array — error instead).
        let sheet = sheet.unwrap_or(self.sheet);
        if (r1, c1) != (r2, c2) {
            return CValue::Error("#VALUE!");
        }
        self.cell_value(sheet, r1, c1)
    }

    fn cell_value(&self, sheet: usize, row: u32, col: u32) -> CValue {
        let Some(s) = self.wb.sheets.get(sheet) else {
            return CValue::Error("#REF!");
        };
        let Some(cell) = s.get(row, col) else {
            return CValue::Empty;
        };
        match &cell.value {
            CellValue::Empty => CValue::Empty,
            CellValue::Number(n) => CValue::Number(*n),
            CellValue::Text(t) => CValue::Str(t.clone()),
            CellValue::Bool(b) => CValue::Bool(*b),
            CellValue::Error(e) => match e.as_str() {
                "#DIV/0!" => CValue::Error("#DIV/0!"),
                "#VALUE!" => CValue::Error("#VALUE!"),
                "#NAME?" => CValue::Error("#NAME?"),
                "#REF!" => CValue::Error("#REF!"),
                "#N/A" => CValue::Error("#N/A"),
                _ => CValue::Error("#VALUE!"),
            },
            CellValue::Formula { expr, cached, .. } => match cached {
                Some(n) => CValue::Number(*n),
                None => match expr.as_str() {
                    "" => CValue::Empty,
                    _ => CValue::Empty,
                },
            },
        }
    }

    fn resolve_sheet(&self, name: &Option<String>) -> Result<usize, &'static str> {
        match name {
            None => Ok(self.sheet),
            Some(n) => self.wb.sheet_index(n).ok_or("#REF!"),
        }
    }

    fn range_values(
        &self,
        sheet: Option<usize>,
        r1: u32,
        c1: u32,
        r2: u32,
        c2: u32,
    ) -> Vec<CValue> {
        let sheet = sheet.unwrap_or(self.sheet);
        let mut out = Vec::new();
        for r in r1..=r2 {
            for c in c1..=c2 {
                out.push(self.cell_value(sheet, r, c));
            }
        }
        out
    }

    fn parse_expr(&mut self, min_prec: u8) -> Result<Arg, &'static str> {
        let mut lhs = self.parse_unary()?;
        while let Some(Tok::Op(raw)) = self.peek() {
            let (op, prec) = match raw.as_str() {
                "=" => ("=", 1u8),
                "<>" => ("<>", 1),
                "<" => ("<", 1),
                "<=" => ("<=", 1),
                ">" => (">", 1),
                ">=" => (">=", 1),
                "&" => ("&", 2),
                "+" => ("+", 3),
                "-" => ("-", 3),
                "*" => ("*", 4),
                "/" => ("/", 4),
                "^" => ("^", 5),
                _ => break,
            };
            if prec < min_prec {
                break;
            }
            self.pos += 1;
            let next_min = if op == "^" { prec } else { prec + 1 };
            let rhs = self.parse_expr(next_min)?;
            let a = match lhs {
                Arg::Value(v) => v,
                Arg::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                } => self.read_cell(sheet.or(Some(self.sheet)), r1, c1, r2, c2),
            };
            let b = match rhs {
                Arg::Value(v) => v,
                Arg::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                } => self.read_cell(sheet, r1, c1, r2, c2),
            };
            lhs = Arg::Value(self.arith(op, a, b)?);
        }
        Ok(lhs)
    }

    fn parse_unary(&mut self) -> Result<Arg, &'static str> {
        if self.eat_op("-") {
            let inner = self.parse_unary()?;
            let v = match inner {
                Arg::Value(v) => v,
                Arg::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                } => self.read_cell(sheet, r1, c1, r2, c2),
            };
            return Ok(Arg::Value(CValue::Number(-v.to_number()?)));
        }
        if self.eat_op("+") {
            return self.parse_unary();
        }
        self.parse_primary()
    }

    fn parse_primary(&mut self) -> Result<Arg, &'static str> {
        match self.bump() {
            Some(Tok::Num(n)) => Ok(Arg::Value(CValue::Number(n))),
            Some(Tok::Str(s)) => Ok(Arg::Value(CValue::Str(s))),
            Some(Tok::Ref { sheet, r, c }) => Ok(Arg::Range {
                sheet: Some(self.resolve_sheet(&sheet)?),
                r1: r,
                c1: c,
                r2: r,
                c2: c,
            }),
            Some(Tok::Range {
                sheet,
                r1,
                c1,
                r2,
                c2,
            }) => Ok(Arg::Range {
                sheet: Some(self.resolve_sheet(&sheet)?),
                r1,
                c1,
                r2,
                c2,
            }),
            Some(Tok::Ident(name)) => {
                let upper = name.to_ascii_uppercase();
                if self.eat_op("(") {
                    let mut args = Vec::new();
                    if !self.eat_op(")") {
                        loop {
                            // Argument errors become values so that IFERROR and
                            // IF can inspect them, exactly like Excel.
                            match self.parse_expr(0) {
                                Ok(a) => args.push(a),
                                Err(e) => args.push(Arg::Value(CValue::Error(e))),
                            }
                            if self.eat_op(",") {
                                continue;
                            }
                            break;
                        }
                        if !self.eat_op(")") {
                            return Err("#VALUE!");
                        }
                    }
                    let value = match self.call_function(&upper, args) {
                        Ok(v) => v,
                        Err(e) => CValue::Error(e),
                    };
                    Ok(Arg::Value(value))
                } else {
                    match upper.as_str() {
                        "TRUE" => Ok(Arg::Value(CValue::Bool(true))),
                        "FALSE" => Ok(Arg::Value(CValue::Bool(false))),
                        _ => Err("#NAME?"),
                    }
                }
            }
            Some(Tok::Op(o)) if o == "(" => {
                let inner = self.parse_expr(0)?;
                if !self.eat_op(")") {
                    return Err("#VALUE!");
                }
                Ok(inner)
            }
            _ => Err("#VALUE!"),
        }
    }

    fn arith(&self, op: &str, a: CValue, b: CValue) -> Result<CValue, &'static str> {
        match op {
            "&" => return Ok(CValue::Str(format!("{}{}", a.to_text(), b.to_text()))),
            "=" | "<>" | "<" | "<=" | ">" | ">=" => {
                let ord = match (&a, &b) {
                    (CValue::Str(x), CValue::Str(y)) => Some(x.cmp(y)),
                    (CValue::Empty, CValue::Empty) => Some(std::cmp::Ordering::Equal),
                    _ => a
                        .to_number()?
                        .partial_cmp(&b.to_number()?)
                        .or(Some(std::cmp::Ordering::Equal)),
                };
                let ord = ord.ok_or("#VALUE!")?;
                let ok = match op {
                    "=" => ord == std::cmp::Ordering::Equal,
                    "<>" => ord != std::cmp::Ordering::Equal,
                    "<" => ord == std::cmp::Ordering::Less,
                    "<=" => ord != std::cmp::Ordering::Greater,
                    ">" => ord == std::cmp::Ordering::Greater,
                    _ => ord != std::cmp::Ordering::Less,
                };
                return Ok(CValue::Bool(ok));
            }
            _ => {}
        }
        let x = a.to_number()?;
        let y = b.to_number()?;
        Ok(CValue::Number(match op {
            "+" => x + y,
            "-" => x - y,
            "*" => x * y,
            "/" => {
                if y == 0.0 {
                    return Err("#DIV/0!");
                }
                x / y
            }
            "^" => x.powf(y),
            _ => return Err("#VALUE!"),
        }))
    }

    fn flat_numbers(&self, args: &[Arg]) -> Result<Vec<f64>, &'static str> {
        let mut out = Vec::new();
        for a in args {
            match a {
                Arg::Value(v) => {
                    if let CValue::Error(e) = v {
                        return Err(e);
                    }
                    match v {
                        CValue::Empty => {}
                        CValue::Number(n) => out.push(*n),
                        CValue::Bool(b) => out.push(if *b { 1.0 } else { 0.0 }),
                        CValue::Str(s) => {
                            if let Ok(n) = s.trim().parse::<f64>() {
                                out.push(n)
                            }
                        }
                        _ => {}
                    }
                }
                Arg::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                } => {
                    for v in self.range_values(*sheet, *r1, *c1, *r2, *c2) {
                        match v {
                            CValue::Number(n) => out.push(n),
                            CValue::Error(e) => return Err(e),
                            _ => {}
                        }
                    }
                }
            }
        }
        Ok(out)
    }

    fn flat_texts(&self, args: &[Arg]) -> Vec<String> {
        let mut out = Vec::new();
        for a in args {
            match a {
                Arg::Value(v) => out.push(v.to_text()),
                Arg::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                } => {
                    for v in self.range_values(*sheet, *r1, *c1, *r2, *c2) {
                        out.push(v.to_text());
                    }
                }
            }
        }
        out
    }

    fn call_function(&mut self, name: &str, args: Vec<Arg>) -> Result<CValue, &'static str> {
        let single = |args: &[Arg], i: usize| -> Result<CValue, &'static str> {
            match args.get(i) {
                Some(Arg::Value(v)) => Ok(v.clone()),
                Some(Arg::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                }) => Ok(self.read_cell(*sheet, *r1, *c1, *r2, *c2)),
                None => Ok(CValue::Empty),
            }
        };
        match name {
            "SUM" => Ok(CValue::Number(self.flat_numbers(&args)?.iter().sum())),
            "PRODUCT" => Ok(CValue::Number(
                self.flat_numbers(&args)?.iter().product::<f64>(),
            )),
            "AVERAGE" => {
                let nums = self.flat_numbers(&args)?;
                if nums.is_empty() {
                    Err("#DIV/0!")
                } else {
                    Ok(CValue::Number(nums.iter().sum::<f64>() / nums.len() as f64))
                }
            }
            "MIN" => {
                let nums = self.flat_numbers(&args)?;
                Ok(CValue::Number(
                    nums.iter()
                        .cloned()
                        .fold(f64::INFINITY, f64::min)
                        .min(f64::MAX),
                ))
            }
            "MAX" => {
                let nums = self.flat_numbers(&args)?;
                Ok(CValue::Number(
                    nums.iter().cloned().fold(f64::NEG_INFINITY, f64::max),
                ))
            }
            "COUNT" => Ok(CValue::Number(self.flat_numbers(&args)?.len() as f64)),
            "COUNTA" => Ok(CValue::Number(
                self.flat_texts(&args)
                    .iter()
                    .filter(|s| !s.is_empty())
                    .count() as f64,
            )),
            "COUNTBLANK" => Ok(CValue::Number(
                self.flat_texts(&args)
                    .iter()
                    .filter(|s| s.is_empty())
                    .count() as f64,
            )),
            "IF" => {
                let cond = single(&args, 0)?;
                if cond.to_bool()? {
                    single(&args, 1)
                } else if args.len() > 2 {
                    single(&args, 2)
                } else {
                    Ok(CValue::Bool(false))
                }
            }
            "IFERROR" => {
                let v = single(&args, 0)?;
                if matches!(v, CValue::Error(_)) {
                    single(&args, 1)
                } else {
                    Ok(v)
                }
            }
            "AND" => {
                for v in self.flat_texts(&args) {
                    if !(v.eq_ignore_ascii_case("true") || v == "1") {
                        return Ok(CValue::Bool(false));
                    }
                }
                Ok(CValue::Bool(true))
            }
            "OR" => {
                for v in self.flat_texts(&args) {
                    if v.eq_ignore_ascii_case("true") || v == "1" {
                        return Ok(CValue::Bool(true));
                    }
                }
                Ok(CValue::Bool(false))
            }
            "NOT" => Ok(CValue::Bool(!single(&args, 0)?.to_bool()?)),
            "ABS" => Ok(CValue::Number(single(&args, 0)?.to_number()?.abs())),
            "INT" => Ok(CValue::Number(single(&args, 0)?.to_number()?.floor())),
            "MOD" => {
                let a = single(&args, 0)?.to_number()?;
                let b = single(&args, 1)?.to_number()?;
                if b == 0.0 {
                    Err("#DIV/0!")
                } else {
                    Ok(CValue::Number(a.rem_euclid(b)))
                }
            }
            "POWER" => Ok(CValue::Number(
                single(&args, 0)?
                    .to_number()?
                    .powf(single(&args, 1)?.to_number()?),
            )),
            "SQRT" => Ok(CValue::Number(single(&args, 0)?.to_number()?.sqrt())),
            "EXP" => Ok(CValue::Number(single(&args, 0)?.to_number()?.exp())),
            "LN" => Ok(CValue::Number(single(&args, 0)?.to_number()?.ln())),
            "LOG10" => Ok(CValue::Number(single(&args, 0)?.to_number()?.log10())),
            "ROUND" | "ROUNDUP" | "ROUNDDOWN" => {
                let v = single(&args, 0)?.to_number()?;
                let digits = single(&args, 1)?.to_number()? as i32;
                let factor = 10f64.powi(digits);
                let scaled = v * factor;
                let rounded = match name {
                    "ROUND" => scaled.round(),
                    "ROUNDUP" => scaled.abs().ceil() * scaled.signum(),
                    _ => scaled.abs().floor() * scaled.signum(),
                };
                Ok(CValue::Number(rounded / factor))
            }
            "LEN" => Ok(CValue::Number(
                single(&args, 0)?.to_text().chars().count() as f64
            )),
            "LEFT" => {
                let s = single(&args, 0)?.to_text();
                let n = if args.len() > 1 {
                    single(&args, 1)?.to_number()? as usize
                } else {
                    1
                };
                Ok(CValue::Str(s.chars().take(n).collect()))
            }
            "RIGHT" => {
                let s = single(&args, 0)?.to_text();
                let n = if args.len() > 1 {
                    single(&args, 1)?.to_number()? as usize
                } else {
                    1
                };
                let chars: Vec<char> = s.chars().collect();
                let from = chars.len().saturating_sub(n);
                Ok(CValue::Str(chars[from..].iter().collect()))
            }
            "MID" => {
                let s = single(&args, 0)?.to_text();
                let start = single(&args, 1)?.to_number()?.max(1.0) as usize;
                let len = single(&args, 2)?.to_number()?.max(0.0) as usize;
                let chars: Vec<char> = s.chars().collect();
                let from = (start - 1).min(chars.len());
                let to = (from + len).min(chars.len());
                Ok(CValue::Str(chars[from..to].iter().collect()))
            }
            "TRIM" => Ok(CValue::Str(single(&args, 0)?.to_text().trim().to_string())),
            "UPPER" => Ok(CValue::Str(single(&args, 0)?.to_text().to_uppercase())),
            "LOWER" => Ok(CValue::Str(single(&args, 0)?.to_text().to_lowercase())),
            "PROPER" => {
                let s = single(&args, 0)?.to_text();
                let mut out = String::new();
                let mut cap = true;
                for ch in s.chars() {
                    if ch.is_alphabetic() {
                        if cap {
                            out.extend(ch.to_uppercase());
                        } else {
                            out.extend(ch.to_lowercase());
                        }
                        cap = false;
                    } else {
                        out.push(ch);
                        cap = true;
                    }
                }
                Ok(CValue::Str(out))
            }
            "CONCAT" | "CONCATENATE" => Ok(CValue::Str(self.flat_texts(&args).join(""))),
            "VALUE" => Ok(CValue::Number(single(&args, 0)?.to_number()?)),
            "ISBLANK" => Ok(CValue::Bool(matches!(single(&args, 0)?, CValue::Empty))),
            "ISNUMBER" => Ok(CValue::Bool(matches!(single(&args, 0)?, CValue::Number(_)))),
            "ISTEXT" => Ok(CValue::Bool(matches!(single(&args, 0)?, CValue::Str(_)))),
            // Anything the core does not implement itself is dispatched to the
            // function library, which covers the lookup / text / date /
            // statistical / financial families.
            _ => {
                let fargs = to_fargs(&args);
                match crate::funcs::call(name, &fargs, self) {
                    Some(result) => result,
                    None => Err("#NAME?"),
                }
            }
        }
    }
}

fn to_fargs(args: &[Arg]) -> Vec<crate::funcs::FArg> {
    args.iter()
        .map(|a| match a {
            Arg::Value(v) => crate::funcs::FArg::Value(v.clone()),
            Arg::Range {
                sheet,
                r1,
                c1,
                r2,
                c2,
            } => crate::funcs::FArg::Range(crate::funcs::RangeRef {
                sheet: *sheet,
                r1: *r1,
                c1: *c1,
                r2: *r2,
                c2: *c2,
            }),
        })
        .collect()
}

impl<'a> crate::funcs::Grid for CalcParser<'a> {
    fn value(&self, sheet: Option<usize>, row: u32, col: u32) -> CValue {
        self.cell_value(sheet.unwrap_or(self.sheet), row, col)
    }

    fn sheet_index(&self, name: &str) -> Option<usize> {
        self.wb.sheet_index(name)
    }
}

/// Apply cached formula results so that a freshly written workbook shows
/// numbers in viewers that do not calculate.
pub fn recalculate_to_bytes(wb: &mut Workbook) -> crate::Result<Vec<u8>> {
    wb.recalculate();
    wb.to_bytes()
}
