//! Word processing engine: `.docx` reader/writer (WordprocessingML).
//!
//! Supported on write: paragraphs, character formatting (bold / italic /
//! underline / strike / size / colour / monospace), heading levels 1-6, title,
//! quote, code, bulleted and numbered lists, tables with a header row,
//! alignment, page size/margins/orientation and explicit page breaks.
//!
//! Supported on read: everything above plus `w:br`/`w:tab` inside runs, and a
//! `Text`/`Markdown` export used by the CLI and by the "paste as text" path.

use std::fmt::Write as _;

use crate::error::{Error, Result};
use crate::pkg::{self, Package};
use crate::xml::{self, Event, Reader};

const NS_W: &str = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
const NS_R: &str = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const CT_DOC: &str =
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml";
const CT_STYLES: &str = "application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml";
const CT_NUMBERING: &str =
    "application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml";
const CT_SETTINGS: &str =
    "application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml";
const RT_DOC: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument";
const RT_STYLES: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles";
const RT_NUMBERING: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering";
const RT_SETTINGS: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings";

/// Horizontal alignment of a paragraph.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum Align {
    #[default]
    Left,
    Center,
    Right,
    Justify,
}

impl Align {
    pub fn as_str(self) -> Option<&'static str> {
        match self {
            Align::Left => None,
            Align::Center => Some("center"),
            Align::Right => Some("right"),
            Align::Justify => Some("both"),
        }
    }
}

/// The paragraph styles the writer emits; all of them exist in `styles.xml`.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub enum ParaStyle {
    #[default]
    Normal,
    Title,
    Heading(u8),
    Quote,
    Code,
    Bullet,
    Numbered,
}

impl ParaStyle {
    fn style_id(&self) -> Option<String> {
        match self {
            ParaStyle::Normal => None,
            ParaStyle::Title => Some("Title".into()),
            ParaStyle::Heading(n) => Some(format!("Heading{}", (*n).clamp(1, 6))),
            ParaStyle::Quote => Some("Quote".into()),
            ParaStyle::Code => Some("PocCode".into()),
            ParaStyle::Bullet => Some("ListParagraph".into()),
            ParaStyle::Numbered => Some("ListParagraph".into()),
        }
    }

    fn num_id(&self) -> Option<u32> {
        match self {
            ParaStyle::Bullet => Some(1),
            ParaStyle::Numbered => Some(2),
            _ => None,
        }
    }

    pub fn from_style_id(id: &str) -> ParaStyle {
        match id {
            "Title" => ParaStyle::Title,
            "Quote" => ParaStyle::Quote,
            "PocCode" => ParaStyle::Code,
            "ListParagraph" => ParaStyle::Bullet,
            other if other.starts_with("Heading") => other[7..]
                .parse()
                .map(ParaStyle::Heading)
                .unwrap_or(ParaStyle::Normal),
            _ => ParaStyle::Normal,
        }
    }
}

/// Revision marks used by 変更履歴 (track changes).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum Change {
    #[default]
    None,
    /// Text that was added (`w:ins`).
    Inserted,
    /// Text that was removed but is kept for review (`w:del`).
    Deleted,
}

/// A paragraph-level note (「脚注」).
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Footnote {
    pub text: String,
}

impl Footnote {
    pub fn new(text: impl Into<String>) -> Self {
        Footnote { text: text.into() }
    }
}

/// A review comment anchored to a paragraph.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct DocComment {
    pub author: String,
    pub initials: String,
    pub date: String,
    pub text: String,
}

impl DocComment {
    pub fn new(author: impl Into<String>, text: impl Into<String>) -> Self {
        let author = author.into();
        DocComment {
            initials: author.chars().take(2).collect(),
            author,
            date: "2026-01-01T00:00:00Z".into(),
            text: text.into(),
        }
    }
}

/// Running header / footer text. `page_number` adds a `PAGE` field.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct HeaderFooter {
    pub text: String,
    pub page_number: bool,
}

impl HeaderFooter {
    pub fn new(text: impl Into<String>) -> Self {
        HeaderFooter {
            text: text.into(),
            page_number: false,
        }
    }
    pub fn page_number(mut self) -> Self {
        self.page_number = true;
        self
    }
}

/// An inline picture.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Picture {
    pub data: Vec<u8>,
    /// `png` or `jpeg`.
    pub ext: String,
    pub width_mm: f32,
    pub height_mm: f32,
    pub name: String,
}

impl Picture {
    /// Wrap the picture in its own paragraph.
    pub fn into_block(self, name: impl Into<String>) -> Block {
        Block::Image(Picture {
            name: name.into(),
            ..self
        })
    }

    pub fn new(data: Vec<u8>, width_mm: f32, height_mm: f32) -> Self {
        let ext = if data.starts_with(b"\x89PNG") {
            "png"
        } else if data.starts_with(&[0xFF, 0xD8]) {
            "jpeg"
        } else {
            "png"
        };
        Picture {
            data,
            ext: ext.into(),
            width_mm,
            height_mm,
            name: String::new(),
        }
    }
}

/// A run of characters with uniform formatting.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Run {
    pub text: String,
    pub bold: bool,
    pub italic: bool,
    pub underline: bool,
    pub strike: bool,
    pub size_pt: Option<f32>,
    /// Six hex digits, e.g. `C00000`.
    pub color: Option<String>,
    pub mono: bool,
    /// Explicit font family for this run (Writer's 170-font list).
    pub font: Option<String>,
    /// External hyperlink target (`https://…`, `mailto:…`).
    pub link: Option<String>,
    /// Track-changes mark around this run.
    pub change: Change,
}

impl Run {
    pub fn new(text: impl Into<String>) -> Self {
        Run {
            text: text.into(),
            ..Default::default()
        }
    }
    pub fn bold(mut self) -> Self {
        self.bold = true;
        self
    }
    /// Explicit font family (writes `w:rFonts` for all script slots).
    pub fn font(mut self, family: impl Into<String>) -> Self {
        self.font = Some(family.into());
        self
    }
    /// External hyperlink; the document gets a `TargetMode="External"` rel.
    pub fn link(mut self, url: impl Into<String>) -> Self {
        self.link = Some(url.into());
        self
    }
    pub fn italic(mut self) -> Self {
        self.italic = true;
        self
    }
    pub fn underline(mut self) -> Self {
        self.underline = true;
        self
    }
    pub fn size(mut self, pt: f32) -> Self {
        self.size_pt = Some(pt);
        self
    }
    pub fn color(mut self, hex: impl Into<String>) -> Self {
        self.color = Some(hex.into());
        self
    }
    pub fn mono(mut self) -> Self {
        self.mono = true;
        self
    }
    /// Mark the run as newly inserted text.
    pub fn inserted(mut self) -> Self {
        self.change = Change::Inserted;
        self
    }
    /// Mark the run as deleted text that is kept for review.
    pub fn deleted(mut self) -> Self {
        self.change = Change::Deleted;
        self
    }
}

/// A paragraph.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Paragraph {
    pub style: ParaStyle,
    pub runs: Vec<Run>,
    pub align: Align,
    /// Extra left indent in millimetres (used by quotes/code).
    pub indent_mm: Option<f32>,
    /// Comment id anchored to this paragraph (see [`Document::comments`]).
    pub comment: Option<u32>,
    /// Footnote id referenced at the end of the paragraph.
    pub footnote: Option<u32>,
}

impl Paragraph {
    pub fn new(text: impl Into<String>) -> Self {
        Paragraph {
            runs: vec![Run::new(text)],
            ..Default::default()
        }
    }
    pub fn styled(style: ParaStyle, text: impl Into<String>) -> Self {
        Paragraph {
            style,
            ..Paragraph::new(text)
        }
    }
    pub fn with_runs(runs: Vec<Run>) -> Self {
        Paragraph {
            runs,
            ..Default::default()
        }
    }
    pub fn align(mut self, align: Align) -> Self {
        self.align = align;
        self
    }
    /// Attach a footnote, returning the document a caller must register it on.
    pub fn with_footnote(mut self, id: u32) -> Self {
        self.footnote = Some(id);
        self
    }
    /// Attach a review comment.
    pub fn with_comment(mut self, id: u32) -> Self {
        self.comment = Some(id);
        self
    }
    /// Concatenated text of all runs.
    pub fn text(&self) -> String {
        self.runs.iter().map(|r| r.text.as_str()).collect()
    }
}

/// A simple table; the first row is rendered as a shaded header.
#[derive(Debug, Clone, PartialEq)]
pub struct Table {
    pub rows: Vec<Vec<String>>,
    pub header: bool,
}

impl Table {
    pub fn new(rows: Vec<Vec<String>>) -> Self {
        Table { rows, header: true }
    }
}

/// Block-level content.
#[derive(Debug, Clone, PartialEq)]
pub enum Block {
    Paragraph(Paragraph),
    Table(Table),
    PageBreak,
    /// An inline picture on its own paragraph.
    Image(Picture),
    /// A table-of-contents field (`TOC \\o "1-3" \\h \\z \\u`).
    Toc,
}

/// Page geometry (A4 by default).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PageSetup {
    /// Width and height in millimetres.
    pub width_mm: f32,
    pub height_mm: f32,
    pub margin_mm: f32,
}

impl Default for PageSetup {
    fn default() -> Self {
        PageSetup {
            width_mm: 210.0,
            height_mm: 297.0,
            margin_mm: 20.0,
        }
    }
}

/// A Word document.
#[derive(Debug, Clone, Default)]
pub struct Document {
    pub blocks: Vec<Block>,
    pub title: String,
    pub creator: String,
    pub created: String,
    pub page: PageSetup,
    /// Running header on every page.
    pub header: Option<HeaderFooter>,
    /// Running footer on every page.
    pub footer: Option<HeaderFooter>,
    pub footnotes: Vec<Footnote>,
    pub comments: Vec<DocComment>,
    /// Author recorded on tracked changes and comments.
    pub revision_author: String,
    /// Timestamp recorded on tracked changes.
    pub revision_date: String,
}

impl Document {
    pub fn new() -> Self {
        Document {
            blocks: Vec::new(),
            title: String::new(),
            creator: "Poccham Office Next".into(),
            created: pkg::now_w3cdtf(),
            page: PageSetup::default(),
            header: None,
            footer: None,
            footnotes: Vec::new(),
            comments: Vec::new(),
            revision_author: "Poccham Office Next".into(),
            revision_date: "2026-01-01T00:00:00Z".into(),
        }
    }

    pub fn push(&mut self, block: Block) -> &mut Self {
        self.blocks.push(block);
        self
    }

    pub fn para(&mut self, text: impl Into<String>) -> &mut Self {
        self.push(Block::Paragraph(Paragraph::new(text)))
    }

    pub fn heading(&mut self, level: u8, text: impl Into<String>) -> &mut Self {
        self.push(Block::Paragraph(Paragraph::styled(
            ParaStyle::Heading(level),
            text,
        )))
    }

    pub fn bullet(&mut self, text: impl Into<String>) -> &mut Self {
        self.push(Block::Paragraph(Paragraph::styled(ParaStyle::Bullet, text)))
    }

    pub fn table(&mut self, rows: Vec<Vec<String>>) -> &mut Self {
        self.push(Block::Table(Table::new(rows)))
    }

    /// Plain-text rendering (one line per paragraph, tab separated tables).
    pub fn to_text(&self) -> String {
        let mut out = String::new();
        for block in &self.blocks {
            match block {
                Block::Paragraph(p) => {
                    out.push_str(&p.text());
                    out.push('\n');
                }
                Block::Table(t) => {
                    for row in &t.rows {
                        out.push_str(&row.join("\t"));
                        out.push('\n');
                    }
                }
                Block::PageBreak => out.push('\n'),
                Block::Image(_) => out.push_str("[画像]\n"),
                Block::Toc => out.push_str("[目次]\n"),
            }
        }
        out
    }

    /// Markdown rendering, used for previews and for quick conversions.
    pub fn to_markdown(&self) -> String {
        let mut out = String::new();
        for block in &self.blocks {
            match block {
                Block::Paragraph(p) => {
                    let mut line = String::new();
                    let prefix = match &p.style {
                        ParaStyle::Title => "# ".to_string(),
                        ParaStyle::Heading(n) => {
                            format!("{} ", "#".repeat((*n).clamp(1, 6) as usize))
                        }
                        ParaStyle::Quote => "> ".to_string(),
                        ParaStyle::Bullet => "- ".to_string(),
                        ParaStyle::Numbered => "1. ".to_string(),
                        _ => String::new(),
                    };
                    line.push_str(&prefix);
                    for run in &p.runs {
                        let mut text = run.text.clone();
                        if run.mono {
                            text = format!("`{text}`");
                        }
                        if run.bold && run.italic {
                            text = format!("***{text}***");
                        } else if run.bold {
                            text = format!("**{text}**");
                        } else if run.italic {
                            text = format!("*{text}*");
                        }
                        line.push_str(&text);
                    }
                    out.push_str(line.trim_end());
                    out.push_str("\n\n");
                }
                Block::Table(t) => {
                    if let Some((head, body)) = t.rows.split_first() {
                        out.push_str("| ");
                        out.push_str(&head.join(" | "));
                        out.push_str(" |\n|");
                        for _ in head {
                            out.push_str(" --- |");
                        }
                        out.push('\n');
                        for row in body {
                            out.push_str("| ");
                            out.push_str(&row.join(" | "));
                            out.push_str(" |\n");
                        }
                        out.push('\n');
                    }
                }
                Block::PageBreak => out.push_str("---\n\n"),
                Block::Image(pic) => {
                    let name = if pic.name.is_empty() {
                        "image"
                    } else {
                        &pic.name
                    };
                    out.push_str(&format!("![{name}]({name})\n\n"));
                }
                Block::Toc => out.push_str("\n- [目次](#目次)\n\n"),
            }
        }
        out.trim_end().to_string() + "\n"
    }

    // ---- serialisation -------------------------------------------------

    pub fn to_bytes(&self) -> Result<Vec<u8>> {
        let mut pkg = Package::new();
        let needs_numbering = self.blocks.iter().any(|b| match b {
            Block::Paragraph(p) => matches!(p.style, ParaStyle::Bullet | ParaStyle::Numbered),
            _ => false,
        });

        // Relationship ids are handed out in the order parts are added; the
        // body needs them up front, so plan the parts first.
        let mut rels: Vec<(String, String, String, bool)> = Vec::new();
        let mut next = 1u32;
        let mut next_rid = || {
            let id = format!("rId{next}");
            next += 1;
            id
        };
        rels.push((next_rid(), RT_STYLES.into(), "styles.xml".into(), false));
        if needs_numbering {
            rels.push((
                next_rid(),
                RT_NUMBERING.into(),
                "numbering.xml".into(),
                false,
            ));
        }
        rels.push((next_rid(), RT_SETTINGS.into(), "settings.xml".into(), false));

        let mut parts = DocParts::default();
        // External hyperlinks: one relationship per distinct URL.
        for block in &self.blocks {
            let Block::Paragraph(p) = block else { continue };
            for run in &p.runs {
                let Some(url) = run.link.as_deref() else {
                    continue;
                };
                if url.is_empty() || parts.link_rids.iter().any(|(u, _)| u == url) {
                    continue;
                }
                let rid = next_rid();
                rels.push((rid.clone(), RT_HYPERLINK.into(), url.into(), true));
                parts.link_rids.push((url.to_string(), rid));
            }
        }
        let mut overrides: Vec<(String, String)> = Vec::new();
        let mut defaults: Vec<(String, String)> = Vec::new();

        // pictures
        let mut image_no = 0usize;
        for block in &self.blocks {
            if let Block::Image(pic) = block {
                image_no += 1;
                let rid = next_rid();
                rels.push((
                    rid.clone(),
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"
                        .into(),
                    format!("media/image{image_no}.{}", pic.ext),
                    false,
                ));
                parts.image_rids.push(rid);
                pkg.insert(
                    &format!("word/media/image{image_no}.{}", pic.ext),
                    pic.data.clone(),
                );
                let ct = if pic.ext == "jpeg" {
                    "image/jpeg"
                } else {
                    "image/png"
                };
                if !defaults.iter().any(|(e, _)| *e == pic.ext) {
                    defaults.push((pic.ext.clone(), ct.into()));
                }
            }
        }

        // header / footer
        if let Some(header) = &self.header {
            let rid = next_rid();
            rels.push((
                rid.clone(),
                "http://schemas.openxmlformats.org/officeDocument/2006/relationships/header".into(),
                "header1.xml".into(),
                false,
            ));
            parts.header_rid = Some(rid);
            pkg.insert_str("word/header1.xml", write_header_footer(header));
            overrides.push((
                "/word/header1.xml".into(),
                "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml".into(),
            ));
        }
        if let Some(footer) = &self.footer {
            let rid = next_rid();
            rels.push((
                rid.clone(),
                "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer".into(),
                "footer1.xml".into(),
                false,
            ));
            parts.footer_rid = Some(rid);
            pkg.insert_str("word/footer1.xml", write_footer_part(footer));
            overrides.push((
                "/word/footer1.xml".into(),
                "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml".into(),
            ));
        }

        // footnotes: id 0/1 are the separator/continuation stubs Word expects
        if !self.footnotes.is_empty() {
            parts.has_footnotes = true;
            let rid = next_rid();
            rels.push((
                rid,
                "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes"
                    .into(),
                "footnotes.xml".into(),
                false,
            ));
            pkg.insert_str("word/footnotes.xml", write_footnotes(&self.footnotes));
            overrides.push((
                "/word/footnotes.xml".into(),
                "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml"
                    .into(),
            ));
        }

        // comments
        if !self.comments.is_empty() {
            parts.has_comments = true;
            let rid = next_rid();
            rels.push((
                rid,
                "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
                    .into(),
                "comments.xml".into(),
                false,
            ));
            pkg.insert_str("word/comments.xml", write_comments(&self.comments));
            overrides.push((
                "/word/comments.xml".into(),
                "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml"
                    .into(),
            ));
        }

        pkg.insert_str("word/document.xml", write_document(self, &parts));
        pkg.insert_str("word/styles.xml", STYLES_XML);
        if needs_numbering {
            pkg.insert_str("word/numbering.xml", NUMBERING_XML);
        }
        pkg.insert_str("word/settings.xml", SETTINGS_XML);
        pkg.insert_str("word/_rels/document.xml.rels", pkg::rels_xml(&rels));

        overrides.push(("/word/styles.xml".into(), CT_STYLES.into()));
        overrides.push(("/word/settings.xml".into(), CT_SETTINGS.into()));
        if needs_numbering {
            overrides.push(("/word/numbering.xml".into(), CT_NUMBERING.into()));
        }
        overrides.push((
            "/docProps/core.xml".into(),
            "application/vnd.openxmlformats-package.core-properties+xml".into(),
        ));
        overrides.push((
            "/docProps/app.xml".into(),
            "application/vnd.openxmlformats-officedocument.extended-properties+xml".into(),
        ));
        pkg.insert_str(
            "[Content_Types].xml",
            pkg::content_types_xml_full("/word/document.xml", CT_DOC, &defaults, &overrides),
        );
        pkg.insert_str("_rels/.rels", pkg::root_rels("word/document.xml", RT_DOC));
        pkg.insert_str(
            "docProps/core.xml",
            pkg::core_xml(&self.title, &self.creator, &self.created),
        );
        pkg.insert_str(
            "docProps/app.xml",
            pkg::app_xml(
                &crate::producer(),
                &[("Pages", "1"), ("ScaleCrop", "false")],
            ),
        );
        pkg.to_bytes()
    }

    pub fn save(&self, path: impl AsRef<std::path::Path>) -> Result<()> {
        std::fs::write(path, self.to_bytes()?)?;
        Ok(())
    }

    pub fn from_bytes(bytes: &[u8]) -> Result<Self> {
        let pkg = Package::from_bytes(bytes)?;
        let main = if pkg.contains("word/document.xml") {
            "word/document.xml"
        } else if pkg.contains("word/document2.xml") {
            "word/document2.xml"
        } else {
            return Err(Error::Format("missing word/document.xml".into()));
        };
        let src = pkg.get_str(main).unwrap();
        // External hyperlinks live in the part-level rels; resolve them so the
        // link survives a write -> read round trip.
        let mut links: Vec<(String, String)> = Vec::new();
        if let Some(rels) = pkg.get_str("word/_rels/document.xml.rels") {
            let mut rr = Reader::new(rels);
            loop {
                match rr.next_event() {
                    Event::Start { name, attrs, .. } if xml::local(&name) == "Relationship" => {
                        let id = attrs.iter().find(|(k, _)| xml::local(k) == "Id");
                        let ty = attrs.iter().find(|(k, _)| xml::local(k) == "Type");
                        let target = attrs.iter().find(|(k, _)| xml::local(k) == "Target");
                        let external = attrs
                            .iter()
                            .any(|(k, v)| xml::local(k) == "TargetMode" && v == "External");
                        if external && ty.map(|t| t.1.contains("/hyperlink")).unwrap_or(false) {
                            if let (Some(id), Some(target)) = (id, target) {
                                links.push((id.1.clone(), target.1.clone()));
                            }
                        }
                    }
                    Event::Eof => break,
                    _ => {}
                }
            }
        }
        let mut doc = Document::new();
        doc.blocks = read_blocks(src, &links)?;
        // Running header / footer parts
        if let Some(text) = pkg.get_str("word/header1.xml").map(part_text) {
            if !text.is_empty() {
                doc.header = Some(HeaderFooter::new(text));
            }
        }
        if let Some(text) = pkg.get_str("word/footer1.xml").map(part_text) {
            if !text.is_empty() {
                doc.footer = Some(HeaderFooter::new(text));
            }
        }
        if let Some(core) = pkg.get_str("docProps/core.xml") {
            let mut r = Reader::new(core);
            loop {
                match r.next_event() {
                    Event::Start { name, .. } if xml::local(&name) == "title" => {
                        doc.title = r.read_text()
                    }
                    Event::Start { name, .. } if xml::local(&name) == "creator" => {
                        doc.creator = r.read_text()
                    }
                    Event::Eof => break,
                    _ => {}
                }
            }
        }
        Ok(doc)
    }

    pub fn open(path: impl AsRef<std::path::Path>) -> Result<Self> {
        Document::from_bytes(&std::fs::read(path)?)
    }
}

/// Relationship type for external hyperlinks.
const RT_HYPERLINK: &str =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink";

/// Relationship ids the document body needs.
#[derive(Debug, Clone, Default)]
struct DocParts {
    /// One rel id per [`Block::Image`], in document order.
    image_rids: Vec<String>,
    /// `(url, rel id)` for every external hyperlink in the body.
    link_rids: Vec<(String, String)>,
    header_rid: Option<String>,
    footer_rid: Option<String>,
    has_footnotes: bool,
    has_comments: bool,
}

impl DocParts {
    /// Rel id for an external URL, if the body registered one.
    fn link_rid(&self, url: &str) -> Option<&str> {
        self.link_rids
            .iter()
            .find(|(u, _)| u == url)
            .map(|(_, rid)| rid.as_str())
    }
}

fn write_document(doc: &Document, parts: &DocParts) -> String {
    let mut s = String::with_capacity(1024 + doc.blocks.len() * 128);
    s.push_str(xml::DECL);
    let _ = write!(
        s,
        r#"<w:document xmlns:w="{NS_W}" xmlns:r="{NS_R}" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">"#
    );
    s.push_str("<w:body>");
    let mut image_no = 0usize;
    for block in &doc.blocks {
        match block {
            Block::Paragraph(p) => write_paragraph(&mut s, p, doc, parts),
            Block::Table(t) => write_table(&mut s, t),
            Block::PageBreak => {
                s.push_str(r#"<w:p><w:r><w:br w:type="page"/></w:r></w:p>"#);
            }
            Block::Image(pic) => {
                let rid = parts
                    .image_rids
                    .get(image_no)
                    .cloned()
                    .unwrap_or_else(|| "rId99".into());
                image_no += 1;
                write_picture(&mut s, pic, &rid, image_no);
            }
            Block::Toc => write_toc(&mut s),
        }
    }
    // Section properties: page geometry plus the header/footer references.
    let twips = |mm: f32| (mm * 56.692_913_f32).round() as i64;
    let mut sect = String::new();
    if let Some(rid) = &parts.header_rid {
        xml::open_tag(
            &mut sect,
            "w:headerReference",
            &[("w:type", "default"), ("r:id", rid)],
            true,
        );
    }
    if let Some(rid) = &parts.footer_rid {
        xml::open_tag(
            &mut sect,
            "w:footerReference",
            &[("w:type", "default"), ("r:id", rid)],
            true,
        );
    }
    let _ = write!(
        sect,
        r#"<w:pgSz w:w="{w}" w:h="{h}"/><w:pgMar w:top="{m}" w:right="{m}" w:bottom="{m}" w:left="{m}" w:header="425" w:footer="425" w:gutter="0"/><w:cols w:space="425"/><w:docGrid w:linePitch="360"/>"#,
        w = twips(doc.page.width_mm),
        h = twips(doc.page.height_mm),
        m = twips(doc.page.margin_mm)
    );
    if parts.has_footnotes {
        sect.push_str(r#"<w:footnotePr><w:numFmt w:val="decimal"/></w:footnotePr>"#);
    }
    s.push_str("<w:sectPr>");
    s.push_str(&sect);
    s.push_str("</w:sectPr>");
    s.push_str("</w:body></w:document>");
    s
}

/// An inline picture: `<w:drawing>` → `wp:inline` → `pic:pic`.
fn write_picture(out: &mut String, pic: &Picture, rid: &str, index: usize) {
    let emu = |mm: f32| (mm * 36_000.0).round() as i64;
    let cx = emu(if pic.width_mm > 0.0 {
        pic.width_mm
    } else {
        80.0
    });
    let cy = emu(if pic.height_mm > 0.0 {
        pic.height_mm
    } else {
        60.0
    });
    let name = if pic.name.is_empty() {
        format!("picture{index}.{}", pic.ext)
    } else {
        pic.name.clone()
    };
    out.push_str(r#"<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:drawing>"#);
    let _ = write!(
        out,
        r#"<wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:docPr id="{index}" name="{}"/><wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="{index}" name="{}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline>"#,
        xml::esc(&name),
        xml::esc(&name)
    );
    out.push_str("</w:drawing></w:r></w:p>");
}

/// A `TOC` field with a placeholder result so the page is never blank.
fn write_toc(out: &mut String) {
    out.push_str(r#"<w:sdt><w:sdtPr><w:docPartObj><w:docPartGallery w:val="Table of Contents"/><w:docPartUnique/></w:docPartObj></w:sdtPr><w:sdtContent>"#);
    out.push_str(
        r#"<w:p><w:pPr><w:pStyle w:val="TOCHeading"/></w:pPr><w:r><w:t>目次</w:t></w:r></w:p>"#,
    );
    out.push_str(r#"<w:p><w:r><w:fldChar w:fldCharType="begin" w:dirty="true"/></w:r><w:r><w:instrText xml:space="preserve"> TOC \o "1-3" \h \z \u </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>目次を更新するには F9 キーを押してください。</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p>"#);
    out.push_str("</w:sdtContent></w:sdt>");
}

/// Header or footer part body.
/// `footnotes.xml`: the two required separator entries plus our notes.
fn write_footnotes(notes: &[Footnote]) -> String {
    let mut s = String::with_capacity(256 + notes.len() * 96);
    s.push_str(xml::DECL);
    let _ = write!(s, r#"<w:footnotes xmlns:w="{NS_W}" xmlns:r="{NS_R}">"#);
    s.push_str(r#"<w:footnote w:type="separator" w:id="-1"><w:p><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:r><w:separator/></w:r></w:p></w:footnote>"#);
    s.push_str(r#"<w:footnote w:type="continuationSeparator" w:id="0"><w:p><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:r><w:continuationSeparator/></w:r></w:p></w:footnote>"#);
    for (i, note) in notes.iter().enumerate() {
        let id = i + 2;
        let _ = write!(
            s,
            r#"<w:footnote w:id="{id}"><w:p><w:pPr><w:pStyle w:val="FootnoteText"/></w:pPr><w:r><w:rPr><w:rStyle w:val="FootnoteReference"/></w:rPr><w:footnoteRef/></w:r><w:r><w:t xml:space="preserve"> {} </w:t></w:r></w:p></w:footnote>"#,
            xml::esc(&note.text)
        );
    }
    s.push_str("</w:footnotes>");
    s
}

/// `comments.xml`.
fn write_comments(comments: &[DocComment]) -> String {
    let mut s = String::with_capacity(128 + comments.len() * 128);
    s.push_str(xml::DECL);
    let _ = write!(s, r#"<w:comments xmlns:w="{NS_W}" xmlns:r="{NS_R}">"#);
    for (i, c) in comments.iter().enumerate() {
        let _ = write!(
            s,
            r#"<w:comment w:id="{i}" w:author="{}" w:date="{}" w:initials="{}"><w:p><w:r><w:annotationRef/></w:r><w:r><w:t xml:space="preserve">{}</w:t></w:r></w:p></w:comment>"#,
            xml::esc(&c.author),
            xml::esc(&c.date),
            xml::esc(&c.initials),
            xml::esc(&c.text)
        );
    }
    s.push_str("</w:comments>");
    s
}

fn write_header_footer(hf: &HeaderFooter) -> String {
    let mut s = String::with_capacity(256);
    s.push_str(xml::DECL);
    let _ = write!(
        s,
        r#"<w:hdr xmlns:w="{NS_W}" xmlns:r="{NS_R}"><w:p><w:pPr><w:pStyle w:val="Header"/><w:jc w:val="right"/></w:pPr>"#
    );
    if !hf.text.is_empty() {
        s.push_str("<w:r>");
        xml::open_tag(&mut s, "w:t", &[("xml:space", "preserve")], false);
        xml::esc_into(&mut s, &hf.text);
        xml::close_tag(&mut s, "w:t");
        s.push_str("</w:r>");
    }
    if hf.page_number {
        s.push_str(r#"<w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>1</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r>"#);
    }
    s.push_str("</w:p></w:hdr>");
    s
}

fn write_footer_part(hf: &HeaderFooter) -> String {
    write_header_footer(hf)
        .replace("<w:hdr", "<w:ftr")
        .replace("</w:hdr>", "</w:ftr>")
}

fn write_paragraph(out: &mut String, p: &Paragraph, doc: &Document, parts: &DocParts) {
    out.push_str("<w:p>");
    let style_id = p.style.style_id();
    let num_id = p.style.num_id();
    if style_id.is_some() || num_id.is_some() || p.align.as_str().is_some() || p.indent_mm.is_some()
    {
        out.push_str("<w:pPr>");
        if let Some(id) = &style_id {
            xml::open_tag(out, "w:pStyle", &[("w:val", id)], true);
        }
        if let Some(n) = num_id {
            let n = n.to_string();
            out.push_str(&format!(
                r#"<w:numPr><w:ilvl w:val="0"/><w:numId w:val="{n}"/></w:numPr>"#
            ));
        }
        if let Some(a) = p.align.as_str() {
            xml::open_tag(out, "w:jc", &[("w:val", a)], true);
        }
        if let Some(mm) = p.indent_mm {
            let v = (mm * 56.692_913_f32).round() as i64;
            let v = format!("{v}");
            xml::open_tag(out, "w:ind", &[("w:left", &v)], true);
        }
        out.push_str("</w:pPr>");
    }
    if let Some(id) = p.comment {
        let id = id.to_string();
        xml::open_tag(out, "w:commentRangeStart", &[("w:id", &id)], true);
    }
    // Runs are grouped so that a stretch of tracked text becomes one `w:ins`
    // or `w:del` element, the way Word writes it.
    let mut i = 0;
    while i < p.runs.len() {
        let change = p.runs[i].change;
        let mut j = i;
        while j < p.runs.len() && p.runs[j].change == change {
            j += 1;
        }
        let group = &p.runs[i..j];
        let id = (i as u32 + 1).to_string();
        match change {
            Change::None => {
                for run in group {
                    write_run(out, run, false, parts);
                }
            }
            Change::Inserted => {
                xml::open_tag(
                    out,
                    "w:ins",
                    &[
                        ("w:id", &id),
                        ("w:author", &doc.revision_author),
                        ("w:date", &doc.revision_date),
                    ],
                    false,
                );
                for run in group {
                    write_run(out, run, false, parts);
                }
                out.push_str("</w:ins>");
            }
            Change::Deleted => {
                xml::open_tag(
                    out,
                    "w:del",
                    &[
                        ("w:id", &id),
                        ("w:author", &doc.revision_author),
                        ("w:date", &doc.revision_date),
                    ],
                    false,
                );
                for run in group {
                    write_run(out, run, true, parts);
                }
                out.push_str("</w:del>");
            }
        }
        i = j;
    }
    if let Some(n) = p.footnote {
        let n = n.to_string();
        out.push_str(
            r#"<w:r><w:rPr><w:rStyle w:val="FootnoteReference"/></w:rPr><w:footnoteReference"#,
        );
        let _ = write!(out, r#" w:id="{n}"/></w:r>"#);
    }
    if let Some(id) = p.comment {
        let id = id.to_string();
        xml::open_tag(out, "w:commentRangeEnd", &[("w:id", &id)], true);
        out.push_str(
            r#"<w:r><w:rPr><w:rStyle w:val="CommentReference"/></w:rPr><w:commentReference"#,
        );
        let _ = write!(out, r#" w:id="{id}"/></w:r>"#);
    }
    out.push_str("</w:p>");
}

/// One run, optionally as deleted text (`w:delText` inside `w:del`).
fn write_run(out: &mut String, run: &Run, deleted: bool, parts: &DocParts) {
    // External link: the run becomes a child of `w:hyperlink` and picks up the
    // built-in Hyperlink character style (blue + underline in Word).
    let rid = run
        .link
        .as_deref()
        .filter(|url| !url.is_empty())
        .and_then(|url| parts.link_rid(url))
        .map(str::to_string);
    if let Some(rid) = &rid {
        xml::open_tag(
            out,
            "w:hyperlink",
            &[("r:id", rid), ("w:history", "1")],
            false,
        );
    }
    out.push_str("<w:r>");
    let mut rpr = String::new();
    if rid.is_some() {
        xml::open_tag(&mut rpr, "w:rStyle", &[("w:val", "Hyperlink")], true);
    }
    if let Some(family) = &run.font {
        xml::open_tag(
            &mut rpr,
            "w:rFonts",
            &[
                ("w:ascii", family),
                ("w:hAnsi", family),
                ("w:eastAsia", family),
                ("w:cs", family),
            ],
            true,
        );
    }
    if run.mono {
        xml::open_tag(
            &mut rpr,
            "w:rFonts",
            &[("w:ascii", "Consolas"), ("w:hAnsi", "Consolas")],
            true,
        );
    }
    if run.bold {
        rpr.push_str("<w:b/>");
    }
    if run.italic {
        rpr.push_str("<w:i/>");
    }
    if run.strike {
        rpr.push_str("<w:strike/>");
    }
    if run.underline {
        xml::open_tag(&mut rpr, "w:u", &[("w:val", "single")], true);
    }
    if let Some(pt) = run.size_pt {
        let half = (pt * 2.0).round() as i64;
        let half = half.to_string();
        xml::open_tag(&mut rpr, "w:sz", &[("w:val", &half)], true);
        xml::open_tag(&mut rpr, "w:szCs", &[("w:val", &half)], true);
    }
    if let Some(color) = &run.color {
        xml::open_tag(&mut rpr, "w:color", &[("w:val", color)], true);
    }
    if !rpr.is_empty() {
        out.push_str("<w:rPr>");
        out.push_str(&rpr);
        out.push_str("</w:rPr>");
    }
    // Split on tabs and newlines, which must be encoded as elements.
    let text_tag = if deleted { "w:delText" } else { "w:t" };
    let mut buf = String::new();
    let flush = |out: &mut String, buf: &mut String| {
        if !buf.is_empty() {
            xml::open_tag(out, text_tag, &[("xml:space", "preserve")], false);
            xml::esc_into(out, buf);
            xml::close_tag(out, text_tag);
            buf.clear();
        }
    };
    for c in run.text.chars() {
        match c {
            '\n' => {
                flush(out, &mut buf);
                out.push_str("<w:br/>");
            }
            '\t' => {
                flush(out, &mut buf);
                out.push_str("<w:tab/>");
            }
            c => buf.push(c),
        }
    }
    flush(out, &mut buf);
    out.push_str("</w:r>");
    if rid.is_some() {
        out.push_str("</w:hyperlink>");
    }
}

fn write_table(out: &mut String, t: &Table) {
    let cols = t.rows.iter().map(|r| r.len()).max().unwrap_or(0).max(1);
    // Distribute the text width (170 mm) across the columns, in twips.
    let total_twips = 9_637_i64;
    let col_w = total_twips / cols as i64;
    out.push_str("<w:tbl><w:tblPr>");
    xml::open_tag(out, "w:tblStyle", &[("w:val", "TableGrid")], true);
    out.push_str(r#"<w:tblW w:w="5000" w:type="pct"/>"#);
    out.push_str(r#"<w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/>"#);
    out.push_str("</w:tblPr><w:tblGrid>");
    for _ in 0..cols {
        let w = col_w.to_string();
        xml::open_tag(out, "w:gridCol", &[("w:w", &w)], true);
    }
    out.push_str("</w:tblGrid>");
    for (ri, row) in t.rows.iter().enumerate() {
        out.push_str("<w:tr>");
        let is_head = t.header && ri == 0;
        if is_head {
            out.push_str("<w:trPr><w:tblHeader/></w:trPr>");
        }
        for ci in 0..cols {
            let text = row.get(ci).cloned().unwrap_or_default();
            out.push_str("<w:tc><w:tcPr>");
            let w = col_w.to_string();
            xml::open_tag(out, "w:tcW", &[("w:w", &w), ("w:type", "dxa")], true);
            if is_head {
                out.push_str(r#"<w:shd w:val="clear" w:color="auto" w:fill="1F3864"/>"#);
            }
            out.push_str("</w:tcPr><w:p>");
            if is_head {
                out.push_str("<w:r><w:rPr><w:b/><w:color w:val=\"FFFFFF\"/></w:rPr>");
            } else {
                out.push_str("<w:r>");
            }
            xml::open_tag(out, "w:t", &[("xml:space", "preserve")], false);
            xml::esc_into(out, &text);
            xml::close_tag(out, "w:t");
            out.push_str("</w:r></w:p></w:tc>");
        }
        out.push_str("</w:tr>");
    }
    out.push_str("</w:tbl>");
    // A table must be followed by a paragraph, otherwise Word inserts one and
    // some consumers (and our own reader) can mis-nest what follows.
    out.push_str("<w:p/>");
}

/// Concatenate every `<w:t>` in a header/footer part.
fn part_text(src: &str) -> String {
    let mut out = String::new();
    let mut r = Reader::new(src);
    loop {
        match r.next_event() {
            Event::Start {
                name, self_closing, ..
            } if xml::local(&name) == "t" => {
                if !self_closing {
                    out.push_str(&r.read_text());
                }
            }
            Event::Eof => break,
            _ => {}
        }
    }
    out
}

fn read_blocks(src: &str, links: &[(String, String)]) -> Result<Vec<Block>> {
    let mut blocks = Vec::new();
    let mut r = Reader::new(src);

    // paragraph/run state
    let mut para: Option<Paragraph> = None;
    let mut run: Option<Run> = None;
    let mut in_rpr = false;
    let mut table: Option<Table> = None;
    let mut row: Vec<String> = Vec::new();
    let mut cell_text = String::new();
    let mut in_cell = false;
    let mut cur_link: Option<String> = None;

    macro_rules! flush_run {
        () => {
            if let (Some(par), Some(rn)) = (para.as_mut(), run.take()) {
                if !rn.text.is_empty() {
                    par.runs.push(rn);
                }
            }
        };
    }

    loop {
        match r.next_event() {
            Event::Start {
                name,
                attrs,
                self_closing,
            } => match xml::local(&name) {
                "tbl" => {
                    table = Some(Table {
                        rows: Vec::new(),
                        header: true,
                    });
                }
                "tr" => {
                    row.clear();
                }
                "tc" => {
                    in_cell = true;
                    cell_text.clear();
                    para = None;
                    run = None;
                }
                "p" => {
                    if !self_closing {
                        flush_run!();
                        para = Some(Paragraph::default());
                    }
                }
                "pStyle" if para.is_some() && !in_cell => {
                    if let Some(v) = attrs.iter().find(|(k, _)| xml::local(k) == "val") {
                        if let Some(p) = para.as_mut() {
                            p.style = ParaStyle::from_style_id(&v.1);
                        }
                    }
                }
                "jc" if !in_cell => {
                    if let Some(p) = para.as_mut() {
                        p.align = match attrs
                            .iter()
                            .find(|(k, _)| xml::local(k) == "val")
                            .map(|v| v.1.as_str())
                        {
                            Some("center") => Align::Center,
                            Some("right") => Align::Right,
                            Some("both") => Align::Justify,
                            _ => Align::Left,
                        };
                    }
                }
                "numPr" if para.is_some() && !in_cell => {
                    // list paragraphs are recognised by their numId child
                    // (numId 1 = bullets, numId 2 = numbers, see numbering.xml)
                    if let Some(p) = para.as_mut() {
                        if p.style == ParaStyle::Normal {
                            p.style = ParaStyle::Bullet;
                        }
                    }
                }
                "numId" if para.is_some() && !in_cell => {
                    let id = attrs
                        .iter()
                        .find(|(k, _)| xml::local(k) == "val")
                        .map(|(_, v)| v.as_str());
                    if let Some(p) = para.as_mut() {
                        match id {
                            Some("2") => p.style = ParaStyle::Numbered,
                            Some(_) if p.style == ParaStyle::Normal => p.style = ParaStyle::Bullet,
                            _ => {}
                        }
                    }
                }
                "hyperlink" => {
                    cur_link = attrs
                        .iter()
                        .find(|(k, _)| xml::local(k) == "id")
                        .and_then(|(_, id)| links.iter().find(|(rid, _)| rid == id))
                        .map(|(_, url)| url.clone());
                }
                "r" => {
                    if !self_closing {
                        flush_run!();
                        run = Some(Run {
                            link: cur_link.clone(),
                            ..Default::default()
                        });
                    }
                }
                "rPr" => in_rpr = true,
                "b" | "i" | "u" | "strike" if in_rpr => {
                    let on = !matches!(
                        attrs
                            .iter()
                            .find(|(k, _)| xml::local(k) == "val")
                            .map(|v| v.1.as_str()),
                        Some("0") | Some("false") | Some("none")
                    );
                    if let Some(rn) = run.as_mut() {
                        match xml::local(&name) {
                            "b" => rn.bold = on,
                            "i" => rn.italic = on,
                            "u" => rn.underline = on,
                            "strike" => rn.strike = on,
                            _ => {}
                        }
                    }
                }
                "sz" if in_rpr => {
                    if let Some(v) = attrs.iter().find(|(k, _)| xml::local(k) == "val") {
                        if let (Some(rn), Ok(half)) = (run.as_mut(), v.1.parse::<f32>()) {
                            rn.size_pt = Some(half / 2.0);
                        }
                    }
                }
                "color" if in_rpr => {
                    if let Some(v) = attrs.iter().find(|(k, _)| xml::local(k) == "val") {
                        if let Some(rn) = run.as_mut() {
                            rn.color = Some(v.1.clone());
                        }
                    }
                }
                "rFonts" if in_rpr => {
                    if let Some(v) = attrs.iter().find(|(k, _)| xml::local(k) == "ascii") {
                        let lower = v.1.to_ascii_lowercase();
                        if lower.contains("consol") || lower.contains("mono") {
                            if let Some(rn) = run.as_mut() {
                                rn.mono = true;
                            }
                        } else if !v.1.is_empty() {
                            // Writer で選んだフォントをそのまま復元する
                            if let Some(rn) = run.as_mut() {
                                rn.font = Some(v.1.clone());
                            }
                        }
                    }
                }
                "t" => {
                    let text = r.read_text();
                    if in_cell {
                        cell_text.push_str(&text);
                    } else {
                        if run.is_none() {
                            run = Some(Run::default());
                        }
                        if let Some(rn) = run.as_mut() {
                            rn.text.push_str(&text);
                        }
                    }
                }
                "br" => {
                    let kind = attrs
                        .iter()
                        .find(|(k, _)| xml::local(k) == "type")
                        .map(|v| v.1.as_str());
                    if kind == Some("page") {
                        blocks.push(Block::PageBreak);
                    } else if let Some(rn) = run.as_mut() {
                        rn.text.push('\n');
                    }
                }
                "tab" if !in_rpr => {
                    if let Some(rn) = run.as_mut() {
                        rn.text.push('\t');
                    }
                }
                _ => {}
            },
            Event::End { name } => match xml::local(&name) {
                "hyperlink" => cur_link = None,
                "rPr" => in_rpr = false,
                "r" => flush_run!(),
                "p" => {
                    flush_run!();
                    if let Some(p) = para.take() {
                        // Paragraphs inside a table cell are folded into the
                        // cell's text; they never become block-level content.
                        if !in_cell && (!p.text().is_empty() || p.style != ParaStyle::Normal) {
                            blocks.push(Block::Paragraph(p));
                        }
                    }
                }
                "tc" => {
                    in_cell = false;
                    row.push(cell_text.trim().to_string());
                    cell_text.clear();
                }
                "tr" => {
                    if !row.is_empty() {
                        if let Some(t) = table.as_mut() {
                            t.rows.push(std::mem::take(&mut row));
                        } else {
                            row.clear();
                        }
                    }
                }
                "tbl" => {
                    if let Some(t) = table.take() {
                        if !t.rows.is_empty() {
                            blocks.push(Block::Table(Table {
                                header: true,
                                rows: t.rows,
                            }));
                        }
                    }
                }
                _ => {}
            },
            Event::Text(_) => {}
            Event::Eof => break,
        }
    }
    flush_run!();
    Ok(blocks)
}

const STYLES_XML: &str = concat!(
    r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"#,
    r#"<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">"#,
    r#"<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Yu Gothic UI" w:eastAsia="Yu Gothic UI" w:hAnsi="Yu Gothic UI" w:cs="Calibri"/><w:sz w:val="21"/><w:szCs w:val="21"/><w:lang w:val="ja-JP" w:eastAsia="ja-JP"/></w:rPr></w:rPrDefault>"#,
    r#"<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="264" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>"#,
    r#"<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>"#,
    r#"<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:before="240" w:after="240"/></w:pPr><w:rPr><w:b/><w:sz w:val="56"/><w:szCs w:val="56"/><w:color w:val="1F3864"/></w:rPr></w:style>"#,
    r#"<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="360" w:after="160"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:sz w:val="40"/><w:szCs w:val="40"/><w:color w:val="1F3864"/></w:rPr></w:style>"#,
    r#"<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="280" w:after="120"/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:sz w:val="32"/><w:szCs w:val="32"/><w:color w:val="2E5496"/></w:rPr></w:style>"#,
    r#"<w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="240" w:after="80"/><w:outlineLvl w:val="2"/></w:pPr><w:rPr><w:b/><w:sz w:val="26"/><w:szCs w:val="26"/></w:rPr></w:style>"#,
    r#"<w:style w:type="paragraph" w:styleId="Heading4"><w:name w:val="heading 4"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:outlineLvl w:val="3"/></w:pPr><w:rPr><w:b/><w:i/></w:rPr></w:style>"#,
    r#"<w:style w:type="paragraph" w:styleId="Heading5"><w:name w:val="heading 5"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:outlineLvl w:val="4"/></w:pPr><w:rPr><w:i/></w:rPr></w:style>"#,
    r#"<w:style w:type="paragraph" w:styleId="Heading6"><w:name w:val="heading 6"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:outlineLvl w:val="5"/></w:pPr><w:rPr><w:i/><w:color w:val="595959"/></w:rPr></w:style>"#,
    r#"<w:style w:type="paragraph" w:styleId="Quote"><w:name w:val="Quote"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:ind w:left="567" w:right="567"/><w:pBdr><w:left w:val="single" w:sz="18" w:space="8" w:color="2E5496"/></w:pBdr></w:pPr><w:rPr><w:i/><w:color w:val="404040"/></w:rPr></w:style>"#,
    r#"<w:style w:type="paragraph" w:customStyle="1" w:styleId="PocCode"><w:name w:val="Poccham Code"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:shd w:val="clear" w:color="auto" w:fill="F4F5F7"/><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:cs="Consolas"/><w:sz w:val="19"/></w:rPr></w:style>"#,
    r#"<w:style w:type="paragraph" w:styleId="FootnoteText"><w:name w:val="footnote text"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:rPr><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr></w:style>"#,
    r#"<w:style w:type="character" w:styleId="FootnoteReference"><w:name w:val="footnote reference"/><w:rPr><w:vertAlign w:val="superscript"/></w:rPr></w:style>"#,
    r#"<w:style w:type="character" w:styleId="Hyperlink"><w:name w:val="Hyperlink"/><w:basedOn w:val="DefaultParagraphFont"/><w:uiPriority w:val="99"/><w:unhideWhenUsed/><w:rPr><w:color w:val="0563C1"/><w:u w:val="single"/></w:rPr></w:style>"#,
    r#"<w:style w:type="character" w:styleId="CommentReference"><w:name w:val="annotation reference"/><w:rPr><w:sz w:val="16"/><w:szCs w:val="16"/></w:rPr></w:style>"#,
    r#"<w:style w:type="paragraph" w:styleId="Header"><w:name w:val="header"/><w:basedOn w:val="Normal"/><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="4" w:space="1" w:color="BFBFBF"/></w:pBdr><w:spacing w:after="0"/></w:pPr><w:rPr><w:sz w:val="18"/><w:szCs w:val="18"/><w:color w:val="595959"/></w:rPr></w:style>"#,
    r#"<w:style w:type="paragraph" w:styleId="TOCHeading"><w:name w:val="TOC Heading"/><w:basedOn w:val="Heading1"/><w:pPr><w:spacing w:before="240" w:after="120"/></w:pPr></w:style>"#,
    r#"<w:style w:type="paragraph" w:styleId="ListParagraph"><w:name w:val="List Paragraph"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:ind w:left="720"/><w:contextualSpacing/></w:pPr></w:style>"#,
    r#"<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="BFBFBF"/><w:left w:val="single" w:sz="4" w:space="0" w:color="BFBFBF"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="BFBFBF"/><w:right w:val="single" w:sz="4" w:space="0" w:color="BFBFBF"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="BFBFBF"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="BFBFBF"/></w:tblBorders><w:tblCellMar><w:top w:w="72" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="72" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>"#,
    r#"</w:styles>"#
);

const NUMBERING_XML: &str = concat!(
    r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"#,
    r#"<w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">"#,
    r#"<w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="hybridMultilevel"/>"#,
    r#"<w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="•"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="720" w:hanging="360"/></w:pPr><w:rPr><w:rFonts w:ascii="Segoe UI Symbol" w:hAnsi="Segoe UI Symbol"/></w:rPr></w:lvl>"#,
    r#"</w:abstractNum>"#,
    r#"<w:abstractNum w:abstractNumId="2"><w:multiLevelType w:val="hybridMultilevel"/>"#,
    r#"<w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1."/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="720" w:hanging="360"/></w:pPr></w:lvl>"#,
    r#"</w:abstractNum>"#,
    r#"<w:num w:numId="1"><w:abstractNumId w:val="1"/></w:num>"#,
    r#"<w:num w:numId="2"><w:abstractNumId w:val="2"/></w:num>"#,
    r#"</w:numbering>"#
);

const SETTINGS_XML: &str = concat!(
    r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"#,
    r#"<w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">"#,
    r#"<w:zoom w:percent="100"/><w:defaultTabStop w:val="720"/><w:characterSpacingControl w:val="compressPunctuation"/>"#,
    r#"<w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat>"#,
    r#"</w:settings>"#
);

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hyperlink_roundtrip() {
        let mut doc = Document::new();
        doc.push(Block::Paragraph(Paragraph::with_runs(vec![
            Run::new("公式サイトは "),
            Run::new("こちら")
                .link("https://example.com/poccham")
                .font("Yu Gothic")
                .bold(),
            Run::new(" です。"),
        ])));
        doc.push(Block::Paragraph(Paragraph::with_runs(vec![Run::new(
            "お問い合わせ",
        )
        .link("mailto:info@example.com")])));

        let bytes = doc.to_bytes().unwrap();

        // 1) 本文にハイパーリンク要素がある
        let pkg = crate::pkg::Package::from_bytes(&bytes).unwrap();
        let body = pkg.get_str("word/document.xml").unwrap();
        assert!(
            body.contains("<w:hyperlink r:id=\"rId") && body.contains("w:history=\"1\""),
            "body should wrap the run in w:hyperlink"
        );
        assert!(
            body.contains("<w:rStyle w:val=\"Hyperlink\"/>"),
            "link run should use the Hyperlink character style"
        );
        // 2) 外部リレーションとして 2 件登録される
        let rels = pkg.get_str("word/_rels/document.xml.rels").unwrap();
        assert_eq!(rels.matches("TargetMode=\"External\"").count(), 2);
        assert!(rels.contains("Target=\"https://example.com/poccham\""));
        assert!(rels.contains("Target=\"mailto:info@example.com\""));
        // 3) フォント指定が run に載っている
        assert!(body.contains("<w:rFonts w:ascii=\"Yu Gothic\""));
        // 4) 読み戻すとリンクと書式が復元される
        let back = Document::from_bytes(&bytes).unwrap();
        let linked: Vec<&Run> = back
            .blocks
            .iter()
            .filter_map(|b| match b {
                Block::Paragraph(p) => Some(&p.runs),
                _ => None,
            })
            .flatten()
            .filter(|r| r.link.is_some())
            .collect();
        assert_eq!(linked.len(), 2, "two runs carry a link");
        assert_eq!(linked[0].text, "こちら");
        assert_eq!(
            linked[0].link.as_deref(),
            Some("https://example.com/poccham")
        );
        assert_eq!(linked[0].font.as_deref(), Some("Yu Gothic"));
        assert!(linked[0].bold);
        assert_eq!(linked[1].link.as_deref(), Some("mailto:info@example.com"));
    }

    #[test]
    fn document_roundtrip() {
        let mut doc = Document::new();
        doc.title = "テスト文書".into();
        doc.heading(1, "第1章");
        doc.para("これは本文です。");
        doc.push(Block::Paragraph(Paragraph::with_runs(vec![
            Run::new("強調").bold(),
            Run::new(" と "),
            Run::new("斜体").italic().size(14.0),
        ])));
        doc.bullet("箇条書き1");
        doc.bullet("箇条書き2");
        doc.table(vec![
            vec!["項目".into(), "値".into()],
            vec!["速度".into(), "高速".into()],
        ]);

        let bytes = doc.to_bytes().unwrap();
        let back = Document::from_bytes(&bytes).unwrap();
        assert_eq!(back.title, "テスト文書");
        let paras: Vec<&Paragraph> = back
            .blocks
            .iter()
            .filter_map(|b| match b {
                Block::Paragraph(p) => Some(p),
                _ => None,
            })
            .collect();
        assert_eq!(paras[0].style, ParaStyle::Heading(1));
        assert_eq!(paras[0].text(), "第1章");
        assert_eq!(paras[1].text(), "これは本文です。");
        assert!(paras[2].runs[0].bold);
        assert!(paras[2].runs[2].italic);
        assert_eq!(paras[2].runs[2].size_pt, Some(14.0));
        assert_eq!(paras[3].style, ParaStyle::Bullet);
        let table = back
            .blocks
            .iter()
            .find_map(|b| match b {
                Block::Table(t) => Some(t),
                _ => None,
            })
            .unwrap();
        assert_eq!(table.rows[1], vec!["速度", "高速"]);
    }

    #[test]
    fn markdown_export() {
        let mut doc = Document::new();
        doc.heading(2, "見出し");
        doc.para("本文");
        doc.bullet("項目");
        let md = doc.to_markdown();
        assert!(md.contains("## 見出し"), "{md}");
        assert!(md.contains("- 項目"), "{md}");
    }

    #[test]
    fn multiline_runs_and_page_breaks() {
        let mut doc = Document::new();
        doc.push(Block::Paragraph(Paragraph::with_runs(vec![Run::new(
            "行1\n行2\tタブ",
        )])));
        doc.push(Block::PageBreak);
        let bytes = doc.to_bytes().unwrap();
        let back = Document::from_bytes(&bytes).unwrap();
        let text = back.to_text();
        assert!(text.starts_with("行1\n行2\tタブ"), "{text:?}");
        assert!(back.blocks.contains(&Block::PageBreak));
    }
}
