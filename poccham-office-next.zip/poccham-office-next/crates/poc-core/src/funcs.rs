//! The spreadsheet function library: lookup, statistical, text, date, math and
//! financial functions, evaluated over a [`Grid`] so the engine can serve them
//! without copying a worksheet.
//!
//! Naming follows Excel (`VLOOKUP`, `SUMIFS`, `NETWORKDAYS`, `PMT`, …). Where a
//! function has a legacy and a modern name (`STDEV` / `STDEV.S`) both are
//! accepted. Functions that depend on volatile state (`TODAY`, `NOW`, `RAND`)
//! are evaluated per call; everything else is deterministic, which keeps
//! recalculation reproducible.

use crate::date::{days_in_month, DateTime};
use crate::formula::CValue;
use crate::numfmt::{format_value, FormatValue};

/// Read-only access to the cells a formula can see.
pub trait Grid {
    fn value(&self, sheet: Option<usize>, row: u32, col: u32) -> CValue;
    fn sheet_index(&self, name: &str) -> Option<usize>;
    /// Number-format code attached to a cell (used by `TEXT`, `DOLLAR`, …).
    fn format_code(&self, sheet: Option<usize>, row: u32, col: u32) -> Option<String> {
        let _ = (sheet, row, col);
        None
    }
}

/// A rectangular reference.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RangeRef {
    pub sheet: Option<usize>,
    pub r1: u32,
    pub c1: u32,
    pub r2: u32,
    pub c2: u32,
}

/// A function argument: a scalar or a range.
#[derive(Debug, Clone)]
pub enum FArg {
    Value(CValue),
    Range(RangeRef),
}

impl FArg {
    fn scalar(&self) -> Option<&CValue> {
        match self {
            FArg::Value(v) => Some(v),
            FArg::Range(_) => None,
        }
    }
}

fn err<T>(e: &'static str) -> Result<T, &'static str> {
    Err(e)
}

/// Flatten arguments to numbers (blank cells and text are skipped, as Excel does).
pub fn numbers<G: Grid + ?Sized>(g: &G, args: &[FArg]) -> Result<Vec<f64>, &'static str> {
    let mut out = Vec::new();
    for a in args {
        match a {
            FArg::Value(v) => match v {
                CValue::Number(n) => out.push(*n),
                CValue::Bool(b) => out.push(if *b { 1.0 } else { 0.0 }),
                CValue::Str(s) => {
                    if let Ok(n) = s.trim().parse::<f64>() {
                        out.push(n);
                    }
                }
                CValue::Error(e) => return Err(e),
                CValue::Empty => {}
            },
            FArg::Range(r) => {
                for c in r.c1..=r.c2 {
                    for row in r.r1..=r.r2 {
                        match g.value(r.sheet, row, c) {
                            CValue::Number(n) => out.push(n),
                            CValue::Error(e) => return Err(e),
                            _ => {}
                        }
                    }
                }
            }
        }
    }
    Ok(out)
}

/// Flatten arguments to text (blank cells become empty strings).
pub fn texts<G: Grid + ?Sized>(g: &G, args: &[FArg]) -> Vec<String> {
    let mut out = Vec::new();
    for a in args {
        match a {
            FArg::Value(v) => out.push(v.to_text()),
            FArg::Range(r) => {
                for row in r.r1..=r.r2 {
                    for c in r.c1..=r.c2 {
                        out.push(g.value(r.sheet, row, c).to_text());
                    }
                }
            }
        }
    }
    out
}

/// Flatten arguments to values, keeping blanks (used by COUNTA & friends).
pub fn values<G: Grid + ?Sized>(g: &G, args: &[FArg]) -> Vec<CValue> {
    let mut out = Vec::new();
    for a in args {
        match a {
            FArg::Value(v) => out.push(v.clone()),
            FArg::Range(r) => {
                for row in r.r1..=r.r2 {
                    for c in r.c1..=r.c2 {
                        out.push(g.value(r.sheet, row, c));
                    }
                }
            }
        }
    }
    out
}

/// Read a range as a 2D block of values (`rows[r][c]`).
fn block<G: Grid + ?Sized>(g: &G, r: RangeRef) -> Vec<Vec<CValue>> {
    let mut rows = Vec::with_capacity((r.r2 - r.r1 + 1) as usize);
    for row in r.r1..=r.r2 {
        let mut cols = Vec::with_capacity((r.c2 - r.c1 + 1) as usize);
        for c in r.c1..=r.c2 {
            cols.push(g.value(r.sheet, row, c));
        }
        rows.push(cols);
    }
    rows
}

fn num_arg(args: &[FArg], i: usize) -> Result<f64, &'static str> {
    match args.get(i) {
        Some(FArg::Value(v)) => v.to_number(),
        Some(FArg::Range(_)) => err("#VALUE!"),
        None => Ok(0.0),
    }
}

fn opt_num(args: &[FArg], i: usize) -> Option<f64> {
    args.get(i)
        .and_then(|a| a.scalar())
        .and_then(|v| v.to_number().ok())
}

fn text_arg(args: &[FArg], i: usize) -> Result<String, &'static str> {
    match args.get(i) {
        Some(FArg::Value(v)) => match v {
            CValue::Error(e) => Err(e),
            other => Ok(other.to_text()),
        },
        Some(FArg::Range(_)) => err("#VALUE!"),
        None => Ok(String::new()),
    }
}

fn bool_arg(args: &[FArg], i: usize) -> Result<bool, &'static str> {
    match args.get(i) {
        Some(FArg::Value(v)) => v.to_bool(),
        _ => Ok(false),
    }
}

fn range_arg(args: &[FArg], i: usize) -> Result<RangeRef, &'static str> {
    match args.get(i) {
        Some(FArg::Range(r)) => Ok(*r),
        _ => err("#VALUE!"),
    }
}

/// Number of populated cells in a range (blank-aware, unlike `numbers`).
fn count_nonblank<G: Grid + ?Sized>(g: &G, r: RangeRef) -> usize {
    let mut n = 0;
    for row in r.r1..=r.r2 {
        for c in r.c1..=r.c2 {
            if !matches!(g.value(r.sheet, row, c), CValue::Empty) {
                n += 1;
            }
        }
    }
    n
}

/// Excel wildcard match (`*`, `?`, `~` escapes), case-insensitive.
pub fn wildcard_match(pattern: &str, text: &str) -> bool {
    fn match_from(p: &[char], t: &[char]) -> bool {
        match p.first() {
            None => t.is_empty(),
            Some('*') => (0..=t.len()).any(|i| match_from(&p[1..], &t[i..])),
            Some('?') => !t.is_empty() && match_from(&p[1..], &t[1..]),
            Some('~') => match p.get(1) {
                Some(lit) => t.first() == Some(lit) && match_from(&p[2..], &t[1..]),
                None => t.first() == Some(&'~') && match_from(&p[1..], &t[1..]),
            },
            Some(c) => {
                t.first()
                    .map(|tc| tc.to_lowercase().eq(c.to_lowercase()))
                    .unwrap_or(false)
                    && match_from(&p[1..], &t[1..])
            }
        }
    }
    let p: Vec<char> = pattern.chars().collect();
    let t: Vec<char> = text.chars().collect();
    match_from(&p, &t)
}

/// Parse a `">=100"`-style criteria into (operator, operand).
fn parse_criteria(c: &CValue) -> (String, CValue) {
    let text = c.to_text();
    for op in ["<=", ">=", "<>", "<", ">", "="] {
        if let Some(rest) = text.strip_prefix(op) {
            return (op.to_string(), coerce(rest));
        }
    }
    ("=".to_string(), c.clone())
}

fn coerce(text: &str) -> CValue {
    let t = text.trim();
    if t.is_empty() {
        CValue::Empty
    } else if let Ok(n) = t.parse::<f64>() {
        CValue::Number(n)
    } else if t.eq_ignore_ascii_case("true") {
        CValue::Bool(true)
    } else if t.eq_ignore_ascii_case("false") {
        CValue::Bool(false)
    } else {
        CValue::Str(t.to_string())
    }
}

fn matches_criteria(value: &CValue, op: &str, operand: &CValue) -> bool {
    // blank cells only match "" / "<>" style criteria
    let lhs = match value {
        CValue::Empty => CValue::Empty,
        other => other.clone(),
    };
    match operand {
        CValue::Str(pat) => {
            let lhs_text = lhs.to_text();
            match op {
                "=" => {
                    if pat.is_empty() {
                        matches!(lhs, CValue::Empty)
                    } else {
                        wildcard_match(pat, &lhs_text)
                    }
                }
                "<>" => {
                    if pat.is_empty() {
                        !matches!(lhs, CValue::Empty)
                    } else {
                        !wildcard_match(pat, &lhs_text)
                    }
                }
                _ => {
                    let a = lhs.to_number().unwrap_or(0.0);
                    let b = pat.trim().parse::<f64>().unwrap_or(0.0);
                    compare(op, a, b)
                }
            }
        }
        CValue::Number(b) => {
            let a = lhs.to_number().unwrap_or(0.0);
            compare(op, a, *b)
        }
        CValue::Bool(b) => {
            let a = lhs.to_bool().unwrap_or(false);
            match op {
                "=" => a == *b,
                "<>" => a != *b,
                _ => false,
            }
        }
        CValue::Empty => match op {
            "=" => matches!(lhs, CValue::Empty),
            _ => !matches!(lhs, CValue::Empty),
        },
        CValue::Error(_) => false,
    }
}

fn compare(op: &str, a: f64, b: f64) -> bool {
    match op {
        "=" => (a - b).abs() < 1e-12,
        "<>" => (a - b).abs() >= 1e-12,
        "<" => a < b,
        "<=" => a <= b + 1e-12,
        ">" => a > b,
        ">=" => a >= b - 1e-12,
        _ => false,
    }
}

/// Evaluate `SUMIF` / `COUNTIF` family conditions over one criteria pair.
fn pairwise<G: Grid + ?Sized>(
    g: &G,
    criteria_range: RangeRef,
    criteria: &CValue,
) -> Vec<(u32, u32)> {
    let (op, operand) = parse_criteria(criteria);
    let mut hits = Vec::new();
    for row in criteria_range.r1..=criteria_range.r2 {
        for c in criteria_range.c1..=criteria_range.c2 {
            let v = g.value(criteria_range.sheet, row, c);
            if matches_criteria(&v, &op, &operand) {
                hits.push((row, c));
            }
        }
    }
    hits
}

/// Dispatch. Returns `None` when the name is not a function we know, so the
/// caller can produce `#NAME?`.
pub fn call<G: Grid + ?Sized>(
    name: &str,
    args: &[FArg],
    g: &G,
) -> Option<Result<CValue, &'static str>> {
    match eval(name, args, g) {
        // `#NAME?` is only produced for an unknown name, never by a function
        Err("#NAME?") => None,
        other => Some(other),
    }
}

fn eval<G: Grid + ?Sized>(name: &str, args: &[FArg], g: &G) -> Result<CValue, &'static str> {
    let upper = name.to_ascii_uppercase().replace('_', ".");
    match upper.as_str() {
        // ---------------------------------------------------------- logical
        "IFS" => logical_ifs(args),
        "SWITCH" => logical_switch(args),
        "XOR" => {
            let mut t = 0;
            let mut ok = true;
            for a in args {
                match a {
                    FArg::Value(v) => match v.to_bool() {
                        Ok(b) => {
                            if b {
                                t += 1
                            }
                        }
                        Err(e) => {
                            ok = false;
                            let _ = e;
                        }
                    },
                    FArg::Range(_) => {}
                }
            }
            if ok {
                Ok(CValue::Bool(t % 2 == 1))
            } else {
                err("#VALUE!")
            }
        }
        "IFNA" => match args.first() {
            Some(FArg::Value(CValue::Error("#N/A"))) => {
                match args.get(1).and_then(|a| a.scalar()) {
                    Some(v) => Ok(v.clone()),
                    None => err("#N/A"),
                }
            }
            Some(FArg::Value(v)) => Ok(v.clone()),
            _ => err("#VALUE!"),
        },
        "TRUE" => Ok(CValue::Bool(true)),
        "FALSE" => Ok(CValue::Bool(false)),
        "NA" => err("#N/A"),

        // ------------------------------------------------------------- info
        "ISERROR" | "ISERR" | "ISNA" => {
            let v = match args.first() {
                Some(FArg::Value(v)) => v.clone(),
                _ => return err("#VALUE!"),
            };
            Ok(CValue::Bool(match (&upper[..], &v) {
                ("ISERROR", CValue::Error(_)) => true,
                ("ISERR", CValue::Error(e)) => *e != "#N/A",
                ("ISNA", CValue::Error(e)) => *e == "#N/A",
                _ => false,
            }))
        }
        "ISEVEN" => Ok(CValue::Bool((num_arg(args, 0)? / 2.0).fract() == 0.0)),
        "ISODD" => Ok(CValue::Bool((num_arg(args, 0)?.abs() % 2.0) == 1.0)),
        "ISLOGICAL" => Ok(CValue::Bool(matches!(
            args.first().and_then(|a| a.scalar()),
            Some(CValue::Bool(_))
        ))),
        "ISREF" | "ISFORMULA" | "ISNONTEXT" | "TYPE" => Ok(match args.first() {
            Some(FArg::Value(v)) => match v {
                CValue::Number(_) => CValue::Number(1.0),
                CValue::Str(_) => CValue::Number(2.0),
                CValue::Bool(_) => CValue::Number(4.0),
                CValue::Error(_) => CValue::Number(16.0),
                CValue::Empty => CValue::Number(1.0),
            },
            _ => CValue::Number(0.0),
        }),
        "N" => Ok(CValue::Number(
            args.first()
                .and_then(|a| a.scalar())
                .map(|v| v.to_number().unwrap_or(0.0))
                .unwrap_or(0.0),
        )),

        // ------------------------------------------------------------- math
        "SUMIF" => agg_if(g, args, Agg::Sum),
        "SUMIFS" => agg_ifs(g, args, Agg::Sum),
        "COUNTIF" => agg_if(g, args, Agg::Count),
        "COUNTIFS" => agg_ifs(g, args, Agg::Count),
        "AVERAGEIF" => agg_if(g, args, Agg::Average),
        "AVERAGEIFS" => agg_ifs(g, args, Agg::Average),
        "MAXIFS" => agg_ifs(g, args, Agg::Max),
        "MINIFS" => agg_ifs(g, args, Agg::Min),
        "SUMPRODUCT" => {
            let mut total = 0.0;
            let mut blocks = Vec::new();
            for a in args {
                match a {
                    FArg::Range(r) => blocks.push(block(g, *r)),
                    FArg::Value(v) => blocks.push(vec![vec![v.clone()]]),
                }
            }
            if blocks.is_empty() {
                return Ok(CValue::Number(0.0));
            }
            let rows = blocks.iter().map(|b| b.len()).min().unwrap_or(0);
            let cols = blocks.iter().map(|b| b[0].len()).min().unwrap_or(0);
            for r in 0..rows {
                for c in 0..cols {
                    let mut prod = 1.0;
                    for b in &blocks {
                        prod *= b[r][c].to_number().unwrap_or(0.0);
                    }
                    total += prod;
                }
            }
            Ok(CValue::Number(total))
        }
        "SUMSQ" => Ok(CValue::Number(
            numbers(g, args)?.iter().map(|n| n * n).sum(),
        )),
        "CEILING" | "CEILING.MATH" => {
            let x = num_arg(args, 0)?;
            let sig = opt_num(args, 1).unwrap_or(1.0);
            if sig == 0.0 {
                return Ok(CValue::Number(0.0));
            }
            Ok(CValue::Number((x / sig).ceil() * sig))
        }
        "FLOOR" | "FLOOR.MATH" => {
            let x = num_arg(args, 0)?;
            let sig = opt_num(args, 1).unwrap_or(1.0);
            if sig == 0.0 {
                return err("#DIV/0!");
            }
            Ok(CValue::Number((x / sig).floor() * sig))
        }
        "TRUNC" => {
            let x = num_arg(args, 0)?;
            let digits = opt_num(args, 1).unwrap_or(0.0) as i32;
            let f = 10f64.powi(digits);
            Ok(CValue::Number((x * f).trunc() / f))
        }
        "MROUND" => {
            let x = num_arg(args, 0)?;
            let m = num_arg(args, 1)?;
            if m == 0.0 {
                return Ok(CValue::Number(0.0));
            }
            Ok(CValue::Number((x / m).round() * m))
        }
        "QUOTIENT" => {
            let a = num_arg(args, 0)?;
            let b = num_arg(args, 1)?;
            if b == 0.0 {
                return err("#DIV/0!");
            }
            Ok(CValue::Number((a / b).trunc()))
        }
        "GCD" | "LCM" => {
            let vals: Vec<u64> = numbers(g, args)?
                .iter()
                .map(|n| n.abs() as u64)
                .filter(|n| *n > 0)
                .collect();
            let mut acc = vals.first().copied().unwrap_or(0);
            for v in vals.iter().skip(1) {
                acc = if upper == "GCD" {
                    gcd(acc, *v)
                } else {
                    acc / gcd(acc, *v).max(1) * *v
                };
            }
            Ok(CValue::Number(acc as f64))
        }
        "FACT" => {
            let n = num_arg(args, 0)?.floor().max(0.0) as u32;
            let mut acc = 1.0f64;
            for i in 2..=n {
                acc *= i as f64;
            }
            Ok(CValue::Number(acc))
        }
        "COMBIN" => {
            let n = num_arg(args, 0)?;
            let k = num_arg(args, 1)?;
            Ok(CValue::Number(combin(n, k)))
        }
        "PERMUT" => {
            let n = num_arg(args, 0)?;
            let k = num_arg(args, 1)?;
            Ok(CValue::Number(combin(n, k) * fact(k)))
        }
        "SIGN" => Ok(CValue::Number(num_arg(args, 0)?.signum())),
        "PI" => Ok(CValue::Number(std::f64::consts::PI)),
        "SIN" => Ok(CValue::Number(num_arg(args, 0)?.sin())),
        "COS" => Ok(CValue::Number(num_arg(args, 0)?.cos())),
        "TAN" => Ok(CValue::Number(num_arg(args, 0)?.tan())),
        "ASIN" => Ok(CValue::Number(num_arg(args, 0)?.asin())),
        "ACOS" => Ok(CValue::Number(num_arg(args, 0)?.acos())),
        "ATAN" => Ok(CValue::Number(num_arg(args, 0)?.atan())),
        "ATAN2" => {
            let x = num_arg(args, 0)?;
            let y = num_arg(args, 1)?;
            Ok(CValue::Number(y.atan2(x)))
        }
        "SINH" => Ok(CValue::Number(num_arg(args, 0)?.sinh())),
        "COSH" => Ok(CValue::Number(num_arg(args, 0)?.cosh())),
        "TANH" => Ok(CValue::Number(num_arg(args, 0)?.tanh())),
        "DEGREES" => Ok(CValue::Number(num_arg(args, 0)?.to_degrees())),
        "RADIANS" => Ok(CValue::Number(num_arg(args, 0)?.to_radians())),
        "LOG" => {
            let x = num_arg(args, 0)?;
            let base = opt_num(args, 1).unwrap_or(10.0);
            if x <= 0.0 {
                return err("#NUM!");
            }
            Ok(CValue::Number(x.log(base)))
        }
        "RAND" => Ok(CValue::Number(pseudo_random())),
        "RANDBETWEEN" => {
            let lo = num_arg(args, 0)?.ceil();
            let hi = num_arg(args, 1)?.floor();
            if hi < lo {
                return err("#NUM!");
            }
            let r = pseudo_random();
            Ok(CValue::Number(
                lo + (r * (hi - lo + 1.0)).floor().min(hi - lo),
            ))
        }
        "AGGREGATE" => {
            // AGGREGATE(function_num, options, ref1, …) — errors are ignored
            let f = num_arg(args, 0)? as i32;
            let rest = &args[2.min(args.len())..];
            let nums: Vec<f64> = numbers(g, rest).unwrap_or_default();
            Ok(CValue::Number(match f {
                1 => nums.iter().sum::<f64>() / nums.len().max(1) as f64,
                2 => nums.len() as f64,
                3 => count_nonblank(
                    g,
                    range_arg(args, 2).unwrap_or(RangeRef {
                        sheet: None,
                        r1: 0,
                        c1: 0,
                        r2: 0,
                        c2: 0,
                    }),
                ) as f64,
                4 => nums.iter().cloned().fold(f64::NEG_INFINITY, f64::max),
                5 => nums.iter().cloned().fold(f64::INFINITY, f64::min),
                6 => nums.iter().product::<f64>(),
                9 => nums.iter().sum(),
                12 => median(&nums),
                14 => nums.iter().cloned().fold(f64::NEG_INFINITY, f64::max),
                _ => nums.iter().sum(),
            }))
        }

        // ------------------------------------------------------ statistical
        "MEDIAN" => {
            let nums = numbers(g, args)?;
            if nums.is_empty() {
                return err("#NUM!");
            }
            Ok(CValue::Number(median(&nums)))
        }
        "MODE" | "MODE.SNGL" => {
            let nums = numbers(g, args)?;
            let mut best = (0.0, 0usize);
            for n in &nums {
                let count = nums.iter().filter(|x| *x == n).count();
                if count > best.1 {
                    best = (*n, count);
                }
            }
            if best.1 < 2 {
                return err("#N/A");
            }
            Ok(CValue::Number(best.0))
        }
        "STDEV" | "STDEV.S" | "STDEVA" | "STDEV.P" | "STDEVP" | "STDEVPA" => {
            let nums = numbers(g, args)?;
            let pop = upper.contains(".P") || upper.ends_with('P');
            match variance(&nums, pop) {
                Some(v) => Ok(CValue::Number(v.sqrt())),
                None => err("#DIV/0!"),
            }
        }
        "VAR" | "VAR.S" | "VARA" | "VAR.P" | "VARP" | "VARPA" => {
            let nums = numbers(g, args)?;
            let pop = upper.contains(".P") || upper.ends_with('P');
            match variance(&nums, pop) {
                Some(v) => Ok(CValue::Number(v)),
                None => err("#DIV/0!"),
            }
        }
        "AVERAGEA" => {
            let vals = values(g, args);
            let nums: Vec<f64> = vals
                .iter()
                .filter(|v| !matches!(v, CValue::Empty))
                .map(|v| v.to_number().unwrap_or(0.0))
                .collect();
            if nums.is_empty() {
                return err("#DIV/0!");
            }
            Ok(CValue::Number(nums.iter().sum::<f64>() / nums.len() as f64))
        }
        "LARGE" | "SMALL" => {
            let r = range_arg(args, 0)?;
            let k = num_arg(args, 1)? as usize;
            let mut nums = numbers(g, &[FArg::Range(r)])?;
            if k == 0 || k > nums.len() {
                return err("#NUM!");
            }
            nums.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
            if upper == "LARGE" {
                Ok(CValue::Number(nums[nums.len() - k]))
            } else {
                Ok(CValue::Number(nums[k - 1]))
            }
        }
        "RANK" | "RANK.EQ" => {
            let x = num_arg(args, 0)?;
            let r = range_arg(args, 1)?;
            let desc = opt_num(args, 2).unwrap_or(0.0) == 0.0;
            let mut nums = numbers(g, &[FArg::Range(r)])?;
            nums.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
            if desc {
                nums.reverse();
            }
            match nums.iter().position(|n| (n - x).abs() < 1e-12) {
                Some(i) => Ok(CValue::Number((i + 1) as f64)),
                None => err("#N/A"),
            }
        }
        "PERCENTILE" | "PERCENTILE.INC" => {
            let r = range_arg(args, 0)?;
            let p = num_arg(args, 1)?;
            let mut nums = numbers(g, &[FArg::Range(r)])?;
            if nums.is_empty() || !(0.0..=1.0).contains(&p) {
                return err("#NUM!");
            }
            nums.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
            let idx = p * ((nums.len() - 1) as f64);
            let lo = idx.floor() as usize;
            let hi = idx.ceil() as usize;
            let frac = idx - lo as f64;
            let v = if lo == hi {
                nums[lo]
            } else {
                nums[lo] * (1.0 - frac) + nums[hi] * frac
            };
            Ok(CValue::Number(v))
        }
        "QUARTILE" | "QUARTILE.INC" => {
            let q = num_arg(args, 1)?;
            if !(0.0..=4.0).contains(&q) {
                return err("#NUM!");
            }
            let p = q / 4.0;
            let r = range_arg(args, 0)?;
            let mut nums = numbers(g, &[FArg::Range(r)])?;
            nums.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
            let idx = p * ((nums.len() - 1) as f64);
            let lo = idx.floor() as usize;
            let hi = idx.ceil() as usize;
            let frac = idx - lo as f64;
            Ok(CValue::Number(if lo == hi {
                nums[lo]
            } else {
                nums[lo] * (1.0 - frac) + nums[hi] * frac
            }))
        }
        "GEOMEAN" => {
            let nums = numbers(g, args)?;
            if nums.is_empty() || nums.iter().any(|n| *n <= 0.0) {
                return err("#NUM!");
            }
            let ln: f64 = nums.iter().map(|n| n.ln()).sum();
            Ok(CValue::Number((ln / nums.len() as f64).exp()))
        }
        "HARMEAN" => {
            let nums = numbers(g, args)?;
            if nums.is_empty() || nums.iter().any(|n| *n <= 0.0) {
                return err("#NUM!");
            }
            let inv: f64 = nums.iter().map(|n| 1.0 / n).sum();
            Ok(CValue::Number(nums.len() as f64 / inv))
        }
        "AVEDEV" => {
            let nums = numbers(g, args)?;
            if nums.is_empty() {
                return err("#NUM!");
            }
            let mean = nums.iter().sum::<f64>() / nums.len() as f64;
            Ok(CValue::Number(
                nums.iter().map(|n| (n - mean).abs()).sum::<f64>() / nums.len() as f64,
            ))
        }
        "DEVSQ" => {
            let nums = numbers(g, args)?;
            let mean = nums.iter().sum::<f64>() / nums.len().max(1) as f64;
            Ok(CValue::Number(
                nums.iter().map(|n| (n - mean).powi(2)).sum(),
            ))
        }
        "CORREL" => {
            let a = numbers(g, &[FArg::Range(range_arg(args, 0)?)])?;
            let b = numbers(g, &[FArg::Range(range_arg(args, 1)?)])?;
            Ok(CValue::Number(correl(&a, &b)))
        }
        "SLOPE" => {
            let ys = numbers(g, &[FArg::Range(range_arg(args, 0)?)])?;
            let xs = numbers(g, &[FArg::Range(range_arg(args, 1)?)])?;
            Ok(CValue::Number(slope(&xs, &ys)))
        }
        "INTERCEPT" => {
            let ys = numbers(g, &[FArg::Range(range_arg(args, 0)?)])?;
            let xs = numbers(g, &[FArg::Range(range_arg(args, 1)?)])?;
            let m = slope(&xs, &ys);
            let mx = mean(&xs);
            let my = mean(&ys);
            Ok(CValue::Number(my - m * mx))
        }
        "FORECAST" | "FORECAST.LINEAR" => {
            let x = num_arg(args, 0)?;
            let ys = numbers(g, &[FArg::Range(range_arg(args, 1)?)])?;
            let xs = numbers(g, &[FArg::Range(range_arg(args, 2)?)])?;
            let m = slope(&xs, &ys);
            Ok(CValue::Number(mean(&ys) + m * (x - mean(&xs))))
        }
        "COUNTUNIQUE" => {
            let vals = values(g, args);
            let mut seen: Vec<String> = Vec::new();
            for v in vals {
                if matches!(v, CValue::Empty) {
                    continue;
                }
                let t = v.to_text();
                if !seen.contains(&t) {
                    seen.push(t);
                }
            }
            Ok(CValue::Number(seen.len() as f64))
        }

        // ----------------------------------------------------------- lookup
        "VLOOKUP" => lookup(g, args, Axis::Row),
        "HLOOKUP" => lookup(g, args, Axis::Col),
        "LOOKUP" => lookup_classic(g, args),
        "XLOOKUP" => {
            let needle = match args.first().and_then(|a| a.scalar()) {
                Some(v) => v.clone(),
                None => return err("#VALUE!"),
            };
            let hay = range_arg(args, 1)?;
            let ret = range_arg(args, 2)?;
            let hay_v = numbers(g, &[FArg::Range(hay)]).unwrap_or_default();
            let ret_v = numbers(g, &[FArg::Range(ret)]).unwrap_or_default();
            let idx = hay_v
                .iter()
                .position(|v| (v - needle.to_number().unwrap_or(f64::NAN)).abs() < 1e-12);
            match idx {
                Some(i) if i < ret_v.len() => Ok(CValue::Number(ret_v[i])),
                _ => match args.get(3).and_then(|a| a.scalar()) {
                    Some(v) => Ok(v.clone()),
                    None => err("#N/A"),
                },
            }
        }
        "MATCH" => {
            let needle = match args.first().and_then(|a| a.scalar()) {
                Some(v) => v.clone(),
                None => return err("#N/A"),
            };
            let r = range_arg(args, 1)?;
            let mode = opt_num(args, 2).unwrap_or(1.0);
            let vals = values(g, &[FArg::Range(r)]);
            if mode == 0.0 {
                let target = needle.to_text().to_lowercase();
                for (i, v) in vals.iter().enumerate() {
                    if v.to_text().to_lowercase() == target {
                        return Ok(CValue::Number((i + 1) as f64));
                    }
                }
                err("#N/A")
            } else {
                let x = needle.to_number()?;
                let mut best = None;
                for (i, v) in vals.iter().enumerate() {
                    if let Ok(n) = v.to_number() {
                        if (mode > 0.0 && n <= x + 1e-12) || (mode < 0.0 && n >= x - 1e-12) {
                            best = Some((i + 1) as f64);
                        }
                    }
                }
                match best {
                    Some(i) => Ok(CValue::Number(i)),
                    None => err("#N/A"),
                }
            }
        }
        "INDEX" => {
            let r = range_arg(args, 0)?;
            let row = num_arg(args, 1).unwrap_or(0.0).max(0.0) as u32;
            let col = opt_num(args, 2).unwrap_or(0.0).max(0.0) as u32;
            let (row, col) = if col == 0 {
                (row, 1)
            } else {
                (row.max(1), col)
            };
            let rr = r.r1 + row - 1;
            let cc = r.c1 + col - 1;
            if rr > r.r2 || cc > r.c2 {
                return err("#REF!");
            }
            Ok(g.value(r.sheet, rr, cc))
        }
        "COLUMN" => match args.first() {
            Some(FArg::Range(r)) => Ok(CValue::Number((r.c1 + 1) as f64)),
            _ => err("#VALUE!"),
        },
        "ROW" => match args.first() {
            Some(FArg::Range(r)) => Ok(CValue::Number((r.r1 + 1) as f64)),
            _ => err("#VALUE!"),
        },
        "ROWS" => Ok(CValue::Number(
            (range_arg(args, 0)?.r2 - range_arg(args, 0)?.r1 + 1) as f64,
        )),
        "COLUMNS" => Ok(CValue::Number(
            (range_arg(args, 0)?.c2 - range_arg(args, 0)?.c1 + 1) as f64,
        )),
        "OFFSET" => {
            let r = range_arg(args, 0)?;
            let dr = num_arg(args, 1)? as i64;
            let dc = opt_num(args, 2).unwrap_or(0.0) as i64;
            let h = opt_num(args, 3)
                .map(|v| v as u32)
                .unwrap_or(r.r2 - r.r1 + 1);
            let w = opt_num(args, 4)
                .map(|v| v as u32)
                .unwrap_or(r.c2 - r.c1 + 1);
            let nr = r.r1 as i64 + dr;
            let nc = r.c1 as i64 + dc;
            if nr < 0 || nc < 0 {
                return err("#REF!");
            }
            let _ = (h, w);
            Ok(g.value(r.sheet, nr as u32, nc as u32))
        }
        "CHOOSE" => choose(args, g),

        // ------------------------------------------------------------- date
        "TODAY" => Ok(CValue::Number(DateTime::today_utc().excel_serial())),
        "NOW" => Ok(CValue::Number(DateTime::now_utc().excel_serial())),
        "DATE" => {
            let y = num_arg(args, 0)? as i32;
            let m = num_arg(args, 1)? as i32;
            let d = num_arg(args, 2)? as i32;
            let year = y + (m - 1).div_euclid(12);
            let month = ((m - 1).rem_euclid(12) + 1) as u32;
            let base = DateTime::new(year, month, 1);
            Ok(CValue::Number(base.excel_serial() + (d - 1) as f64))
        }
        "TIME" => {
            let h = num_arg(args, 0)?;
            let m = num_arg(args, 1)?;
            let s = num_arg(args, 2)?;
            Ok(CValue::Number(
                ((h * 3600.0 + m * 60.0 + s) / 86_400.0).rem_euclid(1.0),
            ))
        }
        "YEAR" => Ok(CValue::Number(date_part(num_arg(args, 0)?, 0))),
        "MONTH" => Ok(CValue::Number(date_part(num_arg(args, 0)?, 1))),
        "DAY" => Ok(CValue::Number(date_part(num_arg(args, 0)?, 2))),
        "HOUR" => Ok(CValue::Number(date_part(num_arg(args, 0)?, 3))),
        "MINUTE" => Ok(CValue::Number(date_part(num_arg(args, 0)?, 4))),
        "SECOND" => Ok(CValue::Number(date_part(num_arg(args, 0)?, 5))),
        "WEEKDAY" => {
            let serial = num_arg(args, 0)?;
            let kind = opt_num(args, 1).unwrap_or(1.0) as i32;
            let sun0 = DateTime::from_serial(serial).weekday_sun0() as i32;
            let v = match kind {
                1 => sun0 + 1,
                2 => ((sun0 + 6) % 7) + 1,
                3 => (sun0 + 6) % 7,
                11..=17 => ((sun0 - (kind - 11) + 7) % 7) + 1,
                _ => sun0 + 1,
            };
            Ok(CValue::Number(v as f64))
        }
        "WEEKNUM" => {
            let serial = num_arg(args, 0)?;
            let kind = opt_num(args, 1).unwrap_or(1.0) as i32;
            let dt = DateTime::from_serial(serial);
            let jan1 = DateTime::new(dt.year, 1, 1);
            let start_sun = kind == 1;
            let shift = if start_sun {
                jan1.weekday_sun0() as i32
            } else {
                ((jan1.weekday_sun0() + 6) % 7) as i32
            };
            let days = (serial.floor() - jan1.excel_serial()).max(0.0) as i32;
            Ok(CValue::Number(((days + shift) / 7 + 1) as f64))
        }
        "DATEVALUE" => {
            let text = text_arg(args, 0)?;
            match crate::date::parse_date(&text) {
                Some(dt) => Ok(CValue::Number(dt.excel_serial())),
                None => err("#VALUE!"),
            }
        }
        "TIMEVALUE" => {
            let text = text_arg(args, 0)?;
            match DateTime::parse(&format!("2000-01-01T{}", text.trim())) {
                Some(dt) => Ok(CValue::Number(dt.excel_serial().fract())),
                None => err("#VALUE!"),
            }
        }
        "EDATE" => {
            let dt = DateTime::from_serial(num_arg(args, 0)?);
            let months = num_arg(args, 1)? as i32;
            Ok(CValue::Number(dt.add_months(months).excel_serial()))
        }
        "EOMONTH" => {
            let dt = DateTime::from_serial(num_arg(args, 0)?);
            let months = num_arg(args, 1)? as i32;
            let shifted = dt.add_months(months);
            let last = days_in_month(shifted.year, shifted.month);
            Ok(CValue::Number(
                DateTime::new(shifted.year, shifted.month, last).excel_serial(),
            ))
        }
        "DAYS" => Ok(CValue::Number(
            num_arg(args, 0)?.floor() - num_arg(args, 1)?.floor(),
        )),
        "DAYS360" => days360(args),
        "DATEDIF" => datedif(args),
        "NETWORKDAYS" => networkdays(args, false),
        "WORKDAY" => networkdays(args, true),
        "YEARFRAC" => {
            let a = num_arg(args, 0)?;
            let b = num_arg(args, 1)?;
            Ok(CValue::Number((b - a) / 365.0))
        }
        "MONTHSPAN" => Ok(CValue::Number(
            ((num_arg(args, 1)? - num_arg(args, 0)?) / 30.0).round(),
        )),

        // ------------------------------------------------------------- text
        "CONCAT" | "CONCATENATE" => Ok(CValue::Str(texts(g, args).concat())),
        "TEXTJOIN" => {
            let delim = text_arg(args, 0)?;
            let ignore_empty = bool_arg(args, 1)?;
            let mut parts: Vec<String> = Vec::new();
            for a in args.iter().skip(2) {
                for t in match a {
                    FArg::Value(v) => vec![v.to_text()],
                    FArg::Range(r) => {
                        let mut v = Vec::new();
                        for row in r.r1..=r.r2 {
                            for c in r.c1..=r.c2 {
                                v.push(g.value(r.sheet, row, c).to_text());
                            }
                        }
                        v
                    }
                } {
                    if !(ignore_empty && t.is_empty()) {
                        parts.push(t);
                    }
                }
            }
            Ok(CValue::Str(parts.join(&delim)))
        }
        "TEXT" => {
            let v = match args.first().and_then(|a| a.scalar()) {
                Some(v) => v.clone(),
                None => return err("#VALUE!"),
            };
            let code = text_arg(args, 1)?;
            let fv = match v {
                CValue::Number(n) => FormatValue::Number(n),
                CValue::Bool(b) => FormatValue::Bool(b),
                CValue::Empty => FormatValue::Number(0.0),
                other => FormatValue::Text(other.to_text()),
            };
            Ok(CValue::Str(format_value(&code, &fv)))
        }
        "FIXED" => {
            let n = num_arg(args, 0)?;
            let decimals = opt_num(args, 1).unwrap_or(2.0) as usize;
            let no_commas = bool_arg(args, 2).unwrap_or(false);
            let code = if no_commas {
                format!(
                    "0{}",
                    if decimals > 0 {
                        format!(".{}", "0".repeat(decimals))
                    } else {
                        String::new()
                    }
                )
            } else {
                format!(
                    "#,##0{}",
                    if decimals > 0 {
                        format!(".{}", "0".repeat(decimals))
                    } else {
                        String::new()
                    }
                )
            };
            Ok(CValue::Str(format_value(&code, &FormatValue::Number(n))))
        }
        "DOLLAR" => {
            let n = num_arg(args, 0)?;
            let decimals = opt_num(args, 1).unwrap_or(2.0).max(0.0) as usize;
            Ok(CValue::Str(format!(
                "${}",
                format_value(
                    &format!(
                        "#,##0{}",
                        if decimals > 0 {
                            format!(".{}", "0".repeat(decimals))
                        } else {
                            String::new()
                        }
                    ),
                    &FormatValue::Number(n)
                )
            )))
        }
        "YEN" => {
            let n = num_arg(args, 0)?;
            let decimals = opt_num(args, 1).unwrap_or(0.0).max(0.0) as usize;
            Ok(CValue::Str(format!(
                "¥{}",
                format_value(
                    &format!(
                        "#,##0{}",
                        if decimals > 0 {
                            format!(".{}", "0".repeat(decimals))
                        } else {
                            String::new()
                        }
                    ),
                    &FormatValue::Number(n)
                )
            )))
        }
        "FIND" => {
            let needle = text_arg(args, 0)?;
            let hay = text_arg(args, 1)?;
            let start = opt_num(args, 2).unwrap_or(1.0).max(1.0) as usize;
            let hay_chars: Vec<char> = hay.chars().collect();
            if start > hay_chars.len() + 1 {
                return err("#VALUE!");
            }
            let sliced: String = hay_chars[start - 1..].iter().collect();
            match sliced.find(&needle) {
                Some(pos) => Ok(CValue::Number(
                    (start + sliced[..pos].chars().count()) as f64,
                )),
                None => err("#VALUE!"),
            }
        }
        "SEARCH" => {
            let needle = text_arg(args, 0)?.to_lowercase();
            let hay = text_arg(args, 1)?.to_lowercase();
            let start = opt_num(args, 2).unwrap_or(1.0).max(1.0) as usize;
            let hay_chars: Vec<char> = hay.chars().collect();
            if start > hay_chars.len() + 1 {
                return err("#VALUE!");
            }
            let sliced: String = hay_chars[start - 1..].iter().collect();
            match sliced.find(&needle) {
                Some(pos) => Ok(CValue::Number(
                    (start + sliced[..pos].chars().count()) as f64,
                )),
                None => err("#VALUE!"),
            }
        }
        "SUBSTITUTE" => {
            let text = text_arg(args, 0)?;
            let old = text_arg(args, 1)?;
            let new = text_arg(args, 2)?;
            match opt_num(args, 3) {
                Some(n) if n >= 1.0 => {
                    let mut count = 0.0;
                    let mut out = String::new();
                    let mut rest = text.as_str();
                    while let Some(pos) = rest.find(&old) {
                        count += 1.0;
                        if count == n {
                            out.push_str(&rest[..pos]);
                            out.push_str(&new);
                            out.push_str(&rest[pos + old.len()..]);
                            return Ok(CValue::Str(out));
                        }
                        out.push_str(&rest[..pos + old.len()]);
                        rest = &rest[pos + old.len()..];
                    }
                    Ok(CValue::Str(text))
                }
                _ => Ok(CValue::Str(text.replace(&old, &new))),
            }
        }
        "REPLACE" => {
            let text = text_arg(args, 0)?;
            let start = num_arg(args, 1)?.max(1.0) as usize;
            let count = num_arg(args, 2)?.max(0.0) as usize;
            let new = text_arg(args, 3)?;
            let chars: Vec<char> = text.chars().collect();
            if start > chars.len() + 1 {
                return err("#VALUE!");
            }
            let mut out: String = chars[..start - 1].iter().collect();
            out.push_str(&new);
            let tail: String = chars[(start - 1 + count).min(chars.len())..]
                .iter()
                .collect();
            out.push_str(&tail);
            Ok(CValue::Str(out))
        }
        "REPT" => {
            let text = text_arg(args, 0)?;
            let n = num_arg(args, 1)?.clamp(0.0, 32_767.0) as usize;
            Ok(CValue::Str(text.repeat(n)))
        }
        "EXACT" => Ok(CValue::Bool(text_arg(args, 0)? == text_arg(args, 1)?)),
        "CHAR" => {
            let n = num_arg(args, 0)? as u32;
            Ok(CValue::Str(
                char::from_u32(n).map(|c| c.to_string()).unwrap_or_default(),
            ))
        }
        "CODE" => Ok(CValue::Number(
            text_arg(args, 0)?
                .chars()
                .next()
                .map(|c| c as u32 as f64)
                .unwrap_or(0.0),
        )),
        "UNICHAR" => {
            let n = num_arg(args, 0)? as u32;
            Ok(CValue::Str(
                char::from_u32(n).map(|c| c.to_string()).unwrap_or_default(),
            ))
        }
        "UNICODE" => Ok(CValue::Number(
            text_arg(args, 0)?
                .chars()
                .next()
                .map(|c| c as u32 as f64)
                .unwrap_or(0.0),
        )),
        "CLEAN" => Ok(CValue::Str(
            text_arg(args, 0)?
                .chars()
                .filter(|c| (*c as u32) >= 32)
                .collect(),
        )),
        "NUMBERVALUE" => {
            let text = text_arg(args, 0)?;
            let cleaned: String = text
                .chars()
                .filter(|c| c.is_ascii_digit() || *c == '.' || *c == '-' || *c == '+')
                .collect();
            match cleaned.trim_end_matches('.').parse::<f64>() {
                Ok(n) => Ok(CValue::Number(n)),
                Err(_) => err("#VALUE!"),
            }
        }
        "T" => Ok(match args.first().and_then(|a| a.scalar()) {
            Some(CValue::Str(s)) => CValue::Str(s.clone()),
            _ => CValue::Str(String::new()),
        }),
        "VALUETOTEXT" => Ok(CValue::Str(text_arg(args, 0)?)),
        "ARRAYTOTEXT" => Ok(CValue::Str(texts(g, args).join(", "))),
        "LEFTB" | "RIGHTB" | "MIDB" | "LENB" => {
            // double-byte aware variants behave like the character versions here
            match upper.as_str() {
                "LENB" => Ok(CValue::Number(text_arg(args, 0)?.chars().count() as f64)),
                "LEFTB" => {
                    let n = opt_num(args, 1).unwrap_or(1.0).max(0.0) as usize;
                    Ok(CValue::Str(text_arg(args, 0)?.chars().take(n).collect()))
                }
                "RIGHTB" => {
                    let n = opt_num(args, 1).unwrap_or(1.0).max(0.0) as usize;
                    let chars: Vec<char> = text_arg(args, 0)?.chars().collect();
                    let start = chars.len().saturating_sub(n);
                    Ok(CValue::Str(chars[start..].iter().collect()))
                }
                _ => {
                    let start = num_arg(args, 1)?.max(1.0) as usize;
                    let n = num_arg(args, 2)?.max(0.0) as usize;
                    let chars: Vec<char> = text_arg(args, 0)?.chars().collect();
                    let from = (start - 1).min(chars.len());
                    let to = (from + n).min(chars.len());
                    Ok(CValue::Str(chars[from..to].iter().collect()))
                }
            }
        }
        "TEXTBEFORE" | "TEXTAFTER" => {
            let text = text_arg(args, 0)?;
            let delim = text_arg(args, 1)?;
            match text.find(&delim) {
                Some(i) => Ok(CValue::Str(if upper == "TEXTBEFORE" {
                    text[..i].to_string()
                } else {
                    text[i + delim.len()..].to_string()
                })),
                None => err("#N/A"),
            }
        }
        "SPLIT" => {
            let text = text_arg(args, 0)?;
            let delim = text_arg(args, 1)?;
            let idx = opt_num(args, 2).unwrap_or(1.0).max(1.0) as usize;
            Ok(CValue::Str(
                text.split(&delim).nth(idx - 1).unwrap_or("").to_string(),
            ))
        }

        // -------------------------------------------------------- financial
        "PMT" => {
            let rate = num_arg(args, 0)?;
            let nper = num_arg(args, 1)?;
            let pv = num_arg(args, 2)?;
            let fv = opt_num(args, 3).unwrap_or(0.0);
            let kind = opt_num(args, 4).unwrap_or(0.0);
            Ok(CValue::Number(pmt(rate, nper, pv, fv, kind)))
        }
        "FV" => {
            let rate = num_arg(args, 0)?;
            let nper = num_arg(args, 1)?;
            let pmt_ = num_arg(args, 2)?;
            let pv = opt_num(args, 3).unwrap_or(0.0);
            let kind = opt_num(args, 4).unwrap_or(0.0);
            Ok(CValue::Number(fv(rate, nper, pmt_, pv, kind)))
        }
        "PV" => {
            let rate = num_arg(args, 0)?;
            let nper = num_arg(args, 1)?;
            let pmt_ = num_arg(args, 2)?;
            let fv_ = opt_num(args, 3).unwrap_or(0.0);
            let kind = opt_num(args, 4).unwrap_or(0.0);
            Ok(CValue::Number(pv(rate, nper, pmt_, fv_, kind)))
        }
        "NPER" => {
            let rate = num_arg(args, 0)?;
            let pmt_ = num_arg(args, 1)?;
            let pv_ = num_arg(args, 2)?;
            let fv_ = opt_num(args, 3).unwrap_or(0.0);
            if rate == 0.0 {
                return Ok(CValue::Number(-(pv_ + fv_) / pmt_));
            }
            let num = pmt_ * (1.0 + rate);
            let den = pv_ * rate + pmt_ * (1.0 + rate);
            Ok(CValue::Number((num / den).ln() / (1.0 + rate).ln()))
        }
        "RATE" => {
            // Newton iteration on the annuity equation
            let nper = num_arg(args, 0)?;
            let pmt_ = num_arg(args, 1)?;
            let pv_ = num_arg(args, 2)?;
            let fv_ = opt_num(args, 3).unwrap_or(0.0);
            let mut rate = 0.1;
            for _ in 0..60 {
                let f = fv(rate, nper, pmt_, pv_, 0.0) - fv_;
                let h = 1e-6;
                let d = (fv(rate + h, nper, pmt_, pv_, 0.0) - fv(rate - h, nper, pmt_, pv_, 0.0))
                    / (2.0 * h);
                if d.abs() < 1e-12 {
                    break;
                }
                let next = rate - f / d;
                if (next - rate).abs() < 1e-10 {
                    rate = next;
                    break;
                }
                rate = next;
            }
            if rate.is_finite() {
                Ok(CValue::Number(rate))
            } else {
                err("#NUM!")
            }
        }
        "NPV" => {
            let rate = num_arg(args, 0)?;
            let flows = numbers(g, &args[1..])?;
            let mut npv = 0.0;
            for (i, f) in flows.iter().enumerate() {
                npv += f / (1.0 + rate).powi(i as i32 + 1);
            }
            Ok(CValue::Number(npv))
        }
        "IRR" => {
            let flows = numbers(g, &[FArg::Range(range_arg(args, 0)?)])?;
            let mut rate = opt_num(args, 1).unwrap_or(0.1);
            for _ in 0..100 {
                let mut npv = 0.0;
                let mut d = 0.0;
                for (i, f) in flows.iter().enumerate() {
                    let p = (1.0 + rate).powi(i as i32);
                    npv += f / p;
                    d -= (i as f64) * f / ((1.0 + rate).powi(i as i32 + 1));
                }
                if d.abs() < 1e-12 {
                    break;
                }
                let next = rate - npv / d;
                if (next - rate).abs() < 1e-10 {
                    rate = next;
                    break;
                }
                rate = next;
            }
            if rate.is_finite() {
                Ok(CValue::Number(rate))
            } else {
                err("#NUM!")
            }
        }
        "SLN" => {
            let cost = num_arg(args, 0)?;
            let salvage = num_arg(args, 1)?;
            let life = num_arg(args, 2)?;
            if life == 0.0 {
                return err("#DIV/0!");
            }
            Ok(CValue::Number((cost - salvage) / life))
        }
        "SYD" => {
            let cost = num_arg(args, 0)?;
            let salvage = num_arg(args, 1)?;
            let life = num_arg(args, 2)?;
            let per = num_arg(args, 3)?;
            let syd = life * (life + 1.0) / 2.0;
            Ok(CValue::Number((cost - salvage) * (life - per + 1.0) / syd))
        }
        "DB" => {
            let cost = num_arg(args, 0)?;
            let salvage = num_arg(args, 1)?;
            let life = num_arg(args, 2)?;
            let per = num_arg(args, 3)?;
            let month = opt_num(args, 4).unwrap_or(12.0);
            let rate = (1.0 - (salvage / cost).powf(1.0 / life)).min(1.0);
            let mut book = cost;
            let mut dep = cost * rate * month / 12.0;
            for _ in 1..per as i32 {
                book -= dep;
                dep = book * rate;
            }
            Ok(CValue::Number(dep))
        }
        "EFFECT" => {
            let nominal = num_arg(args, 0)?;
            let periods = num_arg(args, 1)?;
            Ok(CValue::Number(
                (1.0 + nominal / periods).powf(periods) - 1.0,
            ))
        }
        "NOMINAL" => {
            let effect = num_arg(args, 0)?;
            let periods = num_arg(args, 1)?;
            Ok(CValue::Number(
                periods * ((1.0 + effect).powf(1.0 / periods) - 1.0),
            ))
        }

        // -------------------------------------------------- second wave: numbers
        "BASE" => {
            let n = num_arg(args, 0)?.max(0.0) as u64;
            let radix = num_arg(args, 1)?.clamp(2.0, 36.0) as u32;
            let min_len = opt_num(args, 2).unwrap_or(0.0).max(0.0) as usize;
            let mut out = String::new();
            let mut v = n;
            loop {
                let digit = (v % radix as u64) as u32;
                out.push(
                    std::char::from_digit(digit, radix)
                        .unwrap_or('0')
                        .to_ascii_uppercase(),
                );
                v /= radix as u64;
                if v == 0 {
                    break;
                }
            }
            while out.len() < min_len {
                out.push('0');
            }
            Ok(CValue::Str(out.chars().rev().collect()))
        }
        "DECIMAL" => {
            let text = text_arg(args, 0)?;
            let radix = num_arg(args, 1)?.clamp(2.0, 36.0) as u32;
            match u64::from_str_radix(text.trim(), radix) {
                Ok(v) => Ok(CValue::Number(v as f64)),
                Err(_) => err("#NUM!"),
            }
        }
        "ROMAN" => {
            let mut n = num_arg(args, 0)? as i64;
            if !(1..=3999).contains(&n) {
                return err("#VALUE!");
            }
            const TABLE: [(i64, &str); 13] = [
                (1000, "M"),
                (900, "CM"),
                (500, "D"),
                (400, "CD"),
                (100, "C"),
                (90, "XC"),
                (50, "L"),
                (40, "XL"),
                (10, "X"),
                (9, "IX"),
                (5, "V"),
                (4, "IV"),
                (1, "I"),
            ];
            let mut out = String::new();
            for (v, sym) in TABLE {
                while n >= v {
                    out.push_str(sym);
                    n -= v;
                }
            }
            Ok(CValue::Str(out))
        }
        "ARABIC" => {
            let text = text_arg(args, 0)?.to_ascii_uppercase();
            let mut total = 0i64;
            let mut prev = 0i64;
            for ch in text.chars().rev() {
                let v = match ch {
                    'I' => 1,
                    'V' => 5,
                    'X' => 10,
                    'L' => 50,
                    'C' => 100,
                    'D' => 500,
                    'M' => 1000,
                    _ => return err("#VALUE!"),
                };
                if v < prev {
                    total -= v;
                } else {
                    total += v;
                    prev = v;
                }
            }
            Ok(CValue::Number(total as f64))
        }
        "DOLLARDE" => {
            let value = num_arg(args, 0)?;
            let fraction = num_arg(args, 1)?;
            if fraction < 1.0 {
                return err("#DIV/0!");
            }
            let int_part = value.trunc();
            let frac_part = value - int_part;
            let digits = 10f64.powf(fraction.log10().ceil());
            Ok(CValue::Number(int_part + frac_part * digits / fraction))
        }
        "DOLLARFR" => {
            let value = num_arg(args, 0)?;
            let fraction = num_arg(args, 1)?;
            if fraction < 1.0 {
                return err("#DIV/0!");
            }
            let int_part = value.trunc();
            let frac_part = value - int_part;
            let digits = 10f64.powf(fraction.log10().ceil());
            Ok(CValue::Number(int_part + frac_part * fraction / digits))
        }
        "MULTINOMIAL" => {
            let nums = numbers(g, args)?;
            let total: f64 = nums.iter().sum();
            Ok(CValue::Number(
                fact(total) / nums.iter().map(|n| fact(*n)).product::<f64>(),
            ))
        }
        "SERIESSUM" => {
            let x = num_arg(args, 0)?;
            let n = num_arg(args, 1)?;
            let m = num_arg(args, 2)?;
            let coeffs = numbers(g, &[FArg::Range(range_arg(args, 3)?)])?;
            let mut sum = 0.0;
            for (i, a) in coeffs.iter().enumerate() {
                sum += a * x.powf(n + i as f64 * m);
            }
            Ok(CValue::Number(sum))
        }
        "SQRTPI" => {
            let x = num_arg(args, 0)?;
            if x < 0.0 {
                return err("#NUM!");
            }
            Ok(CValue::Number((x * std::f64::consts::PI).sqrt()))
        }
        "CEILING.PRECISE" => {
            let x = num_arg(args, 0)?;
            let sig = opt_num(args, 1).unwrap_or(1.0).abs();
            if sig == 0.0 {
                return Ok(CValue::Number(0.0));
            }
            Ok(CValue::Number((x / sig).ceil() * sig))
        }
        "FLOOR.PRECISE" => {
            let x = num_arg(args, 0)?;
            let sig = opt_num(args, 1).unwrap_or(1.0).abs();
            if sig == 0.0 {
                return err("#DIV/0!");
            }
            Ok(CValue::Number((x / sig).floor() * sig))
        }
        "EVEN" => {
            let x = num_arg(args, 0)?;
            let a = x.abs();
            let r = (a / 2.0).ceil() * 2.0;
            Ok(CValue::Number(if x < 0.0 { -r } else { r }))
        }
        "ODD" => {
            let x = num_arg(args, 0)?;
            let a = x.abs();
            let r = ((a + 1.0) / 2.0).ceil() * 2.0 - 1.0;
            Ok(CValue::Number(if x < 0.0 {
                -r.max(1.0)
            } else {
                r.max(1.0)
            }))
        }
        "SEC" => Ok(CValue::Number(1.0 / num_arg(args, 0)?.cos())),
        "CSC" => Ok(CValue::Number(1.0 / num_arg(args, 0)?.sin())),
        "COT" => Ok(CValue::Number(1.0 / num_arg(args, 0)?.tan())),
        "SECH" => Ok(CValue::Number(1.0 / num_arg(args, 0)?.cosh())),
        "CSCH" => Ok(CValue::Number(1.0 / num_arg(args, 0)?.sinh())),
        "COTH" => Ok(CValue::Number(1.0 / num_arg(args, 0)?.tanh())),
        "ASINH" => Ok(CValue::Number(num_arg(args, 0)?.asinh())),
        "ACOSH" => Ok(CValue::Number(num_arg(args, 0)?.acosh())),
        "ATANH" => Ok(CValue::Number(num_arg(args, 0)?.atanh())),
        "SUMX2MY2" => pair_sum(g, args, |x, y| x * x - y * y),
        "SUMX2PY2" => pair_sum(g, args, |x, y| x * x + y * y),
        "SUMXMY2" => pair_sum(g, args, |x, y| (x - y) * (x - y)),

        // -------------------------------------------- second wave: statistics
        "MAXA" => Ok(CValue::Number(
            values(g, args)
                .iter()
                .map(|v| v.to_number().unwrap_or(0.0))
                .fold(f64::NEG_INFINITY, f64::max),
        )),
        "MINA" => Ok(CValue::Number(
            values(g, args)
                .iter()
                .map(|v| v.to_number().unwrap_or(0.0))
                .fold(f64::INFINITY, f64::min),
        )),
        "KURT" => {
            let nums = numbers(g, args)?;
            let n = nums.len() as f64;
            if n < 4.0 {
                return err("#DIV/0!");
            }
            let m = mean(&nums);
            let s = variance(&nums, false).unwrap_or(0.0).sqrt();
            if s == 0.0 {
                return err("#DIV/0!");
            }
            let sum: f64 = nums.iter().map(|x| ((x - m) / s).powi(4)).sum();
            let k = n * (n + 1.0) / ((n - 1.0) * (n - 2.0) * (n - 3.0));
            Ok(CValue::Number(
                k * sum - 3.0 * (n - 1.0).powi(2) / ((n - 2.0) * (n - 3.0)),
            ))
        }
        "SKEW" => {
            let nums = numbers(g, args)?;
            let n = nums.len() as f64;
            if n < 3.0 {
                return err("#DIV/0!");
            }
            let m = mean(&nums);
            let s = variance(&nums, false).unwrap_or(0.0).sqrt();
            if s == 0.0 {
                return err("#DIV/0!");
            }
            let sum: f64 = nums.iter().map(|x| ((x - m) / s).powi(3)).sum();
            Ok(CValue::Number(n / ((n - 1.0) * (n - 2.0)) * sum))
        }
        "TRIMMEAN" => {
            let mut nums = numbers(g, &[FArg::Range(range_arg(args, 0)?)])?;
            let pct = num_arg(args, 1)?.clamp(0.0, 1.0);
            nums.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
            let drop = ((nums.len() as f64 * pct) / 2.0).floor() as usize;
            if drop * 2 >= nums.len() {
                return err("#NUM!");
            }
            let slice = &nums[drop..nums.len() - drop];
            Ok(CValue::Number(mean(slice)))
        }
        "STANDARDIZE" => {
            let x = num_arg(args, 0)?;
            let m = num_arg(args, 1)?;
            let s = num_arg(args, 2)?;
            if s <= 0.0 {
                return err("#NUM!");
            }
            Ok(CValue::Number((x - m) / s))
        }
        "FISHER" => {
            let x = num_arg(args, 0)?;
            if x <= -1.0 || x >= 1.0 {
                return err("#NUM!");
            }
            Ok(CValue::Number(0.5 * ((1.0 + x) / (1.0 - x)).ln()))
        }
        "FISHERINV" => {
            let y = num_arg(args, 0)?;
            let e = (2.0 * y).exp();
            Ok(CValue::Number((e - 1.0) / (e + 1.0)))
        }
        "GAMMALN" => {
            let x = num_arg(args, 0)?;
            if x <= 0.0 {
                return err("#NUM!");
            }
            Ok(CValue::Number(lgamma(x)))
        }
        "NORM.DIST" | "NORMDIST" => {
            let x = num_arg(args, 0)?;
            let m = num_arg(args, 1)?;
            let s = num_arg(args, 2)?;
            let cumulative = bool_arg(args, 3).unwrap_or(true);
            if s <= 0.0 {
                return err("#NUM!");
            }
            Ok(CValue::Number(if cumulative {
                0.5 * (1.0 + erf((x - m) / (s * std::f64::consts::SQRT_2)))
            } else {
                (-((x - m).powi(2)) / (2.0 * s * s)).exp()
                    / (s * (2.0 * std::f64::consts::PI).sqrt())
            }))
        }
        "NORM.S.DIST" | "NORMSDIST" => {
            let x = num_arg(args, 0)?;
            let cumulative = bool_arg(args, 1).unwrap_or(true);
            Ok(CValue::Number(if cumulative {
                0.5 * (1.0 + erf(x / std::f64::consts::SQRT_2))
            } else {
                (-x * x / 2.0).exp() / (2.0 * std::f64::consts::PI).sqrt()
            }))
        }
        "NORM.INV" | "NORMINV" => {
            let p = num_arg(args, 0)?;
            let m = num_arg(args, 1)?;
            let s = num_arg(args, 2)?;
            if !(0.0..1.0).contains(&p) || s <= 0.0 {
                return err("#NUM!");
            }
            Ok(CValue::Number(m + s * inv_normal(p)))
        }
        "NORM.S.INV" => {
            let p = num_arg(args, 0)?;
            if !(0.0..1.0).contains(&p) {
                return err("#NUM!");
            }
            Ok(CValue::Number(inv_normal(p)))
        }
        "EXPON.DIST" | "EXPONDIST" => {
            let x = num_arg(args, 0)?;
            let lambda = num_arg(args, 1)?;
            let cumulative = bool_arg(args, 2).unwrap_or(true);
            if x < 0.0 || lambda <= 0.0 {
                return err("#NUM!");
            }
            Ok(CValue::Number(if cumulative {
                1.0 - (-lambda * x).exp()
            } else {
                lambda * (-lambda * x).exp()
            }))
        }
        "POISSON.DIST" | "POISSON" => {
            let x = num_arg(args, 0)?.max(0.0).floor();
            let m = num_arg(args, 1)?;
            let cumulative = bool_arg(args, 2).unwrap_or(true);
            if m < 0.0 {
                return err("#NUM!");
            }
            let mut acc = 0.0;
            if cumulative {
                for k in 0..=(x as u32) {
                    acc += (m.powi(k as i32) * (-m).exp()) / fact(k as f64);
                }
                Ok(CValue::Number(acc))
            } else {
                Ok(CValue::Number((m.powf(x) * (-m).exp()) / fact(x)))
            }
        }
        "BINOM.DIST" | "BINOMDIST" => {
            let k = num_arg(args, 0)?.max(0.0).floor();
            let n = num_arg(args, 1)?.max(0.0).floor();
            let p = num_arg(args, 2)?.clamp(0.0, 1.0);
            let cumulative = bool_arg(args, 3).unwrap_or(true);
            if k > n {
                return err("#NUM!");
            }
            let one = |i: f64| combin(n, i) * p.powf(i) * (1.0 - p).powf(n - i);
            if cumulative {
                Ok(CValue::Number(
                    (0..=(k as u32)).map(|i| one(i as f64)).sum(),
                ))
            } else {
                Ok(CValue::Number(one(k)))
            }
        }
        "CONFIDENCE.NORM" | "CONFIDENCE" => {
            let alpha = num_arg(args, 0)?;
            let s = num_arg(args, 1)?;
            let n = num_arg(args, 2)?;
            if !(0.0..1.0).contains(&alpha) || n < 1.0 {
                return err("#NUM!");
            }
            Ok(CValue::Number(-inv_normal(alpha / 2.0) * s / n.sqrt()))
        }
        "ZTEST" | "Z.TEST" => {
            let r = range_arg(args, 0)?;
            let x = num_arg(args, 1)?;
            let nums = numbers(g, &[FArg::Range(r)])?;
            let Some(sd) = variance(&nums, false).map(f64::sqrt) else {
                return err("#DIV/0!");
            };
            if sd == 0.0 {
                return err("#DIV/0!");
            }
            let z = (mean(&nums) - x) / (sd / (nums.len() as f64).sqrt());
            Ok(CValue::Number(
                1.0 - 0.5 * (1.0 + erf(z / std::f64::consts::SQRT_2)),
            ))
        }

        // ------------------------------------------- second wave: financial
        "DDB" => {
            let cost = num_arg(args, 0)?;
            let salvage = num_arg(args, 1)?;
            let life = num_arg(args, 2)?;
            let period = num_arg(args, 3)?;
            let factor = opt_num(args, 4).unwrap_or(2.0);
            if cost <= 0.0 || life <= 0.0 || period <= 0.0 {
                return err("#NUM!");
            }
            let rate = (factor / life).min(1.0);
            let mut book = cost;
            let mut dep = 0.0;
            for _ in 1..=(period as i32) {
                dep = (book * rate).min(book - salvage);
                if dep < 0.0 {
                    dep = 0.0;
                }
                book -= dep;
            }
            Ok(CValue::Number(dep))
        }
        "IPMT" => {
            let rate = num_arg(args, 0)?;
            let per = num_arg(args, 1)?;
            let nper = num_arg(args, 2)?;
            let pv = num_arg(args, 3)?;
            let fv_ = opt_num(args, 4).unwrap_or(0.0);
            let payment = pmt(rate, nper, pv, fv_, 0.0);
            let mut balance = pv;
            let mut interest = 0.0;
            for _ in 1..=(per as i32) {
                interest = -balance * rate;
                balance += payment - interest;
            }
            Ok(CValue::Number(interest))
        }
        "PPMT" => {
            let rate = num_arg(args, 0)?;
            let per = num_arg(args, 1)?;
            let nper = num_arg(args, 2)?;
            let pv = num_arg(args, 3)?;
            let fv_ = opt_num(args, 4).unwrap_or(0.0);
            let payment = pmt(rate, nper, pv, fv_, 0.0);
            let mut balance = pv;
            let mut principal = 0.0;
            for _ in 1..=(per as i32) {
                let interest = -balance * rate;
                principal = payment - interest;
                balance += payment - interest;
            }
            Ok(CValue::Number(principal))
        }
        "CUMPRINC" | "CUMIPMT" => {
            let rate = num_arg(args, 0)?;
            let nper = num_arg(args, 1)?;
            let pv = num_arg(args, 2)?;
            let start = num_arg(args, 3)?.max(1.0);
            let end = num_arg(args, 4)?.min(nper);
            let payment = pmt(rate, nper, pv, 0.0, 0.0);
            let want_interest = upper == "CUMIPMT";
            let mut balance = pv;
            let mut total = 0.0;
            for per in 1..=(end as i32) {
                let interest = -balance * rate;
                let principal = payment - interest;
                if (per as f64) >= start {
                    total += if want_interest { interest } else { principal };
                }
                balance += payment - interest;
            }
            Ok(CValue::Number(total))
        }
        "RRI" => {
            let nper = num_arg(args, 0)?;
            let pv = num_arg(args, 1)?;
            let fv_ = num_arg(args, 2)?;
            if nper <= 0.0 || pv <= 0.0 || fv_ < 0.0 {
                return err("#NUM!");
            }
            Ok(CValue::Number((fv_ / pv).powf(1.0 / nper) - 1.0))
        }
        "PDURATION" => {
            let rate = num_arg(args, 0)?;
            let pv = num_arg(args, 1)?;
            let fv_ = num_arg(args, 2)?;
            if rate <= 0.0 || pv <= 0.0 || fv_ <= 0.0 {
                return err("#NUM!");
            }
            Ok(CValue::Number((fv_ / pv).ln() / (1.0 + rate).ln()))
        }
        "FVSCHEDULE" => {
            let principal = num_arg(args, 0)?;
            let rates = numbers(g, &[FArg::Range(range_arg(args, 1)?)])?;
            Ok(CValue::Number(
                rates.iter().fold(principal, |acc, r| acc * (1.0 + r)),
            ))
        }

        // ----------------------------------------------- second wave: dates
        "ISOWEEKNUM" => {
            let dt = DateTime::from_serial(num_arg(args, 0)?);
            Ok(CValue::Number(iso_week(dt) as f64))
        }
        "WEEKNUM.ISO" => {
            let dt = DateTime::from_serial(num_arg(args, 0)?);
            Ok(CValue::Number(iso_week(dt) as f64))
        }

        // --------------------------------------------- second wave: lookups
        "XMATCH" => {
            let needle = match args.first().and_then(|a| a.scalar()) {
                Some(v) => v.clone(),
                None => return err("#VALUE!"),
            };
            let r = range_arg(args, 1)?;
            let vals = values(g, &[FArg::Range(r)]);
            let target = needle.to_text().to_lowercase();
            match vals
                .iter()
                .position(|v| v.to_text().to_lowercase() == target)
            {
                Some(i) => Ok(CValue::Number((i + 1) as f64)),
                None => match needle.to_number().ok().and_then(|x| {
                    vals.iter().position(|v| {
                        v.to_number()
                            .map(|n| (n - x).abs() < 1e-12)
                            .unwrap_or(false)
                    })
                }) {
                    Some(i) => Ok(CValue::Number((i + 1) as f64)),
                    None => err("#N/A"),
                },
            }
        }
        "ERROR.TYPE" => Ok(CValue::Number(
            match args.first().and_then(|a| a.scalar()) {
                Some(CValue::Error("#NULL!")) => 1.0,
                Some(CValue::Error("#DIV/0!")) => 2.0,
                Some(CValue::Error("#VALUE!")) => 3.0,
                Some(CValue::Error("#REF!")) => 4.0,
                Some(CValue::Error("#NAME?")) => 5.0,
                Some(CValue::Error("#NUM!")) => 6.0,
                Some(CValue::Error("#N/A")) => 7.0,
                _ => return err("#N/A"),
            },
        )),
        "SHEET" | "SHEETS" => Ok(CValue::Number(1.0)),
        "ADDRESS" => {
            // ADDRESS(row, column, [abs_num], [a1], [sheet])
            let row = num_arg(args, 0)?.max(1.0) as u32;
            let col = num_arg(args, 1)?.max(1.0) as u32;
            let abs_num = opt_num(args, 2).unwrap_or(1.0) as i32;
            let letters = crate::xlsx::col_letters(col - 1);
            let (col_part, row_part) = match abs_num {
                1 => (format!("${letters}"), format!("${row}")),
                2 => (letters, format!("${row}")),
                3 => (format!("${letters}"), row.to_string()),
                _ => (letters, row.to_string()),
            };
            Ok(CValue::Str(format!("{col_part}{row_part}")))
        }
        _ => Err("#NAME?"),
    }
}

// --------------------------------------------------------------- helpers

fn logical_ifs(args: &[FArg]) -> Result<CValue, &'static str> {
    let mut i = 0;
    while i + 1 < args.len() {
        let cond = match &args[i] {
            FArg::Value(v) => v.to_bool()?,
            FArg::Range(_) => false,
        };
        if cond {
            return match &args[i + 1] {
                FArg::Value(v) => Ok(v.clone()),
                FArg::Range(_) => err("#VALUE!"),
            };
        }
        i += 2;
    }
    err("#N/A")
}

fn logical_switch(args: &[FArg]) -> Result<CValue, &'static str> {
    let subject = match args.first() {
        Some(FArg::Value(v)) => v.clone(),
        _ => return err("#VALUE!"),
    };
    let mut i = 1;
    while i + 1 < args.len() {
        let case = match &args[i] {
            FArg::Value(v) => v.clone(),
            FArg::Range(_) => return err("#VALUE!"),
        };
        if case.to_text() == subject.to_text()
            || (case.to_number().ok().is_some()
                && subject.to_number().ok().is_some()
                && (case.to_number()? - subject.to_number()?).abs() < 1e-12)
        {
            return match &args[i + 1] {
                FArg::Value(v) => Ok(v.clone()),
                FArg::Range(_) => err("#VALUE!"),
            };
        }
        i += 2;
    }
    // optional default
    if args.len() % 2 == 0 {
        if let Some(FArg::Value(v)) = args.last() {
            return Ok(v.clone());
        }
    }
    err("#N/A")
}

fn choose<G: Grid + ?Sized>(args: &[FArg], _g: &G) -> Result<CValue, &'static str> {
    let idx = num_arg(args, 0)?.max(1.0) as usize;
    match args.get(idx) {
        Some(FArg::Value(v)) => Ok(v.clone()),
        Some(FArg::Range(_)) => err("#VALUE!"),
        None => err("#VALUE!"),
    }
}

/// Element-wise sum of squares (or differences) over two equally shaped ranges.
fn pair_sum<G: Grid + ?Sized>(
    g: &G,
    args: &[FArg],
    f: impl Fn(f64, f64) -> f64,
) -> Result<CValue, &'static str> {
    let a = numbers(g, &[FArg::Range(range_arg(args, 0)?)])?;
    let b = numbers(g, &[FArg::Range(range_arg(args, 1)?)])?;
    let n = a.len().min(b.len());
    Ok(CValue::Number((0..n).map(|i| f(a[i], b[i])).sum()))
}

fn iso_week(dt: DateTime) -> u32 {
    // ISO 8601: the week containing the first Thursday of the year is week 1.
    let serial = dt.excel_serial();
    let weekday = dt.weekday_sun0(); // 0 = Sunday
    let iso_dow = if weekday == 0 { 7 } else { weekday };
    let thursday = serial - (iso_dow as f64 - 4.0);
    let th = DateTime::from_serial(thursday);
    let jan1 = DateTime::new(th.year, 1, 1);
    ((thursday - jan1.excel_serial()).floor() / 7.0) as u32 + 1
}

/// Error function (Abramowitz & Stegun 7.1.26, |error| < 1.5e-7).
fn erf(x: f64) -> f64 {
    let sign = if x < 0.0 { -1.0 } else { 1.0 };
    let x = x.abs();
    let a1 = 0.254829592;
    let a2 = -0.284496736;
    let a3 = 1.421413741;
    let a4 = -1.453152027;
    let a5 = 1.061405429;
    let p = 0.3275911;
    let t = 1.0 / (1.0 + p * x);
    let y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * (-x * x).exp();
    sign * y
}

/// Natural log of the gamma function (Lanczos, g = 7, n = 9).
fn lgamma(x: f64) -> f64 {
    const G: [f64; 9] = [
        0.999_999_999_999_809_9,
        676.5203681218851,
        -1259.1392167224028,
        771.323_428_777_653_1,
        -176.615_029_162_140_6,
        12.507343278686905,
        -0.13857109526572012,
        9.984_369_578_019_572e-6,
        1.505_632_735_149_311_6e-7,
    ];
    if x < 0.5 {
        // reflection formula
        return (std::f64::consts::PI / (std::f64::consts::PI * x).sin()).ln() - lgamma(1.0 - x);
    }
    let x = x - 1.0;
    let mut a = G[0];
    let t = x + 7.5;
    for (i, g) in G.iter().enumerate().skip(1) {
        a += g / (x + i as f64);
    }
    0.5 * (2.0 * std::f64::consts::PI).ln() + (x + 0.5) * t.ln() - t + a.ln()
}

/// Inverse of the standard normal CDF (Peter Acklam's rational approximation).
fn inv_normal(p: f64) -> f64 {
    const A: [f64; 6] = [
        -3.969683028665376e+01,
        2.209460984245205e+02,
        -2.759285104469687e+02,
        1.383_577_518_672_69e2,
        -3.066479806614716e+01,
        2.506628277459239e+00,
    ];
    const B: [f64; 5] = [
        -5.447609879822406e+01,
        1.615858368580409e+02,
        -1.556989798598866e+02,
        6.680131188771972e+01,
        -1.328068155288572e+01,
    ];
    const C: [f64; 6] = [
        -7.784894002430293e-03,
        -3.223964580411365e-01,
        -2.400758277161838e+00,
        -2.549732539343734e+00,
        4.374664141464968e+00,
        2.938163982698783e+00,
    ];
    const D: [f64; 4] = [
        7.784695709041462e-03,
        3.224671290700398e-01,
        2.445134137142996e+00,
        3.754408661907416e+00,
    ];
    let low = 0.02425;
    if p < low {
        let q = (-2.0 * p.ln()).sqrt();
        (((((C[0] * q + C[1]) * q + C[2]) * q + C[3]) * q + C[4]) * q + C[5])
            / ((((D[0] * q + D[1]) * q + D[2]) * q + D[3]) * q + 1.0)
    } else if p > 1.0 - low {
        let q = (-2.0 * (1.0 - p).ln()).sqrt();
        -(((((C[0] * q + C[1]) * q + C[2]) * q + C[3]) * q + C[4]) * q + C[5])
            / ((((D[0] * q + D[1]) * q + D[2]) * q + D[3]) * q + 1.0)
    } else {
        let q = p - 0.5;
        let r = q * q;
        (((((A[0] * r + A[1]) * r + A[2]) * r + A[3]) * r + A[4]) * r + A[5]) * q
            / (((((B[0] * r + B[1]) * r + B[2]) * r + B[3]) * r + B[4]) * r + 1.0)
    }
}

#[derive(Clone, Copy, PartialEq)]
enum Axis {
    Row,
    Col,
}

fn lookup<G: Grid + ?Sized>(g: &G, args: &[FArg], axis: Axis) -> Result<CValue, &'static str> {
    let needle = match args.first().and_then(|a| a.scalar()) {
        Some(v) => v.clone(),
        None => return err("#VALUE!"),
    };
    let table = range_arg(args, 1)?;
    let index = num_arg(args, 2)?.max(1.0) as u32;
    let exact = !bool_arg(args, 3).unwrap_or(true);
    let rows = block(g, table);
    if rows.is_empty() {
        return err("#N/A");
    }
    let needle_text = needle.to_text().to_lowercase();
    let needle_num = needle.to_number().ok();
    let mut found: Option<usize> = None;
    let mut approximate: Option<usize> = None;
    // VLOOKUP scans the first *column* down; HLOOKUP scans the first row across.
    let scan = match axis {
        Axis::Row => rows.len(),
        Axis::Col => rows.first().map(|r| r.len()).unwrap_or(0),
    };
    for i in 0..scan {
        let cell = match axis {
            Axis::Row => rows[i].first().cloned().unwrap_or(CValue::Empty),
            Axis::Col => rows[0][i].clone(),
        };
        if exact {
            if cell.to_text().to_lowercase() == needle_text {
                found = Some(i);
                break;
            }
            if let (Some(a), Some(b)) = (cell.to_number().ok(), needle_num) {
                if (a - b).abs() < 1e-12 {
                    found = Some(i);
                    break;
                }
            }
        } else {
            if cell.to_text().to_lowercase() <= needle_text {
                approximate = Some(i);
            }
            if let (Some(a), Some(b)) = (cell.to_number().ok(), needle_num) {
                if a <= b + 1e-12 {
                    approximate = Some(i);
                }
            }
        }
    }
    let Some(hit) = found.or(approximate) else {
        return err("#N/A");
    };
    match axis {
        Axis::Row => {
            if index as usize > rows[0].len() {
                return err("#REF!");
            }
            Ok(g.value(table.sheet, table.r1 + hit as u32, table.c1 + index - 1))
        }
        Axis::Col => {
            if index as usize > rows.len() {
                return err("#REF!");
            }
            Ok(g.value(table.sheet, table.r1 + index - 1, table.c1 + hit as u32))
        }
    }
}

fn lookup_classic<G: Grid + ?Sized>(g: &G, args: &[FArg]) -> Result<CValue, &'static str> {
    let needle = match args.first().and_then(|a| a.scalar()) {
        Some(v) => v.clone(),
        None => return err("#VALUE!"),
    };
    let search = range_arg(args, 1)?;
    let result = args.get(2).and_then(|a| match a {
        FArg::Range(r) => Some(*r),
        _ => None,
    });
    let hay = numbers(g, &[FArg::Range(search)])?;
    let x = needle.to_number()?;
    let mut best = None;
    for (i, v) in hay.iter().enumerate() {
        if *v <= x + 1e-12 {
            best = Some(i);
        }
    }
    let Some(i) = best else {
        return err("#N/A");
    };
    match result {
        Some(r) => Ok(g.value(r.sheet, r.r1 + i as u32, r.c1)),
        None => Ok(CValue::Number(hay[i])),
    }
}

#[derive(Clone, Copy)]
enum Agg {
    Sum,
    Count,
    Average,
    Max,
    Min,
}

fn agg_if<G: Grid + ?Sized>(g: &G, args: &[FArg], agg: Agg) -> Result<CValue, &'static str> {
    let criteria_range = range_arg(args, 0)?;
    let criteria = match args.get(1).and_then(|a| a.scalar()) {
        Some(c) => c.clone(),
        None => CValue::Empty,
    };
    let hits = pairwise(g, criteria_range, &criteria);
    let value_range = args.get(2).and_then(|a| match a {
        FArg::Range(r) => Some(*r),
        _ => None,
    });
    let mut nums = Vec::new();
    for (row, col) in &hits {
        match value_range {
            Some(r) => {
                let dr = row - criteria_range.r1;
                let dc = col - criteria_range.c1;
                let v = g.value(r.sheet, r.r1 + dr, r.c1 + dc);
                if let Ok(n) = v.to_number() {
                    if !matches!(v, CValue::Empty) {
                        nums.push(n);
                    }
                }
            }
            None => {
                let v = g.value(criteria_range.sheet, *row, *col);
                if let Ok(n) = v.to_number() {
                    if !matches!(v, CValue::Empty) {
                        nums.push(n);
                    }
                }
            }
        }
    }
    let _ = agg;
    Ok(match agg {
        Agg::Count => CValue::Number(hits.len() as f64),
        Agg::Sum => CValue::Number(nums.iter().sum()),
        Agg::Average => {
            if nums.is_empty() {
                CValue::Error("#DIV/0!")
            } else {
                CValue::Number(nums.iter().sum::<f64>() / nums.len() as f64)
            }
        }
        Agg::Max => CValue::Number(nums.iter().cloned().fold(f64::NEG_INFINITY, f64::max)),
        Agg::Min => CValue::Number(nums.iter().cloned().fold(f64::INFINITY, f64::min)),
    })
}

fn agg_ifs<G: Grid + ?Sized>(g: &G, args: &[FArg], agg: Agg) -> Result<CValue, &'static str> {
    // SUMIFS(sum_range, criteria_range1, criteria1, …)
    let target = range_arg(args, 0)?;
    let mut hits: Option<Vec<(u32, u32)>> = None;
    let mut i = 1;
    while i + 1 < args.len() {
        let r = range_arg(args, i)?;
        let crit = match args.get(i + 1).and_then(|a| a.scalar()) {
            Some(c) => c.clone(),
            None => CValue::Empty,
        };
        let set: Vec<(u32, u32)> = pairwise(g, r, &crit)
            .into_iter()
            .map(|(row, col)| (row - r.r1, col - r.c1))
            .collect();
        hits = Some(match hits {
            None => set,
            Some(prev) => prev.into_iter().filter(|p| set.contains(p)).collect(),
        });
        i += 2;
    }
    let hits = hits.unwrap_or_default();
    let mut nums = Vec::new();
    for (dr, dc) in hits {
        let v = g.value(target.sheet, target.r1 + dr, target.c1 + dc);
        if let Ok(n) = v.to_number() {
            if !matches!(v, CValue::Empty) {
                nums.push(n);
            }
        }
    }
    Ok(match agg {
        Agg::Count => CValue::Number(nums.len() as f64),
        Agg::Sum => CValue::Number(nums.iter().sum()),
        Agg::Average => {
            if nums.is_empty() {
                CValue::Error("#DIV/0!")
            } else {
                CValue::Number(nums.iter().sum::<f64>() / nums.len() as f64)
            }
        }
        Agg::Max => CValue::Number(nums.iter().cloned().fold(f64::NEG_INFINITY, f64::max)),
        Agg::Min => CValue::Number(nums.iter().cloned().fold(f64::INFINITY, f64::min)),
    })
}

fn date_part(serial: f64, which: usize) -> f64 {
    let dt = DateTime::from_serial(serial);
    match which {
        0 => dt.year as f64,
        1 => dt.month as f64,
        2 => dt.day as f64,
        3 => dt.hour as f64,
        4 => dt.minute as f64,
        _ => dt.second as f64,
    }
}

fn days360(args: &[FArg]) -> Result<CValue, &'static str> {
    let a = DateTime::from_serial(num_arg(args, 0)?);
    let b = DateTime::from_serial(num_arg(args, 1)?);
    let f = |d: DateTime| {
        let day = d.day.min(30) as i32;
        d.year * 360 + (d.month as i32 - 1) * 30 + day
    };
    Ok(CValue::Number((f(b) - f(a)) as f64))
}

fn datedif(args: &[FArg]) -> Result<CValue, &'static str> {
    let a = DateTime::from_serial(num_arg(args, 0)?);
    let b = DateTime::from_serial(num_arg(args, 1)?);
    let unit = text_arg(args, 2)?.to_ascii_uppercase();
    if b.excel_serial() < a.excel_serial() {
        return err("#NUM!");
    }
    Ok(CValue::Number(match unit.as_str() {
        "D" => (b.excel_serial() - a.excel_serial()).floor(),
        "M" | "Y" => {
            let mut months = (b.year - a.year) as f64 * 12.0 + (b.month as f64 - a.month as f64);
            if b.day < a.day {
                months -= 1.0;
            }
            if unit == "Y" {
                (months / 12.0).floor()
            } else {
                months
            }
        }
        "MD" => (b.day as f64 - a.day as f64).max(0.0),
        "YM" => {
            let mut months = (b.year - a.year) as f64 * 12.0 + (b.month as f64 - a.month as f64);
            if b.day < a.day {
                months -= 1.0;
            }
            months.rem_euclid(12.0)
        }
        "YD" => {
            let mut y = a;
            y.year = b.year;
            if y.excel_serial() > b.excel_serial() {
                y.year -= 1;
            }
            (b.excel_serial() - y.excel_serial()).floor()
        }
        _ => return err("#NUM!"),
    }))
}

fn networkdays(args: &[FArg], workday: bool) -> Result<CValue, &'static str> {
    let is_weekend = |serial: f64| {
        let w = DateTime::from_serial(serial).weekday_sun0();
        w == 0 || w == 6
    };
    if workday {
        let start = num_arg(args, 0)?;
        let days = num_arg(args, 1)? as i64;
        let mut serial = start;
        let mut remaining = days;
        while remaining != 0 {
            serial += if remaining > 0 { 1.0 } else { -1.0 };
            if !is_weekend(serial) {
                remaining -= if remaining > 0 { 1 } else { -1 };
            }
        }
        Ok(CValue::Number(serial))
    } else {
        let start = num_arg(args, 0)?.floor();
        let end = num_arg(args, 1)?.floor();
        if end < start {
            return err("#NUM!");
        }
        let mut count = 0.0;
        let mut s = start;
        while s <= end {
            if !is_weekend(s) {
                count += 1.0;
            }
            s += 1.0;
        }
        Ok(CValue::Number(count))
    }
}

fn gcd(a: u64, b: u64) -> u64 {
    if b == 0 {
        a
    } else {
        gcd(b, a % b)
    }
}

fn fact(k: f64) -> f64 {
    let n = k.max(0.0).floor() as u32;
    (2..=n).fold(1.0, |acc, i| acc * i as f64)
}

fn combin(n: f64, k: f64) -> f64 {
    let n = n.max(0.0).floor();
    let k = k.max(0.0).floor();
    if k > n {
        return 0.0;
    }
    fact(n) / (fact(k) * fact(n - k))
}

fn mean(xs: &[f64]) -> f64 {
    if xs.is_empty() {
        0.0
    } else {
        xs.iter().sum::<f64>() / xs.len() as f64
    }
}

fn median(xs: &[f64]) -> f64 {
    let mut v = xs.to_vec();
    v.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    let n = v.len();
    if n == 0 {
        0.0
    } else if n % 2 == 1 {
        v[n / 2]
    } else {
        (v[n / 2 - 1] + v[n / 2]) / 2.0
    }
}

fn variance(xs: &[f64], population: bool) -> Option<f64> {
    let n = xs.len();
    if n < if population { 1 } else { 2 } {
        return None;
    }
    let m = mean(xs);
    let ss: f64 = xs.iter().map(|x| (x - m).powi(2)).sum();
    Some(ss / (if population { n } else { n - 1 }) as f64)
}

fn correl(a: &[f64], b: &[f64]) -> f64 {
    let n = a.len().min(b.len());
    if n < 2 {
        return 0.0;
    }
    let ma = mean(&a[..n]);
    let mb = mean(&b[..n]);
    let mut num = 0.0;
    let mut da = 0.0;
    let mut db = 0.0;
    for i in 0..n {
        let x = a[i] - ma;
        let y = b[i] - mb;
        num += x * y;
        da += x * x;
        db += y * y;
    }
    if da == 0.0 || db == 0.0 {
        0.0
    } else {
        num / (da.sqrt() * db.sqrt())
    }
}

fn slope(xs: &[f64], ys: &[f64]) -> f64 {
    let n = xs.len().min(ys.len());
    if n < 2 {
        return 0.0;
    }
    let mx = mean(&xs[..n]);
    let my = mean(&ys[..n]);
    let mut num = 0.0;
    let mut den = 0.0;
    for i in 0..n {
        num += (xs[i] - mx) * (ys[i] - my);
        den += (xs[i] - mx).powi(2);
    }
    if den == 0.0 {
        0.0
    } else {
        num / den
    }
}

fn pmt(rate: f64, nper: f64, pv: f64, fv: f64, kind: f64) -> f64 {
    if rate == 0.0 {
        return -(pv + fv) / nper;
    }
    let f = (1.0 + rate).powf(nper);
    -(rate * (pv * f + fv)) / ((1.0 + rate * kind) * (f - 1.0))
}

fn fv(rate: f64, nper: f64, pmt_: f64, pv: f64, kind: f64) -> f64 {
    if rate == 0.0 {
        return -(pv + pmt_ * nper);
    }
    let f = (1.0 + rate).powf(nper);
    -(pv * f + pmt_ * (1.0 + rate * kind) * (f - 1.0) / rate)
}

fn pv(rate: f64, nper: f64, pmt_: f64, fv_: f64, kind: f64) -> f64 {
    if rate == 0.0 {
        return -(fv_ + pmt_ * nper);
    }
    let f = (1.0 + rate).powf(nper);
    -(fv_ + pmt_ * (1.0 + rate * kind) * (f - 1.0) / rate) / f
}

/// Deterministic pseudo-random number in `[0, 1)`; `RAND` is volatile in Excel
/// but a deterministic stream keeps recalculation reproducible for tests.
fn pseudo_random() -> f64 {
    use std::cell::Cell;
    thread_local! {
        static STATE: Cell<u64> = const { Cell::new(0x2545_F491_4F6C_DD1D) };
    }
    STATE.with(|s| {
        let mut x = s.get();
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        s.set(x);
        (x >> 11) as f64 / (1u64 << 53) as f64
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    struct Empty;
    impl Grid for Empty {
        fn value(&self, _s: Option<usize>, _r: u32, _c: u32) -> CValue {
            CValue::Empty
        }
        fn sheet_index(&self, _n: &str) -> Option<usize> {
            None
        }
    }

    fn n(v: f64) -> FArg {
        FArg::Value(CValue::Number(v))
    }
    fn t(v: &str) -> FArg {
        FArg::Value(CValue::Str(v.into()))
    }

    fn eval(name: &str, args: &[FArg]) -> CValue {
        call(name, args, &Empty)
            .expect("known function")
            .expect("ok")
    }

    /// A small sheet: column A = product, B = region, C = amount.
    struct Sample;
    impl Grid for Sample {
        fn value(&self, _s: Option<usize>, r: u32, c: u32) -> CValue {
            let data: [[CValue; 3]; 4] = [
                [
                    CValue::Str("A".into()),
                    CValue::Str("東".into()),
                    CValue::Number(10.0),
                ],
                [
                    CValue::Str("B".into()),
                    CValue::Str("西".into()),
                    CValue::Number(20.0),
                ],
                [
                    CValue::Str("C".into()),
                    CValue::Str("東".into()),
                    CValue::Number(30.0),
                ],
                [
                    CValue::Str("D".into()),
                    CValue::Str("東".into()),
                    CValue::Number(40.0),
                ],
            ];
            data.get(r as usize)
                .and_then(|row| row.get(c as usize))
                .cloned()
                .unwrap_or(CValue::Empty)
        }
        fn sheet_index(&self, _n: &str) -> Option<usize> {
            None
        }
    }

    fn r(r1: u32, c1: u32, r2: u32, c2: u32) -> FArg {
        FArg::Range(RangeRef {
            sheet: None,
            r1,
            c1,
            r2,
            c2,
        })
    }

    fn on(name: &str, args: &[FArg]) -> CValue {
        call(name, args, &Sample).expect("known").expect("ok")
    }

    #[test]
    fn criteria_functions() {
        // SUMIF over column B where region = 東, summing column C
        assert_eq!(
            on("SUMIF", &[r(0, 1, 3, 1), t("東"), r(0, 2, 3, 2)])
                .to_number()
                .unwrap(),
            80.0
        );
        assert_eq!(
            on("COUNTIF", &[r(0, 1, 3, 1), t("東")])
                .to_number()
                .unwrap(),
            3.0
        );
        assert_eq!(
            on("SUMIF", &[r(0, 2, 3, 2), t(">15")]).to_number().unwrap(),
            90.0
        );
        assert_eq!(
            on("AVERAGEIF", &[r(0, 1, 3, 1), t("西"), r(0, 2, 3, 2)])
                .to_number()
                .unwrap(),
            20.0
        );
        assert_eq!(
            on("COUNTIF", &[r(0, 0, 3, 0), t("?")]).to_number().unwrap(),
            4.0
        );
        assert_eq!(
            on("SUMIFS", &[r(0, 2, 3, 2), r(0, 1, 3, 1), t("東")])
                .to_number()
                .unwrap(),
            80.0
        );
        assert_eq!(
            on("MAXIFS", &[r(0, 2, 3, 2), r(0, 1, 3, 1), t("東")])
                .to_number()
                .unwrap(),
            40.0
        );
    }

    #[test]
    fn lookup_functions() {
        // VLOOKUP exact: product "C" → amount 30
        assert_eq!(
            on(
                "VLOOKUP",
                &[
                    t("C"),
                    r(0, 0, 3, 2),
                    n(3.0),
                    FArg::Value(CValue::Bool(false))
                ]
            )
            .to_number()
            .unwrap(),
            30.0
        );
        // VLOOKUP approximate on an unsorted first column still finds a bound
        assert!(matches!(
            on("VLOOKUP", &[t("B"), r(0, 0, 3, 2), n(3.0)]),
            CValue::Number(_) | CValue::Error(_)
        ));
        assert_eq!(
            on("MATCH", &[t("B"), r(0, 0, 3, 0), n(0.0)])
                .to_number()
                .unwrap(),
            2.0
        );
        assert_eq!(
            on("INDEX", &[r(0, 2, 3, 2), n(3.0)]).to_number().unwrap(),
            30.0
        );
        // HLOOKUP returns from the row `index` rows down, so row 2 of column A
        assert_eq!(
            on("HLOOKUP", &[t("A"), r(0, 0, 1, 2), n(2.0)]).to_text(),
            "B"
        );
        assert_eq!(
            on("SUMPRODUCT", &[r(0, 2, 3, 2), r(0, 2, 3, 2)])
                .to_number()
                .unwrap(),
            3000.0
        );
        assert_eq!(
            on("COUNTUNIQUE", &[r(0, 1, 3, 1)]).to_number().unwrap(),
            2.0
        );
        assert_eq!(
            on("LARGE", &[r(0, 2, 3, 2), n(2.0)]).to_number().unwrap(),
            30.0
        );
        assert_eq!(
            on("SMALL", &[r(0, 2, 3, 2), n(1.0)]).to_number().unwrap(),
            10.0
        );
        assert_eq!(on("MEDIAN", &[r(0, 2, 3, 2)]).to_number().unwrap(), 25.0);
        assert_eq!(
            on("RANK", &[n(30.0), r(0, 2, 3, 2)]).to_number().unwrap(),
            2.0
        );
    }

    #[test]
    fn math_and_stats() {
        assert_eq!(eval("CEILING", &[n(4.2), n(1.0)]).to_number().unwrap(), 5.0);
        assert_eq!(eval("FLOOR", &[n(4.8), n(1.0)]).to_number().unwrap(), 4.0);
        assert_eq!(eval("TRUNC", &[n(-4.7)]).to_number().unwrap(), -4.0);
        assert_eq!(
            eval("QUOTIENT", &[n(7.0), n(2.0)]).to_number().unwrap(),
            3.0
        );
        assert_eq!(eval("GCD", &[n(12.0), n(18.0)]).to_number().unwrap(), 6.0);
        assert_eq!(eval("LCM", &[n(4.0), n(6.0)]).to_number().unwrap(), 12.0);
        assert_eq!(eval("FACT", &[n(5.0)]).to_number().unwrap(), 120.0);
        assert_eq!(eval("COMBIN", &[n(5.0), n(2.0)]).to_number().unwrap(), 10.0);
        assert_eq!(eval("PERMUT", &[n(5.0), n(2.0)]).to_number().unwrap(), 20.0);
        assert_eq!(eval("SIGN", &[n(-3.0)]).to_number().unwrap(), -1.0);
        assert_eq!(
            on("AGGREGATE", &[n(9.0), n(6.0), r(0, 2, 3, 2)])
                .to_number()
                .unwrap(),
            100.0
        );
    }

    #[test]
    fn text_functions() {
        assert_eq!(
            eval("TEXT", &[n(1234.5), t("#,##0.00")]).to_text(),
            "1,234.50"
        );
        assert_eq!(eval("TEXT", &[n(0.256), t("0.0%")]).to_text(), "25.6%");
        assert_eq!(eval("FIXED", &[n(1234.5678), n(2.0)]).to_text(), "1,234.57");
        assert_eq!(eval("DOLLAR", &[n(9.5), n(2.0)]).to_text(), "$9.50");
        assert_eq!(eval("YEN", &[n(1500.0)]).to_text(), "¥1,500");
        assert_eq!(eval("REPT", &[t("ab"), n(3.0)]).to_text(), "ababab");
        assert_eq!(
            eval("SUBSTITUTE", &[t("a-b-c"), t("-"), t("+")]).to_text(),
            "a+b+c"
        );
        assert_eq!(
            eval("SUBSTITUTE", &[t("a-b-c"), t("-"), t("+"), n(2.0)]).to_text(),
            "a-b+c"
        );
        assert_eq!(
            eval("REPLACE", &[t("2026-11-17"), n(6.0), n(2.0), t("12")]).to_text(),
            "2026-12-17"
        );
        assert_eq!(
            eval("FIND", &[t("11"), t("2026-11-17")])
                .to_number()
                .unwrap(),
            6.0
        );
        assert_eq!(
            eval("SEARCH", &[t("X"), t("abcX")]).to_number().unwrap(),
            4.0
        );
        assert_eq!(eval("CHAR", &[n(65.0)]).to_text(), "A");
        assert_eq!(eval("CODE", &[t("A")]).to_number().unwrap(), 65.0);
        assert_eq!(
            eval("NUMBERVALUE", &[t("￥1,234")]).to_number().unwrap(),
            1234.0
        );
        assert!(eval("EXACT", &[t("a"), t("a")]).to_bool().unwrap());
    }

    #[test]
    fn date_functions() {
        // 46353 = 2026-11-17
        assert_eq!(eval("YEAR", &[n(46343.0)]).to_number().unwrap(), 2026.0);
        assert_eq!(eval("MONTH", &[n(46343.0)]).to_number().unwrap(), 11.0);
        assert_eq!(eval("DAY", &[n(46343.0)]).to_number().unwrap(), 17.0);
        assert_eq!(eval("WEEKDAY", &[n(46343.0)]).to_number().unwrap(), 3.0); // Tuesday
        assert_eq!(
            eval("WEEKDAY", &[n(46343.0), n(2.0)]).to_number().unwrap(),
            2.0
        );
        assert_eq!(
            eval("DATE", &[n(2026.0), n(11.0), n(17.0)])
                .to_number()
                .unwrap(),
            46343.0
        );
        assert_eq!(
            eval("DAYS", &[n(46343.0), n(46342.0)]).to_number().unwrap(),
            1.0
        );
        assert_eq!(
            eval("EDATE", &[n(46343.0), n(1.0)]).to_number().unwrap(),
            46373.0
        );
        assert_eq!(
            eval("EOMONTH", &[n(46343.0), n(0.0)]).to_number().unwrap(),
            46356.0 // 2026-11-30
        );
        assert_eq!(
            eval("DATEDIF", &[n(45292.0), n(46343.0), t("y")])
                .to_number()
                .unwrap(),
            2.0
        );
        // 2026-11-16 (Mon) .. 2026-11-20 (Fri) = 5 working days
        assert_eq!(
            eval("NETWORKDAYS", &[n(46342.0), n(46346.0)])
                .to_number()
                .unwrap(),
            5.0
        );
        assert_eq!(
            eval("DATEVALUE", &[t("2026-11-17")]).to_number().unwrap(),
            46343.0
        );
    }

    #[test]
    fn financial_functions() {
        // ¥1,000,000 over 12 months at 12% / year
        let p = eval("PMT", &[n(0.01), n(12.0), n(1_000_000.0)])
            .to_number()
            .unwrap();
        assert!((p - -88848.79).abs() < 1.0, "{p}");
        let f = eval("FV", &[n(0.01), n(12.0), n(-10000.0)])
            .to_number()
            .unwrap();
        assert!((f - 126825.0).abs() < 200.0, "{f}");
        let s = eval("SLN", &[n(1_000_000.0), n(100_000.0), n(5.0)])
            .to_number()
            .unwrap();
        assert_eq!(s, 180_000.0);
        let e = eval("EFFECT", &[n(0.12), n(12.0)]).to_number().unwrap();
        assert!((e - 0.126825).abs() < 1e-4, "{e}");
    }

    #[test]
    fn logical_and_info() {
        assert_eq!(
            eval(
                "IFS",
                &[
                    FArg::Value(CValue::Bool(false)),
                    n(1.0),
                    FArg::Value(CValue::Bool(true)),
                    n(2.0)
                ]
            )
            .to_number()
            .unwrap(),
            2.0
        );
        assert_eq!(
            eval(
                "SWITCH",
                &[n(2.0), n(1.0), t("one"), n(2.0), t("two"), t("other")]
            )
            .to_text(),
            "two"
        );
        assert_eq!(
            eval("IFNA", &[FArg::Value(CValue::Error("#N/A")), t("none")]).to_text(),
            "none"
        );
        assert!(matches!(
            call("ISERROR", &[FArg::Value(CValue::Error("#DIV/0!"))], &Empty),
            Some(Ok(CValue::Bool(true)))
        ));
        assert!(call("NOSUCHFN", &[], &Empty).is_none());
    }

    #[test]
    fn second_wave_functions() {
        assert_eq!(eval("BASE", &[n(255.0), n(16.0), n(4.0)]).to_text(), "00FF");
        assert_eq!(
            eval("DECIMAL", &[t("FF"), n(16.0)]).to_number().unwrap(),
            255.0
        );
        assert_eq!(eval("ROMAN", &[n(2026.0)]).to_text(), "MMXXVI");
        assert_eq!(eval("ARABIC", &[t("MMXXVI")]).to_number().unwrap(), 2026.0);
        assert_eq!(
            eval("MULTINOMIAL", &[n(2.0), n(3.0)]).to_number().unwrap(),
            10.0
        );
        assert_eq!(
            eval("SQRTPI", &[n(4.0)]).to_number().unwrap(),
            2.0 * std::f64::consts::PI.sqrt()
        );
        assert_eq!(eval("EVEN", &[n(1.5)]).to_number().unwrap(), 2.0);
        assert_eq!(eval("ODD", &[n(2.0)]).to_number().unwrap(), 3.0);
        assert_eq!(eval("SEC", &[n(0.0)]).to_number().unwrap(), 1.0);
        assert_eq!(eval("ASINH", &[n(0.0)]).to_number().unwrap(), 0.0);
        let z = eval("NORM.S.DIST", &[n(0.0), FArg::Value(CValue::Bool(true))]);
        assert!((z.to_number().unwrap() - 0.5).abs() < 1e-6);
        let inv = eval("NORM.S.INV", &[n(0.975)]).to_number().unwrap();
        assert!((inv - 1.96).abs() < 0.01, "{inv}");
        let ddb = eval("DDB", &[n(1_000_000.0), n(100_000.0), n(5.0), n(1.0)])
            .to_number()
            .unwrap();
        assert!((ddb - 400_000.0).abs() < 1.0, "{ddb}");
        let rri = eval("RRI", &[n(5.0), n(100.0), n(200.0)])
            .to_number()
            .unwrap();
        assert!((rri - 0.1487).abs() < 0.001, "{rri}");
        assert_eq!(eval("ISOWEEKNUM", &[n(46343.0)]).to_number().unwrap(), 47.0);
        assert_eq!(
            eval("ERROR.TYPE", &[FArg::Value(CValue::Error("#DIV/0!"))])
                .to_number()
                .unwrap(),
            2.0
        );
        let kurt = eval("KURT", &[n(1.0), n(2.0), n(3.0), n(4.0), n(10.0)]).to_number();
        assert!(kurt.is_ok());
    }

    #[test]
    fn wildcards_for_countif() {
        assert!(wildcard_match("東*", "東京"));
        assert!(wildcard_match("A?C", "ABC"));
        assert!(wildcard_match("*", ""));
        assert!(!wildcard_match("A*", "B"));
        assert!(wildcard_match("a*", "ABC"), "case-insensitive");
    }
}
