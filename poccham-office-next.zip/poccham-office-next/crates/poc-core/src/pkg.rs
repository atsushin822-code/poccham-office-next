//! OPC / ZIP container handling.
//!
//! Both OOXML (`.docx`, `.xlsx`, `.pptx`) and ODF (`.odt`, `.ods`, `.odp`)
//! documents are ZIP archives of parts.  We write them deterministically:
//! stable part order, fixed modification timestamps and no extra fields, so
//! generating the same document twice yields identical bytes.

use std::collections::BTreeMap;
use std::io::{Cursor, Read, Write};

use zip::write::SimpleFileOptions;
use zip::{CompressionMethod, ZipArchive, ZipWriter};

use crate::error::{Error, Result};

/// A single part inside a container.
#[derive(Debug, Clone)]
struct Part {
    data: Vec<u8>,
    stored: bool,
}

/// An in-memory document container.
#[derive(Debug, Default, Clone)]
pub struct Package {
    /// Kept ordered: ODF requires `mimetype` first, OOXML is order agnostic.
    order: Vec<String>,
    parts: BTreeMap<String, Part>,
}

impl Package {
    pub fn new() -> Self {
        Self::default()
    }

    /// Insert a deflated part.
    pub fn insert(&mut self, name: &str, data: impl Into<Vec<u8>>) {
        self.insert_inner(name, data.into(), false);
    }

    /// Insert a part with no compression.  ODF's `mimetype` part must be the
    /// first entry of the archive and must not be compressed.
    pub fn insert_stored(&mut self, name: &str, data: impl Into<Vec<u8>>) {
        self.insert_inner(name, data.into(), true);
    }

    fn insert_inner(&mut self, name: &str, data: Vec<u8>, stored: bool) {
        let name = name.trim_start_matches('/').to_string();
        if !self.parts.contains_key(&name) {
            self.order.push(name.clone());
        }
        self.parts.insert(name, Part { data, stored });
    }

    /// Insert a UTF-8 text part.
    pub fn insert_str(&mut self, name: &str, data: impl Into<String>) {
        self.insert(name, data.into().into_bytes());
    }

    pub fn contains(&self, name: &str) -> bool {
        self.parts.contains_key(name.trim_start_matches('/'))
    }

    pub fn get(&self, name: &str) -> Option<&[u8]> {
        self.parts
            .get(name.trim_start_matches('/'))
            .map(|p| p.data.as_slice())
    }

    pub fn get_str(&self, name: &str) -> Option<&str> {
        self.get(name).and_then(|b| std::str::from_utf8(b).ok())
    }

    /// Part names in archive order.
    pub fn names(&self) -> Vec<&str> {
        self.order.iter().map(|s| s.as_str()).collect()
    }

    pub fn len(&self) -> usize {
        self.parts.len()
    }

    pub fn is_empty(&self) -> bool {
        self.parts.is_empty()
    }

    /// Uncompressed payload size of all parts.
    pub fn payload_size(&self) -> usize {
        self.parts.values().map(|p| p.data.len()).sum()
    }

    /// Serialise the container.
    pub fn to_bytes(&self) -> Result<Vec<u8>> {
        let mut zw = ZipWriter::new(Cursor::new(Vec::with_capacity(self.payload_size() / 2)));
        for name in &self.order {
            let part = &self.parts[name];
            let method = if part.stored {
                CompressionMethod::Stored
            } else {
                CompressionMethod::Deflated
            };
            let opts = SimpleFileOptions::default()
                .compression_method(method)
                // Level 1 deflate: ~3x faster than the default for XML parts,
                // with only a few percent larger output.  Office files are
                // re-read far more often than they are re-compressed.
                .compression_level(if part.stored { None } else { Some(1) })
                .last_modified_time(zip::DateTime::default())
                .unix_permissions(0o644);
            zw.start_file(name.as_str(), opts)?;
            zw.write_all(&part.data)?;
        }
        let cursor = zw.finish()?;
        Ok(cursor.into_inner())
    }

    pub fn save(&self, path: impl AsRef<std::path::Path>) -> Result<()> {
        std::fs::write(path, self.to_bytes()?)?;
        Ok(())
    }

    /// Read a container from memory.
    pub fn from_bytes(bytes: &[u8]) -> Result<Self> {
        let mut archive = ZipArchive::new(Cursor::new(bytes.to_vec()))
            .map_err(|e| Error::Package(format!("not a ZIP container: {e}")))?;
        let mut pkg = Package::new();
        for i in 0..archive.len() {
            let mut entry = archive.by_index(i)?;
            if entry.is_dir() {
                continue;
            }
            let name = entry.name().to_string();
            let mut buf = Vec::with_capacity(entry.size() as usize);
            entry.read_to_end(&mut buf)?;
            let stored = entry.compression() == CompressionMethod::Stored;
            pkg.insert_inner(&name, buf, stored);
        }
        Ok(pkg)
    }

    pub fn open(path: impl AsRef<std::path::Path>) -> Result<Self> {
        let bytes = std::fs::read(path)?;
        Package::from_bytes(&bytes)
    }
}

/// Resolve a relationship target against the directory of its source part.
///
/// `resolve("xl", "worksheets/sheet1.xml")` -> `xl/worksheets/sheet1.xml`
/// `resolve("ppt/slides", "../slideLayouts/slideLayout1.xml")` -> `ppt/slideLayouts/slideLayout1.xml`
/// Resolve a relationship target against the directory of the part that
/// declares it.
///
/// OPC allows both forms and both appear in the wild:
/// * relative — `worksheets/sheet1.xml`, `../docProps/core.xml`
/// * absolute — `/xl/worksheets/sheet1.xml` (openpyxl, some LibreOffice builds)
pub fn resolve(base_dir: &str, target: &str) -> String {
    let (base, target) = match target.strip_prefix('/') {
        Some(abs) => ("", abs), // package-absolute: ignore the base
        None => (base_dir, target),
    };
    let mut out: Vec<&str> = base.split('/').filter(|s| !s.is_empty()).collect();
    for seg in target.split('/') {
        match seg {
            "" | "." => {}
            ".." => {
                out.pop();
            }
            seg => out.push(seg),
        }
    }
    out.join("/")
}

/// Relationship helper: `<Relationships>` for a part.
pub fn rels_xml(rels: &[(String, String, String, bool)]) -> String {
    // (id, type, target, external)
    let mut s = String::with_capacity(256);
    s.push_str(crate::xml::DECL);
    s.push_str(
        r#"<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">"#,
    );
    for (id, ty, target, external) in rels {
        let mut attrs = vec![
            ("Id", id.as_str()),
            ("Type", ty.as_str()),
            ("Target", target.as_str()),
        ];
        if *external {
            attrs.push(("TargetMode", "External"));
        }
        crate::xml::open_tag(&mut s, "Relationship", &attrs, true);
    }
    s.push_str("</Relationships>");
    s
}

/// Standard content types header shared by the three OOXML document families.
pub fn content_types_xml(
    main_part: &str,
    main_type: &str,
    overrides: &[(String, String)],
) -> String {
    content_types_xml_full(main_part, main_type, &[], overrides)
}

/// Like [`content_types_xml`], plus `<Default>` entries for extra extensions
/// (`png`, `jpeg`, `vml`, …) that embedded media needs.
pub fn content_types_xml_full(
    main_part: &str,
    main_type: &str,
    defaults: &[(String, String)],
    overrides: &[(String, String)],
) -> String {
    let mut s = String::with_capacity(1024);
    s.push_str(crate::xml::DECL);
    s.push_str(r#"<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">"#);
    s.push_str(
        r#"<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>"#,
    );
    s.push_str(r#"<Default Extension="xml" ContentType="application/xml"/>"#);
    for (ext, ty) in defaults {
        crate::xml::open_tag(
            &mut s,
            "Default",
            &[("Extension", ext), ("ContentType", ty)],
            true,
        );
    }
    let mut attrs = vec![("PartName", main_part), ("ContentType", main_type)];
    crate::xml::open_tag(&mut s, "Override", &attrs, true);
    for (part, ty) in overrides {
        attrs = vec![("PartName", part.as_str()), ("ContentType", ty.as_str())];
        crate::xml::open_tag(&mut s, "Override", &attrs, true);
    }
    s.push_str("</Types>");
    s
}

/// `docProps/core.xml` (Dublin Core metadata).
pub fn core_xml(title: &str, creator: &str, created: &str) -> String {
    let mut s = String::with_capacity(512);
    s.push_str(crate::xml::DECL);
    s.push_str(
        r#"<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">"#,
    );
    crate::xml::text_tag(&mut s, "dc:title", &[], title);
    crate::xml::text_tag(&mut s, "dc:creator", &[], creator);
    crate::xml::text_tag(&mut s, "cp:lastModifiedBy", &[], creator);
    s.push_str(&format!(
        r#"<dcterms:created xsi:type="dcterms:W3CDTF">{created}</dcterms:created>"#
    ));
    s.push_str(&format!(
        r#"<dcterms:modified xsi:type="dcterms:W3CDTF">{created}</dcterms:modified>"#
    ));
    s.push_str("</cp:coreProperties>");
    s
}

/// `docProps/app.xml` (extended properties).
pub fn app_xml(application: &str, extra: &[(&str, &str)]) -> String {
    let mut s = String::with_capacity(512);
    s.push_str(crate::xml::DECL);
    s.push_str(
        r#"<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">"#,
    );
    crate::xml::text_tag(&mut s, "Application", &[], application);
    crate::xml::text_tag(&mut s, "AppVersion", &[], crate::VERSION);
    for (k, v) in extra {
        crate::xml::text_tag(&mut s, k, &[], v);
    }
    s.push_str("</Properties>");
    s
}

/// Root `_rels/.rels` pointing at the main document part.
pub fn root_rels(main_target: &str, main_type: &str) -> String {
    rels_xml(&[
        (
            "rId1".to_string(),
            main_type.to_string(),
            main_target.to_string(),
            false,
        ),
        (
            "rId2".to_string(),
            "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties"
                .to_string(),
            "docProps/core.xml".to_string(),
            false,
        ),
        (
            "rId3".to_string(),
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties"
                .to_string(),
            "docProps/app.xml".to_string(),
            false,
        ),
    ])
}

/// Current UTC time as a W3CDTF string, without pulling in a date crate.
pub fn now_w3cdtf() -> String {
    let secs = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    w3cdtf_from_unix(secs)
}

/// Convert unix seconds to `2026-11-17T12:00:00Z` (proleptic Gregorian).
pub fn w3cdtf_from_unix(secs: u64) -> String {
    let days = (secs / 86_400) as i64;
    let rem = secs % 86_400;
    let (y, m, d) = civil_from_days(days);
    format!(
        "{y:04}-{m:02}-{d:02}T{:02}:{:02}:{:02}Z",
        rem / 3600,
        (rem % 3600) / 60,
        rem % 60
    )
}

/// Howard Hinnant's `civil_from_days` (public domain algorithm).
fn civil_from_days(z: i64) -> (i64, u32, u32) {
    let z = z + 719_468;
    let era = if z >= 0 { z } else { z - 146_096 } / 146_097;
    let doe = (z - era * 146_097) as u64;
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let y = yoe as i64 + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = (doy - (153 * mp + 2) / 5 + 1) as u32;
    let m = if mp < 10 { mp + 3 } else { mp - 9 } as u32;
    (if m <= 2 { y + 1 } else { y }, m, d)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn package_roundtrip() {
        let mut p = Package::new();
        p.insert_str("a.xml", "<a>1</a>");
        p.insert_str("b/c.xml", "<c/>");
        let bytes = p.to_bytes().unwrap();
        let back = Package::from_bytes(&bytes).unwrap();
        assert_eq!(back.get_str("a.xml").unwrap(), "<a>1</a>");
        assert_eq!(back.get_str("/b/c.xml").unwrap(), "<c/>");
        assert_eq!(back.names(), vec!["a.xml", "b/c.xml"]);
    }

    #[test]
    fn deterministic_output() {
        let build = || {
            let mut p = Package::new();
            p.insert_str("x.txt", "hello hello hello hello hello");
            p.to_bytes().unwrap()
        };
        assert_eq!(build(), build());
    }

    #[test]
    fn stored_parts_stay_stored() {
        let mut p = Package::new();
        p.insert_stored("mimetype", "application/vnd.oasis.opendocument.text");
        p.insert_str("content.xml", "<x/>");
        let bytes = p.to_bytes().unwrap();
        let back = Package::from_bytes(&bytes).unwrap();
        assert_eq!(back.names()[0], "mimetype");
        assert_eq!(
            back.payload_size(),
            "application/vnd.oasis.opendocument.text".len() + 4
        );
    }

    #[test]
    fn civil_dates() {
        assert_eq!(w3cdtf_from_unix(0), "1970-01-01T00:00:00Z");
        assert_eq!(w3cdtf_from_unix(1_767_225_600), "2026-01-01T00:00:00Z");
    }
}
