//! Rich cell formatting: the `styles.xml` part of a workbook.
//!
//! A workbook carries one stylesheet; every cell points at a *cell format*
//! (`cellXfs` entry) by index.  Keeping the pool on the workbook means a
//! million cells formatted "bold, right aligned, ¥#,##0" cost one entry, and
//! identical formats are deduplicated as they are interned.
//!
//! The first ten entries are the built-in styles that
//! [`crate::xlsx::styles`] names, so `Cell::styled(styles::HEADER)` keeps
//! working and files written by older versions read back identically.

use std::fmt::Write as _;

use crate::xml::{self, Event, Reader};

/// An sRGB colour.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct Rgb(pub u8, pub u8, pub u8);

impl Rgb {
    pub const fn hex(v: u32) -> Self {
        Rgb((v >> 16) as u8, (v >> 8) as u8, v as u8)
    }
    /// `FFRRGGBB`, the form OOXML stores.
    pub fn argb(self) -> String {
        format!("FF{:02X}{:02X}{:02X}", self.0, self.1, self.2)
    }
    pub fn from_argb(s: &str) -> Option<Self> {
        let s = s.trim();
        let hex = s.strip_prefix("FF").filter(|h| h.len() == 6).unwrap_or(s);
        if hex.len() != 6 {
            return None;
        }
        let v = u32::from_str_radix(hex, 16).ok()?;
        Some(Rgb::hex(v))
    }
    /// `#RRGGBB`, what the UI wants.
    pub fn css(self) -> String {
        format!("#{:02X}{:02X}{:02X}", self.0, self.1, self.2)
    }
    pub fn from_css(s: &str) -> Option<Self> {
        let s = s.trim().trim_start_matches('#');
        if s.len() != 6 {
            return None;
        }
        Rgb::from_argb(s)
    }
}

pub const BLACK: Rgb = Rgb(0, 0, 0);
pub const WHITE: Rgb = Rgb(255, 255, 255);

/// Font attributes.
#[derive(Debug, Clone, PartialEq)]
pub struct Font {
    pub name: String,
    pub size: f32,
    pub bold: bool,
    pub italic: bool,
    pub underline: bool,
    pub strike: bool,
    pub color: Option<Rgb>,
}

impl Default for Font {
    fn default() -> Self {
        Font {
            name: "Calibri".into(),
            size: 11.0,
            bold: false,
            italic: false,
            underline: false,
            strike: false,
            color: None,
        }
    }
}

impl Font {
    pub fn bold(mut self) -> Self {
        self.bold = true;
        self
    }
    pub fn italic(mut self) -> Self {
        self.italic = true;
        self
    }
    pub fn size(mut self, size: f32) -> Self {
        self.size = size;
        self
    }
    pub fn color(mut self, color: Rgb) -> Self {
        self.color = Some(color);
        self
    }
}

/// Border line styles, spelled as OOXML spells them.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LineStyle {
    Hair,
    Thin,
    Medium,
    Thick,
    Double,
    Dashed,
    Dotted,
}

impl LineStyle {
    pub fn as_str(self) -> &'static str {
        match self {
            LineStyle::Hair => "hair",
            LineStyle::Thin => "thin",
            LineStyle::Medium => "medium",
            LineStyle::Thick => "thick",
            LineStyle::Double => "double",
            LineStyle::Dashed => "dashed",
            LineStyle::Dotted => "dotted",
        }
    }
    pub fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "hair" => LineStyle::Hair,
            "thin" => LineStyle::Thin,
            "medium" => LineStyle::Medium,
            "thick" => LineStyle::Thick,
            "double" => LineStyle::Double,
            "dashed" => LineStyle::Dashed,
            "dotted" => LineStyle::Dotted,
            _ => return None,
        })
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Line {
    pub style: LineStyle,
    pub color: Rgb,
}

impl Line {
    pub const fn new(style: LineStyle, color: Rgb) -> Self {
        Line { style, color }
    }
    pub const fn thin(color: Rgb) -> Self {
        Line::new(LineStyle::Thin, color)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct Border {
    pub left: Option<Line>,
    pub right: Option<Line>,
    pub top: Option<Line>,
    pub bottom: Option<Line>,
    pub diagonal: Option<Line>,
}

impl Border {
    /// All four edges the same line.
    pub fn boxed(line: Line) -> Self {
        Border {
            left: Some(line),
            right: Some(line),
            top: Some(line),
            bottom: Some(line),
            diagonal: None,
        }
    }
    /// The classic spreadsheet "grid" look: thin black everywhere.
    pub fn grid() -> Self {
        Border::boxed(Line::thin(BLACK))
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum HAlign {
    #[default]
    General,
    Left,
    Center,
    Right,
    Justify,
}

impl HAlign {
    pub fn as_str(self) -> &'static str {
        match self {
            HAlign::General => "general",
            HAlign::Left => "left",
            HAlign::Center => "center",
            HAlign::Right => "right",
            HAlign::Justify => "justify",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum VAlign {
    #[default]
    Bottom,
    Top,
    Center,
}

impl VAlign {
    pub fn as_str(self) -> &'static str {
        match self {
            VAlign::Bottom => "bottom",
            VAlign::Top => "top",
            VAlign::Center => "center",
        }
    }
}

/// One `cellXfs` entry: everything a cell can be formatted with.
#[derive(Debug, Clone, PartialEq)]
pub struct Xf {
    pub font: Font,
    /// Solid fill colour.
    pub fill: Option<Rgb>,
    pub border: Border,
    /// Number-format code (`General`, `#,##0`, `yyyy-mm-dd`, …).
    pub num_fmt: String,
    pub halign: HAlign,
    pub valign: VAlign,
    pub wrap: bool,
}

impl Default for Xf {
    fn default() -> Self {
        Xf {
            font: Font::default(),
            fill: None,
            border: Border::default(),
            num_fmt: "General".into(),
            halign: HAlign::General,
            valign: VAlign::Bottom,
            wrap: false,
        }
    }
}

impl Xf {
    pub fn with_num_fmt(code: impl Into<String>) -> Self {
        Xf {
            num_fmt: code.into(),
            ..Xf::default()
        }
    }
    pub fn bold(mut self) -> Self {
        self.font.bold = true;
        self
    }
    pub fn fill(mut self, color: Rgb) -> Self {
        self.fill = Some(color);
        self
    }
    pub fn border(mut self, border: Border) -> Self {
        self.border = border;
        self
    }
    pub fn aligned(mut self, h: HAlign, v: VAlign) -> Self {
        self.halign = h;
        self.valign = v;
        self
    }
    /// Is this the plain default format?
    pub fn is_default(&self) -> bool {
        *self == Xf::default()
    }
}

/// A differential format (used by conditional formatting).
#[derive(Debug, Clone, PartialEq, Default)]
pub struct Dxf {
    pub font_color: Option<Rgb>,
    pub bold: bool,
    pub italic: bool,
    pub fill: Option<Rgb>,
    pub num_fmt: Option<String>,
    pub border: Option<Border>,
}

/// The workbook-wide style pool.
#[derive(Debug, Clone, PartialEq)]
pub struct StyleSheet {
    pub xfs: Vec<Xf>,
    pub dxfs: Vec<Dxf>,
}

impl Default for StyleSheet {
    fn default() -> Self {
        StyleSheet::with_builtins()
    }
}

/// The ten built-in formats, in the order [`crate::xlsx::styles`] declares.
pub fn builtin_xfs() -> Vec<Xf> {
    let white_bold = Font::default().bold().color(WHITE);
    vec![
        Xf::default(),        // NORMAL
        Xf::default().bold(), // BOLD
        Xf {
            font: Font::default().italic(),
            ..Xf::default()
        }, // ITALIC
        Xf::default().bold().font_italic(), // BOLD_ITALIC
        Xf::with_num_fmt("0.00"), // NUMBER_2DP
        Xf::with_num_fmt("0.00%"), // PERCENT
        Xf::with_num_fmt("yyyy-mm-dd"), // DATE
        Xf {
            wrap: true,
            valign: VAlign::Top,
            ..Xf::default()
        }, // WRAP
        Xf {
            font: white_bold,
            fill: Some(Rgb::hex(0x1F3864)),
            border: Border::boxed(Line::thin(BLACK)),
            halign: HAlign::Left,
            valign: VAlign::Center,
            ..Xf::default()
        }, // HEADER
        Xf::with_num_fmt("\"¥\"#,##0"), // CURRENCY
    ]
}

trait XfItalic {
    fn font_italic(self) -> Self;
}

impl XfItalic for Xf {
    fn font_italic(mut self) -> Self {
        self.font.italic = true;
        self
    }
}

impl StyleSheet {
    pub fn new() -> Self {
        StyleSheet {
            xfs: Vec::new(),
            dxfs: Vec::new(),
        }
    }

    /// The ten built-ins and nothing else — what a fresh workbook has.
    pub fn with_builtins() -> Self {
        StyleSheet {
            xfs: builtin_xfs(),
            dxfs: Vec::new(),
        }
    }

    /// Return the index of `xf`, adding it when new.
    pub fn intern(&mut self, xf: Xf) -> u16 {
        if let Some(i) = self.xfs.iter().position(|x| *x == xf) {
            return i as u16;
        }
        let idx = self.xfs.len();
        if idx > u16::MAX as usize {
            return 0;
        }
        self.xfs.push(xf);
        idx as u16
    }

    pub fn intern_dxf(&mut self, dxf: Dxf) -> u16 {
        if let Some(i) = self.dxfs.iter().position(|x| *x == dxf) {
            return i as u16;
        }
        self.dxfs.push(dxf);
        (self.dxfs.len() - 1) as u16
    }

    pub fn xf(&self, idx: u16) -> &Xf {
        self.xfs.get(idx as usize).unwrap_or(&self.xfs[0])
    }

    /// Number-format code for a cell format index.
    pub fn num_fmt(&self, idx: u16) -> &str {
        &self.xf(idx).num_fmt
    }

    // ---------------------------------------------------------- serialise

    pub fn to_xml(&self) -> String {
        let mut out = String::with_capacity(2048);
        out.push_str(xml::DECL);
        out.push_str(
            r#"<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">"#,
        );

        // custom number formats start at 164 (the first id Excel hands out)
        let mut custom: Vec<(u16, String)> = Vec::new();
        let mut fmt_id = 164u16;
        let mut fmt_ids: Vec<u16> = Vec::with_capacity(self.xfs.len());
        for xf in &self.xfs {
            let id = if let Some(builtin) = builtin_num_fmt_id(&xf.num_fmt) {
                builtin
            } else {
                match custom.iter().find(|(_, code)| *code == xf.num_fmt) {
                    Some((id, _)) => *id,
                    None => {
                        custom.push((fmt_id, xf.num_fmt.clone()));
                        let id = fmt_id;
                        fmt_id += 1;
                        id
                    }
                }
            };
            fmt_ids.push(id);
        }
        if !custom.is_empty() {
            let _ = write!(out, r#"<numFmts count="{}">"#, custom.len());
            for (id, code) in &custom {
                xml::open_tag(
                    &mut out,
                    "numFmt",
                    &[("numFmtId", &id.to_string()), ("formatCode", code)],
                    true,
                );
            }
            out.push_str("</numFmts>");
        }

        // fonts, fills, borders: deduplicated pools
        let mut fonts: Vec<Font> = vec![Font::default()];
        let mut font_ids: Vec<u16> = Vec::with_capacity(self.xfs.len());
        for xf in &self.xfs {
            match fonts.iter().position(|f| *f == xf.font) {
                Some(i) => font_ids.push(i as u16),
                None => {
                    fonts.push(xf.font.clone());
                    font_ids.push((fonts.len() - 1) as u16);
                }
            }
        }
        let _ = write!(out, r#"<fonts count="{}">"#, fonts.len());
        for f in &fonts {
            out.push_str("<font>");
            if f.bold {
                out.push_str("<b/>");
            }
            if f.italic {
                out.push_str("<i/>");
            }
            if f.strike {
                out.push_str("<strike/>");
            }
            if f.underline {
                out.push_str("<u/>");
            }
            let _ = write!(out, r#"<sz val="{:.2}"/>"#, f.size);
            if let Some(c) = f.color {
                let _ = write!(out, r#"<color rgb="{}"/>"#, c.argb());
            }
            let _ = write!(
                out,
                r#"<name val="{}"/><family val="2"/><scheme val="minor"/>"#,
                xml::esc(&f.name)
            );
            out.push_str("</font>");
        }
        out.push_str("</fonts>");

        // fill 0 = none, fill 1 = gray125 (both required by the spec)
        let mut fills: Vec<Option<Rgb>> = vec![None, Some(Rgb(0x80, 0x80, 0x80))];
        let mut fill_ids: Vec<u16> = Vec::with_capacity(self.xfs.len());
        for xf in &self.xfs {
            match xf.fill {
                None => fill_ids.push(0),
                Some(c) => match fills.iter().position(|f| *f == Some(c)) {
                    Some(i) => fill_ids.push(i as u16),
                    None => {
                        fills.push(Some(c));
                        fill_ids.push((fills.len() - 1) as u16);
                    }
                },
            }
        }
        let _ = write!(out, r#"<fills count="{}">"#, fills.len());
        out.push_str(r#"<fill><patternFill patternType="none"/></fill>"#);
        out.push_str(r#"<fill><patternFill patternType="gray125"/></fill>"#);
        for f in fills.iter().skip(2) {
            let c = f.expect("colour fill");
            let _ = write!(
                out,
                r#"<fill><patternFill patternType="solid"><fgColor rgb="{}"/><bgColor indexed="64"/></patternFill></fill>"#,
                c.argb()
            );
        }
        out.push_str("</fills>");

        let mut borders: Vec<Border> = vec![Border::default()];
        let mut border_ids: Vec<u16> = Vec::with_capacity(self.xfs.len());
        for xf in &self.xfs {
            match borders.iter().position(|b| *b == xf.border) {
                Some(i) => border_ids.push(i as u16),
                None => {
                    borders.push(xf.border);
                    border_ids.push((borders.len() - 1) as u16);
                }
            }
        }
        let _ = write!(out, r#"<borders count="{}">"#, borders.len());
        for b in &borders {
            out.push_str("<border>");
            for (tag, line) in [
                ("left", b.left),
                ("right", b.right),
                ("top", b.top),
                ("bottom", b.bottom),
                ("diagonal", b.diagonal),
            ] {
                match line {
                    Some(l) => {
                        let _ = write!(
                            out,
                            r#"<{tag} style="{}"><color rgb="{}"/></{tag}>"#,
                            l.style.as_str(),
                            l.color.argb()
                        );
                    }
                    None => {
                        let _ = write!(out, "<{tag}/>");
                    }
                }
            }
            out.push_str("</border>");
        }
        out.push_str("</borders>");

        out.push_str(r#"<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>"#);
        let _ = write!(out, r#"<cellXfs count="{}">"#, self.xfs.len());
        for (i, xf) in self.xfs.iter().enumerate() {
            let num_id = fmt_ids[i].to_string();
            let font = font_ids[i].to_string();
            let fill = fill_ids[i].to_string();
            let border = border_ids[i].to_string();
            let mut attrs = vec![
                ("numFmtId", num_id.as_str()),
                ("fontId", font.as_str()),
                ("fillId", fill.as_str()),
                ("borderId", border.as_str()),
                ("xfId", "0"),
            ];
            if fmt_ids[i] != 0 {
                attrs.push(("applyNumberFormat", "1"));
            }
            if font_ids[i] != 0 {
                attrs.push(("applyFont", "1"));
            }
            if fill_ids[i] != 0 {
                attrs.push(("applyFill", "1"));
            }
            if border_ids[i] != 0 {
                attrs.push(("applyBorder", "1"));
            }
            let has_align = xf.halign != HAlign::General || xf.valign != VAlign::Bottom || xf.wrap;
            if has_align {
                attrs.push(("applyAlignment", "1"));
                xml::open_tag(&mut out, "xf", &attrs, false);
                let mut align_attrs: Vec<(&str, &str)> = Vec::new();
                let h = xf.halign.as_str();
                let v = xf.valign.as_str();
                if xf.halign != HAlign::General {
                    align_attrs.push(("horizontal", h));
                }
                if xf.valign != VAlign::Bottom {
                    align_attrs.push(("vertical", v));
                }
                if xf.wrap {
                    align_attrs.push(("wrapText", "1"));
                }
                xml::open_tag(&mut out, "alignment", &align_attrs, true);
                out.push_str("</xf>");
            } else {
                xml::open_tag(&mut out, "xf", &attrs, true);
            }
        }
        out.push_str("</cellXfs>");
        out.push_str(r#"<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>"#);

        let _ = write!(out, r#"<dxfs count="{}">"#, self.dxfs.len());
        for d in &self.dxfs {
            out.push_str("<dxf>");
            let mut font_attrs: Vec<String> = Vec::new();
            if d.bold {
                font_attrs.push("<b/>".into());
            }
            if d.italic {
                font_attrs.push("<i/>".into());
            }
            if let Some(c) = d.font_color {
                font_attrs.push(format!(r#"<color rgb="{}"/>"#, c.argb()));
            }
            if !font_attrs.is_empty() {
                let _ = write!(out, "<font>{}</font>", font_attrs.join(""));
            }
            if let Some(c) = d.fill {
                let _ = write!(
                    out,
                    r#"<fill><patternFill patternType="solid"><fgColor rgb="{}"/><bgColor indexed="64"/></patternFill></fill>"#,
                    c.argb()
                );
            }
            if let Some(code) = &d.num_fmt {
                let id = builtin_num_fmt_id(code).unwrap_or(164);
                let _ = write!(
                    out,
                    r#"<numFmt numFmtId="{id}" formatCode="{}"/>"#,
                    xml::esc(code)
                );
            }
            if let Some(b) = d.border {
                out.push_str("<border>");
                for (tag, line) in [
                    ("left", b.left),
                    ("right", b.right),
                    ("top", b.top),
                    ("bottom", b.bottom),
                ] {
                    match line {
                        Some(l) => {
                            let _ = write!(
                                out,
                                r#"<{tag} style="{}"><color rgb="{}"/></{tag}>"#,
                                l.style.as_str(),
                                l.color.argb()
                            );
                        }
                        None => {
                            let _ = write!(out, "<{tag}/>");
                        }
                    }
                }
                out.push_str("</border>");
            }
            out.push_str("</dxf>");
        }
        out.push_str("</dxfs>");
        out.push_str(r#"<tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/>"#);
        out.push_str("</styleSheet>");
        out
    }

    // --------------------------------------------------------------- read

    /// Parse a `styles.xml` part.  Unknown constructs are skipped, never fatal:
    /// reading a foreign file must not fail because of a style we do not model.
    pub fn from_xml(src: &str) -> Self {
        let mut num_fmts: Vec<(u16, String)> = builtin_num_fmts();
        let mut fonts: Vec<Font> = Vec::new();
        let mut fills: Vec<Option<Rgb>> = Vec::new();
        let mut borders: Vec<Border> = Vec::new();
        let mut xfs: Vec<Xf> = Vec::new();
        let mut dxfs: Vec<Dxf> = Vec::new();

        #[derive(Clone, Copy, PartialEq)]
        enum Scope {
            Fonts,
            Fills,
            Borders,
            Xfs,
            Dxfs,
            NumFmts,
            Other,
        }
        let mut scope = Scope::Other;
        let mut font: Option<Font> = None;
        let mut fill_color: Option<Rgb> = None;
        let mut border: Option<Border> = None;
        let mut dxf: Option<Dxf> = None;
        // the edge currently being read inside a <border>
        let mut edge: Option<(&'static str, Option<Line>)> = None;

        let mut r = Reader::new(src);
        loop {
            match r.next_event() {
                Event::Eof => break,
                Event::Start {
                    name,
                    ref attrs,
                    self_closing,
                } => {
                    let tag = xml::local(&name).to_string();
                    match tag.as_str() {
                        "numFmts" => scope = Scope::NumFmts,
                        "fonts" => scope = Scope::Fonts,
                        "fills" => scope = Scope::Fills,
                        "borders" => scope = Scope::Borders,
                        "cellXfs" => scope = Scope::Xfs,
                        "dxfs" => scope = Scope::Dxfs,
                        "numFmt" => {
                            if let (Some(id), Some(code)) =
                                (attr_u16(attrs, "numFmtId"), attr_str(attrs, "formatCode"))
                            {
                                num_fmts.push((id, code.to_string()));
                            }
                        }
                        "font" => {
                            if scope == Scope::Fonts {
                                font = Some(Font::default());
                            }
                        }
                        "b" => {
                            if let Some(f) = font.as_mut() {
                                f.bold = true;
                            }
                            if let Some(d) = dxf.as_mut() {
                                d.bold = true;
                            }
                        }
                        "i" => {
                            if let Some(f) = font.as_mut() {
                                f.italic = true;
                            }
                            if let Some(d) = dxf.as_mut() {
                                d.italic = true;
                            }
                        }
                        "u" => {
                            if let Some(f) = font.as_mut() {
                                f.underline = true;
                            }
                        }
                        "strike" => {
                            if let Some(f) = font.as_mut() {
                                f.strike = true;
                            }
                        }
                        "sz" => {
                            if let (Some(f), Some(v)) = (font.as_mut(), attr_str(attrs, "val")) {
                                if let Ok(size) = v.parse::<f32>() {
                                    f.size = size;
                                }
                            }
                        }
                        "name" => {
                            if let (Some(f), Some(v)) = (font.as_mut(), attr_str(attrs, "val")) {
                                f.name = v.to_string();
                            }
                        }
                        "color" => {
                            let rgb = attr_str(attrs, "rgb").and_then(Rgb::from_argb);
                            if let Some(f) = font.as_mut() {
                                f.color = rgb;
                            }
                            if let Some(d) = dxf.as_mut() {
                                if rgb.is_some() {
                                    d.font_color = rgb;
                                }
                            }
                            if scope == Scope::Fills {
                                fill_color = rgb;
                            }
                            if let Some((_, line)) = edge.as_mut() {
                                if let Some(l) = line.as_mut() {
                                    if let Some(c) = rgb {
                                        l.color = c;
                                    }
                                }
                            }
                        }
                        "fgColor" => {
                            let rgb = attr_str(attrs, "rgb").and_then(Rgb::from_argb);
                            match scope {
                                Scope::Fills => fill_color = rgb,
                                Scope::Dxfs => {
                                    if let Some(d) = dxf.as_mut() {
                                        d.fill = rgb;
                                    }
                                }
                                _ => {}
                            }
                        }
                        "bgColor" => {}
                        "patternFill" => {
                            if scope == Scope::Fills {
                                fill_color = None;
                            }
                        }
                        "fill" => {
                            if scope == Scope::Fills {
                                fill_color = None;
                            }
                        }
                        "border" => {
                            if scope == Scope::Borders {
                                border = Some(Border::default());
                            } else if scope == Scope::Dxfs {
                                if let Some(d) = dxf.as_mut() {
                                    d.border = Some(Border::default());
                                }
                            }
                        }
                        "left" | "right" | "top" | "bottom" | "diagonal" => {
                            let style = attr_str(attrs, "style").and_then(LineStyle::parse);
                            edge = Some((
                                match tag.as_str() {
                                    "left" => "left",
                                    "right" => "right",
                                    "top" => "top",
                                    "bottom" => "bottom",
                                    _ => "diagonal",
                                },
                                style.map(|s| Line::new(s, BLACK)),
                            ));
                            if self_closing {
                                apply_edge(&mut border, &mut dxf, edge.take());
                            }
                        }
                        "alignment" => {
                            if let Some(xf) = xfs.last_mut() {
                                if let Some(h) = attr_str(attrs, "horizontal") {
                                    xf.halign = match h {
                                        "left" => HAlign::Left,
                                        "center" => HAlign::Center,
                                        "right" => HAlign::Right,
                                        "justify" => HAlign::Justify,
                                        _ => HAlign::General,
                                    };
                                }
                                if let Some(v) = attr_str(attrs, "vertical") {
                                    xf.valign = match v {
                                        "top" => VAlign::Top,
                                        "center" => VAlign::Center,
                                        _ => VAlign::Bottom,
                                    };
                                }
                                xf.wrap = attr_str(attrs, "wrapText")
                                    .map(|v| v == "1" || v.eq_ignore_ascii_case("true"))
                                    .unwrap_or(false);
                            }
                        }
                        "dxf" => {
                            dxf = Some(Dxf::default());
                        }
                        "xf" if scope == Scope::Xfs => {
                            let num_id = attr_u16(attrs, "numFmtId").unwrap_or(0);
                            let font_id = attr_u16(attrs, "fontId").unwrap_or(0) as usize;
                            let fill_id = attr_u16(attrs, "fillId").unwrap_or(0) as usize;
                            let border_id = attr_u16(attrs, "borderId").unwrap_or(0) as usize;
                            xfs.push(Xf {
                                font: fonts.get(font_id).cloned().unwrap_or_default(),
                                fill: fills
                                    .get(fill_id)
                                    .copied()
                                    .unwrap_or(None)
                                    .filter(|c| *c != Rgb(0x80, 0x80, 0x80)),
                                border: borders.get(border_id).copied().unwrap_or_default(),
                                num_fmt: num_fmts
                                    .iter()
                                    .find(|(id, _)| *id == num_id)
                                    .map(|(_, c)| c.clone())
                                    .unwrap_or_else(|| "General".into()),
                                ..Xf::default()
                            });
                        }
                        _ => {}
                    }
                }
                Event::End { name } => {
                    let tag = xml::local(&name).to_string();
                    match tag.as_str() {
                        "fonts" | "fills" | "borders" | "cellXfs" | "dxfs" | "numFmts" => {
                            scope = Scope::Other
                        }
                        "font" => {
                            if let Some(f) = font.take() {
                                fonts.push(f);
                            }
                        }
                        "fill" => {
                            if scope == Scope::Fills {
                                fills.push(fill_color.take());
                            }
                        }
                        "border" => {
                            if let Some(b) = border.take() {
                                borders.push(b);
                            }
                        }
                        "left" | "right" | "top" | "bottom" | "diagonal" => {
                            apply_edge(&mut border, &mut dxf, edge.take());
                        }
                        "dxf" => {
                            if let Some(d) = dxf.take() {
                                dxfs.push(d);
                            }
                        }
                        _ => {}
                    }
                }
                Event::Text(_) => {}
            }
        }
        if xfs.is_empty() {
            return StyleSheet::with_builtins();
        }
        StyleSheet { xfs, dxfs }
    }
}

fn apply_edge(
    border: &mut Option<Border>,
    dxf: &mut Option<Dxf>,
    edge: Option<(&'static str, Option<Line>)>,
) {
    let Some((side, line)) = edge else { return };
    if let Some(b) = border.as_mut() {
        match side {
            "left" => b.left = line,
            "right" => b.right = line,
            "top" => b.top = line,
            "bottom" => b.bottom = line,
            _ => b.diagonal = line,
        }
    }
    if let Some(d) = dxf.as_mut() {
        let b = d.border.get_or_insert_with(Border::default);
        match side {
            "left" => b.left = line,
            "right" => b.right = line,
            "top" => b.top = line,
            "bottom" => b.bottom = line,
            _ => b.diagonal = line,
        }
    }
}

fn attr_str<'a>(attrs: &'a [(String, String)], key: &str) -> Option<&'a str> {
    attrs
        .iter()
        .find(|(k, _)| k == key || xml::local(k) == key)
        .map(|(_, v)| v.as_str())
}

fn attr_u16(attrs: &[(String, String)], key: &str) -> Option<u16> {
    attr_str(attrs, key)?.trim().parse().ok()
}

/// Built-in number formats (ECMA-376 §18.8.30), enough of them to render.
pub fn builtin_num_fmts() -> Vec<(u16, String)> {
    [
        (0, "General"),
        (1, "0"),
        (2, "0.00"),
        (3, "#,##0"),
        (4, "#,##0.00"),
        (9, "0%"),
        (10, "0.00%"),
        (11, "0.00E+00"),
        (12, "# ?/?"),
        (13, "# ??/??"),
        (14, "yyyy-mm-dd"),
        (15, "d-mmm-yy"),
        (16, "d-mmm"),
        (17, "mmm-yy"),
        (18, "h:mm AM/PM"),
        (19, "h:mm:ss AM/PM"),
        (20, "h:mm"),
        (21, "h:mm:ss"),
        (22, "yyyy-mm-dd h:mm"),
        (37, "#,##0 ;(#,##0)"),
        (38, "#,##0 ;[Red](#,##0)"),
        (39, "#,##0.00;(#,##0.00)"),
        (40, "#,##0.00;[Red](#,##0.00)"),
        (45, "mm:ss"),
        (46, "[h]:mm:ss"),
        (47, "mmss.0"),
        (48, "##0.0E+0"),
        (49, "@"),
    ]
    .iter()
    .map(|(id, code)| (*id, code.to_string()))
    .collect()
}

/// Reverse map: an exact built-in code keeps its built-in id (no `<numFmt>`).
pub fn builtin_num_fmt_id(code: &str) -> Option<u16> {
    builtin_num_fmts()
        .into_iter()
        .find(|(_, c)| c == code)
        .map(|(id, _)| id)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn builtins_round_trip() {
        let sheet = StyleSheet::with_builtins();
        let xml = sheet.to_xml();
        let back = StyleSheet::from_xml(&xml);
        assert_eq!(back.xfs.len(), sheet.xfs.len());
        assert!(back.xfs[1].font.bold, "BOLD survives");
        assert_eq!(back.xfs[4].num_fmt, "0.00");
        assert_eq!(back.xfs[6].num_fmt, "yyyy-mm-dd");
        assert!(back.xfs[7].wrap);
        assert_eq!(back.xfs[8].fill, Some(Rgb::hex(0x1F_3864)));
    }

    #[test]
    fn intern_deduplicates() {
        let mut sheet = StyleSheet::with_builtins();
        let xf = Xf::default().bold();
        let a = sheet.intern(xf.clone());
        let b = sheet.intern(xf);
        assert_eq!(a, b);
        assert_eq!(a, 1, "same as the built-in BOLD entry");
        let n = sheet.xfs.len();
        let c = sheet.intern(Xf::default().fill(Rgb::hex(0xFF_0000)));
        assert_ne!(c as usize, 1);
        assert_eq!(sheet.xfs.len(), n + 1);
    }

    #[test]
    fn custom_format_gets_a_164_id() {
        let mut sheet = StyleSheet::new();
        sheet.xfs.push(Xf::default());
        sheet.intern(Xf::with_num_fmt("\"売上\"#,##0"));
        let xml = sheet.to_xml();
        assert!(xml.contains(r#"numFmtId="164""#), "{xml}");
        let back = StyleSheet::from_xml(&xml);
        assert!(back.xfs.iter().any(|x| x.num_fmt == "\"売上\"#,##0"));
    }

    #[test]
    fn colours_round_trip() {
        let c = Rgb::hex(0x12_34_56);
        assert_eq!(c.argb(), "FF123456");
        assert_eq!(Rgb::from_argb("FF123456"), Some(c));
        assert_eq!(c.css(), "#123456");
        assert_eq!(Rgb::from_css("#123456"), Some(c));
    }

    #[test]
    fn foreign_stylesheet_is_readable() {
        // A stylesheet shaped like the ones openpyxl writes.
        let src = r#"<?xml version="1.0" encoding="UTF-8"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="14"/><color rgb="FFFF0000"/><name val="Yu Gothic"/></font></fonts>
<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFFF00"/></patternFill></fill></fills>
<borders count="2"><border><left/><right/><top/><bottom/></border><border><left style="thin"><color rgb="FF000000"/></left><right style="thin"><color rgb="FF000000"/></right><top/><bottom/></border></borders>
<cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/><xf numFmtId="14" fontId="1" fillId="2" borderId="1" applyFont="1"><alignment horizontal="center" wrapText="1"/></xf><xf numFmtId="2" fontId="0" fillId="0" borderId="0"/></cellXfs>
<dxfs count="1"><dxf><font><color rgb="FF9C0006"/></font><fill><patternFill patternType="solid"><fgColor rgb="FFFFC7CE"/></patternFill></fill></dxf></dxfs>
</styleSheet>"#;
        let sheet = StyleSheet::from_xml(src);
        assert_eq!(sheet.xfs.len(), 3);
        assert!(sheet.xfs[1].font.bold);
        assert_eq!(sheet.xfs[1].font.name, "Yu Gothic");
        assert_eq!(sheet.xfs[1].font.size, 14.0);
        assert_eq!(sheet.xfs[1].font.color, Some(Rgb::hex(0xFF_0000)));
        assert_eq!(sheet.xfs[1].fill, Some(Rgb::hex(0xFF_FF00)));
        assert_eq!(sheet.xfs[1].num_fmt, "yyyy-mm-dd");
        assert!(sheet.xfs[1].border.left.is_some());
        assert_eq!(sheet.xfs[1].halign, HAlign::Center);
        assert!(sheet.xfs[1].wrap);
        assert_eq!(sheet.xfs[2].num_fmt, "0.00");
        assert_eq!(sheet.dxfs.len(), 1);
        assert_eq!(sheet.dxfs[0].fill, Some(Rgb::hex(0xFF_C7CE)));
    }
}
