//! Poccham Office Next — document engine.
//!
//! A dependency-light implementation of the file formats used by office
//! suites.  Everything here is written from the published standards
//! (ECMA-376 / ISO-IEC 29500 for OOXML, OASIS ODF 1.3, RFC 4180 for CSV);
//! no code is copied from OnlyOffice (AGPL-3.0) or LibreOffice (MPL-2.0) —
//! those projects are used only as *behavioural* references, see
//! `docs/IP_NOTES.md`.
//!
//! Design goals
//! ------------
//! * **Small**: one external crate (`zip`) for the whole engine.
//! * **Fast**: no DOM is ever built for writing; reading builds only the
//!   structures the caller asked for.  A 200k-cell workbook is written in
//!   ~35 ms on a laptop-class CPU (see `poc bench`).
//! * **Predictable**: byte-for-byte reproducible output (fixed ZIP
//!   timestamps, stable part ordering) so files diff cleanly in git.
//! * **Cheap snapshots**: undo/history use copy-on-write buffers
//!   ([`cow::CowBuffer`]) so a checkpoint costs one `Arc` bump, not a copy.
//! * **No unsafe**: `#![forbid(unsafe_code)]`.

#![forbid(unsafe_code)]

pub mod cow;
pub mod csv;
pub mod date;
pub mod detect;
pub mod docx;
pub mod error;
pub mod formula;
pub mod funcs;
pub mod numfmt;
pub mod pkg;
pub mod pptx;
pub mod style;
pub mod xlparts;
pub mod xlsx;
pub mod xml;

pub use detect::Format;
pub use error::{Error, Result};

/// Poccham Office Next release string embedded in every produced file.
pub const PRODUCT: &str = "Poccham Office Next";
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

/// Producer string used in `docProps/app.xml`.
pub(crate) fn producer() -> String {
    format!("{PRODUCT} {}", VERSION)
}
