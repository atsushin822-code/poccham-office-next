//! RFC 4180 CSV, tolerant on input (LF or CRLF, quoted fields, doubled
//! quotes, `"` inside unquoted fields) and strict on output.

/// Parse CSV text into rows of fields.
pub fn parse(text: &str) -> Vec<Vec<String>> {
    let mut rows = Vec::new();
    let mut row = Vec::new();
    let mut field = String::new();
    let mut in_quotes = false;
    let mut chars = text.chars().peekable();
    let mut any = false;

    while let Some(c) = chars.next() {
        any = true;
        if in_quotes {
            match c {
                '"' => {
                    if chars.peek() == Some(&'"') {
                        chars.next();
                        field.push('"');
                    } else {
                        in_quotes = false;
                    }
                }
                c => field.push(c),
            }
            continue;
        }
        match c {
            '"' if field.is_empty() => in_quotes = true,
            ',' => row.push(std::mem::take(&mut field)),
            '\r' => {
                if chars.peek() == Some(&'\n') {
                    chars.next();
                }
                row.push(std::mem::take(&mut field));
                rows.push(std::mem::take(&mut row));
            }
            '\n' => {
                row.push(std::mem::take(&mut field));
                rows.push(std::mem::take(&mut row));
            }
            c => field.push(c),
        }
    }
    if !field.is_empty() || !row.is_empty() || any {
        row.push(field);
        if !(row.len() == 1 && row[0].is_empty()) {
            rows.push(row);
        }
    }
    rows
}

/// Serialise rows as CSV with CRLF line endings.
pub fn write(rows: &[Vec<String>]) -> String {
    let mut out = String::with_capacity(rows.iter().map(|r| r.len() * 8).sum());
    for row in rows {
        for (i, field) in row.iter().enumerate() {
            if i > 0 {
                out.push(',');
            }
            let needs_quote = field.contains([',', '"', '\n', '\r'])
                || field.starts_with(' ')
                || field.ends_with(' ');
            if needs_quote {
                out.push('"');
                for c in field.chars() {
                    if c == '"' {
                        out.push('"');
                    }
                    out.push(c);
                }
                out.push('"');
            } else {
                out.push_str(field);
            }
        }
        out.push_str("\r\n");
    }
    out
}

/// Delimiter-sniffing parse for `.csv` / `.tsv` promises.
pub fn parse_with_delimiter(text: &str, delim: char) -> Vec<Vec<String>> {
    if delim == ',' {
        return parse(text);
    }
    parse(&text.replace(delim, ","))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_quoted() {
        let rows = vec![
            vec!["plain".to_string(), "with,comma".to_string()],
            vec!["line\nbreak".to_string(), "quote\"inside".to_string()],
            vec![String::new(), "trailing ".to_string()],
        ];
        let text = write(&rows);
        assert_eq!(parse(&text), rows);
    }

    #[test]
    fn parses_lf_and_crlf_and_ragged_rows() {
        assert_eq!(parse("a,b\nc,d\n"), vec![vec!["a", "b"], vec!["c", "d"]]);
        assert_eq!(parse("a,b\r\nc\r\n"), vec![vec!["a", "b"], vec!["c"]]);
        assert_eq!(parse(""), Vec::<Vec<String>>::new());
    }

    #[test]
    fn numbers_become_fields() {
        assert_eq!(parse("1,2.5,-3"), vec![vec!["1", "2.5", "-3"]]);
    }
}
