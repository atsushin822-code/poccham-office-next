//! Copy-on-write (CoW) buffers used to make snapshots and undo cheap.
//!
//! The rule is simple: a value is held in an [`Arc`], a snapshot is another
//! handle on the same allocation (O(1), zero copying), and the first write
//! after a snapshot clones — only then does the memory actually duplicate
//! (`Arc::make_mut`).  Undo therefore costs one `Arc` bump per step rather
//! than a deep copy of the whole document, no matter how large it is.
//!
//! ```no_run
//! use poc_core::cow::CowBuffer;
//! let mut buf = CowBuffer::new(vec![1, 2, 3]);
//! let snapshot = buf.snapshot();      // O(1), shares the allocation
//! buf.push(4);                        // clones once, snapshot is untouched
//! assert_eq!(snapshot.len(), 3);
//! assert_eq!(buf.len(), 4);
//! ```
//!
//! Same idea for whole documents: [`History`] keeps a stack of snapshots and
//! hands back an owned copy only when someone really edits.

use std::sync::Arc;

/// A vector that is shared until written.
#[derive(Debug, Clone)]
pub struct CowBuffer<T> {
    inner: Arc<Vec<T>>,
}

impl<T> CowBuffer<T> {
    /// Wrap an owned vector (no copy).
    pub fn new(items: Vec<T>) -> Self {
        CowBuffer {
            inner: Arc::new(items),
        }
    }

    /// O(1) handle on the same data.
    pub fn snapshot(&self) -> Self {
        CowBuffer {
            inner: Arc::clone(&self.inner),
        }
    }

    /// How many handles (snapshots) share this allocation right now.
    pub fn handles(&self) -> usize {
        Arc::strong_count(&self.inner)
    }

    /// True when a write would have to clone (i.e. a snapshot is alive).
    pub fn is_shared(&self) -> bool {
        self.handles() > 1
    }

    pub fn len(&self) -> usize {
        self.inner.len()
    }

    pub fn is_empty(&self) -> bool {
        self.inner.is_empty()
    }

    pub fn as_slice(&self) -> &[T] {
        &self.inner
    }
}

impl<T: Clone> CowBuffer<T> {
    /// Take the data out; free when this was the last handle.
    pub fn into_vec(self) -> Vec<T> {
        match Arc::try_unwrap(self.inner) {
            Ok(v) => v,
            Err(shared) => (*shared).clone(),
        }
    }

    /// Mutable access: clones the whole vector only if it is shared.
    pub fn make_mut(&mut self) -> &mut Vec<T> {
        Arc::make_mut(&mut self.inner)
    }

    pub fn push(&mut self, item: T) {
        self.make_mut().push(item);
    }

    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        self.make_mut().get_mut(index)
    }
}

impl<T: PartialEq> PartialEq for CowBuffer<T> {
    fn eq(&self, other: &Self) -> bool {
        Arc::ptr_eq(&self.inner, &other.inner) || self.inner == other.inner
    }
}

impl<T> Default for CowBuffer<T> {
    fn default() -> Self {
        CowBuffer::new(Vec::new())
    }
}

impl<T> From<Vec<T>> for CowBuffer<T> {
    fn from(items: Vec<T>) -> Self {
        CowBuffer::new(items)
    }
}

impl<T: Clone> FromIterator<T> for CowBuffer<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        CowBuffer::new(iter.into_iter().collect())
    }
}

/// An undo history whose checkpoints are O(1).
///
/// `snapshot()` never copies; `current_mut()` clones only if the state is
/// still referenced by a checkpoint, so editing costs one copy per edit
/// *batch*, not one copy per checkpoint.
#[derive(Debug, Clone)]
pub struct History<T> {
    current: CowBuffer<T>,
    undo: Vec<CowBuffer<T>>,
    redo: Vec<CowBuffer<T>>,
    /// Upper bound on checkpoints (oldest dropped first), 0 = unlimited.
    limit: usize,
}

impl<T: Clone> History<T> {
    pub fn new(initial: Vec<T>) -> Self {
        History {
            current: CowBuffer::new(initial),
            undo: Vec::new(),
            redo: Vec::new(),
            limit: 200,
        }
    }

    pub fn with_limit(mut self, limit: usize) -> Self {
        self.limit = limit;
        self
    }

    /// Record the current state as an undo point (O(1)).
    pub fn checkpoint(&mut self) {
        self.undo.push(self.current.snapshot());
        if self.limit > 0 && self.undo.len() > self.limit {
            self.undo.remove(0);
        }
        self.redo.clear();
    }

    /// Edit the current state (copies only if a checkpoint shares it).
    pub fn current_mut(&mut self) -> &mut Vec<T> {
        self.current.make_mut()
    }

    pub fn current(&self) -> &[T] {
        self.current.as_slice()
    }

    pub fn undo_depth(&self) -> usize {
        self.undo.len()
    }

    pub fn redo_depth(&self) -> usize {
        self.redo.len()
    }

    /// Step back. Returns false when there is nothing to undo.
    pub fn undo(&mut self) -> bool {
        let Some(prev) = self.undo.pop() else {
            return false;
        };
        self.redo.push(std::mem::replace(&mut self.current, prev));
        true
    }

    /// Step forward again.
    pub fn redo(&mut self) -> bool {
        let Some(next) = self.redo.pop() else {
            return false;
        };
        self.undo.push(std::mem::replace(&mut self.current, next));
        true
    }

    /// Number of live handles on the current buffer (1 = exclusive).
    pub fn handles(&self) -> usize {
        self.current.handles()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn snapshot_is_free_and_stays_intact() {
        let mut buf = CowBuffer::new(vec![1u32, 2, 3]);
        let snap = buf.snapshot();
        assert_eq!(buf.handles(), 2);
        assert!(buf.is_shared());
        buf.push(4);
        assert_eq!(snap.as_slice(), &[1, 2, 3]);
        assert_eq!(buf.as_slice(), &[1, 2, 3, 4]);
        // the write detached the buffer from the snapshot
        assert_eq!(snap.handles(), 1);
    }

    #[test]
    fn snapshots_of_big_buffers_allocate_nothing() {
        // 1,000,000 要素でもスナップショットは Arc の複製 1 回だけ。
        let mut buf = CowBuffer::new(vec![0u8; 1_000_000]);
        let start = std::time::Instant::now();
        let mut snaps = Vec::new();
        for _ in 0..1000 {
            snaps.push(buf.snapshot());
        }
        let elapsed = start.elapsed();
        assert_eq!(snaps.len(), 1000);
        assert_eq!(buf.handles(), 1001);
        // 1000 回のスナップショットは 10 ms 未満 (実測は µs 台)
        assert!(elapsed.as_millis() < 10, "snapshots took {elapsed:?}");
        buf.push(1);
        assert_eq!(snaps[0].len(), 1_000_000);
        assert_eq!(buf.len(), 1_000_001);
    }

    #[test]
    fn history_undo_redo_without_deep_copies() {
        let mut h = History::new(vec![1]);
        h.checkpoint();
        h.current_mut().push(2);
        h.checkpoint();
        h.current_mut().push(3);
        assert_eq!(h.current(), &[1, 2, 3]);
        assert!(h.undo());
        assert_eq!(h.current(), &[1, 2]);
        assert!(h.undo());
        assert_eq!(h.current(), &[1]);
        assert!(!h.undo());
        assert!(h.redo());
        assert_eq!(h.current(), &[1, 2]);
        assert!(h.redo());
        assert_eq!(h.current(), &[1, 2, 3]);
    }

    #[test]
    fn unshared_write_does_not_copy() {
        let mut h = History::new(vec![1, 2, 3]);
        // まだチェックポイントが無いので書き込みは in-place
        assert_eq!(h.handles(), 1);
        let ptr_before = h.current().as_ptr();
        h.current_mut().push(4);
        assert_eq!(h.current().as_ptr(), ptr_before, "no reallocation happened");
    }

    #[test]
    fn limit_drops_the_oldest_checkpoint() {
        let mut h = History::new(vec![0]).with_limit(2);
        for i in 1..=5 {
            h.checkpoint();
            h.current_mut().push(i);
        }
        assert_eq!(h.undo_depth(), 2);
    }
}
