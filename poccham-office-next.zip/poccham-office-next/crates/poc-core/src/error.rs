//! Error type shared by every Poccham engine crate.

use std::fmt;

pub type Result<T> = std::result::Result<T, Error>;

#[derive(Debug)]
pub enum Error {
    /// Underlying I/O failure.
    Io(std::io::Error),
    /// The ZIP container is broken or a part is missing.
    Package(String),
    /// XML was not well formed.
    Xml(String),
    /// The document is not what the caller asked for.
    Format(String),
    /// Feature intentionally not implemented yet (reported, never silent).
    Unsupported(String),
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Error::Io(e) => write!(f, "I/O error: {e}"),
            Error::Package(m) => write!(f, "package error: {m}"),
            Error::Xml(m) => write!(f, "malformed XML: {m}"),
            Error::Format(m) => write!(f, "unsupported document: {m}"),
            Error::Unsupported(m) => write!(f, "not implemented yet: {m}"),
        }
    }
}

impl std::error::Error for Error {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Error::Io(e) => Some(e),
            _ => None,
        }
    }
}

impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Self {
        Error::Io(e)
    }
}

impl From<zip::result::ZipError> for Error {
    fn from(e: zip::result::ZipError) -> Self {
        Error::Package(e.to_string())
    }
}
