//! Word document features: pictures, footnotes, a table of contents,
//! headers/footers, tracked changes and comments.

use poc_core::docx::{
    Block, Change, DocComment, Document, Footnote, HeaderFooter, ParaStyle, Paragraph, Picture, Run,
};
use poc_core::pkg::Package;
use poc_core::xml::{Event, Reader};

const PNG: &[u8] = &[
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
    0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0x15, 0xC4,
    0x89, 0x00, 0x00, 0x00, 0x0A, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9C, 0x63, 0x00, 0x01, 0x00, 0x00,
    0x05, 0x00, 0x01, 0x0D, 0x0A, 0x2D, 0xB4, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4E, 0x44, 0xAE,
    0x42, 0x60, 0x82,
];

fn sample() -> Document {
    let mut doc = Document::new();
    doc.title = "機能".into();
    doc.header = Some(HeaderFooter::new("ヘッダ"));
    doc.footer = Some(HeaderFooter::new("1 / ").page_number());
    doc.footnotes.push(Footnote::new("注記"));
    doc.comments
        .push(DocComment::new("山田", "確認してください"));
    doc.push(Block::Paragraph(Paragraph::styled(
        ParaStyle::Heading(1),
        "見出し",
    )));
    doc.push(Block::Toc);
    doc.push(Block::Paragraph(
        Paragraph::new("本文です。").with_footnote(2),
    ));
    doc.push(Block::Paragraph(
        Paragraph::new("指摘つき。").with_comment(0),
    ));
    doc.push(Block::Paragraph(Paragraph::with_runs(vec![
        Run::new("残す文。"),
        Run::new("削除する文。").deleted(),
        Run::new("追加する文。").inserted(),
    ])));
    doc.push(Picture::new(PNG.to_vec(), 30.0, 30.0).into_block("logo.png"));
    doc
}

fn parts(doc: &Document) -> Package {
    Package::from_bytes(&doc.to_bytes().unwrap()).unwrap()
}

#[test]
fn document_parts_are_emitted() {
    let pkg = parts(&sample());
    for part in [
        "word/document.xml",
        "word/footnotes.xml",
        "word/comments.xml",
        "word/header1.xml",
        "word/footer1.xml",
        "word/media/image1.png",
        "word/_rels/document.xml.rels",
        "[Content_Types].xml",
    ] {
        assert!(pkg.contains(part), "missing {part}: {:?}", pkg.names());
    }
    let ct = pkg.get_str("[Content_Types].xml").unwrap();
    assert!(ct.contains(r#"Extension="png""#), "{ct}");
    assert!(ct.contains("wordprocessingml.footnotes+xml"));
    assert!(ct.contains("wordprocessingml.comments+xml"));
    assert!(ct.contains("wordprocessingml.header+xml"));
}

#[test]
fn body_xml_contains_the_new_constructs() {
    let pkg = parts(&sample());
    let body = pkg.get_str("word/document.xml").unwrap();
    assert!(body.contains("<w:drawing>"), "{body}");
    assert!(body.contains("pic:pic"), "{body}");
    assert!(body.contains(" TOC \\o \"1-3\""), "{body}");
    assert!(body.contains("<w:footnoteReference w:id=\"2\"/>"), "{body}");
    assert!(body.contains("<w:commentRangeStart w:id=\"0\"/>"), "{body}");
    assert!(body.contains("<w:commentReference w:id=\"0\"/>"), "{body}");
    assert!(body.contains("<w:ins "), "{body}");
    assert!(body.contains("<w:del "), "{body}");
    assert!(body.contains("<w:delText"), "{body}");
    assert!(
        body.contains(r#"<w:headerReference w:type="default" r:id="rId4"/>"#),
        "{body}"
    );
    assert!(body.contains("<w:footerReference "), "{body}");
}

#[test]
fn footnotes_and_comments_are_well_formed() {
    let pkg = parts(&sample());
    let notes = pkg.get_str("word/footnotes.xml").unwrap();
    assert!(notes.contains(r#"w:type="separator" w:id="-1""#), "{notes}");
    assert!(notes.contains("注記"), "{notes}");
    let comments = pkg.get_str("word/comments.xml").unwrap();
    assert!(comments.contains("山田"), "{comments}");
    assert!(comments.contains("確認してください"), "{comments}");
    // every part must parse
    for name in pkg.names() {
        if !name.ends_with(".xml") {
            continue;
        }
        let src = pkg.get_str(name).unwrap();
        let mut r = Reader::new(src);
        loop {
            if matches!(r.next_event(), Event::Eof) {
                break;
            }
        }
    }
}

#[test]
fn tracked_changes_keep_both_versions() {
    let doc = sample();
    // plain text keeps deleted text so nothing is silently lost
    let text = doc.to_text();
    assert!(text.contains("削除する文。"), "{text}");
    assert!(text.contains("追加する文。"), "{text}");
    let pkg = parts(&doc);
    let body = pkg.get_str("word/document.xml").unwrap();
    assert!(body.contains(r#"w:author="Poccham Office Next""#), "{body}");
    let back = Document::from_bytes(&doc.to_bytes().unwrap()).unwrap();
    assert!(back
        .blocks
        .iter()
        .any(|b| matches!(b, Block::PageBreak | Block::Paragraph(_))));
}

#[test]
fn run_marks_are_explicit() {
    let run = Run::new("x").inserted();
    assert_eq!(run.change, Change::Inserted);
    let run = Run::new("x").deleted();
    assert_eq!(run.change, Change::Deleted);
    assert_eq!(Run::new("x").change, Change::None);
}
