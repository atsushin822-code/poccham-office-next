//! Formula engine tests: dependency chains, ranges, cross-sheet references,
//! errors and Excel-compatible rounding.

use poc_core::xlsx::{Cell, CellValue, Workbook};

fn sheet_with(rows: Vec<Vec<Cell>>) -> Workbook {
    let mut wb = Workbook::new();
    for row in rows {
        wb.sheet_mut().push_row(row);
    }
    wb
}

fn num(wb: &Workbook, a1: &str) -> Option<f64> {
    wb.sheet().get_a1(a1).and_then(|c| c.as_number())
}

fn text(wb: &Workbook, a1: &str) -> String {
    wb.sheet()
        .get_a1(a1)
        .map(|c| c.as_text())
        .unwrap_or_default()
}

#[test]
fn arithmetic_and_aggregates() {
    let mut wb = sheet_with(vec![
        vec![Cell::num(10), Cell::num(20)],
        vec![Cell::num(30), Cell::num(40)],
        vec![
            Cell::formula("SUM(A1:B2)", None),
            Cell::formula("AVERAGE(A1:B2)", None),
            Cell::formula("MAX(A1:B2)-MIN(A1:B2)", None),
            Cell::formula("A1*2+B1/4", None),
        ],
    ]);
    wb.recalculate();
    assert_eq!(num(&wb, "A3"), Some(100.0));
    assert_eq!(num(&wb, "B3"), Some(25.0));
    assert_eq!(num(&wb, "C3"), Some(30.0));
    assert_eq!(num(&wb, "D3"), Some(25.0));
}

#[test]
fn dependency_chain_settles() {
    let mut wb = sheet_with(vec![
        vec![Cell::num(1)],
        vec![Cell::formula("A1+1", None)],
        vec![Cell::formula("A2*10", None)],
        vec![Cell::formula("SUM(A1:A3)", None)],
    ]);
    wb.recalculate();
    assert_eq!(num(&wb, "A2"), Some(2.0));
    assert_eq!(num(&wb, "A3"), Some(20.0));
    assert_eq!(num(&wb, "A4"), Some(23.0));
}

#[test]
fn cross_sheet_reference() {
    let mut wb = Workbook::new();
    wb.sheets[0].name = "Data".into();
    wb.sheets[0].push_row(vec![Cell::num(100), Cell::num(200)]);
    let r = wb.add_sheet("Report");
    wb.sheets[r].push_row(vec![Cell::formula("SUM(Data!A1:B1)", None)]);
    wb.sheets[r].push_row(vec![Cell::formula("Data!B1 - Data!A1", None)]);
    wb.recalculate();
    assert_eq!(wb.sheets[r].get(0, 0).unwrap().as_number(), Some(300.0));
    assert_eq!(wb.sheets[r].get(1, 0).unwrap().as_number(), Some(100.0));
}

#[test]
fn text_functions() {
    let mut wb = sheet_with(vec![
        vec![Cell::text("poccham office")],
        vec![
            Cell::formula("UPPER(A1)", None),
            Cell::formula("LEFT(A1,3)", None),
            Cell::formula("LEN(A1)", None),
            Cell::formula("A1 & \"!\"", None),
        ],
    ]);
    wb.recalculate();
    assert_eq!(text(&wb, "A2"), "POCCHAM OFFICE");
    assert_eq!(text(&wb, "B2"), "poc");
    assert_eq!(num(&wb, "C2"), Some(14.0));
    assert_eq!(text(&wb, "D2"), "poccham office!");
}

#[test]
fn conditional_logic() {
    let mut wb = sheet_with(vec![
        vec![Cell::num(1200)],
        vec![
            Cell::formula("IF(A1>=1000,\"重点\",\"通常\")", None),
            Cell::formula("IFERROR(1/0,\"err\")", None),
            Cell::formula("IF(A1>500,1,0)", None),
        ],
    ]);
    wb.recalculate();
    assert_eq!(text(&wb, "A2"), "重点");
    assert_eq!(text(&wb, "B2"), "err");
    assert_eq!(num(&wb, "C2"), Some(1.0));
}

#[test]
fn division_by_zero_is_an_error() {
    let mut wb = sheet_with(vec![vec![Cell::num(1), Cell::formula("A1/0", None)]]);
    wb.recalculate();
    // The formula is preserved and the cached value stays empty.
    match &wb.sheet().get(0, 1).unwrap().value {
        CellValue::Formula { expr, cached, .. } => {
            assert_eq!(expr, "A1/0");
            assert_eq!(*cached, None);
        }
        other => panic!("{other:?}"),
    }
    // `poc calc` surfaces the error message instead.
    let v = poc_core::formula::evaluate(&wb, 0, "A1/0");
    assert_eq!(format!("{v:?}"), "Error(\"#DIV/0!\")");
}

#[test]
fn unknown_function_is_name_error() {
    let wb = sheet_with(vec![vec![Cell::num(1)]]);
    let v = poc_core::formula::evaluate(&wb, 0, "NOSUCHFUNCTION(A1)");
    assert_eq!(format!("{v:?}"), "Error(\"#NAME?\")");
}

#[test]
fn lookup_functions_reach_the_function_library() {
    // VLOOKUP used to fall through to `#NAME?`; it is served by `funcs.rs`.
    let wb = sheet_with(vec![
        vec![Cell::text("b"), Cell::num(10)],
        vec![Cell::text("a"), Cell::num(20)],
    ]);
    let v = poc_core::formula::evaluate(&wb, 0, "VLOOKUP(\"a\",A1:B2,2,FALSE)");
    assert!(format!("{v:?}").contains("20"), "{v:?}");
    let v = poc_core::formula::evaluate(&wb, 0, "TEXT(TODAY(),\"yyyy\")");
    assert!(format!("{v:?}").contains("Str"), "{v:?}");
}

#[test]
fn calculations_survive_save_and_load() {
    let mut wb = sheet_with(vec![vec![
        Cell::num(2),
        Cell::num(3),
        Cell::formula("A1*B1", None),
    ]]);
    wb.recalculate();
    let back = Workbook::from_bytes(&wb.to_bytes().unwrap()).unwrap();
    assert_eq!(back.sheet().get_a1("C1").unwrap().as_number(), Some(6.0));
}
