//! Presentation features: pictures, shapes, transitions, animation timing,
//! speaker notes and themes.

use poc_core::pkg::Package;
use poc_core::pptx::{Presentation, Shape, ShapeKind, Slide, SlideImage, Theme, Transition};
use poc_core::xml::{Event, Reader};

const PNG: &[u8] = &[
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
    0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0x15, 0xC4,
    0x89, 0x00, 0x00, 0x00, 0x0A, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9C, 0x63, 0x00, 0x01, 0x00, 0x00,
    0x05, 0x00, 0x01, 0x0D, 0x0A, 0x2D, 0xB4, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4E, 0x44, 0xAE,
    0x42, 0x60, 0x82,
];

fn sample() -> Presentation {
    let mut pres = Presentation::new();
    pres.title = "機能".into();
    pres.theme = Theme::from_accents(["112233", "223344", "334455", "445566", "556677", "667788"])
        .name("カスタム");
    pres.add(
        Slide::new("一枚目")
            .bullet("本文")
            .shape(
                Shape::new(ShapeKind::RoundedRect, 10.0, 10.0, 40.0, 20.0)
                    .text("図形")
                    .fill("2E75B6"),
            )
            .image(SlideImage::new(PNG.to_vec(), 60.0, 10.0, 20.0, 20.0))
            .notes("発表者ノート")
            .transition(Transition::Fade)
            .animate(),
    );
    pres.add(Slide::new("二枚目").bullet("次のスライド"));
    pres
}

#[test]
fn deck_contains_media_shapes_notes_and_theme() {
    let pkg = Package::from_bytes(&sample().to_bytes().unwrap()).unwrap();
    for part in [
        "ppt/presentation.xml",
        "ppt/slides/slide1.xml",
        "ppt/slides/slide2.xml",
        "ppt/slides/_rels/slide1.xml.rels",
        "ppt/media/image1.png",
        "ppt/notesSlides/notesSlide1.xml",
        "ppt/notesMasters/notesMaster1.xml",
        "ppt/theme/theme1.xml",
    ] {
        assert!(pkg.contains(part), "missing {part}: {:?}", pkg.names());
    }
    let slide = pkg.get_str("ppt/slides/slide1.xml").unwrap();
    assert!(slide.contains("<p:pic>"), "{slide}");
    assert!(slide.contains(r#"prst="roundRect""#), "{slide}");
    assert!(slide.contains("<a:srgbClr val=\"2E75B6\"/>"), "{slide}");
    assert!(slide.contains("<p:transition"), "{slide}");
    assert!(slide.contains("<p:timing>"), "{slide}");
    assert!(
        slide.contains("<p:animEffect transition=\"in\" filter=\"fade\">"),
        "{slide}"
    );
    // the picture is referenced by the relationship the rels part declares
    let rels = pkg.get_str("ppt/slides/_rels/slide1.xml.rels").unwrap();
    assert!(rels.contains("media/image1.png"), "{rels}");
    assert!(slide.contains(r#"r:embed="rId10""#), "{slide}");
    let notes = pkg.get_str("ppt/notesSlides/notesSlide1.xml").unwrap();
    assert!(notes.contains("発表者ノート"), "{notes}");
    let theme = pkg.get_str("ppt/theme/theme1.xml").unwrap();
    assert!(theme.contains("カスタム"), "{theme}");
    assert!(theme.contains("112233"), "{theme}");
    let ct = pkg.get_str("[Content_Types].xml").unwrap();
    assert!(ct.contains("notesSlide+xml"), "{ct}");
    assert!(ct.contains(r#"Extension="png""#), "{ct}");
}

#[test]
fn every_part_parses() {
    let pkg = Package::from_bytes(&sample().to_bytes().unwrap()).unwrap();
    for name in pkg.names() {
        if !name.ends_with(".xml") {
            continue;
        }
        let src = pkg.get_str(name).unwrap();
        let mut r = Reader::new(src);
        let mut depth = 0i32;
        loop {
            match r.next_event() {
                Event::Eof => break,
                Event::Start { self_closing, .. } => {
                    if !self_closing {
                        depth += 1;
                    }
                }
                Event::End { .. } => depth -= 1,
                Event::Text(_) => {}
            }
            assert!(depth >= 0, "{name} closes more elements than it opens");
        }
        assert_eq!(depth, 0, "{name} leaves {depth} elements open");
    }
}

#[test]
fn round_trip_keeps_titles_and_bullets() {
    let bytes = sample().to_bytes().unwrap();
    let back = Presentation::from_bytes(&bytes).unwrap();
    assert_eq!(back.slides.len(), 2);
    assert_eq!(back.slides[0].title, "一枚目");
    assert!(back.slides[0]
        .bullets
        .iter()
        .any(|b| b.text.starts_with("本文")));
    assert!(back.to_markdown().contains("二枚目"));
}

#[test]
fn theme_substitution_keeps_the_rest_of_the_part() {
    let theme = Theme::from_accents(["000001", "000002", "000003", "000004", "000005", "000006"]);
    let xml = poc_core::pptx::theme_xml(&theme);
    for hex in ["000001", "000002", "000003", "000004", "000005", "000006"] {
        assert!(xml.contains(hex), "{hex} missing");
    }
    assert!(xml.contains("<a:fmtScheme"), "the format scheme survives");
    assert!(xml.contains("</a:theme>"));
}

// ---------------------------------------------------------------- links (2026)

#[test]
fn transitions_and_animation_survive_a_round_trip() {
    for (tr, needle) in [
        (Transition::Fade, "<p:fade/>"),
        (Transition::Push, "<p:push"),
        (Transition::Wipe, "<p:wipe"),
        (Transition::Split, "<p:split"),
        (Transition::Cover, "<p:cover"),
    ] {
        let mut pres = Presentation::new();
        let mut slide = Slide::new("切替").bullet("一").bullet("二");
        slide.transition = tr;
        slide.animate = true;
        pres.add(slide);
        let bytes = pres.to_bytes().unwrap();
        let pkg = Package::from_bytes(&bytes).unwrap();
        let xml = pkg.get_str("ppt/slides/slide1.xml").unwrap();
        assert!(
            xml.contains(r#"<p:transition spd="med">"#) && xml.contains(needle),
            "{tr:?}: {xml}"
        );
        // 箇条書きは 1 段落ずつ build され、pRg で個別に animate される。
        assert!(
            xml.contains(r#"<p:bldP spid="3" grpId="0" build="p"/>"#),
            "{xml}"
        );
        assert!(xml.contains(r#"<p:pRg st="0" end="0"/>"#), "{xml}");
        assert!(xml.contains(r#"<p:pRg st="1" end="1"/>"#), "{xml}");
        let back = Presentation::from_bytes(&bytes).unwrap();
        assert_eq!(back.slides[0].transition, tr);
        assert!(back.slides[0].animate, "animate flag survives");
    }
}

#[test]
fn hyperlinks_on_bullets_shapes_and_pictures_survive_a_round_trip() {
    let mut pres = Presentation::new();
    let mut slide = Slide::new("リンク");
    slide
        .bullets
        .push(poc_core::pptx::Bullet::new("資料はこちら").link("https://example.com/poccham"));
    slide.shapes.push(
        Shape::new(ShapeKind::RoundedRect, 10.0, 10.0, 40.0, 20.0)
            .text("詳細")
            .fill("2E75B6")
            .link("https://example.com/shape"),
    );
    slide.images.push(
        SlideImage::new(PNG.to_vec(), 60.0, 10.0, 20.0, 20.0).link("mailto:info@example.com"),
    );
    pres.add(slide);

    let bytes = pres.to_bytes().unwrap();
    let pkg = Package::from_bytes(&bytes).unwrap();
    let xml = pkg.get_str("ppt/slides/slide1.xml").unwrap();
    // 3 種類すべてが hlinkClick を持つ
    assert_eq!(xml.matches("<a:hlinkClick ").count(), 3, "{xml}");
    let rels = pkg.get_str("ppt/slides/_rels/slide1.xml.rels").unwrap();
    assert!(rels.contains(r#"TargetMode="External""#), "{rels}");
    assert!(rels.contains("https://example.com/poccham"), "{rels}");
    assert!(rels.contains("https://example.com/shape"), "{rels}");
    assert!(rels.contains("mailto:info@example.com"), "{rels}");
    // 同じ URL は 1 つのリレーションを共有する
    assert_eq!(rels.matches("/hyperlink").count(), 3, "{rels}");

    let back = Presentation::from_bytes(&bytes).unwrap();
    let s = &back.slides[0];
    assert_eq!(
        s.bullets[0].link.as_deref(),
        Some("https://example.com/poccham")
    );
    assert_eq!(
        s.shapes[0].link.as_deref(),
        Some("https://example.com/shape")
    );
    assert_eq!(s.images[0].link.as_deref(), Some("mailto:info@example.com"));
}

#[test]
fn shapes_and_pictures_survive_a_round_trip() {
    let back = Presentation::from_bytes(&sample().to_bytes().unwrap()).unwrap();
    let s = &back.slides[0];
    assert_eq!(s.shapes.len(), 1, "図形が読み戻せる: {:?}", s.shapes);
    assert_eq!(s.shapes[0].kind, ShapeKind::RoundedRect);
    assert_eq!(s.shapes[0].text, "図形");
    assert_eq!(s.shapes[0].fill.as_deref(), Some("2E75B6"));
    assert!(s.shapes[0].cx > 0 && s.shapes[0].cy > 0);
    assert_eq!(s.images.len(), 1, "画像が読み戻せる");
    assert_eq!(s.images[0].ext, "png");
    assert!(s.images[0].data.starts_with(b"\x89PNG"));
    assert_eq!(back.slides[0].transition, Transition::Fade);
    assert!(back.slides[0].animate);
    // 図形や画像のテキストが本文に混ざらない
    assert!(
        !s.bullets.iter().any(|b| b.text == "図形"),
        "shape text leaked into bullets: {:?}",
        s.bullets
    );
}
