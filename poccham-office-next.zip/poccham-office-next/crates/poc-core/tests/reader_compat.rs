//! Reader compatibility with files produced by *other* implementations.
//!
//! Real-world workbooks differ from ours in small but fatal ways:
//! `openpyxl` writes package-absolute relationship targets
//! (`Target="/xl/worksheets/sheet1.xml"`), inline strings
//! (`<c t="inlineStr"><is><t>…</t></is></c>`) and formulas with an empty
//! cached value (`<v></v>`). Each of these used to make the whole sheet read
//! back empty, so they are pinned here.

use poc_core::pkg::Package;
use poc_core::xlsx::{Cell, CellValue, Sheet, Workbook};

const WORKBOOK_XML: &str = r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheets><sheet xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
                 name="Sheet" sheetId="1" r:id="rId1"/></sheets>
</workbook>"#;

fn rels(target: &str) -> String {
    format!(
        r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"
                Target="{target}" Id="rId1"/>
</Relationships>"#
    )
}

fn sheet_with(sheet_data: &str) -> String {
    format!(
        r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetData>{sheet_data}</sheetData>
</worksheet>"#
    )
}

fn package(target: &str, sheet_data: &str) -> Vec<u8> {
    let mut pkg = Package::new();
    pkg.insert_str("xl/workbook.xml", WORKBOOK_XML);
    pkg.insert_str("xl/_rels/workbook.xml.rels", rels(target));
    pkg.insert_str("xl/worksheets/sheet1.xml", sheet_with(sheet_data));
    pkg.to_bytes().expect("package")
}

#[test]
fn reads_package_absolute_relationship_targets() {
    let bytes = package(
        "/xl/worksheets/sheet1.xml", // what openpyxl writes
        r#"<row r="1"><c r="A1" t="n"><v>42</v></c></row>"#,
    );
    let wb = Workbook::from_bytes(&bytes).expect("parse");
    assert_eq!(wb.sheets.len(), 1);
    assert_eq!(wb.sheets[0].get(0, 0).unwrap().as_number(), Some(42.0));
}

#[test]
fn reads_inline_strings() {
    let bytes = package(
        "worksheets/sheet1.xml",
        r#"<row r="1"><c r="A1" t="inlineStr"><is><t>こんにちは</t></is></c><c r="B1" t="n"><v>5</v></c></row>"#,
    );
    let wb = Workbook::from_bytes(&bytes).expect("parse");
    let a1 = wb.sheets[0].get(0, 0).expect("A1");
    assert_eq!(a1.as_text(), "こんにちは");
    assert_eq!(wb.sheets[0].get(0, 1).unwrap().as_number(), Some(5.0));
}

#[test]
fn reads_formulas_with_an_empty_cached_value() {
    let bytes = package(
        "worksheets/sheet1.xml",
        r#"<row r="1"><c r="A1" t="n"><v>1</v></c><c r="B1"><f>SUM(A1:A1)</f><v></v></c></row>"#,
    );
    let mut wb = Workbook::from_bytes(&bytes).expect("parse");
    let b1 = wb.sheets[0].get(0, 1).expect("B1");
    match &b1.value {
        CellValue::Formula { expr, .. } => assert_eq!(expr, "SUM(A1:A1)"),
        other => panic!("formula expected, got {other:?}"),
    }
    wb.recalculate();
    assert_eq!(wb.sheets[0].get(0, 1).unwrap().as_number(), Some(1.0));
}

#[test]
fn unsupported_functions_keep_their_formula_text() {
    // =VLOOKUP(...) is not implemented yet: it must survive a recalculation and
    // a save without being replaced by its error value.
    let mut wb = Workbook::new();
    wb.sheets[0].set(0, 0, Cell::text("x"));
    wb.sheets[0].set(0, 1, Cell::formula("VLOOKUP(A1,A1:B2,2,FALSE)", None));
    wb.recalculate();

    let bytes = wb.to_bytes().expect("write");
    let again = Workbook::from_bytes(&bytes).expect("read");
    match &again.sheets[0].get(0, 1).unwrap().value {
        CellValue::Formula { expr, .. } => assert_eq!(expr, "VLOOKUP(A1,A1:B2,2,FALSE)"),
        other => panic!("formula must be preserved, got {other:?}"),
    }
}

#[test]
fn round_trips_every_style_index() {
    use poc_core::xlsx::styles;
    let mut wb = Workbook::new();
    let mut sheet = Sheet::new("S");
    for (i, style) in [
        styles::NORMAL,
        styles::BOLD,
        styles::ITALIC,
        styles::BOLD_ITALIC,
        styles::NUMBER_2DP,
        styles::PERCENT,
        styles::DATE,
        styles::WRAP,
        styles::HEADER,
        styles::CURRENCY,
    ]
    .iter()
    .enumerate()
    {
        sheet.set(i as u32, 0, Cell::num(1234.5).styled(*style));
    }
    wb.sheets = vec![sheet];

    let again = Workbook::from_bytes(&wb.to_bytes().expect("write")).expect("read");
    for i in 0..10u32 {
        assert_eq!(
            again.sheets[0].get(i, 0).map(|c| c.style),
            Some(i as u16),
            "style index {i} must survive the round trip"
        );
    }
}
