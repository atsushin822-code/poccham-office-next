use poc_core::xlsx::*;
fn main() {
    let wb = Workbook::open("/tmp/t.xlsx").unwrap();
    println!(
        "sheets: {:?}",
        wb.sheets
            .iter()
            .map(|s| (s.name.clone(), s.rows.len()))
            .collect::<Vec<_>>()
    );
    for (i, row) in wb.sheets[0].rows.iter().enumerate() {
        println!(
            "row {i}: {:?}",
            row.iter().map(|c| c.as_text()).collect::<Vec<_>>()
        );
    }
}
