//! `poc` — the command line front end of Poccham Office Next.
//!
//! Every feature of the engine is reachable from here, which makes the CLI the
//! reference implementation for the desktop shell and a convenient way to
//! script conversions on servers.

use std::path::Path;
use std::process::ExitCode;
use std::time::Instant;

use poc_core::detect::{self, Format};
use poc_core::docx::{Document, ParaStyle, Paragraph, Run};
use poc_core::pptx::{Presentation, Slide};
use poc_core::xlsx::{self, Cell, CellValue, Sheet, Workbook};
use poc_vba::{parse_module, Engine, ExcelHost, Value};

const USAGE: &str = "\
Poccham Office Next — 超軽量オフィススイート (CLI)

使い方:
  poc <コマンド> [引数]

コマンド:
  new <出力ファイル>            サンプル文書を作成 (.xlsx/.docx/.pptx/.csv/.md)
  info <ファイル>               形式・構造・サイズを表示
  parts <ファイル>              パッケージ内のパーツ一覧
  convert <入力> <出力>         形式変換 (下記の対応表を参照)
  calc <ブック.xlsx>            数式を再計算して保存 (--out で別名保存)
  macro run <ブック> --module f.bas [--call Name] [--arg 値] [--out ファイル]
                                 VBA マクロを実行
  bench [--cells N] [--json]    書き込み/読み込み/計算のスループット測定
  version                       バージョン表示
  help                          このメッセージ

対応変換:
  .xlsx  -> .csv .ods .xlsx(再計算)
  .csv   -> .xlsx
  .md    -> .docx .pptx
  .docx  -> .txt .md
  .pptx  -> .md
  .ods   -> .csv .xlsx

例:
  poc new report.xlsx
  poc macro run report.xlsx --module report.bas --call BuildReport --out out.xlsx
  poc convert memo.md memo.docx
  poc bench --cells 200000
";

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    match run(&args) {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("エラー: {e}");
            ExitCode::FAILURE
        }
    }
}

fn run(args: &[String]) -> Result<(), Box<dyn std::error::Error>> {
    let Some(cmd) = args.first().map(|s| s.as_str()) else {
        println!("{USAGE}");
        return Ok(());
    };
    let rest = &args[1..];
    match cmd {
        "help" | "-h" | "--help" => println!("{USAGE}"),
        "version" | "-V" | "--version" => {
            println!(
                "poc {} (Poccham Office Next engine {})",
                env!("CARGO_PKG_VERSION"),
                poc_core::VERSION
            );
            println!(
                "ターゲット: {}-{}",
                std::env::consts::OS,
                std::env::consts::ARCH
            );
        }
        "new" => cmd_new(need(rest, 0, "出力ファイル")?)?,
        "info" => cmd_info(need(rest, 0, "ファイル")?)?,
        "parts" => cmd_parts(need(rest, 0, "ファイル")?)?,
        "convert" => cmd_convert(need(rest, 0, "入力")?, need(rest, 1, "出力")?)?,
        "calc" => cmd_calc(need(rest, 0, "ブック")?, opt(rest, "--out"))?,
        "macro" => cmd_macro(rest)?,
        "bench" => cmd_bench(rest)?,
        other => {
            return Err(format!("不明なコマンド: {other}\n\n{USAGE}").into());
        }
    }
    Ok(())
}

fn need<'a>(args: &'a [String], i: usize, what: &str) -> Result<&'a str, String> {
    args.get(i)
        .map(|s| s.as_str())
        .ok_or_else(|| format!("{what} を指定してください"))
}

fn opt<'a>(args: &'a [String], flag: &str) -> Option<&'a str> {
    args.iter()
        .position(|a| a == flag)
        .and_then(|i| args.get(i + 1))
        .map(|s| s.as_str())
}

// ---------------------------------------------------------------- new

fn cmd_new(path: &str) -> Result<(), Box<dyn std::error::Error>> {
    let fmt = Format::from_extension(path);
    let started = Instant::now();
    let bytes = match fmt {
        Format::Xlsx => sample_workbook()?.to_bytes()?,
        Format::Docx => sample_document().to_bytes()?,
        Format::Pptx => sample_presentation().to_bytes()?,
        Format::Ods => sample_workbook()?.to_ods_bytes()?,
        Format::Csv => vec![],
        Format::Markdown => vec![],
        other => {
            return Err(format!(
                "この形式のサンプルは作成できません: {} (対応: .xlsx .docx .pptx .ods .csv .md)",
                other.label()
            )
            .into())
        }
    };
    if matches!(fmt, Format::Csv | Format::Markdown) {
        let mut wb = sample_workbook()?;
        let text = if fmt == Format::Csv {
            wb.recalculate();
            wb.to_csv(0)?
        } else {
            sample_document().to_markdown()
        };
        std::fs::write(path, text)?;
    } else {
        std::fs::write(path, &bytes)?;
    }
    let size = std::fs::metadata(path)?.len();
    println!(
        "作成しました: {path} ({} / {:.1} KB / {:.2} ms)",
        fmt.label(),
        size as f64 / 1024.0,
        started.elapsed().as_secs_f64() * 1000.0
    );
    Ok(())
}

fn sample_workbook() -> Result<Workbook, Box<dyn std::error::Error>> {
    let mut wb = Workbook::new();
    wb.title = "四半期売上レポート".into();
    let s = &mut wb.sheets[0];
    s.name = "売上".into();
    s.push_row(vec![
        Cell::text("月").styled(xlsx::styles::HEADER),
        Cell::text("売上").styled(xlsx::styles::HEADER),
        Cell::text("前月比").styled(xlsx::styles::HEADER),
        Cell::text("達成").styled(xlsx::styles::HEADER),
    ]);
    let data = [
        ("1月", 1_820_000.0),
        ("2月", 1_940_000.0),
        ("3月", 2_310_000.0),
        ("4月", 2_050_000.0),
    ];
    for (i, (month, amount)) in data.iter().enumerate() {
        let row = (i + 2) as u32;
        s.push_row(vec![
            Cell::text(*month),
            Cell::num(*amount).styled(xlsx::styles::CURRENCY),
            if row == 2 {
                Cell::text("—")
            } else {
                Cell::formula(format!("B{row}/B{}-1", row - 1), None).styled(xlsx::styles::PERCENT)
            },
            Cell::formula(format!("IF(B{row}>=2000000,\"達成\",\"未達\")"), None),
        ]);
    }
    s.push_row(vec![
        Cell::text("合計").styled(xlsx::styles::BOLD),
        Cell::formula("SUM(B2:B5)", None).styled(xlsx::styles::BOLD),
        Cell::empty(),
        Cell::empty(),
    ]);
    s.col_widths = vec![Some(10.0), Some(16.0), Some(12.0), Some(10.0)];
    s.freeze = Some((1, 0));
    s.autofilter = Some("A1:D5".into());
    wb.recalculate();
    Ok(wb)
}

fn sample_document() -> Document {
    let mut doc = Document::new();
    doc.title = "Poccham Office Next 概要".into();
    doc.heading(1, "Poccham Office Next");
    doc.para(
        "Rust でゼロから実装した超軽量オフィススイートです。起動は 1 秒未満、メモリ使用量は 100 MB 未満を目標にしています。",
    );
    doc.heading(2, "特長");
    doc.bullet("ネイティブ実装 (Electron 不使用)");
    doc.bullet("OOXML / ODF / CSV を直接読み書き");
    doc.bullet("VBA 互換マクロエンジン内蔵");
    doc.heading(2, "対応形式");
    doc.table(vec![
        vec!["形式".into(), "読み込み".into(), "書き込み".into()],
        vec![".xlsx".into(), "○".into(), "○".into()],
        vec![".docx".into(), "○".into(), "○".into()],
        vec![".pptx".into(), "○".into(), "○".into()],
        vec![".ods".into(), "○".into(), "○ (書出)".into()],
    ]);
    doc.heading(2, "コード例");
    doc.push(poc_core::docx::Block::Paragraph(Paragraph::with_runs(
        vec![Run::new("let mut wb = Workbook::new();").mono()],
    )));
    doc.push(poc_core::docx::Block::Paragraph(Paragraph::styled(
        ParaStyle::Quote,
        "「速い・軽い・壊さない」を設計原則にしています。",
    )));
    doc
}

fn sample_presentation() -> Presentation {
    let mut p = Presentation::new();
    p.title = "Poccham Office Next".into();
    p.add(
        Slide::new("現状の課題")
            .bullet("既存スイートは起動に 5〜15 秒")
            .bullet("メモリ消費が 500 MB を超える")
            .bullet("VBA が動かないと業務が回らない"),
    );
    p.add(
        Slide::new("提案")
            .bullet("Rust ネイティブ実装で起動 1 秒未満")
            .sub_bullet("メモリは 1/5 以下")
            .bullet("OOXML を直接読み書きして互換性を維持")
            .bullet("VBA 互換エンジンを内蔵"),
    );
    p.add(
        Slide::new("ロードマップ")
            .bullet("2026 Q4: ベータ版")
            .bullet("2027: VBA 完全互換を段階拡張"),
    );
    p
}

// ---------------------------------------------------------------- info

fn cmd_info(path: &str) -> Result<(), Box<dyn std::error::Error>> {
    let started = Instant::now();
    let bytes = std::fs::read(path)?;
    let fmt = detect::sniff(&bytes);
    let fmt = if fmt == Format::Unknown {
        detect::from_path(path)
    } else {
        fmt
    };
    println!("ファイル : {path}");
    println!("形式     : {}", fmt.label());
    println!("サイズ   : {:.1} KB", bytes.len() as f64 / 1024.0);
    match fmt {
        Format::Xlsx | Format::Xlsm => {
            let wb = Workbook::from_bytes(&bytes)?;
            println!("シート   : {}", wb.sheets.len());
            for s in &wb.sheets {
                println!(
                    "  - {:<12} {:>6} 行 × {:>4} 列",
                    s.name,
                    s.row_count(),
                    s.col_count()
                );
            }
            println!("セル数   : {}", wb.total_cells());
            println!("タイトル : {}", wb.title);
        }
        Format::Docx => {
            let doc = Document::from_bytes(&bytes)?;
            let chars: usize = doc
                .blocks
                .iter()
                .filter_map(|b| match b {
                    poc_core::docx::Block::Paragraph(p) => Some(p.text().chars().count()),
                    _ => None,
                })
                .sum();
            println!("ブロック : {}", doc.blocks.len());
            println!("文字数   : {chars}");
            println!("タイトル : {}", doc.title);
        }
        Format::Pptx => {
            let pres = Presentation::from_bytes(&bytes)?;
            println!("スライド : {}", pres.slides.len());
            for (i, s) in pres.slides.iter().enumerate() {
                println!("  {}. {}", i + 1, s.title);
            }
        }
        Format::Ods | Format::Csv | Format::Tsv | Format::PlainText | Format::Markdown => {
            println!("(テキスト系のため詳細解析は省略)");
        }
        _ => println!("(未対応の形式です)"),
    }
    if fmt.is_ooxml() || fmt == Format::Ods {
        let pkg = poc_core::pkg::Package::from_bytes(&bytes)?;
        println!(
            "パーツ   : {} (展開後 {:.1} KB)",
            pkg.len(),
            pkg.payload_size() as f64 / 1024.0
        );
    }
    println!(
        "解析時間 : {:.2} ms",
        started.elapsed().as_secs_f64() * 1000.0
    );
    Ok(())
}

fn cmd_parts(path: &str) -> Result<(), Box<dyn std::error::Error>> {
    let pkg = poc_core::pkg::Package::open(path)?;
    for name in pkg.names() {
        let size = pkg.get(name).map(|b| b.len()).unwrap_or(0);
        println!("{size:>9}  {name}");
    }
    println!(
        "--- {} パーツ / 展開後 {} バイト",
        pkg.len(),
        pkg.payload_size()
    );
    Ok(())
}

// ---------------------------------------------------------------- convert

fn cmd_convert(input: &str, output: &str) -> Result<(), Box<dyn std::error::Error>> {
    let started = Instant::now();
    let in_fmt = detect::from_path(input);
    let out_fmt = Format::from_extension(output);
    let bytes = std::fs::read(input)?;
    let detected = detect::sniff(&bytes);
    let in_fmt = if detected == Format::Unknown {
        in_fmt
    } else {
        detected
    };
    let result: Vec<u8> = match (in_fmt, out_fmt) {
        (Format::Xlsx | Format::Xlsm, Format::Csv) => {
            let mut wb = Workbook::from_bytes(&bytes)?;
            wb.recalculate();
            wb.to_csv(0)?.into_bytes()
        }
        (Format::Xlsx | Format::Xlsm, Format::Ods) => {
            let mut wb = Workbook::from_bytes(&bytes)?;
            wb.recalculate();
            wb.to_ods_bytes()?
        }
        (Format::Xlsx | Format::Xlsm, Format::Xlsx) => {
            let mut wb = Workbook::from_bytes(&bytes)?;
            wb.recalculate();
            wb.to_bytes()?
        }
        (Format::Csv | Format::Tsv, Format::Xlsx) => {
            let text = String::from_utf8_lossy(&bytes).to_string();
            let delimiter = if in_fmt == Format::Tsv { '\t' } else { ',' };
            let mut wb = Workbook::new();
            let rows = poc_core::csv::parse_with_delimiter(&text, delimiter);
            let sheet = &mut wb.sheets[0];
            for row in rows {
                sheet.push_row(row.into_iter().map(|field| parse_field(&field)));
            }
            wb.recalculate();
            wb.to_bytes()?
        }
        (Format::Markdown, Format::Docx) => {
            let text = String::from_utf8_lossy(&bytes).to_string();
            markdown_to_docx(&text).to_bytes()?
        }
        (Format::Markdown, Format::Pptx) => {
            let text = String::from_utf8_lossy(&bytes).to_string();
            Presentation::from_markdown(&text).to_bytes()?
        }
        (Format::Docx, Format::PlainText) => Document::from_bytes(&bytes)?.to_text().into_bytes(),
        (Format::Docx, Format::Markdown) => {
            Document::from_bytes(&bytes)?.to_markdown().into_bytes()
        }
        (Format::Pptx, Format::Markdown) => {
            Presentation::from_bytes(&bytes)?.to_markdown().into_bytes()
        }
        (Format::Ods, Format::Csv) => Workbook::from_bytes(&bytes)?.to_csv(0)?.into_bytes(),
        (Format::Ods, Format::Xlsx) => {
            let mut wb = Workbook::from_bytes(&bytes)?;
            wb.recalculate();
            wb.to_bytes()?
        }
        (a, b) if a == b => bytes.clone(),
        (a, b) => {
            return Err(format!(
                "この変換は未対応です: {} -> {}\n(poc help の対応表を参照してください)",
                a.label(),
                b.label()
            )
            .into())
        }
    };
    std::fs::write(output, &result)?;
    println!(
        "変換しました: {input} ({}) -> {output} ({}) / {:.1} KB / {:.2} ms",
        in_fmt.label(),
        out_fmt.label(),
        result.len() as f64 / 1024.0,
        started.elapsed().as_secs_f64() * 1000.0
    );
    Ok(())
}

fn parse_field(field: &str) -> Cell {
    let t = field.trim();
    if t.is_empty() {
        return Cell::empty();
    }
    if let Ok(n) = t.parse::<f64>() {
        return Cell::num(n);
    }
    if t.eq_ignore_ascii_case("true") {
        return Cell::boolean(true);
    }
    if t.eq_ignore_ascii_case("false") {
        return Cell::boolean(false);
    }
    if let Some(expr) = t.strip_prefix('=') {
        return Cell::formula(expr.to_string(), None);
    }
    Cell::text(field)
}

fn markdown_to_docx(md: &str) -> Document {
    let mut doc = Document::new();
    let mut in_code = false;
    let mut table: Vec<Vec<String>> = Vec::new();
    for line in md.lines() {
        let line = line.trim_end();
        if line.trim_start().starts_with("```") {
            in_code = !in_code;
            continue;
        }
        if in_code {
            doc.push(poc_core::docx::Block::Paragraph(Paragraph::with_runs(
                vec![Run::new(line).mono()],
            )));
            continue;
        }
        if line.starts_with('|') {
            let cells: Vec<String> = line
                .trim_matches('|')
                .split('|')
                .map(|c| c.trim().to_string())
                .collect();
            if cells
                .iter()
                .all(|c| c.chars().all(|ch| ch == '-' || ch == ':'))
            {
                continue;
            }
            table.push(cells);
            continue;
        } else if !table.is_empty() {
            doc.table(std::mem::take(&mut table));
        }
        if let Some(title) = line.strip_prefix("# ") {
            doc.heading(1, title);
        } else if let Some(title) = line.strip_prefix("## ") {
            doc.heading(2, title);
        } else if let Some(title) = line.strip_prefix("### ") {
            doc.heading(3, title);
        } else if let Some(item) = line.trim_start().strip_prefix("- ") {
            doc.bullet(item);
        } else if let Some(quote) = line.strip_prefix("> ") {
            doc.push(poc_core::docx::Block::Paragraph(Paragraph::styled(
                ParaStyle::Quote,
                quote,
            )));
        } else if line.trim().is_empty() {
            continue;
        } else {
            doc.para(line);
        }
    }
    if !table.is_empty() {
        doc.table(table);
    }
    doc
}

// ---------------------------------------------------------------- calc

fn cmd_calc(path: &str, out: Option<&str>) -> Result<(), Box<dyn std::error::Error>> {
    let started = Instant::now();
    let mut wb = Workbook::open(path)?;
    let before = formula_count(&wb);
    let elapsed_read = started.elapsed();
    let t = Instant::now();
    wb.recalculate();
    let elapsed_calc = t.elapsed();
    let target = out.unwrap_or(path);
    let t = Instant::now();
    wb.save(target)?;
    println!(
        "再計算しました: 数式 {before} 個 / 読み込み {:.2} ms / 計算 {:.2} ms / 保存 {:.2} ms",
        elapsed_read.as_secs_f64() * 1000.0,
        elapsed_calc.as_secs_f64() * 1000.0,
        t.elapsed().as_secs_f64() * 1000.0
    );
    Ok(())
}

fn formula_count(wb: &Workbook) -> usize {
    wb.sheets
        .iter()
        .flat_map(|s| s.rows.iter())
        .flatten()
        .filter(|c| matches!(c.value, CellValue::Formula { .. }))
        .count()
}

// ---------------------------------------------------------------- macro

fn cmd_macro(args: &[String]) -> Result<(), Box<dyn std::error::Error>> {
    let Some(sub) = args.first().map(|s| s.as_str()) else {
        return Err("`poc macro run <ブック> --module <file.bas>` の形式で指定してください".into());
    };
    if sub != "run" {
        return Err(format!("不明なサブコマンド: macro {sub}").into());
    }
    let book = need(args, 1, "ブックファイル")?;
    let module_path =
        opt(args, "--module").ok_or("--module <マクロ定義ファイル (.bas)> を指定してください")?;
    let src = std::fs::read_to_string(module_path)?;
    let module = parse_module(
        &src,
        &Path::new(module_path)
            .file_stem()
            .unwrap()
            .to_string_lossy(),
    )?;
    let call = opt(args, "--call")
        .map(|s| s.to_string())
        .unwrap_or_else(|| {
            module
                .procs
                .iter()
                .find(|p| p.kind == poc_vba::ProcKind::Sub && p.is_public)
                .or_else(|| module.procs.first())
                .map(|p| p.name.clone())
                .unwrap_or_else(|| "Main".into())
        });
    let macro_args: Vec<Value> = args
        .iter()
        .enumerate()
        .filter(|(i, _)| i > &0 && args[i - 1] == "--arg")
        .map(|(_, a)| match a.parse::<f64>() {
            Ok(n) => Value::Number(n),
            Err(_) => Value::Str(a.clone()),
        })
        .collect();

    let started = Instant::now();
    let mut wb = Workbook::open(book)?;
    let outcome = {
        let mut host = ExcelHost::new(&mut wb);
        let mut engine = Engine::new(&module, &mut host);
        let out = engine.run(&call, macro_args)?;
        for line in &host.printed {
            println!("[Debug] {line}");
        }
        out
    };
    for message in &outcome.messages {
        println!("[MsgBox] {message}");
    }
    for warning in &outcome.warnings {
        println!("[警告] {warning}");
    }
    if !matches!(outcome.return_value, Value::Empty) {
        println!("[戻り値] {}", outcome.return_value.as_str());
    }
    let target = opt(args, "--out").unwrap_or(book);
    if target != book || formula_count(&wb) > 0 {
        wb.save(target)?;
    }
    println!(
        "マクロ実行完了: {call} / {} ステップ / {:.2} ms{}",
        outcome.steps,
        started.elapsed().as_secs_f64() * 1000.0,
        if target == book {
            ""
        } else {
            " / 保存済み"
        }
    );
    Ok(())
}

// ---------------------------------------------------------------- bench

fn cmd_bench(args: &[String]) -> Result<(), Box<dyn std::error::Error>> {
    let cells: usize = opt(args, "--cells")
        .and_then(|s| s.parse().ok())
        .unwrap_or(200_000);
    let json = args.iter().any(|a| a == "--json");
    let rows = (cells / 8).max(1);
    let cols = 8usize;

    // ---- build -------------------------------------------------------
    let t = Instant::now();
    let mut wb = Workbook::new();
    {
        let sheet: &mut Sheet = &mut wb.sheets[0];
        sheet.name = "Bench".into();
        for r in 0..rows {
            let mut row = Vec::with_capacity(cols);
            for c in 0..cols {
                row.push(if c == 0 {
                    Cell::text(format!("row {r}"))
                } else if c == cols - 1 {
                    Cell::formula(format!("SUM(B{}:G{})", r + 1, r + 1), None)
                } else {
                    Cell::num(((r * 7 + c * 13) % 1000) as f64)
                });
            }
            sheet.push_row(row);
        }
    }
    wb.recalculate();
    let build = t.elapsed();

    let filesize;
    let write;
    let bytes;
    {
        let t = Instant::now();
        bytes = wb.to_bytes()?;
        write = t.elapsed();
        filesize = bytes.len();
    }
    let read = {
        let t = Instant::now();
        let back = Workbook::from_bytes(&bytes)?;
        let elapsed = t.elapsed();
        assert_eq!(back.sheets[0].row_count() as usize, rows);
        elapsed
    };
    let calc = {
        let mut copy = Workbook::from_bytes(&bytes)?;
        let t = Instant::now();
        copy.recalculate();
        t.elapsed()
    };
    let csv = {
        let t = Instant::now();
        let text = wb.to_csv(0)?;
        let elapsed = t.elapsed();
        assert!(!text.is_empty());
        elapsed
    };

    let per = |d: std::time::Duration| d.as_secs_f64() * 1e9 / (rows * cols) as f64;
    if json {
        println!(
            "{{\"cells\":{},\"rows\":{},\"cols\":{},\"build_ms\":{:.2},\"write_ms\":{:.2},\"read_ms\":{:.2},\"calc_ms\":{:.2},\"csv_ms\":{:.2},\"file_kb\":{:.1},\"write_ns_per_cell\":{:.0},\"read_ns_per_cell\":{:.0}}}",
            rows * cols,
            rows,
            cols,
            build.as_secs_f64() * 1000.0,
            write.as_secs_f64() * 1000.0,
            read.as_secs_f64() * 1000.0,
            calc.as_secs_f64() * 1000.0,
            csv.as_secs_f64() * 1000.0,
            filesize as f64 / 1024.0,
            per(write),
            per(read)
        );
        return Ok(());
    }
    println!("Poccham Office Next ベンチマーク");
    println!(
        "  {} セル ({} 行 × {} 列, 数式 {} 個)",
        rows * cols,
        rows,
        cols,
        rows
    );
    println!("  ------------------------------------------------------------");
    println!(
        "  モデル構築        {:>8.2} ms",
        build.as_secs_f64() * 1000.0
    );
    println!(
        "  .xlsx 書き込み   {:>8.2} ms  ({:.0} ns/セル, {:.2} セル/ms)",
        write.as_secs_f64() * 1000.0,
        per(write),
        (rows * cols) as f64 / (write.as_secs_f64() * 1000.0)
    );
    println!(
        "  .xlsx 読み込み   {:>8.2} ms  ({:.0} ns/セル)",
        read.as_secs_f64() * 1000.0,
        per(read)
    );
    println!(
        "  数式再計算        {:>8.2} ms",
        calc.as_secs_f64() * 1000.0
    );
    println!("  CSV 出力          {:>8.2} ms", csv.as_secs_f64() * 1000.0);
    println!("  ファイルサイズ    {:>8.1} KB", filesize as f64 / 1024.0);
    println!("  ------------------------------------------------------------");
    println!("  参考: 同条件の openpyxl 比較は scripts/bench_compare.py を実行");
    Ok(())
}
