//! End-to-end tests for the UI ⇄ engine contract.
//!
//! These run on every platform in CI (no webview SDK needed) and are the safety
//! net for the JSON shapes the web UI sends and expects.

use std::path::PathBuf;

use serde_json::{json, Value};

use poc_bridge as bridge;

/// A unique scratch directory per test.
fn scratch(name: &str) -> PathBuf {
    let dir = std::env::temp_dir().join(format!("poc-bridge-{}-{}", name, std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).expect("scratch dir");
    dir
}

fn ui_workbook_payload() -> Value {
    json!({
        "kind": "workbook",
        "title": "テスト集計",
        "sheets": [{
            "name": "集計",
            "freeze": [1, 0],
            "filter": "A1:C5",
            "cells": [
                ["A1", "月", "", 8],
                ["B1", "売上", "", 8],
                ["C1", "達成", "", 8],
                ["A2", "1月", "", 0],
                ["B2", "1200000", "", 9],
                ["C2", "", "IF(B2>=1000000,\"達成\",\"未達\")", 0],
                ["A3", "2月", "", 0],
                ["B3", "900000", "", 9],
                ["C3", "", "IF(B3>=1000000,\"達成\",\"未達\")", 0],
                ["A4", "合計", "", 1],
                ["B4", "", "SUM(B2:B3)", 9],
                ["A5", "平均", "", 1],
                ["B5", "", "AVERAGE(B2:B3)", 9],
                ["C4", "", "COUNT(B2:B3)", 0]
            ]
        }]
    })
}

fn find_cell<'a>(doc: &'a Value, addr: &str) -> Option<&'a Value> {
    doc["sheets"][0]["cells"]
        .as_array()?
        .iter()
        .find(|c| c[0].as_str() == Some(addr))
}

#[test]
fn workbook_round_trip_preserves_values_formulas_and_layout() {
    let dir = scratch("roundtrip");
    let path = dir.join("book.xlsx");
    let path_s = path.to_string_lossy().to_string();

    let saved = bridge::save_workbook(path_s.clone(), ui_workbook_payload()).expect("save");
    // the save command returns the recalculated model
    let c2 = find_cell(&saved, "C2").expect("C2 present");
    assert_eq!(c2[2].as_str(), Some("IF(B2>=1000000,\"達成\",\"未達\")"));
    assert_eq!(
        c2[4].as_str(),
        Some("達成"),
        "cached string result must be kept"
    );

    let reopened = bridge::open_document(path_s).expect("open");
    assert_eq!(reopened["kind"], "workbook");
    assert_eq!(reopened["sheets"][0]["name"], "集計");

    let total = find_cell(&reopened, "B4").expect("B4");
    assert_eq!(total[2].as_str(), Some("SUM(B2:B3)"));
    assert_eq!(total[4].as_str(), Some("2100000"), "cached formula result");
    assert_eq!(total[3], json!(9), "currency style index survives");

    let avg = find_cell(&reopened, "B5").expect("B5");
    assert_eq!(avg[4].as_str(), Some("1050000"));

    let count = find_cell(&reopened, "C4").expect("C4");
    assert_eq!(count[4].as_str(), Some("2"));

    assert_eq!(
        reopened["sheets"][0]["freeze"],
        json!([1, 0]),
        "freeze pane survives"
    );
    assert_eq!(
        reopened["sheets"][0]["filter"], "A1:C5",
        "autofilter survives"
    );
    assert_eq!(
        find_cell(&reopened, "A1").unwrap()[3],
        json!(8),
        "header style index survives"
    );
    assert_eq!(
        find_cell(&reopened, "A4").unwrap()[3],
        json!(1),
        "bold style index survives"
    );

    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn workbook_saves_ods_and_csv() {
    let dir = scratch("formats");
    let ods = dir.join("book.ods").to_string_lossy().to_string();
    let csv = dir.join("book.csv").to_string_lossy().to_string();

    bridge::save_workbook(ods.clone(), ui_workbook_payload()).expect("ods save");
    bridge::save_workbook(csv.clone(), ui_workbook_payload()).expect("csv save");

    let bytes = std::fs::read(&ods).expect("ods bytes");
    assert!(bytes.starts_with(b"PK"), "ODS is a zip container");
    let reopened = bridge::open_document(ods).expect("ods reopen");
    assert_eq!(reopened["kind"], "workbook");
    assert_eq!(
        reopened["sheets"][0]["name"], "集計",
        "sheet name survives ODS"
    );
    let b2 = find_cell(&reopened, "B2").expect("B2 from ODS");
    assert_eq!(b2[1].as_str(), Some("1200000"), "numbers stay numbers");
    let b4 = find_cell(&reopened, "B4").expect("B4 from ODS");
    assert_eq!(
        b4[2].as_str(),
        Some("SUM(B2:B3)"),
        "OpenFormula is converted to A1"
    );
    assert_eq!(
        b4[4].as_str(),
        Some("2100000"),
        "cached result survives the ODS trip"
    );
    let c2 = find_cell(&reopened, "C2").expect("C2 from ODS");
    assert_eq!(
        c2[4].as_str(),
        Some("達成"),
        "string formula results survive"
    );

    let text = std::fs::read_to_string(&csv).expect("csv text");
    assert!(
        text.starts_with('\u{feff}') || text.contains("月"),
        "CSV has the header row"
    );
    assert!(text.contains("合計"));

    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn csv_is_detected_and_typed_on_open() {
    let dir = scratch("csv");
    let path = dir.join("sales.csv");
    std::fs::write(&path, "月,売上\n1月,1200\n2月,900\n").expect("write csv");

    let doc = bridge::open_document(path.to_string_lossy().to_string()).expect("open csv");
    assert_eq!(doc["kind"], "workbook");
    assert_eq!(doc["sheets"][0]["name"], "sales");
    let b2 = find_cell(&doc, "B2").expect("B2");
    assert_eq!(b2[1].as_str(), Some("1200"));

    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn recalculate_refreshes_every_formula() {
    let mut payload = ui_workbook_payload();
    // stale values in, correct values out
    payload["sheets"][0]["cells"][4][1] = json!("1"); // B2 = 1
    let out = bridge::recalculate(payload).expect("recalc");
    let b4 = find_cell(&out, "B4").expect("B4");
    assert_eq!(
        b4[4].as_str(),
        Some("900001"),
        "SUM recalculated from new inputs"
    );
    assert_eq!(
        b4[3],
        json!(9),
        "the number format is kept through a recalculation"
    );
}

#[test]
fn document_round_trip_keeps_structure() {
    let dir = scratch("docx");
    let path = dir.join("memo.docx").to_string_lossy().to_string();
    let payload = json!({
        "kind": "document",
        "title": "週次メモ",
        "blocks": [
            { "type": "p", "style": "Title", "align": "left", "text": "週次メモ" },
            { "type": "p", "style": "Heading1", "align": "left", "text": "第1章" },
            { "type": "p", "style": "Normal", "align": "justify", "text": "本文です。" },
            { "type": "p", "style": "Bullet", "align": "left", "text": "要点A" },
            { "type": "p", "style": "Numbered", "align": "left", "text": "手順1" },
            { "type": "p", "style": "Quote", "align": "left", "text": "引用" },
            { "type": "table", "rows": [["見出し", "値"], ["A", "1"]], "header": true },
            { "type": "pagebreak" }
        ]
    });

    bridge::save_document(path.clone(), payload).expect("save docx");
    let back = bridge::open_document(path).expect("open docx");
    assert_eq!(back["kind"], "document");
    let blocks = back["blocks"].as_array().expect("blocks");
    assert_eq!(blocks.len(), 8, "every block survives: {:?}", blocks);
    assert_eq!(blocks[0]["style"], "Title");
    assert_eq!(blocks[1]["style"], "Heading1");
    assert_eq!(blocks[2]["align"], "justify");
    assert_eq!(blocks[3]["style"], "Bullet");
    assert_eq!(blocks[4]["style"], "Numbered");
    assert_eq!(blocks[5]["style"], "Quote");
    assert_eq!(blocks[6]["type"], "table");
    assert_eq!(blocks[6]["rows"][1][0], "A");
    assert_eq!(blocks[7]["type"], "pagebreak");

    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn presentation_round_trip_keeps_bullet_levels() {
    let dir = scratch("pptx");
    let path = dir.join("deck.pptx").to_string_lossy().to_string();
    let payload = json!({
        "kind": "presentation",
        "title": "四半期レビュー",
        "slides": [
            { "title": "表紙", "bullets": [
                { "t": "結論", "level": 0 },
                { "t": "根拠", "level": 1 },
                { "t": "補足", "level": 2 }
            ]},
            { "title": "次アクション", "bullets": [{ "t": "着手", "level": 0 }] }
        ]
    });

    bridge::save_presentation(path.clone(), payload).expect("save pptx");
    let back = bridge::open_document(path).expect("open pptx");
    assert_eq!(back["kind"], "presentation");
    let slides = back["slides"].as_array().expect("slides");
    assert_eq!(slides.len(), 2);
    assert_eq!(slides[0]["title"], "表紙");
    assert_eq!(slides[0]["bullets"][2]["level"], 2);
    assert_eq!(slides[1]["bullets"][0]["t"], "着手");

    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn macro_runs_against_the_saved_workbook() {
    let dir = scratch("macro");
    let path = dir.join("macro.xlsx").to_string_lossy().to_string();
    bridge::save_workbook(path.clone(), ui_workbook_payload()).expect("save");

    let source = r#"
Sub DoubleSales()
    Dim r As Long
    Dim total As Double
    For r = 2 To 3
        Cells(r, 2).Value = Cells(r, 2).Value * 2
        total = total + Cells(r, 2).Value
    Next r
    Cells(6, 2).Value = total
End Sub
"#;

    let procs = bridge::macro_procedures(source.to_string()).expect("procs");
    assert_eq!(procs[0]["name"], "DoubleSales");
    assert_eq!(procs[0]["kind"], "Sub");

    let check = bridge::check_macro(source.to_string()).expect("check");
    assert_eq!(check["ok"], true);
    assert_eq!(check["procedures"][0], "DoubleSales");

    let out = bridge::run_macro(path.clone(), source.to_string(), "DoubleSales".to_string())
        .expect("run");
    assert!(out["elapsedMs"].as_f64().unwrap() >= 0.0);
    let b6 = find_cell(&out["document"], "B6").expect("B6 written by the macro");
    assert_eq!(
        b6[4].as_str(),
        Some("4200000"),
        "macro doubled 1,200,000 + 900,000"
    );

    let reopened = bridge::open_document(path).expect("reopen after macro");
    assert_eq!(
        find_cell(&reopened, "B2").unwrap()[4].as_str(),
        Some("2400000")
    );

    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn check_macro_reports_syntax_errors_instead_of_failing() {
    let out = bridge::check_macro("Sub Broken(\n  If Then\n".to_string())
        .expect("check returns ok=false");
    assert_eq!(out["ok"], false);
    assert!(out["error"].as_str().unwrap().len() > 3);
}

#[test]
fn app_info_reports_the_shell_version() {
    let info = bridge::app_info("9.9.9");
    assert_eq!(info["version"], "9.9.9");
    assert_eq!(info["name"], "Poccham Office Next");
    assert_eq!(info["vba"], true);
    assert!(info["engine"].as_str().unwrap().starts_with("0.9"));
}

#[test]
fn corrupt_files_return_an_error_instead_of_panicking() {
    let dir = scratch("corrupt");
    let path = dir.join("broken.xlsx");
    std::fs::write(&path, b"PK\x03\x04 truncated zip").expect("write");
    let err = bridge::open_document(path.to_string_lossy().to_string()).expect_err("must fail");
    assert!(err.len() > 3, "error message present: {err}");

    // a legacy binary format is recognised but not readable yet
    let legacy = dir.join("old.xls");
    std::fs::write(&legacy, [0xD0, 0xCF, 0x11, 0xE0]).expect("write");
    let err = bridge::open_document(legacy.to_string_lossy().to_string()).expect_err("must fail");
    assert!(
        err.contains("開けません") || err.contains("未対応"),
        "{err}"
    );

    let _ = std::fs::remove_dir_all(&dir);
}

// ------------------------------------------------- links everywhere (2026)

#[test]
fn cell_links_round_trip_through_xlsx() {
    let dir = scratch("celllinks");
    let path = dir.join("links.xlsx").to_string_lossy().to_string();
    let payload = json!({
        "kind": "workbook",
        "title": "リンク集",
        "sheets": [{
            "name": "Sheet1",
            "cells": [
                ["A1", "Poccham", "", 0, "Poccham", "https://example.com/poccham"],
                ["A2", "メール", "", 0, "メール", "mailto:info@example.com"]
            ]
        }]
    });
    bridge::save_workbook(path.clone(), payload).expect("save");
    let back = bridge::open_document(path).expect("open");
    let cells = back["sheets"][0]["cells"].as_array().expect("cells");
    let a1 = cells.iter().find(|c| c[0] == "A1").expect("A1 present");
    assert_eq!(a1[5], "https://example.com/poccham", "{a1}");
    let a2 = cells.iter().find(|c| c[0] == "A2").expect("A2 present");
    assert_eq!(a2[5], "mailto:info@example.com");
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn slide_links_round_trip_through_pptx() {
    let dir = scratch("slidelinks");
    let path = dir.join("links.pptx").to_string_lossy().to_string();
    let payload = json!({
        "kind": "presentation",
        "title": "リンク",
        "slides": [{
            "title": "一枚目",
            "bullets": [{ "t": "資料", "level": 0, "link": "https://example.com/doc" }],
            "shapes": [{
                "kind": "roundedRect", "xMm": 20.0, "yMm": 40.0, "wMm": 60.0, "hMm": 30.0,
                "text": "詳細", "fill": "2E75B6", "link": "https://example.com/shape"
            }],
            "transition": "wipe",
            "animate": true
        }]
    });
    bridge::save_presentation(path.clone(), payload).expect("save");
    let back = bridge::open_document(path).expect("open");
    let slide = &back["slides"][0];
    assert_eq!(slide["bullets"][0]["link"], "https://example.com/doc");
    assert_eq!(slide["shapes"][0]["link"], "https://example.com/shape");
    // 画面切り替えとアニメーションも往復する
    assert_eq!(slide["transition"], "wipe");
    assert_eq!(slide["animate"], true);
    let _ = std::fs::remove_dir_all(&dir);
}

/// シートに貼った画像 (ドラッグ＆ドロップで入れたもの) が .xlsx に残り、
/// 読み戻したときに位置と大きさが復元されること。
#[test]
fn sheet_images_survive_a_round_trip() {
    let dir = scratch("sheet-images");
    let path = dir.join("pictures.xlsx");
    // 1x1 の透明 PNG
    let png = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8AARAAE/wH/9gAAAABJRU5ErkJggg==";
    let payload = json!({
        "kind": "workbook",
        "title": "画像つき",
        "sheets": [{
            "name": "Sheet1",
            "freeze": null,
            "filter": null,
            "cells": [["A1", "画像", "", 0, "", ""]],
            "images": [{
                "name": "図.png",
                "col": 2,
                "row": 3,
                "wPx": 160,
                "hPx": 120,
                "ext": "png",
                "data": format!("data:image/png;base64,{png}")
            }]
        }]
    });
    let path_s = path.to_string_lossy().to_string();
    bridge::save_workbook(path_s.clone(), payload).expect("save");
    assert!(path.exists(), "保存先ができていない");

    let back = bridge::open_document(path_s.clone()).expect("open");
    let images = back["sheets"][0]["images"].as_array().expect("images 配列");
    assert_eq!(images.len(), 1, "画像が 1 枚戻ってこない");
    let img = &images[0];
    assert_eq!(img["name"], "図.png");
    assert_eq!(img["col"], 2);
    assert_eq!(img["row"], 3);
    assert_eq!(img["wPx"], 160);
    assert_eq!(img["hPx"], 120);
    let data = img["data"].as_str().unwrap_or("");
    assert!(
        data.starts_with("data:image/png;base64,"),
        "data URL でない: {data}"
    );

    // 画像が無いブックでは images は空配列 (UI 側が分岐しやすい)
    let plain = bridge::open_document(path_s).expect("open");
    assert!(plain["sheets"][0]["images"].as_array().is_some());
    let _ = std::fs::remove_dir_all(&dir);
}
