//! Bridge between the web UI and the document engine.
//!
//! The desktop shell (`crates/poc-ui/src-tauri`) is a thin Tauri wrapper around
//! this crate: everything that understands documents lives here, so the same
//! code is exercised by `cargo test` on every platform without a webview SDK.
//!
//! Every entry point speaks the JSON contract documented in `docs/ARCHITECTURE.md`:
//!
//! * document model — `{ kind, title, path, sheets|blocks|slides }`
//! * cell — `[address, raw, formula, styleIndex, cachedText]`
#![forbid(unsafe_code)]

use std::path::Path;

use serde_json::{json, Value};

use poc_core::detect::{self, Format};
use poc_core::docx::Picture;
use poc_core::docx::{
    Align, Block, DocComment, Document, Footnote, HeaderFooter, ParaStyle, Paragraph, Run, Table,
};
use poc_core::pptx::{Bullet, Presentation, Shape, ShapeKind, Slide};
use poc_core::xlsx::{self, Cell, CellLink, CellValue, Sheet, Workbook};
use poc_vba::{parse_module, Engine, ExcelHost, Value as VbaValue};

// ---------------------------------------------------------------- helpers

fn err<E: std::fmt::Display>(e: E) -> String {
    e.to_string()
}

/// Minimal base64 so pictures can travel through the JSON contract as
/// `data:` URIs (the UI shows them without touching the disk).
fn b64_encode(data: &[u8]) -> String {
    const TABLE: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::with_capacity(data.len().div_ceil(3) * 4);
    for chunk in data.chunks(3) {
        let b = [
            chunk[0],
            *chunk.get(1).unwrap_or(&0),
            *chunk.get(2).unwrap_or(&0),
        ];
        let n = ((b[0] as u32) << 16) | ((b[1] as u32) << 8) | b[2] as u32;
        out.push(TABLE[(n >> 18) as usize & 63] as char);
        out.push(TABLE[(n >> 12) as usize & 63] as char);
        out.push(if chunk.len() > 1 {
            TABLE[(n >> 6) as usize & 63] as char
        } else {
            '='
        });
        out.push(if chunk.len() > 2 {
            TABLE[n as usize & 63] as char
        } else {
            '='
        });
    }
    out
}

fn b64_decode(text: &str) -> Vec<u8> {
    let val = |c: u8| -> Option<u32> {
        Some(match c {
            b'A'..=b'Z' => c - b'A',
            b'a'..=b'z' => c - b'a' + 26,
            b'0'..=b'9' => c - b'0' + 52,
            b'+' => 62,
            b'/' => 63,
            _ => return None,
        } as u32)
    };
    let mut out = Vec::new();
    let mut acc = 0u32;
    let mut bits = 0u32;
    for byte in text.bytes() {
        let Some(v) = val(byte) else { continue };
        acc = (acc << 6) | v;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            out.push((acc >> bits) as u8);
        }
    }
    out
}

/// `data:image/png;base64,…` in, bytes + extension out.
fn split_data_uri(uri: &str) -> Option<(Vec<u8>, String)> {
    let rest = uri.strip_prefix("data:")?;
    let (meta, payload) = rest.split_once(',')?;
    let ext = if meta.contains("jpeg") || meta.contains("jpg") {
        "jpeg"
    } else {
        "png"
    };
    Some((b64_decode(payload), ext.to_string()))
}

fn workbook_to_json(wb: &Workbook, path: Option<&str>) -> Value {
    let sheets: Vec<Value> = wb
        .sheets
        .iter()
        .map(|sheet| {
            let mut cells: Vec<Value> = Vec::with_capacity(sheet.rows.len() * 8);
            for (r, row) in sheet.rows.iter().enumerate() {
                for (c, cell) in row.iter().enumerate() {
                    let addr = format!("{}{}", xlsx::col_letters(c as u32), r + 1);
                    let (raw, formula) = match &cell.value {
                        CellValue::Formula { expr, .. } => (String::new(), expr.clone()),
                        CellValue::Empty => continue,
                        other => (
                            Cell {
                                value: other.clone(),
                                style: cell.style,
                            }
                            .as_text(),
                            String::new(),
                        ),
                    };
                    if raw.is_empty() && formula.is_empty() {
                        continue;
                    }
                    let link = sheet
                        .links
                        .iter()
                        .find(|l| l.row == r as u32 && l.col == c as u32)
                        .map(|l| l.url.clone())
                        .unwrap_or_default();
                    cells.push(json!([
                        addr,
                        raw,
                        formula,
                        cell.style,
                        cell.as_text(),
                        link
                    ]));
                }
            }
            json!({
                "name": sheet.name,
                "freeze": sheet.freeze.map(|(r, c)| json!([r, c])).unwrap_or(Value::Null),
                "filter": sheet.autofilter,
                "widths": sheet.col_widths,
                "cells": cells,
                // セルに貼られた画像 (ドラッグ＆ドロップや Excel で作成したもの)
                "images": sheet.images.iter().map(|img| json!({
                    "name": img.name,
                    "col": img.col,
                    "row": img.row,
                    "wPx": img.width_px,
                    "hPx": img.height_px,
                    "ext": img.ext,
                    "data": format!("data:image/{};base64,{}", img.ext, b64_encode(&img.data)),
                })).collect::<Vec<_>>(),
            })
        })
        .collect();
    json!({
        "kind": "workbook",
        "title": wb.title,
        "path": path,
        "sheets": sheets,
    })
}

fn json_to_workbook(payload: &Value) -> Result<Workbook, String> {
    let mut wb = Workbook::new();
    wb.title = payload
        .get("title")
        .and_then(|v| v.as_str())
        .unwrap_or_default()
        .to_string();
    let Some(sheets) = payload.get("sheets").and_then(|v| v.as_array()) else {
        return Err("シート情報がありません".into());
    };
    wb.sheets.clear();
    for sheet in sheets {
        let mut s = Sheet::new(
            sheet
                .get("name")
                .and_then(|v| v.as_str())
                .unwrap_or("Sheet1"),
        );
        if let Some(images) = sheet.get("images").and_then(|v| v.as_array()) {
            for img in images {
                let data = img.get("data").and_then(|v| v.as_str()).unwrap_or("");
                let Some((bytes, ext)) = split_data_uri(data) else {
                    continue;
                };
                let num = |field: &str, default: u32| {
                    img.get(field)
                        .and_then(|v| v.as_u64())
                        .map(|v| v as u32)
                        .unwrap_or(default)
                };
                s.images.push(poc_core::xlsx::Image {
                    data: bytes,
                    ext: img
                        .get("ext")
                        .and_then(|v| v.as_str())
                        .filter(|v| !v.is_empty())
                        .unwrap_or(&ext)
                        .to_string(),
                    col: num("col", 0),
                    row: num("row", 0),
                    width_px: num("wPx", 120),
                    height_px: num("hPx", 90),
                    name: img
                        .get("name")
                        .and_then(|v| v.as_str())
                        .unwrap_or("画像")
                        .to_string(),
                });
            }
        }
        if let Some(f) = sheet.get("freeze").and_then(|v| v.as_array()) {
            let r = f.first().and_then(|v| v.as_u64()).unwrap_or(0) as u32;
            let c = f.get(1).and_then(|v| v.as_u64()).unwrap_or(0) as u32;
            if r > 0 || c > 0 {
                s.freeze = Some((r, c));
            }
        }
        s.autofilter = sheet
            .get("filter")
            .and_then(|v| v.as_str())
            .map(|v| v.to_string());
        if let Some(cells) = sheet.get("cells").and_then(|v| v.as_array()) {
            for cell in cells {
                let Some(arr) = cell.as_array() else { continue };
                let addr = arr.first().and_then(|v| v.as_str()).unwrap_or("");
                let raw = arr.get(1).and_then(|v| v.as_str()).unwrap_or("");
                let formula = arr.get(2).and_then(|v| v.as_str()).unwrap_or("");
                let style = arr.get(3).and_then(|v| v.as_u64()).unwrap_or(0) as u16;
                let Some((r, c)) = xlsx::parse_ref(addr) else {
                    continue;
                };
                let value = if !formula.trim().is_empty() {
                    Cell::formula(formula.trim().trim_start_matches('=').to_string(), None)
                } else {
                    let t = raw.trim();
                    if t.is_empty() {
                        Cell::empty()
                    } else if let Ok(n) = t.parse::<f64>() {
                        Cell::num(n)
                    } else if t.eq_ignore_ascii_case("true") {
                        Cell::boolean(true)
                    } else if t.eq_ignore_ascii_case("false") {
                        Cell::boolean(false)
                    } else {
                        Cell::text(raw)
                    }
                };
                s.set(r, c, value.styled(style));
                if let Some(link) = arr.get(5).and_then(|v| v.as_str()) {
                    if !link.trim().is_empty() {
                        s.links.push(CellLink::new(r, c, link.trim()));
                    }
                }
            }
        }
        wb.sheets.push(s);
    }
    if wb.sheets.is_empty() {
        wb.sheets.push(Sheet::new("Sheet1"));
    }
    Ok(wb)
}

fn document_to_json(doc: &Document, path: Option<&str>) -> Value {
    let blocks: Vec<Value> = doc
        .blocks
        .iter()
        .map(|b| match b {
            Block::Paragraph(p) => {
                let style = match &p.style {
                    ParaStyle::Normal => "Normal",
                    ParaStyle::Title => "Title",
                    ParaStyle::Heading(1) => "Heading1",
                    ParaStyle::Heading(2) => "Heading2",
                    ParaStyle::Heading(_) => "Heading3",
                    ParaStyle::Quote => "Quote",
                    ParaStyle::Code => "Code",
                    ParaStyle::Bullet => "Bullet",
                    ParaStyle::Numbered => "Numbered",
                };
                let align = match p.align {
                    Align::Left => "left",
                    Align::Center => "center",
                    Align::Right => "right",
                    Align::Justify => "justify",
                };
                let runs: Vec<Value> = p
                    .runs
                    .iter()
                    .map(|r| {
                        let mut o = serde_json::Map::new();
                        o.insert("t".into(), json!(r.text));
                        if r.bold {
                            o.insert("b".into(), json!(true));
                        }
                        if r.italic {
                            o.insert("i".into(), json!(true));
                        }
                        if r.underline {
                            o.insert("u".into(), json!(true));
                        }
                        if let Some(c) = &r.color {
                            o.insert("c".into(), json!(format!("#{}", c.to_ascii_lowercase())));
                        }
                        if let Some(sz) = r.size_pt {
                            o.insert("s".into(), json!(sz));
                        }
                        if let Some(f) = &r.font {
                            o.insert("f".into(), json!(f));
                        }
                        if let Some(l) = &r.link {
                            o.insert("link".into(), json!(l));
                        }
                        Value::Object(o)
                    })
                    .collect();
                // 段落の既定書式 (最初の run から推定)
                let first = p.runs.first();
                let mut fmt = serde_json::Map::new();
                if let Some(f) = first.and_then(|r| r.font.clone()) {
                    fmt.insert("font".into(), json!(f));
                }
                if let Some(sz) = first.and_then(|r| r.size_pt) {
                    fmt.insert("size".into(), json!(sz));
                }
                if let Some(c) = first.and_then(|r| r.color.clone()) {
                    fmt.insert(
                        "color".into(),
                        json!(format!("#{}", c.to_ascii_lowercase())),
                    );
                }
                if first.map(|r| r.bold).unwrap_or(false) {
                    fmt.insert("bold".into(), json!(true));
                }
                if first.map(|r| r.italic).unwrap_or(false) {
                    fmt.insert("italic".into(), json!(true));
                }
                json!({
                    "type": "p",
                    "style": style,
                    "align": align,
                    "text": p.text(),
                    "runs": runs,
                    "fmt": Value::Object(fmt),
                })
            }
            Block::Table(t) => json!({ "type": "table", "rows": t.rows, "header": t.header }),
            Block::PageBreak => json!({ "type": "pagebreak" }),
            Block::Image(pic) => json!({
                "type": "image",
                "name": pic.name,
                "ext": pic.ext,
                "widthMm": pic.width_mm,
                "heightMm": pic.height_mm,
                "data": format!("data:image/{};base64,{}", pic.ext, b64_encode(&pic.data)),
            }),
            Block::Toc => json!({ "type": "toc" }),
        })
        .collect();
    let header = doc
        .header
        .as_ref()
        .map(|h| h.text.clone())
        .unwrap_or_default();
    let footer = doc
        .footer
        .as_ref()
        .map(|f| f.text.clone())
        .unwrap_or_default();
    json!({
        "kind": "document",
        "title": doc.title,
        "path": path,
        "blocks": blocks,
        "header": header,
        "footer": footer,
        "footnotes": doc.footnotes.len(),
        "comments": doc.comments.iter().map(|c| json!({
            "author": c.author,
            "text": c.text,
        })).collect::<Vec<_>>(),
    })
}

fn shape_name(kind: ShapeKind) -> &'static str {
    match kind {
        ShapeKind::Rect => "rect",
        ShapeKind::RoundedRect => "roundedRect",
        ShapeKind::Ellipse => "ellipse",
        ShapeKind::Triangle => "triangle",
        ShapeKind::RightArrow => "rightArrow",
        ShapeKind::Line => "line",
        ShapeKind::Star5 => "star5",
        ShapeKind::Chevron => "chevron",
        ShapeKind::Diamond => "diamond",
    }
}

fn shape_from_name(name: &str) -> ShapeKind {
    match name {
        "roundedRect" => ShapeKind::RoundedRect,
        "ellipse" => ShapeKind::Ellipse,
        "triangle" => ShapeKind::Triangle,
        "rightArrow" => ShapeKind::RightArrow,
        "line" => ShapeKind::Line,
        "star5" => ShapeKind::Star5,
        "chevron" => ShapeKind::Chevron,
        "diamond" => ShapeKind::Diamond,
        _ => ShapeKind::Rect,
    }
}

fn transition_name(t: &poc_core::pptx::Transition) -> &'static str {
    use poc_core::pptx::Transition as T;
    match t {
        T::None => "none",
        T::Fade => "fade",
        T::Push => "push",
        T::Wipe => "wipe",
        T::Split => "split",
        T::Cover => "cover",
    }
}

fn transition_from_name(name: &str) -> poc_core::pptx::Transition {
    use poc_core::pptx::Transition as T;
    match name {
        "fade" => T::Fade,
        "push" => T::Push,
        "wipe" => T::Wipe,
        "split" => T::Split,
        "cover" => T::Cover,
        _ => T::None,
    }
}

fn json_to_document(payload: &Value) -> Document {
    let mut doc = Document::new();
    doc.title = payload
        .get("title")
        .and_then(|v| v.as_str())
        .unwrap_or_default()
        .to_string();
    // ヘッダー / フッター (Writer の「ヘッダーとフッター」)
    if let Some(h) = payload.get("header").and_then(|v| v.as_str()) {
        if !h.is_empty() {
            doc.header = Some(HeaderFooter::new(h));
        }
    }
    if let Some(f) = payload.get("footer").and_then(|v| v.as_str()) {
        if !f.is_empty() {
            doc.footer = Some(HeaderFooter::new(f));
        }
    }
    // 脚注の本文 (UI は件数だけを持つので、ダミー本文でページ下部に注記を残す)
    let footnotes = payload
        .get("footnotes")
        .and_then(|v| v.as_u64())
        .unwrap_or(0);
    for i in 0..footnotes {
        doc.footnotes
            .push(Footnote::new(format!("#{} の注記", i + 1)));
    }
    // コメント (校閲)
    if let Some(items) = payload.get("comments").and_then(|v| v.as_array()) {
        for c in items {
            doc.comments.push(DocComment::new(
                c.get("author")
                    .and_then(|v| v.as_str())
                    .unwrap_or("Poccham Office Next"),
                c.get("text").and_then(|v| v.as_str()).unwrap_or_default(),
            ));
        }
    }
    if let Some(blocks) = payload.get("blocks").and_then(|v| v.as_array()) {
        for b in blocks {
            let kind = b.get("type").and_then(|v| v.as_str()).unwrap_or("p");
            match kind {
                "table" => {
                    let mut rows: Vec<Vec<String>> = Vec::new();
                    if let Some(arr) = b.get("rows").and_then(|v| v.as_array()) {
                        for row in arr {
                            rows.push(
                                row.as_array()
                                    .map(|cells| {
                                        cells
                                            .iter()
                                            .map(|c| c.as_str().unwrap_or_default().to_string())
                                            .collect()
                                    })
                                    .unwrap_or_default(),
                            );
                        }
                    }
                    if !rows.is_empty() {
                        doc.push(Block::Table(Table {
                            rows,
                            header: b.get("header").and_then(|v| v.as_bool()).unwrap_or(true),
                        }));
                    }
                }
                "pagebreak" => {
                    doc.push(Block::PageBreak);
                }
                "toc" => {
                    doc.push(Block::Toc);
                }
                "image" => {
                    let data = b.get("data").and_then(|v| v.as_str()).unwrap_or("");
                    if let Some((bytes, ext)) = split_data_uri(data) {
                        doc.push(Block::Image(Picture {
                            data: bytes,
                            ext,
                            width_mm: b.get("widthMm").and_then(|v| v.as_f64()).unwrap_or(120.0)
                                as f32,
                            height_mm: b.get("heightMm").and_then(|v| v.as_f64()).unwrap_or(80.0)
                                as f32,
                            name: b
                                .get("name")
                                .and_then(|v| v.as_str())
                                .unwrap_or("画像")
                                .to_string(),
                        }));
                    }
                }
                _ => {
                    let text = b.get("text").and_then(|v| v.as_str()).unwrap_or("");
                    let style = match b.get("style").and_then(|v| v.as_str()).unwrap_or("Normal") {
                        "Title" => ParaStyle::Title,
                        "Heading1" => ParaStyle::Heading(1),
                        "Heading2" => ParaStyle::Heading(2),
                        "Heading3" => ParaStyle::Heading(3),
                        "Quote" => ParaStyle::Quote,
                        "Code" => ParaStyle::Code,
                        "Bullet" => ParaStyle::Bullet,
                        "Numbered" => ParaStyle::Numbered,
                        _ => ParaStyle::Normal,
                    };
                    // 段落の既定書式 (Writer のフォント/サイズ/色/強調)
                    let fmt = b.get("fmt");
                    let fmt_str = |k: &str| {
                        fmt.and_then(|f| f.get(k))
                            .and_then(|v| v.as_str())
                            .filter(|s| !s.is_empty())
                            .map(str::to_string)
                    };
                    let fmt_num = |k: &str| fmt.and_then(|f| f.get(k)).and_then(|v| v.as_f64());
                    let fmt_bool = |k: &str| {
                        fmt.and_then(|f| f.get(k))
                            .and_then(|v| v.as_bool())
                            .unwrap_or(false)
                    };
                    let font = fmt_str("font");
                    let size = fmt_num("size");
                    let color =
                        fmt_str("color").map(|c| c.trim_start_matches('#').to_ascii_uppercase());
                    let runs_val = b.get("runs").and_then(|v| v.as_array());
                    let runs: Vec<Run> = match runs_val {
                        Some(items) if !items.is_empty() => items
                            .iter()
                            .map(|r| {
                                let text = r.get("t").and_then(|v| v.as_str()).unwrap_or("");
                                let mut run = Run::new(text);
                                run.bold = r.get("b").and_then(|v| v.as_bool()).unwrap_or(false)
                                    || fmt_bool("bold");
                                run.italic = r.get("i").and_then(|v| v.as_bool()).unwrap_or(false)
                                    || fmt_bool("italic");
                                run.underline =
                                    r.get("u").and_then(|v| v.as_bool()).unwrap_or(false)
                                        || fmt_bool("underline");
                                if let Some(c) = r.get("c").and_then(|v| v.as_str()) {
                                    run.color =
                                        Some(c.trim_start_matches('#').to_ascii_uppercase());
                                } else {
                                    run.color = color.clone();
                                }
                                if let Some(sz) = r.get("s").and_then(|v| v.as_f64()) {
                                    run.size_pt = Some(sz as f32);
                                } else {
                                    run.size_pt = size.map(|s| s as f32);
                                }
                                if let Some(f) = r.get("f").and_then(|v| v.as_str()) {
                                    run.font = Some(f.to_string());
                                } else {
                                    run.font = font.clone();
                                }
                                if let Some(url) = r.get("link").and_then(|v| v.as_str()) {
                                    if !url.is_empty() {
                                        run.link = Some(url.to_string());
                                    }
                                }
                                run
                            })
                            .collect(),
                        _ => {
                            let mut run = Run::new(text);
                            run.bold = fmt_bool("bold");
                            run.italic = fmt_bool("italic");
                            run.underline = fmt_bool("underline");
                            run.color = color.clone();
                            run.size_pt = size.map(|s| s as f32);
                            run.font = font.clone();
                            vec![run]
                        }
                    };
                    let mut p = Paragraph {
                        style,
                        runs,
                        ..Default::default()
                    };
                    p.align = match b.get("align").and_then(|v| v.as_str()).unwrap_or("left") {
                        "center" => Align::Center,
                        "right" => Align::Right,
                        "justify" => Align::Justify,
                        _ => Align::Left,
                    };
                    doc.push(Block::Paragraph(p));
                }
            }
        }
    }
    doc
}

fn presentation_to_json(p: &Presentation, path: Option<&str>) -> Value {
    let slides: Vec<Value> = p
        .slides
        .iter()
        .map(|s| {
            json!({
                "title": s.title,
                "bullets": s.bullets.iter().map(|b| json!({ "t": b.text, "level": b.level, "link": b.link })).collect::<Vec<_>>(),
                "images": s.images.iter().map(|img| json!({
                    "name": img.name,
                    "xMm": img.x as f64 / 36_000.0,
                    "yMm": img.y as f64 / 36_000.0,
                    "wMm": img.cx as f64 / 36_000.0,
                    "hMm": img.cy as f64 / 36_000.0,
                    "data": format!("data:image/{};base64,{}", img.ext, b64_encode(&img.data)),
                    "link": img.link,
                })).collect::<Vec<_>>(),
                "shapes": s.shapes.iter().map(|sh| json!({
                    "kind": shape_name(sh.kind),
                    "xMm": sh.x as f64 / 36_000.0,
                    "yMm": sh.y as f64 / 36_000.0,
                    "wMm": sh.cx as f64 / 36_000.0,
                    "hMm": sh.cy as f64 / 36_000.0,
                    "text": sh.text,
                    "fill": sh.fill,
                    "line": sh.line,
                    "link": sh.link,
                })).collect::<Vec<_>>(),
                "notes": s.notes,
                "transition": transition_name(&s.transition),
                "animate": s.animate,
            })
        })
        .collect();
    json!({ "kind": "presentation", "title": p.title, "path": path, "slides": slides })
}

fn json_to_presentation(payload: &Value) -> Presentation {
    let mut pres = Presentation::new();
    pres.title = payload
        .get("title")
        .and_then(|v| v.as_str())
        .unwrap_or_default()
        .to_string();
    if let Some(slides) = payload.get("slides").and_then(|v| v.as_array()) {
        for s in slides {
            let mut slide = Slide::new(s.get("title").and_then(|v| v.as_str()).unwrap_or(""));
            if let Some(bullets) = s.get("bullets").and_then(|v| v.as_array()) {
                for b in bullets {
                    let level = b.get("level").and_then(|v| v.as_u64()).unwrap_or(0) as u8;
                    slide.bullets.push(Bullet {
                        text: b
                            .get("t")
                            .and_then(|v| v.as_str())
                            .unwrap_or("")
                            .to_string(),
                        level,
                        link: b
                            .get("link")
                            .and_then(|v| v.as_str())
                            .filter(|v| !v.is_empty())
                            .map(|v| v.to_string()),
                    });
                }
            }
            // Pictures, shapes, notes and the transition survive a round trip.
            if let Some(images) = s.get("images").and_then(|v| v.as_array()) {
                for img in images {
                    let data = img.get("data").and_then(|v| v.as_str()).unwrap_or("");
                    let Some((bytes, _ext)) = split_data_uri(data) else {
                        continue;
                    };
                    let mm = |field: &str, default: f32| {
                        img.get(field)
                            .and_then(|v| v.as_f64())
                            .map(|v| v as f32)
                            .unwrap_or(default)
                    };
                    let mut placed = poc_core::pptx::SlideImage::new(
                        bytes,
                        mm("xMm", 20.0),
                        mm("yMm", 40.0),
                        mm("wMm", 80.0),
                        mm("hMm", 60.0),
                    );
                    if let Some(ext) = img.get("ext").and_then(|v| v.as_str()) {
                        placed.ext = ext.to_string();
                    }
                    placed.name = img
                        .get("name")
                        .and_then(|v| v.as_str())
                        .unwrap_or("画像")
                        .to_string();
                    placed.link = img
                        .get("link")
                        .and_then(|v| v.as_str())
                        .filter(|v| !v.is_empty())
                        .map(|v| v.to_string());
                    slide.images.push(placed);
                }
            }
            if let Some(shapes) = s.get("shapes").and_then(|v| v.as_array()) {
                for sh in shapes {
                    let mut a_shape = Shape::new(
                        shape_from_name(sh.get("kind").and_then(|v| v.as_str()).unwrap_or("rect")),
                        sh.get("xMm").and_then(|v| v.as_f64()).unwrap_or(20.0) as f32,
                        sh.get("yMm").and_then(|v| v.as_f64()).unwrap_or(20.0) as f32,
                        sh.get("wMm").and_then(|v| v.as_f64()).unwrap_or(40.0) as f32,
                        sh.get("hMm").and_then(|v| v.as_f64()).unwrap_or(20.0) as f32,
                    );
                    a_shape.text = sh
                        .get("text")
                        .and_then(|v| v.as_str())
                        .unwrap_or("")
                        .to_string();
                    a_shape.fill = sh
                        .get("fill")
                        .and_then(|v| v.as_str())
                        .map(|v| v.to_string());
                    a_shape.line = sh
                        .get("line")
                        .and_then(|v| v.as_str())
                        .map(|v| v.to_string());
                    a_shape.link = sh
                        .get("link")
                        .and_then(|v| v.as_str())
                        .filter(|v| !v.is_empty())
                        .map(|v| v.to_string());
                    slide.shapes.push(a_shape);
                }
            }
            if let Some(notes) = s.get("notes").and_then(|v| v.as_str()) {
                slide.notes = notes.to_string();
            }
            if let Some(t) = s.get("transition").and_then(|v| v.as_str()) {
                slide.transition = transition_from_name(t);
            }
            slide.animate = s.get("animate").and_then(|v| v.as_bool()).unwrap_or(false);
            pres.add(slide);
        }
    }
    pres
}

/// Static information about the running product (shown in the about box).
pub fn app_info(ui_version: &str) -> Value {
    json!({
        "name": "Poccham Office Next",
        "version": ui_version,
        "engine": poc_core::VERSION,
        "os": std::env::consts::OS,
        "arch": std::env::consts::ARCH,
        "formulaEngine": true,
        "vba": true,
    })
}

pub fn open_document(path: String) -> Result<Value, String> {
    let bytes = std::fs::read(&path).map_err(err)?;
    let mut format = detect::sniff(&bytes);
    if format == Format::Unknown {
        format = detect::from_path(&path);
    }
    match format {
        Format::Xlsx | Format::Xlsm => {
            let mut wb = Workbook::from_bytes(&bytes).map_err(err)?;
            wb.recalculate();
            Ok(workbook_to_json(&wb, Some(&path)))
        }
        Format::Docx | Format::Docm => {
            let doc = Document::from_bytes(&bytes).map_err(err)?;
            Ok(document_to_json(&doc, Some(&path)))
        }
        Format::Pptx | Format::Pptm => {
            let pres = Presentation::from_bytes(&bytes).map_err(err)?;
            Ok(presentation_to_json(&pres, Some(&path)))
        }
        Format::Ods => {
            let mut wb = Workbook::from_bytes(&bytes).map_err(err)?;
            wb.recalculate();
            Ok(workbook_to_json(&wb, Some(&path)))
        }
        Format::Csv | Format::Tsv | Format::PlainText => {
            let text = String::from_utf8_lossy(&bytes).to_string();
            let delimiter = if format == Format::Tsv { '\t' } else { ',' };
            let mut wb = Workbook::new();
            for row in poc_core::csv::parse_with_delimiter(&text, delimiter) {
                wb.sheets[0].push_row(row.into_iter().map(|field| {
                    let t = field.trim();
                    match t.parse::<f64>() {
                        Ok(n) if !t.is_empty() => Cell::num(n),
                        _ if t.is_empty() => Cell::empty(),
                        _ => Cell::text(field),
                    }
                }));
            }
            wb.sheets[0].name = Path::new(&path)
                .file_stem()
                .map(|s| s.to_string_lossy().to_string())
                .unwrap_or_else(|| "Sheet1".into());
            Ok(workbook_to_json(&wb, Some(&path)))
        }
        Format::Unknown if bytes.starts_with(&[0xD0, 0xCF, 0x11, 0xE0]) => Err(
            "旧形式の Office ファイル（.xls / .doc / .ppt）は未対応です。\
             .xlsx / .docx / .pptx に変換してから開いてください。"
                .into(),
        ),
        Format::Odt | Format::Odp => Err(format!(
            "{} の読み込みは未対応です（ODS / OOXML は読み込めます）",
            format.label()
        )),
        other => Err(format!("この形式はまだ開けません: {}", other.label())),
    }
}

pub fn save_workbook(path: String, payload: Value) -> Result<Value, String> {
    let mut wb = json_to_workbook(&payload)?;
    wb.recalculate();
    if path.to_ascii_lowercase().ends_with(".ods") {
        std::fs::write(&path, wb.to_ods_bytes().map_err(err)?).map_err(err)?;
    } else if path.to_ascii_lowercase().ends_with(".csv") {
        std::fs::write(&path, wb.to_csv(0).map_err(err)?).map_err(err)?;
    } else {
        wb.save(&path).map_err(err)?;
    }
    Ok(workbook_to_json(&wb, Some(&path)))
}

pub fn save_document(path: String, payload: Value) -> Result<Value, String> {
    let doc = json_to_document(&payload);
    doc.save(&path).map_err(err)?;
    Ok(document_to_json(&doc, Some(&path)))
}

pub fn save_presentation(path: String, payload: Value) -> Result<Value, String> {
    let pres = json_to_presentation(&payload);
    pres.save(&path).map_err(err)?;
    Ok(presentation_to_json(&pres, Some(&path)))
}

pub fn recalculate(payload: Value) -> Result<Value, String> {
    let mut wb = json_to_workbook(&payload)?;
    wb.recalculate();
    Ok(workbook_to_json(
        &wb,
        payload.get("path").and_then(|v| v.as_str()),
    ))
}

pub fn run_macro(path: String, source: String, proc_name: String) -> Result<Value, String> {
    let module = parse_module(&source, "Module1").map_err(err)?;
    let mut wb = Workbook::open(&path).map_err(err)?;
    let started = std::time::Instant::now();
    let (outcome, printed) = {
        let mut host = ExcelHost::new(&mut wb);
        let mut engine = Engine::new(&module, &mut host);
        let outcome = engine
            .run(&proc_name, Vec::<VbaValue>::new())
            .map_err(err)?;
        (outcome, host.printed.clone())
    };
    wb.recalculate();
    wb.save(&path).map_err(err)?;
    Ok(json!({
        "messages": outcome.messages,
        "warnings": outcome.warnings,
        "printed": printed,
        "steps": outcome.steps,
        "returnValue": outcome.return_value.as_str(),
        "elapsedMs": started.elapsed().as_secs_f64() * 1000.0,
        "document": workbook_to_json(&wb, Some(&path)),
    }))
}

pub fn macro_procedures(source: String) -> Result<Value, String> {
    let module = parse_module(&source, "Module1").map_err(err)?;
    let procs: Vec<Value> = module
        .procs
        .iter()
        .map(|p| {
            json!({
                "name": p.name,
                "kind": if p.kind == poc_vba::ProcKind::Sub { "Sub" } else { "Function" },
                "params": p.params.len(),
            })
        })
        .collect();
    Ok(json!(procs))
}

pub fn check_macro(source: String) -> Result<Value, String> {
    match parse_module(&source, "Module1") {
        Ok(m) => Ok(json!({ "ok": true, "procedures": m.proc_names() })),
        Err(e) => Ok(json!({ "ok": false, "error": e.to_string() })),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Writer の UI ペイロード (runs / fmt / ヘッダー / コメント) が
    /// docx に保存され、読み戻しても壊れないこと。
    #[test]
    fn writer_payload_with_links_roundtrips_through_docx() {
        let payload = json!({
            "kind": "document",
            "title": "統合テスト文書",
            "header": "社外秘 / 2026 年度",
            "footer": "Poccham Office Next",
            "footnotes": 1,
            "comments": [{ "author": "山田", "text": "要確認" }],
            "blocks": [
                {
                    "type": "p", "style": "Heading1", "align": "center", "text": "見出し",
                    "fmt": { "font": "Yu Gothic", "size": 18, "color": "#1f3864", "bold": true }
                },
                {
                    "type": "p", "style": "Normal", "align": "left", "text": "公式サイトを見てください",
                    "fmt": { "font": "Noto Sans JP", "size": 11 },
                    "runs": [
                        { "t": "公式サイトは " },
                        { "t": "こちら", "link": "https://example.com/poccham", "u": true, "c": "#1a56db" },
                        { "t": " をご覧ください", "i": true }
                    ]
                }
            ]
        });

        let doc = json_to_document(&payload);
        assert_eq!(doc.title, "統合テスト文書");
        assert!(doc.header.is_some());
        assert_eq!(doc.comments.len(), 1);
        assert_eq!(doc.footnotes.len(), 1);

        let bytes = doc.to_bytes().unwrap();
        let back = Document::from_bytes(&bytes).unwrap();

        // ヘッダー / フッターが保持される
        assert_eq!(
            back.header.as_ref().map(|h| h.text.as_str()),
            Some("社外秘 / 2026 年度")
        );
        assert_eq!(
            back.footer.as_ref().map(|f| f.text.as_str()),
            Some("Poccham Office Next")
        );

        let paras: Vec<&Paragraph> = back
            .blocks
            .iter()
            .filter_map(|b| match b {
                Block::Paragraph(p) => Some(p),
                _ => None,
            })
            .collect();
        assert!(paras.len() >= 2);

        // 段落書式: フォント・サイズ・色・太字・中央揃え
        let head = &paras[0].runs[0];
        assert_eq!(head.font.as_deref(), Some("Yu Gothic"));
        assert_eq!(head.size_pt, Some(18.0));
        assert_eq!(head.color.as_deref(), Some("1F3864"));
        assert!(head.bold);
        assert_eq!(paras[0].align, Align::Center);

        // リンク付き run が復元される
        let linked: Vec<&Run> = paras[1].runs.iter().filter(|r| r.link.is_some()).collect();
        assert_eq!(linked.len(), 1);
        assert_eq!(linked[0].text, "こちら");
        assert_eq!(
            linked[0].link.as_deref(),
            Some("https://example.com/poccham")
        );
        assert_eq!(linked[0].color.as_deref(), Some("1A56DB"));

        // 斜体 run も保持される
        assert!(paras[1]
            .runs
            .iter()
            .any(|r| r.italic && r.text.contains("ご覧ください")));
    }

    /// UI で作った文書を保存 → 開く (document_to_json) でリンクが UI に戻る。
    #[test]
    fn links_survive_save_and_open() {
        let payload = json!({
            "kind": "document",
            "title": "リンク文書",
            "blocks": [{
                "type": "p", "style": "Normal", "align": "left", "text": "リンク",
                "runs": [
                    { "t": "Poccham", "link": "https://example.com/poccham" },
                    { "t": " の続き" }
                ]
            }]
        });
        let dir = std::env::temp_dir().join("poc-bridge-link-test");
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("links.docx");
        let saved = save_document(path.to_string_lossy().to_string(), payload).unwrap();
        assert!(path.exists());
        let opened = open_document(path.to_string_lossy().to_string()).unwrap();
        let text = serde_json::to_string(&opened).unwrap();
        assert!(
            text.contains("https://example.com/poccham"),
            "opened payload: {text}"
        );
        assert_eq!(saved["kind"], "document");
        let _ = std::fs::remove_file(&path);
    }
}
