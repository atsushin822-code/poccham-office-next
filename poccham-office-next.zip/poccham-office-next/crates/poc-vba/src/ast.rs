//! Syntax tree for the supported VBA subset.

use crate::value::Value;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UnOp {
    Neg,
    Not,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BinOp {
    Add,
    Sub,
    Mul,
    Div,
    IntDiv,
    Mod,
    Pow,
    Concat,
    Eq,
    Ne,
    Lt,
    Le,
    Gt,
    Ge,
    And,
    Or,
    Xor,
    Like,
}

#[derive(Debug, Clone, PartialEq)]
pub enum Expr {
    Lit(Value),
    Var(String),
    /// Member access inside a `With` block (`.Value`).
    WithMember(String),
    Member(Box<Expr>, String),
    /// `Callee(arg, ...)`
    Call(Box<Expr>, Vec<Expr>),
    Unary(UnOp, Box<Expr>),
    Binary(BinOp, Box<Expr>, Box<Expr>),
}

#[derive(Debug, Clone, PartialEq)]
pub enum Stmt {
    /// Several statements produced from one source statement
    /// (`Dim a As Long, b(0 To 3) As Double`).
    Seq(Vec<Stmt>),
    Dim(Vec<String>),
    /// `Dim a(0 To 9)` — a fixed-size array of `Empty`.
    DimArray {
        name: String,
        lower: i64,
        upper: i64,
    },
    Assign {
        target: Expr,
        value: Expr,
    },
    /// `Set obj = ...`
    SetAssign {
        target: Expr,
        value: Expr,
    },
    Expr(Expr),
    If {
        branches: Vec<(Expr, Vec<Stmt>)>,
        otherwise: Vec<Stmt>,
    },
    For {
        var: String,
        from: Expr,
        to: Expr,
        step: Option<Expr>,
        body: Vec<Stmt>,
    },
    ForEach {
        var: String,
        collection: Expr,
        body: Vec<Stmt>,
    },
    DoWhile {
        cond: Expr,
        /// `Do Until` instead of `Do While`.
        until: bool,
        body: Vec<Stmt>,
    },
    DoLoop {
        body: Vec<Stmt>,
        cond: Option<Expr>,
        until: bool,
        /// Condition is evaluated before the body (do-while form).
        pre: bool,
    },
    While {
        cond: Expr,
        body: Vec<Stmt>,
    },
    With {
        obj: Expr,
        body: Vec<Stmt>,
    },
    ExitFor,
    ExitDo,
    ExitProc,
    OnErrorResumeNext,
    OnErrorGoToZero,
    /// A bare `End` statement.
    Stop,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProcKind {
    Sub,
    Function,
}

#[derive(Debug, Clone, PartialEq)]
pub struct Param {
    pub name: String,
    pub optional: bool,
    pub default: Option<Expr>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct Proc {
    pub name: String,
    pub kind: ProcKind,
    pub params: Vec<Param>,
    pub body: Vec<Stmt>,
    pub is_public: bool,
}

#[derive(Debug, Clone, Default, PartialEq)]
pub struct Module {
    pub procs: Vec<Proc>,
    pub option_explicit: bool,
}

impl Module {
    pub fn proc(&self, name: &str) -> Option<&Proc> {
        self.procs
            .iter()
            .find(|p| p.name.eq_ignore_ascii_case(name))
    }

    pub fn proc_names(&self) -> Vec<&str> {
        self.procs.iter().map(|p| p.name.as_str()).collect()
    }
}
