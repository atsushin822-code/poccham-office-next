//! Tree-walking interpreter for the VBA subset.
//!
//! Design notes
//! ------------
//! * Procedures are borrowed from the module instead of cloned, so recursion
//!   and loops cost nothing in the AST layer.
//! * Every statement charges one step against `max_steps` (default 20 million)
//!   so a runaway macro can never hang the UI thread — it raises a normal
//!   VBA-style error instead.
//! * `On Error Resume Next` is supported: the failing statement is skipped and
//!   the message is appended to `warnings`, exactly like VBA's `Err` behaviour
//!   for the caller that only cares about continuing.

use std::collections::HashMap;

use crate::ast::*;
use crate::builtins;
use crate::value::Value;
use crate::VbaError;

/// The document the macro runs against.  `obj` handles are opaque strings
/// produced and consumed by the host (see `excel::ExcelHost`).
pub trait Host {
    fn get_property(&mut self, obj: &str, name: &str) -> Result<Value, String>;
    fn set_property(&mut self, obj: &str, name: &str, value: Value) -> Result<(), String>;
    fn invoke_object(&mut self, obj: &str, name: &str, args: Vec<Value>) -> Result<Value, String>;
    fn invoke_global(&mut self, name: &str, args: Vec<Value>) -> Result<Value, String>;
    /// `Debug.Print`
    fn print(&mut self, _text: &str) -> Result<(), String> {
        Ok(())
    }
    /// Items of an enumerable host object (`For Each` over sheets or cells).
    /// `None` means the object cannot be enumerated.
    fn enumerate(&mut self, _obj: &str) -> Option<Vec<Value>> {
        None
    }
}

/// A host that provides no objects; useful for pure calculation macros.
pub struct NullHost;

impl Host for NullHost {
    fn get_property(&mut self, obj: &str, _name: &str) -> Result<Value, String> {
        Err(format!(
            "このマクロ実行ではオブジェクトを利用できません ({obj})"
        ))
    }
    fn set_property(&mut self, obj: &str, _name: &str, _value: Value) -> Result<(), String> {
        Err(format!(
            "このマクロ実行ではオブジェクトを利用できません ({obj})"
        ))
    }
    fn invoke_object(&mut self, obj: &str, name: &str, _args: Vec<Value>) -> Result<Value, String> {
        Err(format!(
            "オブジェクトのメソッド {obj}.{name} は利用できません"
        ))
    }
    fn invoke_global(&mut self, name: &str, _args: Vec<Value>) -> Result<Value, String> {
        Err(format!("`{name}` はこの実行環境では利用できません"))
    }
}

enum Ctl {
    Error(VbaError),
    ExitFor,
    ExitDo,
    ExitProc,
    Stop,
}

type R<T> = Result<T, Ctl>;

impl From<VbaError> for Ctl {
    fn from(e: VbaError) -> Self {
        Ctl::Error(e)
    }
}

struct Frame {
    proc_name: String,
    kind: ProcKind,
    locals: HashMap<String, Value>,
    ret: Value,
}

/// What a macro run produced.
#[derive(Debug, Clone, Default)]
pub struct RunOutcome {
    pub return_value: Value,
    pub steps: u64,
    pub messages: Vec<String>,
    pub warnings: Vec<String>,
}

/// The interpreter.
pub struct Engine<'a> {
    module: &'a Module,
    host: &'a mut dyn Host,
    globals: HashMap<String, Value>,
    frames: Vec<Frame>,
    withs: Vec<Value>,
    steps: u64,
    max_steps: u64,
    max_depth: usize,
    pub messages: Vec<String>,
    pub warnings: Vec<String>,
    resume_next: bool,
    rng: u64,
}

impl<'a> Engine<'a> {
    pub fn new(module: &'a Module, host: &'a mut dyn Host) -> Self {
        Engine {
            module,
            host,
            globals: HashMap::new(),
            frames: Vec::new(),
            withs: Vec::new(),
            steps: 0,
            max_steps: 20_000_000,
            max_depth: 256,
            messages: Vec::new(),
            warnings: Vec::new(),
            resume_next: false,
            rng: 0x2545_F491_4F6C_DD1D,
        }
    }

    pub fn with_max_steps(mut self, steps: u64) -> Self {
        self.max_steps = steps;
        self
    }

    /// Run a procedure by name with the given arguments.
    pub fn run(&mut self, name: &str, args: Vec<Value>) -> Result<RunOutcome, VbaError> {
        let value = match self.call_proc(name, args) {
            Ok(v) => v,
            Err(Ctl::Error(e)) => return Err(e),
            Err(_) => Value::Empty,
        };
        Ok(RunOutcome {
            return_value: value,
            steps: self.steps,
            messages: self.messages.clone(),
            warnings: self.warnings.clone(),
        })
    }

    // ---- procedure calls ------------------------------------------------

    fn call_proc(&mut self, name: &str, args: Vec<Value>) -> R<Value> {
        // The module outlives the engine, so borrowing it does not borrow `self`.
        let module: &'a Module = self.module;
        let Some(proc) = module.proc(name) else {
            return Err(Ctl::Error(VbaError::runtime(
                format!("Sub または Function が定義されていません: {name}"),
                None,
            )));
        };
        if self.frames.len() >= self.max_depth {
            return Err(Ctl::Error(VbaError::runtime(
                "呼び出しのネストが深すぎます（無限再帰の可能性）",
                None,
            )));
        }
        let mut frame = Frame {
            proc_name: proc.name.to_ascii_lowercase(),
            kind: proc.kind,
            locals: HashMap::new(),
            ret: Value::Empty,
        };
        // Bind parameters.  Struct/reference semantics are simplified to
        // by-value + copy-back for ByRef arrays (documented limitation).
        for (i, param) in proc.params.iter().enumerate() {
            let value = match args.get(i) {
                Some(v) => v.clone(),
                None => match &param.default {
                    Some(expr) => {
                        // Defaults are constant expressions evaluated in the
                        // caller's frame before the frame is pushed.
                        self.eval(expr)?
                    }
                    None => {
                        if param.optional {
                            Value::Empty
                        } else {
                            return Err(Ctl::Error(VbaError::runtime(
                                format!("{} の引数 {} が指定されていません", proc.name, param.name),
                                None,
                            )));
                        }
                    }
                },
            };
            frame.locals.insert(param.name.to_ascii_lowercase(), value);
        }
        self.frames.push(frame);
        let result = self.exec_block(&proc.body);
        let frame = self.frames.pop().unwrap();
        match result {
            Ok(()) => Ok(frame.ret),
            Err(Ctl::ExitProc) => Ok(frame.ret),
            Err(Ctl::Error(e)) => Err(Ctl::Error(e)),
            // `Exit For`/`Exit Do` outside a loop terminates the procedure.
            Err(_) => Ok(frame.ret),
        }
    }

    // ---- statements -----------------------------------------------------

    fn exec_block(&mut self, body: &[Stmt]) -> R<()> {
        for stmt in body {
            match self.exec(stmt) {
                Ok(()) => {}
                Err(Ctl::Error(e)) if self.resume_next => {
                    self.warnings.push(e.to_string());
                }
                Err(other) => return Err(other),
            }
        }
        Ok(())
    }

    fn tick(&mut self) -> R<()> {
        self.steps += 1;
        if self.steps > self.max_steps {
            return Err(Ctl::Error(VbaError::runtime(
                format!(
                    "実行ステップ数の上限 ({}) に達しました。無限ループの可能性があります",
                    self.max_steps
                ),
                None,
            )));
        }
        Ok(())
    }

    fn exec(&mut self, stmt: &Stmt) -> R<()> {
        self.tick()?;
        match stmt {
            Stmt::Seq(list) => {
                for s in list {
                    self.exec(s)?;
                }
                Ok(())
            }
            Stmt::Dim(names) => {
                for name in names {
                    self.declare_local(name, Value::Empty);
                }
                Ok(())
            }
            Stmt::DimArray { name, lower, upper } => {
                let len = (upper - lower + 1).max(0) as usize;
                self.declare_local(
                    name,
                    Value::Array {
                        lower: *lower,
                        items: vec![Value::Empty; len],
                    },
                );
                Ok(())
            }
            Stmt::Assign { target, value } => {
                let v = self.eval(value)?;
                self.assign(target, v, false)
            }
            Stmt::SetAssign { target, value } => {
                let v = self.eval(value)?;
                self.assign(target, v, true)
            }
            Stmt::Expr(expr) => {
                // Statement-level call: the value is discarded.
                self.eval(expr).map(|_| ())
            }
            Stmt::If {
                branches,
                otherwise,
            } => {
                for (cond, body) in branches {
                    if self.eval(cond)?.as_bool() {
                        return self.exec_block(body);
                    }
                }
                self.exec_block(otherwise)
            }
            Stmt::For {
                var,
                from,
                to,
                step,
                body,
            } => {
                let start = self.eval(from)?.as_number().map_err(|m| self.rt(m))?;
                let end = self.eval(to)?.as_number().map_err(|m| self.rt(m))?;
                let step_v = match step {
                    Some(e) => self.eval(e)?.as_number().map_err(|m| self.rt(m))?,
                    None => 1.0,
                };
                if step_v == 0.0 {
                    return Err(self.rt("For の Step に 0 は指定できません".into()));
                }
                let mut i = start;
                loop {
                    if (step_v > 0.0 && i > end) || (step_v < 0.0 && i < end) {
                        break;
                    }
                    self.set_var(var, Value::Number(i));
                    match self.exec_block(body) {
                        Ok(()) => {}
                        Err(Ctl::ExitFor) => break,
                        Err(other) => return Err(other),
                    }
                    i += step_v;
                    self.tick()?;
                }
                Ok(())
            }
            Stmt::ForEach {
                var,
                collection,
                body,
            } => {
                let coll = self.eval(collection)?;
                let items = match coll {
                    Value::Array { items, .. } => items,
                    Value::Object(handle) => match self.host.enumerate(&handle) {
                        Some(items) => items,
                        None => {
                            return Err(self.rt(format!(
                                "For Each の対象にできないオブジェクトです ({handle:?})"
                            )))
                        }
                    },
                    other => {
                        return Err(self.rt(format!(
                            "For Each の対象は配列である必要があります ({} が渡されました)",
                            other.type_name()
                        )))
                    }
                };
                for item in items {
                    self.set_var(var, item);
                    match self.exec_block(body) {
                        Ok(()) => {}
                        Err(Ctl::ExitFor) => break,
                        Err(other) => return Err(other),
                    }
                    self.tick()?;
                }
                Ok(())
            }
            Stmt::DoWhile { cond, until, body } => {
                loop {
                    let c = self.eval(cond)?.as_bool();
                    if c == *until {
                        break;
                    }
                    match self.exec_block(body) {
                        Ok(()) => {}
                        Err(Ctl::ExitDo) => break,
                        Err(other) => return Err(other),
                    }
                    self.tick()?;
                }
                Ok(())
            }
            Stmt::DoLoop {
                body,
                cond,
                until,
                pre: _,
            } => {
                loop {
                    match self.exec_block(body) {
                        Ok(()) => {}
                        Err(Ctl::ExitDo) => break,
                        Err(other) => return Err(other),
                    }
                    if let Some(cond) = cond {
                        let c = self.eval(cond)?.as_bool();
                        if c == *until {
                            break;
                        }
                    } else {
                        // `Do ... Loop` without a condition would never end; treat
                        // it as an error rather than freezing the application.
                        return Err(
                            self.rt("条件のない `Do ... Loop` は無限ループになります".into())
                        );
                    }
                    self.tick()?;
                }
                Ok(())
            }
            Stmt::While { cond, body } => {
                while self.eval(cond)?.as_bool() {
                    match self.exec_block(body) {
                        Ok(()) => {}
                        Err(Ctl::ExitDo) => break,
                        Err(other) => return Err(other),
                    }
                    self.tick()?;
                }
                Ok(())
            }
            Stmt::With { obj, body } => {
                let v = self.eval(obj)?;
                self.withs.push(v);
                let result = self.exec_block(body);
                self.withs.pop();
                result
            }
            Stmt::ExitFor => Err(Ctl::ExitFor),
            Stmt::ExitDo => Err(Ctl::ExitDo),
            Stmt::ExitProc => Err(Ctl::ExitProc),
            Stmt::OnErrorResumeNext => {
                self.resume_next = true;
                Ok(())
            }
            Stmt::OnErrorGoToZero => {
                self.resume_next = false;
                Ok(())
            }
            Stmt::Stop => Err(Ctl::Stop),
        }
    }

    fn rt(&self, message: String) -> Ctl {
        Ctl::Error(VbaError::runtime(message, None))
    }

    // ---- variables ------------------------------------------------------

    fn declare_local(&mut self, name: &str, value: Value) {
        let key = name.to_ascii_lowercase();
        match self.frames.last_mut() {
            Some(frame) => {
                frame.locals.insert(key, value);
            }
            None => {
                self.globals.insert(key, value);
            }
        }
    }

    fn set_var(&mut self, name: &str, value: Value) {
        let key = name.to_ascii_lowercase();
        // Assigning to the procedure's own name sets the return value.
        if let Some(frame) = self.frames.last_mut() {
            if frame.proc_name == key && frame.kind == ProcKind::Function {
                frame.ret = value;
                return;
            }
            frame.locals.insert(key, value);
            return;
        }
        self.globals.insert(key, value);
    }

    fn lookup_var(&self, name: &str) -> Option<Value> {
        let key = name.to_ascii_lowercase();
        if let Some(frame) = self.frames.last() {
            if let Some(v) = frame.locals.get(&key) {
                return Some(v.clone());
            }
        }
        self.globals.get(&key).cloned()
    }

    fn get_var(&mut self, name: &str) -> R<Value> {
        if let Some(v) = self.lookup_var(name) {
            return Ok(v);
        }
        if let Some(c) = builtins::constant(name) {
            return Ok(c);
        }
        // Host-provided globals (`ActiveSheet`, `ThisWorkbook`, ...).
        if let Ok(v) = self.host.invoke_global(name, Vec::new()) {
            return Ok(v);
        }
        if self.module.option_explicit {
            return Err(self.rt(format!("変数が定義されていません: {name}")));
        }
        // Without Option Explicit, VBA creates an Empty variable on first use.
        Ok(Value::Empty)
    }

    // ---- assignment -----------------------------------------------------

    fn assign(&mut self, target: &Expr, value: Value, is_set: bool) -> R<()> {
        match target {
            Expr::Var(name) => {
                self.set_var(name, value);
                Ok(())
            }
            Expr::WithMember(name) => {
                let Some(obj) = self.withs.last().cloned() else {
                    return Err(self.rt("`With` の外では `.` で始まる代入はできません".into()));
                };
                let o = obj.as_object().map_err(|m| self.rt(m))?.to_string();
                self.host
                    .set_property(&o, name, value)
                    .map_err(|m| self.rt(m))
            }
            Expr::Member(obj_expr, name) => {
                let ov = self.eval(obj_expr)?;
                let o = ov.as_object().map_err(|m| self.rt(m))?.to_string();
                self.host
                    .set_property(&o, name, value)
                    .map_err(|m| self.rt(m))
            }
            Expr::Call(callee, args) => {
                // `arr(i) = v` or default-member assignment `Range("A1") = v`.
                if let Expr::Var(name) = &**callee {
                    if let Some(Value::Array { lower, items }) = self.lookup_var(name) {
                        let mut argsv = Vec::with_capacity(args.len());
                        for a in args {
                            argsv.push(self.eval(a)?);
                        }
                        let idx = argsv
                            .first()
                            .map(|v| v.as_number())
                            .transpose()
                            .map_err(|m| self.rt(m))?
                            .unwrap_or(0.0) as i64;
                        let pos = idx - lower;
                        if pos < 0 || pos as usize >= items.len() {
                            return Err(self.rt(format!(
                                "配列のインデックスが範囲外です: {idx} (LBound={lower}, UBound={})",
                                lower + items.len() as i64 - 1
                            )));
                        }
                        let mut items = items;
                        items[pos as usize] = value;
                        self.set_var(name, Value::Array { lower, items });
                        return Ok(());
                    }
                }
                let ov = self.eval(target)?;
                let o = ov.as_object().map_err(|m| self.rt(m))?.to_string();
                self.host
                    .set_property(&o, "Value", value)
                    .map_err(|m| self.rt(m))
            }
            other => Err(self.rt(format!("代入できない式です ({other:?})"))),
        }
        .map(|_| {
            let _ = is_set;
        })
    }

    // ---- expressions ----------------------------------------------------

    fn eval(&mut self, expr: &Expr) -> R<Value> {
        match expr {
            Expr::Lit(v) => Ok(v.clone()),
            Expr::Var(name) => self.get_var(name),
            Expr::WithMember(name) => {
                let Some(obj) = self.withs.last().cloned() else {
                    return Err(self.rt("`With` の外では `.` で始まる参照はできません".into()));
                };
                let o = obj.as_object().map_err(|m| self.rt(m))?.to_string();
                self.host.get_property(&o, name).map_err(|m| self.rt(m))
            }
            Expr::Member(obj_expr, name) => {
                let ov = self.eval(obj_expr)?;
                match &ov {
                    Value::Object(o) => {
                        let o = o.clone();
                        self.host.get_property(&o, name).map_err(|m| self.rt(m))
                    }
                    Value::Empty | Value::Null => {
                        Err(self.rt(format!("Nothing の参照を解決できません (`.{name}`)")))
                    }
                    other => Err(self.rt(format!(
                        "{} にはプロパティ `{name}` がありません",
                        other.type_name()
                    ))),
                }
            }
            Expr::Call(callee, args) => self.eval_call(callee, args),
            Expr::Unary(op, inner) => {
                let v = self.eval(inner)?;
                match op {
                    UnOp::Neg => Ok(Value::Number(-v.as_number().map_err(|m| self.rt(m))?)),
                    UnOp::Not => match v {
                        Value::Bool(b) => Ok(Value::Bool(!b)),
                        other => {
                            let n = other.as_number().map_err(|m| self.rt(m))?;
                            Ok(Value::Number(!(n as i64) as f64))
                        }
                    },
                }
            }
            Expr::Binary(op, lhs, rhs) => {
                // Short-circuit `And`/`Or` are not part of VBA, but evaluating
                // lazily here would change error semantics, so both sides are
                // always evaluated — matching VBA.
                let a = self.eval(lhs)?;
                let b = self.eval(rhs)?;
                self.binary(*op, a, b)
            }
        }
    }

    fn eval_call(&mut self, callee: &Expr, args: &[Expr]) -> R<Value> {
        // `Debug.Print x, y`
        if let Expr::Member(obj, name) = callee {
            if let Expr::Var(root) = &**obj {
                if root.eq_ignore_ascii_case("debug") && name.eq_ignore_ascii_case("print") {
                    let mut parts = Vec::new();
                    for a in args {
                        parts.push(self.eval(a)?.as_str());
                    }
                    let text = parts.join("");
                    self.host.print(&text).map_err(|m| self.rt(m))?;
                    return Ok(Value::Empty);
                }
            }
        }
        let mut argv = Vec::with_capacity(args.len());
        for a in args {
            argv.push(self.eval(a)?);
        }
        match callee {
            Expr::Var(name) => {
                // Array indexing shadows everything else.
                if let Some(Value::Array { lower, items }) = self.lookup_var(name) {
                    let idx = argv
                        .first()
                        .map(|v| v.as_number())
                        .transpose()
                        .map_err(|m| self.rt(m))?
                        .unwrap_or(0.0) as i64;
                    let pos = idx - lower;
                    if pos < 0 || pos as usize >= items.len() {
                        return Err(self.rt(format!(
                            "配列のインデックスが範囲外です: {idx} (LBound={lower}, UBound={})",
                            lower + items.len() as i64 - 1
                        )));
                    }
                    return Ok(items[pos as usize].clone());
                }
                if self.module.proc(name).is_some() {
                    return self.call_proc(name, argv);
                }
                if name.eq_ignore_ascii_case("msgbox") {
                    let text = argv.first().map(|v| v.as_str()).unwrap_or_default();
                    self.messages.push(text);
                    return Ok(Value::Number(1.0));
                }
                if name.eq_ignore_ascii_case("inputbox") {
                    return Ok(Value::Str(String::new()));
                }
                if let Some(result) = builtins::call(name, &argv, &mut self.rng) {
                    return result.map_err(|m| self.rt(m));
                }
                self.host.invoke_global(name, argv).map_err(|m| self.rt(m))
            }
            Expr::Member(obj, name) => {
                // `ThisWorkbook.Sheets("x")` style is resolved by the host.
                let ov = self.eval(obj)?;
                let o = ov.as_object().map_err(|m| self.rt(m))?.to_string();
                let _ = name;
                let member = match callee {
                    Expr::Member(_, n) => n.clone(),
                    _ => unreachable!(),
                };
                self.host
                    .invoke_object(&o, &member, argv)
                    .map_err(|m| self.rt(m))
            }
            Expr::WithMember(name) => {
                let Some(obj) = self.withs.last().cloned() else {
                    return Err(self.rt("`With` の外では `.` で始まる呼び出しはできません".into()));
                };
                let o = obj.as_object().map_err(|m| self.rt(m))?.to_string();
                let name = name.clone();
                self.host
                    .invoke_object(&o, &name, argv)
                    .map_err(|m| self.rt(m))
            }
            other => Err(self.rt(format!("呼び出せない式です ({other:?})"))),
        }
    }

    fn binary(&mut self, op: BinOp, a: Value, b: Value) -> R<Value> {
        use BinOp::*;
        match op {
            Concat => Ok(Value::Str(format!("{}{}", a.as_str(), b.as_str()))),
            Add | Sub | Mul | Div | IntDiv | Mod | Pow => {
                // VB's `+` concatenates when both operands are strings that do
                // not look numeric.
                if op == Add {
                    if let (Value::Str(sa), Value::Str(sb)) = (&a, &b) {
                        if sa.trim().parse::<f64>().is_err() || sb.trim().parse::<f64>().is_err() {
                            return Ok(Value::Str(format!("{sa}{sb}")));
                        }
                    }
                }
                let x = a.as_number().map_err(|m| self.rt(m))?;
                let y = b.as_number().map_err(|m| self.rt(m))?;
                let v = match op {
                    Add => x + y,
                    Sub => x - y,
                    Mul => x * y,
                    Div => {
                        if y == 0.0 {
                            return Err(self.rt("0 で除算しました".into()));
                        }
                        x / y
                    }
                    IntDiv => {
                        if y == 0.0 {
                            return Err(self.rt("0 で除算しました".into()));
                        }
                        ((x / y) as i64) as f64
                    }
                    Mod => {
                        if y == 0.0 {
                            return Err(self.rt("0 で除算しました".into()));
                        }
                        (x as i64 % y as i64) as f64
                    }
                    Pow => x.powf(y),
                    _ => unreachable!(),
                };
                Ok(Value::Number(v))
            }
            And | Or | Xor => {
                let lb = a.as_bool();
                let rb = b.as_bool();
                Ok(Value::Bool(match op {
                    And => lb && rb,
                    Or => lb || rb,
                    _ => lb ^ rb,
                }))
            }
            Eq | Ne | Lt | Le | Gt | Ge => {
                let ord = match (&a, &b) {
                    (Value::Str(sa), Value::Str(sb)) => sa.cmp(sb),
                    (Value::Empty, Value::Empty) => std::cmp::Ordering::Equal,
                    _ => {
                        let x = a.as_number().map_err(|m| self.rt(m))?;
                        let y = b.as_number().map_err(|m| self.rt(m))?;
                        x.partial_cmp(&y).unwrap_or(std::cmp::Ordering::Equal)
                    }
                };
                let ok = match op {
                    Eq => ord == std::cmp::Ordering::Equal,
                    Ne => ord != std::cmp::Ordering::Equal,
                    Lt => ord == std::cmp::Ordering::Less,
                    Le => ord != std::cmp::Ordering::Greater,
                    Gt => ord == std::cmp::Ordering::Greater,
                    Ge => ord != std::cmp::Ordering::Less,
                    _ => unreachable!(),
                };
                Ok(Value::Bool(ok))
            }
            Like => Ok(Value::Bool(like_match(&a.as_str(), &b.as_str()))),
        }
    }
}

/// VBA `Like` operator: `*`, `?`, `#`, `[abc]`, `[!abc]`.
fn like_match(text: &str, pattern: &str) -> bool {
    fn helper(t: &[char], p: &[char]) -> bool {
        if p.is_empty() {
            return t.is_empty();
        }
        match p[0] {
            '*' => {
                for i in 0..=t.len() {
                    if helper(&t[i..], &p[1..]) {
                        return true;
                    }
                }
                false
            }
            '?' => !t.is_empty() && helper(&t[1..], &p[1..]),
            '#' => !t.is_empty() && t[0].is_ascii_digit() && helper(&t[1..], &p[1..]),
            '[' => {
                let Some(close) = p.iter().position(|c| *c == ']') else {
                    return false;
                };
                if t.is_empty() {
                    return false;
                }
                let set = &p[1..close];
                let negate = set.first() == Some(&'!');
                let set = if negate { &set[1..] } else { set };
                let mut matched = false;
                let mut i = 0;
                while i < set.len() {
                    if i + 2 < set.len() && set[i + 1] == '-' {
                        if t[0] >= set[i] && t[0] <= set[i + 2] {
                            matched = true;
                        }
                        i += 3;
                    } else {
                        if t[0] == set[i] {
                            matched = true;
                        }
                        i += 1;
                    }
                }
                if matched == negate {
                    return false;
                }
                helper(&t[1..], &p[close + 1..])
            }
            c => !t.is_empty() && t[0] == c && helper(&t[1..], &p[1..]),
        }
    }
    let t: Vec<char> = text.chars().collect();
    let p: Vec<char> = pattern.chars().collect();
    helper(&t, &p)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parser::parse_module;

    fn run_with(src: &str, proc_name: &str, args: Vec<Value>) -> RunOutcome {
        let module = parse_module(src, "Test").expect("parse");
        let mut host = NullHost;
        let mut engine = Engine::new(&module, &mut host);
        engine.run(proc_name, args).expect("run")
    }

    fn run(src: &str, proc_name: &str) -> RunOutcome {
        run_with(src, proc_name, Vec::new())
    }

    #[test]
    fn arithmetic_and_messages() {
        let out = run(
            "Sub Main()\n  Dim a As Long\n  a = 2 + 3 * 4\n  MsgBox \"answer=\" & a\nEnd Sub",
            "Main",
        );
        assert_eq!(out.messages, vec!["answer=14"]);
    }

    #[test]
    fn loops_and_accumulation() {
        let out = run_with(
            "Function Total(n)\n  Dim i As Long, t As Double\n  For i = 1 To n\n    t = t + i\n  Next i\n  Total = t\nEnd Function",
            "Total",
            vec![Value::Number(5.0)],
        );
        assert_eq!(out.return_value.as_str(), "15");
    }

    #[test]
    fn missing_required_argument_is_reported() {
        let module = parse_module("Function F(n)\n F = n\nEnd Function", "T").unwrap();
        let mut host = NullHost;
        let mut engine = Engine::new(&module, &mut host);
        let err = engine.run("F", Vec::new()).unwrap_err();
        assert!(err.to_string().contains("引数"), "{err}");
    }

    #[test]
    fn nested_if_and_like() {
        let out = run(
            "Sub Main()\n Dim s$\n s = \"Poccham\"\n If s Like \"Poc*\" Then\n  MsgBox \"match\"\n Else\n  MsgBox \"no\"\n End If\nEnd Sub",
            "Main",
        );
        assert_eq!(out.messages, vec!["match"]);
    }

    #[test]
    fn do_loops_and_exit() {
        let out = run(
            "Function F()\n Dim i, t\n i = 0\n Do While True\n  i = i + 1\n  If i > 5 Then Exit Do\n  t = t + i\n Loop\n F = t\nEnd Function",
            "F",
        );
        assert_eq!(out.return_value.as_str(), "15");
    }

    #[test]
    fn arrays_and_for_each() {
        let out = run(
            "Function F()\n Dim a(0 To 2)\n a(0) = 10\n a(1) = 20\n a(2) = 30\n Dim v, t\n For Each v In a\n  t = t + v\n Next v\n F = t\nEnd Function",
            "F",
        );
        assert_eq!(out.return_value.as_str(), "60");
    }

    #[test]
    fn strings_and_builtins() {
        let out = run(
            "Function F()\n Dim s$\n s = UCase(Left(\"hello\", 2)) & Mid(\"world\", 2, 2)\n F = s & Len(s)\nEnd Function",
            "F",
        );
        assert_eq!(out.return_value.as_str(), "HEor4");
    }

    #[test]
    fn step_limit_stops_infinite_loop() {
        let module = parse_module(
            "Sub Loop()\n Do While True\n  x = x + 1\n Loop\nEnd Sub",
            "T",
        )
        .unwrap();
        let mut host = NullHost;
        let mut engine = Engine::new(&module, &mut host).with_max_steps(1_000);
        let err = engine.run("Loop", Vec::new()).unwrap_err();
        assert!(err.to_string().contains("上限"), "{err}");
    }

    #[test]
    fn on_error_resume_next_records_warnings() {
        let out = run(
            "Sub Main()\n On Error Resume Next\n x = 1 / 0\n MsgBox \"continued\"\nEnd Sub",
            "Main",
        );
        assert_eq!(out.messages, vec!["continued"]);
        assert_eq!(out.warnings.len(), 1);
    }

    #[test]
    fn boolean_arithmetic_uses_true_is_minus_one() {
        let out = run("Function F()\n F = (1 = 1) + 0\nEnd Function", "F");
        assert_eq!(out.return_value.as_str(), "-1");
    }
}
