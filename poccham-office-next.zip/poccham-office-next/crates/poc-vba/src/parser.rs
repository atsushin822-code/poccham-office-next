//! Recursive-descent parser for the supported VBA subset.
//!
//! Operator precedence follows the VBA specification:
//! `^` > unary `-` > `* /` > `\` > `Mod` > `+ -` > `&` > comparisons > `Not`
//! > `And` > `Or`.

use crate::ast::*;
use crate::lexer::{tokenize, Tok, Token};
use crate::value::Value;
use crate::VbaError;

pub fn parse_module(src: &str, name: &str) -> Result<Module, VbaError> {
    let toks = tokenize(src)?;
    let mut p = Parser {
        toks,
        pos: 0,
        module_name: name.to_string(),
    };
    p.parse_module()
}

struct Parser {
    toks: Vec<Token>,
    pos: usize,
    module_name: String,
}

const PREC_OR: u8 = 1;
const PREC_AND: u8 = 2;
const PREC_CMP: u8 = 3;
const PREC_CONCAT: u8 = 4;
const PREC_ADD: u8 = 5;
const PREC_MOD: u8 = 6;
const PREC_IDIV: u8 = 7;
const PREC_MUL: u8 = 8;
const PREC_POW: u8 = 9;

impl Parser {
    fn peek(&self) -> &Tok {
        &self.toks[self.pos.min(self.toks.len() - 1)].tok
    }
    fn peek_at(&self, n: usize) -> &Tok {
        &self.toks[(self.pos + n).min(self.toks.len() - 1)].tok
    }
    fn line(&self) -> u32 {
        self.toks[self.pos.min(self.toks.len() - 1)].line
    }
    fn bump(&mut self) -> Tok {
        let t = self.toks[self.pos.min(self.toks.len() - 1)].tok.clone();
        if self.pos < self.toks.len() - 1 {
            self.pos += 1;
        }
        t
    }
    fn at_eof(&self) -> bool {
        matches!(self.peek(), Tok::Eof)
    }
    fn eat_op(&mut self, op: &str) -> bool {
        if self.peek().is_op(op) {
            self.bump();
            true
        } else {
            false
        }
    }
    fn eat_ident(&mut self, kw: &str) -> bool {
        if self.peek().is_ident(kw) {
            self.bump();
            true
        } else {
            false
        }
    }
    fn expect_op(&mut self, op: &str) -> Result<(), VbaError> {
        if self.eat_op(op) {
            Ok(())
        } else {
            Err(VbaError::syntax(
                format!(
                    "`{op}` が必要ですが {} が見つかりました",
                    self.peek().describe()
                ),
                self.line(),
            ))
        }
    }
    fn skip_newlines(&mut self) {
        while matches!(self.peek(), Tok::Newline) || self.peek().is_op(":") {
            self.bump();
        }
    }
    /// Consume the rest of the current line, leaving the trailing `Newline`
    /// token in place so statement separation stays unambiguous.
    fn skip_to_eol(&mut self) {
        while !matches!(self.peek(), Tok::Newline | Tok::Eof) {
            self.bump();
        }
    }

    /// True when the upcoming tokens spell `words` (case-insensitive).
    fn ahead(&self, words: &[&str]) -> bool {
        words
            .iter()
            .enumerate()
            .all(|(i, w)| self.peek_at(i).is_ident(w))
    }

    fn parse_module(&mut self) -> Result<Module, VbaError> {
        let mut module = Module::default();
        loop {
            self.skip_newlines();
            if self.at_eof() {
                break;
            }
            if self.ahead(&["option", "explicit"]) {
                module.option_explicit = true;
                self.skip_to_eol();
                continue;
            }
            if self.ahead(&["option", "base"]) || self.ahead(&["option", "compare"]) {
                self.skip_to_eol();
                continue;
            }
            if self.ahead(&["attribute"]) || self.ahead(&["version"]) || self.ahead(&["declare"]) {
                if self.ahead(&["declare"]) {
                    return Err(VbaError::syntax(
                        "Declare (Windows API 呼び出し) は未対応です",
                        self.line(),
                    ));
                }
                self.skip_to_eol();
                continue;
            }
            let mut is_public = false;
            if self.peek().is_ident("public") || self.peek().is_ident("private") {
                is_public = self.peek().is_ident("public");
                self.bump();
            }
            let kind = if self.eat_ident("sub") {
                ProcKind::Sub
            } else if self.eat_ident("function") {
                ProcKind::Function
            } else {
                return Err(VbaError::syntax(
                    format!(
                        "`Sub` または `Function` が必要ですが {} が見つかりました (モジュール {})",
                        self.peek().describe(),
                        self.module_name
                    ),
                    self.line(),
                ));
            };
            let name = match self.bump() {
                Tok::Ident(n) => n,
                other => {
                    return Err(VbaError::syntax(
                        format!(
                            "プロシージャ名が必要ですが {} が見つかりました",
                            other.describe()
                        ),
                        self.line(),
                    ))
                }
            };
            let params = self.parse_params()?;
            // Optional return type: `Function F() As Double`
            if self.eat_ident("as") {
                self.bump();
                while self.peek().is_op(".") {
                    self.bump();
                    self.bump();
                }
            }
            let end_words: &[&str] = if kind == ProcKind::Sub {
                &["end", "sub"]
            } else {
                &["end", "function"]
            };
            let (body, _) = self.parse_block(&[end_words])?;
            if !self.ahead(end_words) {
                return Err(VbaError::syntax(
                    format!(
                        "`End {}` が見つかりません ({name})",
                        if kind == ProcKind::Sub {
                            "Sub"
                        } else {
                            "Function"
                        }
                    ),
                    self.line(),
                ));
            }
            self.skip_to_eol();
            module.procs.push(Proc {
                name,
                kind,
                params,
                body,
                is_public,
            });
        }
        Ok(module)
    }

    fn parse_params(&mut self) -> Result<Vec<Param>, VbaError> {
        let mut params = Vec::new();
        if !self.eat_op("(") {
            return Ok(params);
        }
        if self.eat_op(")") {
            return Ok(params);
        }
        loop {
            // `Optional`, `ByVal`, `ByRef`, `ParamArray`
            let mut optional = false;
            loop {
                if self.eat_ident("optional") {
                    optional = true;
                } else if self.eat_ident("byval")
                    || self.eat_ident("byref")
                    || self.eat_ident("paramarray")
                {
                } else {
                    break;
                }
            }
            let name = match self.bump() {
                Tok::Ident(n) => n,
                other => {
                    return Err(VbaError::syntax(
                        format!("引数名が必要ですが {} が見つかりました", other.describe()),
                        self.line(),
                    ))
                }
            };
            // optional `As Type` / `()`
            if self.eat_op("(") {
                self.expect_op(")")?;
            }
            if self.eat_ident("as") {
                self.bump();
                // possibly `New Foo` or qualified type
                while self.peek().is_op(".") {
                    self.bump();
                    self.bump();
                }
            }
            let mut default = None;
            if self.eat_op("=") {
                default = Some(self.parse_expr()?);
            }
            params.push(Param {
                name,
                optional,
                default,
            });
            if !self.eat_op(",") {
                break;
            }
        }
        self.expect_op(")")?;
        Ok(params)
    }

    /// Parse statements until one of the terminator token sequences is seen at
    /// the start of a line.  Returns the statements and the matched index.
    fn parse_block(&mut self, terms: &[&[&str]]) -> Result<(Vec<Stmt>, usize), VbaError> {
        let mut out = Vec::new();
        loop {
            self.skip_newlines();
            if self.at_eof() {
                return Ok((out, usize::MAX));
            }
            for (i, words) in terms.iter().enumerate() {
                if self.ahead(words) {
                    return Ok((out, i));
                }
            }
            if let Some(stmt) = self.parse_stmt()? {
                out.push(stmt);
            }
            // statement separators
            if matches!(self.peek(), Tok::Newline) {
                self.skip_newlines();
            } else if self.eat_op(":") {
            } else if !self.at_eof() && !terms.iter().any(|w| self.ahead(w)) {
                return Err(VbaError::syntax(
                    format!(
                        "解釈できないトークン {} が文の後にあります",
                        self.peek().describe()
                    ),
                    self.line(),
                ));
            }
        }
    }

    fn parse_stmt(&mut self) -> Result<Option<Stmt>, VbaError> {
        self.skip_newlines();
        if self.at_eof() {
            return Ok(None);
        }
        // ---- declarations -------------------------------------------------
        if self.peek().is_ident("dim") || self.peek().is_ident("static") {
            self.bump();
            return Ok(Some(self.parse_dim()?));
        }
        if self.peek().is_ident("const") {
            self.bump();
            let name = match self.bump() {
                Tok::Ident(n) => n,
                _ => return Err(VbaError::syntax("定数名が必要です", self.line())),
            };
            if self.eat_ident("as") {
                self.bump();
            }
            self.expect_op("=")?;
            let value = self.parse_expr()?;
            return Ok(Some(Stmt::Assign {
                target: Expr::Var(name),
                value,
            }));
        }
        // ---- control flow -------------------------------------------------
        if self.ahead(&["if"]) {
            return Ok(Some(self.parse_if()?));
        }
        if self.ahead(&["for", "each"]) {
            self.bump();
            self.bump();
            let var = match self.bump() {
                Tok::Ident(n) => n,
                _ => return Err(VbaError::syntax("For Each の変数名が必要です", self.line())),
            };
            self.eat_ident("in");
            let collection = self.parse_expr()?;
            let (body, _) = self.parse_block(&[&["next"]])?;
            self.skip_to_eol();
            return Ok(Some(Stmt::ForEach {
                var,
                collection,
                body,
            }));
        }
        if self.peek().is_ident("for") {
            return Ok(Some(self.parse_for()?));
        }
        if self.peek().is_ident("do") {
            return Ok(Some(self.parse_do()?));
        }
        if self.peek().is_ident("while") {
            self.bump();
            let cond = self.parse_expr()?;
            let (body, _) = self.parse_block(&[&["wend"]])?;
            self.skip_to_eol();
            return Ok(Some(Stmt::While { cond, body }));
        }
        if self.peek().is_ident("with") {
            self.bump();
            let obj = self.parse_expr()?;
            let (body, _) = self.parse_block(&[&["end", "with"]])?;
            self.skip_to_eol();
            return Ok(Some(Stmt::With { obj, body }));
        }
        if self.peek().is_ident("select") {
            return Err(VbaError::syntax(
                "`Select Case` は未対応です (If/ElseIf を使用してください)",
                self.line(),
            ));
        }
        if self.peek().is_ident("exit") {
            self.bump();
            let what = self.bump();
            return Ok(Some(match what {
                Tok::Ident(w) if w.eq_ignore_ascii_case("for") => Stmt::ExitFor,
                Tok::Ident(w) if w.eq_ignore_ascii_case("do") => Stmt::ExitDo,
                Tok::Ident(w)
                    if w.eq_ignore_ascii_case("sub") || w.eq_ignore_ascii_case("function") =>
                {
                    Stmt::ExitProc
                }
                other => {
                    return Err(VbaError::syntax(
                        format!("`Exit` の後に {} は指定できません", other.describe()),
                        self.line(),
                    ))
                }
            }));
        }
        if self.peek().is_ident("on") {
            self.bump();
            if !self.eat_ident("error") {
                return Err(VbaError::syntax(
                    "`On Error` のみ対応しています",
                    self.line(),
                ));
            }
            if self.eat_ident("resume") && self.eat_ident("next") {
                return Ok(Some(Stmt::OnErrorResumeNext));
            }
            if self.eat_ident("goto") {
                if self.peek().is_ident("0") {
                    self.bump();
                    return Ok(Some(Stmt::OnErrorGoToZero));
                }
                // GoTo labels are not supported: treat as `Resume Next` so that
                // macro-driven error handling degrades gracefully and loudly.
                return Err(VbaError::syntax(
                    "`On Error GoTo <label>` は未対応です (`On Error Resume Next` を使用してください)",
                    self.line(),
                ));
            }
            return Err(VbaError::syntax("`On Error` の書式が不正です", self.line()));
        }
        if self.ahead(&["goto"]) {
            return Err(VbaError::syntax("`GoTo` ラベルは未対応です", self.line()));
        }
        if self.peek().is_ident("end")
            && !self.ahead(&["end", "if"])
            && !self.ahead(&["end", "with"])
        {
            self.bump();
            return Ok(Some(Stmt::Stop));
        }
        if self.peek().is_ident("stop") {
            self.bump();
            return Ok(Some(Stmt::Stop));
        }
        // ---- assignment / call --------------------------------------------
        let mut set_form = false;
        if self.peek().is_ident("let") {
            self.bump();
        } else if self.peek().is_ident("set") {
            self.bump();
            set_form = true;
        }
        if self.peek().is_ident("call") {
            self.bump();
            let callee = self.parse_operand()?;
            let args = Vec::new();
            let expr = Expr::Call(Box::new(callee), args);
            return Ok(Some(Stmt::Expr(expr)));
        }
        let target = self.parse_operand()?;
        if self.eat_op("=") {
            let value = self.parse_expr()?;
            return Ok(Some(if set_form {
                Stmt::SetAssign { target, value }
            } else {
                Stmt::Assign { target, value }
            }));
        }
        // Statement-level call, with or without parentheses:
        // `MsgBox "hi", vbInformation` / `Foo(1, 2)`
        let callee = match target {
            Expr::Call(callee, args) => {
                // `Foo(1, 2)` parsed as a call already.
                return Ok(Some(Stmt::Expr(Expr::Call(callee, args))));
            }
            other => other,
        };
        let mut args = Vec::new();
        if !matches!(self.peek(), Tok::Newline | Tok::Eof) && !self.peek().is_op(":") {
            loop {
                args.push(self.parse_expr()?);
                if !self.eat_op(",") {
                    break;
                }
            }
        }
        Ok(Some(Stmt::Expr(Expr::Call(Box::new(callee), args))))
    }

    fn parse_dim(&mut self) -> Result<Stmt, VbaError> {
        // `Dim a As Long, b(0 To 3) As Double, c()`
        let mut out: Vec<Stmt> = Vec::new();
        loop {
            let name = match self.bump() {
                Tok::Ident(n) => n,
                other => {
                    return Err(VbaError::syntax(
                        format!("変数名が必要ですが {} が見つかりました", other.describe()),
                        self.line(),
                    ))
                }
            };
            if self.eat_op("(") {
                if self.eat_op(")") {
                    // dynamic array declaration: created empty
                    out.push(Stmt::DimArray {
                        name,
                        lower: 0,
                        upper: -1,
                    });
                } else {
                    let first = self.parse_expr()?;
                    let first = const_int(&first, self.line())?;
                    let (lower, upper) = if self.eat_ident("to") {
                        let second = self.parse_expr()?;
                        (first, const_int(&second, self.line())?)
                    } else {
                        (0, first)
                    };
                    self.expect_op(")")?;
                    out.push(Stmt::DimArray { name, lower, upper });
                }
            } else {
                out.push(Stmt::Dim(vec![name]));
            }
            if self.eat_ident("as") {
                self.bump();
                while self.peek().is_op(".") {
                    self.bump();
                    self.bump();
                }
            }
            if !self.eat_op(",") {
                break;
            }
        }
        Ok(if out.len() == 1 {
            out.remove(0)
        } else {
            Stmt::Seq(out)
        })
    }

    fn parse_if(&mut self) -> Result<Stmt, VbaError> {
        self.bump(); // if
        let cond = self.parse_expr()?;
        if !self.eat_ident("then") {
            return Err(VbaError::syntax("`Then` が必要です", self.line()));
        }
        if !matches!(self.peek(), Tok::Newline | Tok::Eof) {
            // single-line form: If c Then a = 1 Else a = 2
            let mut then_stmts = Vec::new();
            while !matches!(self.peek(), Tok::Newline | Tok::Eof) && !self.peek().is_ident("else") {
                if let Some(s) = self.parse_stmt()? {
                    then_stmts.push(s);
                }
            }
            let mut otherwise = Vec::new();
            if self.eat_ident("else") {
                while !matches!(self.peek(), Tok::Newline | Tok::Eof) {
                    if let Some(s) = self.parse_stmt()? {
                        otherwise.push(s);
                    }
                }
            }
            return Ok(Stmt::If {
                branches: vec![(cond, then_stmts)],
                otherwise,
            });
        }
        let terms: &[&[&str]] = &[&["elseif"], &["else"], &["end", "if"]];
        let mut branches = Vec::new();
        let mut otherwise = Vec::new();
        let (body, mut matched) = self.parse_block(terms)?;
        branches.push((cond, body));
        loop {
            match matched {
                0 => {
                    self.bump(); // elseif
                    let c = self.parse_expr()?;
                    if !self.eat_ident("then") {
                        return Err(VbaError::syntax("`Then` が必要です", self.line()));
                    }
                    let (body, next) = self.parse_block(terms)?;
                    branches.push((c, body));
                    matched = next;
                }
                1 => {
                    self.bump(); // else
                    let (body, _) = self.parse_block(&[&["end", "if"]])?;
                    otherwise = body;
                    matched = 2;
                }
                _ => break,
            }
        }
        // Consume `End If` (and anything else on that line).
        self.skip_to_eol();
        Ok(Stmt::If {
            branches,
            otherwise,
        })
    }

    fn parse_for(&mut self) -> Result<Stmt, VbaError> {
        self.bump(); // for
        let var = match self.bump() {
            Tok::Ident(n) => n,
            _ => return Err(VbaError::syntax("For の変数名が必要です", self.line())),
        };
        self.expect_op("=")?;
        let from = self.parse_expr()?;
        if !self.eat_ident("to") {
            return Err(VbaError::syntax("`To` が必要です", self.line()));
        }
        let to = self.parse_expr()?;
        let step = if self.eat_ident("step") {
            Some(self.parse_expr()?)
        } else {
            None
        };
        let (body, _) = self.parse_block(&[&["next"]])?;
        // `Next` optionally names the loop variable.
        self.bump();
        if let Tok::Ident(_) = self.peek() {
            self.bump();
        }
        Ok(Stmt::For {
            var,
            from,
            to,
            step,
            body,
        })
    }

    fn parse_do(&mut self) -> Result<Stmt, VbaError> {
        self.bump(); // do
        let mut pre_cond = None;
        let mut until = false;
        if self.peek().is_ident("while") || self.peek().is_ident("until") {
            until = self.peek().is_ident("until");
            self.bump();
            pre_cond = Some(self.parse_expr()?);
        }
        let (body, _) = self.parse_block(&[&["loop"]])?;
        self.bump(); // loop
        let mut post_cond = None;
        let mut post_until = false;
        if self.peek().is_ident("while") || self.peek().is_ident("until") {
            post_until = self.peek().is_ident("until");
            self.bump();
            post_cond = Some(self.parse_expr()?);
        }
        Ok(match pre_cond {
            Some(c) => Stmt::DoWhile {
                cond: c,
                until,
                body,
            },
            None => Stmt::DoLoop {
                body,
                cond: post_cond,
                until: post_until,
                pre: false,
            },
        })
    }

    // ---- expressions ----------------------------------------------------

    pub fn parse_expr(&mut self) -> Result<Expr, VbaError> {
        self.parse_binary(0)
    }

    fn peek_binop(&self) -> Option<(BinOp, u8)> {
        let op = match self.peek() {
            Tok::Op(o) => o.as_str(),
            Tok::Ident(i) => {
                let l = i.to_ascii_lowercase();
                match l.as_str() {
                    "and" => return Some((BinOp::And, PREC_AND)),
                    "or" => return Some((BinOp::Or, PREC_OR)),
                    "xor" => return Some((BinOp::Xor, PREC_AND)),
                    "mod" => return Some((BinOp::Mod, PREC_MOD)),
                    "like" => return Some((BinOp::Like, PREC_CMP)),
                    "is" => return Some((BinOp::Eq, PREC_CMP)),
                    _ => return None,
                }
            }
            _ => return None,
        };
        Some(match op {
            "&" => (BinOp::Concat, PREC_CONCAT),
            "+" => (BinOp::Add, PREC_ADD),
            "-" => (BinOp::Sub, PREC_ADD),
            "*" => (BinOp::Mul, PREC_MUL),
            "/" => (BinOp::Div, PREC_MUL),
            "\\" => (BinOp::IntDiv, PREC_IDIV),
            "^" => (BinOp::Pow, PREC_POW),
            "=" => (BinOp::Eq, PREC_CMP),
            "<>" | "><" => (BinOp::Ne, PREC_CMP),
            "<" => (BinOp::Lt, PREC_CMP),
            "<=" | "=<" => (BinOp::Le, PREC_CMP),
            ">" => (BinOp::Gt, PREC_CMP),
            ">=" | "=>" => (BinOp::Ge, PREC_CMP),
            _ => return None,
        })
    }

    fn parse_binary(&mut self, min_prec: u8) -> Result<Expr, VbaError> {
        let mut lhs = self.parse_unary()?;
        while let Some((op, prec)) = self.peek_binop() {
            if prec < min_prec {
                break;
            }
            self.bump();
            let next_min = if op == BinOp::Pow { prec } else { prec + 1 };
            let rhs = self.parse_binary(next_min)?;
            lhs = Expr::Binary(op, Box::new(lhs), Box::new(rhs));
        }
        Ok(lhs)
    }

    fn parse_unary(&mut self) -> Result<Expr, VbaError> {
        if self.eat_op("-") {
            let e = self.parse_unary()?;
            return Ok(Expr::Unary(UnOp::Neg, Box::new(e)));
        }
        if self.eat_op("+") {
            return self.parse_unary();
        }
        if self.eat_ident("not") {
            // `Not` binds looser than comparisons: Not a = b  ==>  Not (a = b)
            let e = self.parse_binary(PREC_CMP)?;
            return Ok(Expr::Unary(UnOp::Not, Box::new(e)));
        }
        self.parse_operand()
    }

    fn parse_operand(&mut self) -> Result<Expr, VbaError> {
        let mut expr = match self.bump() {
            Tok::Num(n) => Expr::Lit(Value::Number(n)),
            Tok::Str(s) => Expr::Lit(Value::Str(s)),
            Tok::Op(o) if o == "(" => {
                let inner = self.parse_expr()?;
                self.expect_op(")")?;
                inner
            }
            Tok::Op(o) if o == "." => {
                let name = match self.bump() {
                    Tok::Ident(n) => n,
                    _ => return Err(VbaError::syntax("メンバー名が必要です", self.line())),
                };
                Expr::WithMember(name)
            }
            Tok::Ident(name) => match name.to_ascii_lowercase().as_str() {
                "true" => Expr::Lit(Value::Bool(true)),
                "false" => Expr::Lit(Value::Bool(false)),
                "empty" => Expr::Lit(Value::Empty),
                "null" => Expr::Lit(Value::Null),
                "nothing" => Expr::Lit(Value::Empty),
                _ => Expr::Var(name),
            },
            other => {
                return Err(VbaError::syntax(
                    format!("式が必要ですが {} が見つかりました", other.describe()),
                    self.line(),
                ))
            }
        };
        loop {
            if self.peek().is_op("(") {
                self.bump();
                let mut args = Vec::new();
                if !self.eat_op(")") {
                    loop {
                        if self.peek().is_op(",") {
                            // omitted argument
                            args.push(Expr::Lit(Value::Empty));
                        } else {
                            args.push(self.parse_expr()?);
                        }
                        if self.eat_op(",") {
                            continue;
                        }
                        break;
                    }
                    self.expect_op(")")?;
                }
                expr = Expr::Call(Box::new(expr), args);
                continue;
            }
            if self.peek().is_op(".") {
                self.bump();
                let name = match self.bump() {
                    Tok::Ident(n) => n,
                    other => {
                        return Err(VbaError::syntax(
                            format!(
                                "メンバー名が必要ですが {} が見つかりました",
                                other.describe()
                            ),
                            self.line(),
                        ))
                    }
                };
                expr = Expr::Member(Box::new(expr), name);
                continue;
            }
            break;
        }
        Ok(expr)
    }
}

/// Evaluate a constant integer bound such as `10` or `-1`.
fn const_int(expr: &Expr, line: u32) -> Result<i64, VbaError> {
    match expr {
        Expr::Lit(Value::Number(n)) => Ok(*n as i64),
        Expr::Unary(UnOp::Neg, inner) => match &**inner {
            Expr::Lit(Value::Number(n)) => Ok(-(*n as i64)),
            _ => Err(VbaError::syntax(
                "配列の境界は定数である必要があります",
                line,
            )),
        },
        _ => Err(VbaError::syntax(
            "配列の境界は定数である必要があります",
            line,
        )),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_sub_with_loop() {
        let m = parse_module(
            "Sub Main()\n  Dim i As Long\n  For i = 1 To 3\n    Cells(i, 1).Value = i * 2\n  Next i\nEnd Sub\n",
            "M",
        )
        .unwrap();
        assert_eq!(m.proc_names(), vec!["Main"]);
        assert_eq!(m.procs[0].body.len(), 2);
    }

    #[test]
    fn statement_call_without_parens() {
        let m = parse_module("Sub A()\n  MsgBox \"hi\", vbInformation\nEnd Sub", "M").unwrap();
        match &m.procs[0].body[0] {
            Stmt::Expr(Expr::Call(_, args)) => assert_eq!(args.len(), 2),
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn if_elseif_else_and_single_line() {
        let m = parse_module(
            "Function F(x)\n If x > 1 Then\n  F = 2\n ElseIf x = 1 Then\n  F = 1\n Else\n  F = 0\n End If\nEnd Function\nSub G()\n If 1 Then a = 1 Else a = 2\nEnd Sub",
            "M",
        )
        .unwrap();
        match &m.procs[0].body[0] {
            Stmt::If {
                branches,
                otherwise,
            } => {
                assert_eq!(branches.len(), 2);
                assert_eq!(otherwise.len(), 1);
            }
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn precedence_matches_vba() {
        // 2 + 3 * 4 = 14 ; "a" & 1+1 = "a2"
        let m = parse_module("Sub A()\n x = 2 + 3 * 4\n y = \"a\" & 1 + 1\nEnd Sub", "M").unwrap();
        assert!(matches!(m.procs[0].body[0], Stmt::Assign { .. }));
    }

    #[test]
    fn do_loop_forms() {
        let m = parse_module(
            "Sub A()\n i = 0\n Do While i < 3\n  i = i + 1\n Loop\n Do\n  i = i - 1\n Loop Until i = 0\nEnd Sub",
            "M",
        )
        .unwrap();
        assert!(matches!(m.procs[0].body[1], Stmt::DoWhile { .. }));
        assert!(matches!(m.procs[0].body[2], Stmt::DoLoop { .. }));
    }

    #[test]
    fn rejects_unsupported_constructs_loudly() {
        assert!(parse_module("Sub A()\n GoTo 10\nEnd Sub", "M").is_err());
        assert!(parse_module("Sub A()\n Select Case x\n End Select\nEnd Sub", "M").is_err());
        assert!(parse_module("Sub A(\nEnd Sub", "M").is_err());
    }

    #[test]
    fn with_block() {
        let m = parse_module(
            "Sub A()\n With Range(\"A1\")\n  .Value = 5\n  .Font.Bold = True\n End With\nEnd Sub",
            "M",
        )
        .unwrap();
        assert!(matches!(m.procs[0].body[0], Stmt::With { .. }));
    }
}
