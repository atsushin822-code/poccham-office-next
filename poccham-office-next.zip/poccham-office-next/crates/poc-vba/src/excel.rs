//! Excel object model for macros: `Range`, `Cells`, `Sheets`, `ActiveSheet`,
//! `ThisWorkbook` and the properties that business macros actually use
//! (`Value`, `Formula`, `Text`, `Row`, `Column`, `Address`, `Count`, `Offset`,
//! `ClearContents`, `UsedRange`).

use poc_core::xlsx::{self, Cell, CellValue, Merge, Workbook};

use crate::interp::Host;
use crate::value::Value;

const SEP: char = '\u{1}';

#[derive(Debug, Clone, Copy, PartialEq)]
enum Obj {
    Workbook,
    /// `Application.WorksheetFunction` — argument-only access to the engine.
    WorksheetFunction,
    Sheet(usize),
    Range {
        sheet: usize,
        r1: u32,
        c1: u32,
        r2: u32,
        c2: u32,
    },
}

fn encode(o: Obj) -> String {
    match o {
        Obj::Workbook => format!("W{SEP}"),
        Obj::WorksheetFunction => format!("F{SEP}"),
        Obj::Sheet(i) => format!("S{SEP}{i}"),
        Obj::Range {
            sheet,
            r1,
            c1,
            r2,
            c2,
        } => format!("R{SEP}{sheet}{SEP}{r1}{SEP}{c1}{SEP}{r2}{SEP}{c2}"),
    }
}

fn decode(handle: &str) -> Result<Obj, String> {
    let parts: Vec<&str> = handle.split(SEP).collect();
    let num = |i: usize| -> Result<u32, String> {
        parts
            .get(i)
            .and_then(|s| s.parse::<u32>().ok())
            .ok_or_else(|| format!("壊たオブジェクト参照です: {handle:?}"))
    };
    match parts.first().copied() {
        Some("W") => Ok(Obj::Workbook),
        Some("F") => Ok(Obj::WorksheetFunction),
        Some("S") => Ok(Obj::Sheet(num(1)? as usize)),
        Some("R") => Ok(Obj::Range {
            sheet: num(1)? as usize,
            r1: num(2)?,
            c1: num(3)?,
            r2: num(4)?,
            c2: num(5)?,
        }),
        _ => Err(format!("不明なオブジェクト参照です: {handle:?}")),
    }
}

/// A macro host backed by a Poccham workbook.
pub struct ExcelHost<'a> {
    pub wb: &'a mut Workbook,
    pub active: usize,
    /// Text captured from `Debug.Print`.
    pub printed: Vec<String>,
    /// Values captured by `Range.Copy`, written back by `Range.Paste`.
    pub clipboard: Vec<Vec<Value>>,
}

impl<'a> ExcelHost<'a> {
    pub fn new(wb: &'a mut Workbook) -> Self {
        ExcelHost {
            wb,
            active: 0,
            printed: Vec::new(),
            clipboard: Vec::new(),
        }
    }

    fn active_sheet(&self) -> usize {
        self.active.min(self.wb.sheets.len().saturating_sub(1))
    }

    fn range_handle(&self, sheet: usize, r1: u32, c1: u32, r2: u32, c2: u32) -> Value {
        Value::Object(encode(Obj::Range {
            sheet: sheet.min(self.wb.sheets.len().saturating_sub(1)),
            r1,
            c1,
            r2: r2.max(r1),
            c2: c2.max(c1),
        }))
    }

    fn set_cell(&mut self, sheet: usize, row: u32, col: u32, cell: Cell) {
        if let Some(s) = self.wb.sheets.get_mut(sheet) {
            s.set(row, col, cell);
        }
        self.wb.recalculate_dirty();
    }

    fn cell_value(&self, sheet: usize, row: u32, col: u32) -> Value {
        let Some(s) = self.wb.sheets.get(sheet) else {
            return Value::Empty;
        };
        match s.get(row, col).map(|c| &c.value) {
            None | Some(CellValue::Empty) => Value::Empty,
            Some(CellValue::Number(n)) => Value::Number(*n),
            Some(CellValue::Bool(b)) => Value::Bool(*b),
            Some(CellValue::Text(t)) => Value::Str(t.clone()),
            Some(CellValue::Error(e)) => Value::Str(e.clone()),
            Some(CellValue::Formula { cached, .. }) => match cached {
                Some(n) => Value::Number(*n),
                None => Value::Empty,
            },
        }
    }

    /// Convert a VBA value into a cell value, honouring the `"="` formula rule.
    fn to_cell(value: Value) -> Cell {
        match value {
            Value::Empty | Value::Null => Cell::empty(),
            Value::Bool(b) => Cell::boolean(b),
            Value::Number(n) => Cell::num(n),
            Value::Str(s) => {
                if let Some(expr) = s.strip_prefix('=') {
                    Cell::formula(expr.to_string(), None)
                } else if s.is_empty() {
                    Cell::empty()
                } else {
                    Cell::text(s)
                }
            }
            Value::Object(_) | Value::Array { .. } => Cell::empty(),
        }
    }

    fn address(r1: u32, c1: u32, r2: u32, c2: u32) -> String {
        let a = format!("{}{}", xlsx::col_letters(c1), r1 + 1);
        if (r1, c1) == (r2, c2) {
            a
        } else {
            format!("{a}:{}{}", xlsx::col_letters(c2), r2 + 1)
        }
    }

    /// Render a VBA value as a formula literal.
    fn literal(value: &Value) -> String {
        match value {
            Value::Number(n) => format!("{n}"),
            Value::Bool(b) => (if *b { "TRUE" } else { "FALSE" }).to_string(),
            Value::Str(s) => format!("\"{}\"", s.replace('"', "")),
            Value::Empty | Value::Null => String::new(),
            Value::Object(h) => match decode(h) {
                Ok(Obj::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                }) => {
                    let _ = sheet;
                    format!(
                        "{}:{}",
                        ExcelHost::address(r1, c1, r1, c1),
                        ExcelHost::address(r2, c2, r2, c2)
                    )
                }
                _ => String::new(),
            },
            Value::Array { items, .. } => items
                .iter()
                .map(ExcelHost::literal)
                .collect::<Vec<_>>()
                .join(","),
        }
    }

    /// Call a worksheet function through the engine: `WorksheetFunction.Sum(a, b)`.
    fn call_worksheet_function(&self, name: &str, args: &[Value]) -> Result<Value, String> {
        let literals: Vec<String> = args.iter().map(ExcelHost::literal).collect();
        let expr = format!("{}({})", name.to_ascii_uppercase(), literals.join(","));
        let sheet = self.active_sheet();
        let value = poc_core::formula::evaluate(self.wb, sheet, &expr);
        Ok(match value {
            poc_core::formula::CValue::Number(n) => Value::Number(n),
            poc_core::formula::CValue::Str(s) => Value::Str(s),
            poc_core::formula::CValue::Bool(b) => Value::Bool(b),
            poc_core::formula::CValue::Error(e) => {
                return Err(format!(
                    "WorksheetFunction.{name} がエラーを返しました: {e}"
                ))
            }
            poc_core::formula::CValue::Empty => Value::Empty,
        })
    }
}

impl Host for ExcelHost<'_> {
    fn get_property(&mut self, obj: &str, name: &str) -> Result<Value, String> {
        let o = decode(obj)?;
        let lname = name.to_ascii_lowercase();
        match o {
            Obj::WorksheetFunction => Err(format!(
                "WorksheetFunction.{name} は関数として呼び出してください (例: WorksheetFunction.Sum(1,2))"
            )),
            Obj::Workbook => match lname.as_str() {
                "name" | "title" => Ok(Value::Str(self.wb.title.clone())),
                "version" => Ok(Value::Str(poc_core::VERSION.into())),
                "worksheetfunction" | "wsf" => Ok(Value::Object(encode(Obj::WorksheetFunction))),
                "count" => Ok(Value::Number(self.wb.sheets.len() as f64)),
                "activesheet" => Ok(Value::Object(encode(Obj::Sheet(self.active_sheet())))),
                // Without an index this is the collection itself, which is
                // enumerable (`For Each s In ThisWorkbook.Sheets`).
                "sheets" | "worksheets" => Ok(Value::Object(encode(Obj::Workbook))),
                _ => Err(format!("Workbook に {name} プロパティはありません")),
            },
            Obj::Sheet(i) => match lname.as_str() {
                "name" => Ok(Value::Str(
                    self.wb
                        .sheets
                        .get(i)
                        .map(|s| s.name.clone())
                        .unwrap_or_default(),
                )),
                "index" => Ok(Value::Number((i + 1) as f64)),
                "visible" => Ok(Value::Bool(true)),
                "usedrange" => {
                    let (rows, cols) = self
                        .wb
                        .sheets
                        .get(i)
                        .map(|s| (s.row_count(), s.col_count()))
                        .unwrap_or((0, 0));
                    Ok(self.range_handle(i, 0, 0, rows.saturating_sub(1), cols.saturating_sub(1)))
                }
                _ => Err(format!("Worksheet に {name} プロパティはありません")),
            },
            Obj::Range {
                sheet,
                r1,
                c1,
                r2,
                c2,
            } => match lname.as_str() {
                "value" | "value2" => Ok(self.cell_value(sheet, r1, c1)),
                "text" => Ok(Value::Str(
                    self.wb
                        .sheets
                        .get(sheet)
                        .and_then(|s| s.get(r1, c1))
                        .map(|c| c.as_text())
                        .unwrap_or_default(),
                )),
                "formula" => {
                    let text = self
                        .wb
                        .sheets
                        .get(sheet)
                        .and_then(|s| s.get(r1, c1))
                        .map(|c| match &c.value {
                            CellValue::Formula { expr, .. } => format!("={expr}"),
                            CellValue::Empty => String::new(),
                            other => Cell {
                                value: other.clone(),
                                style: 0,
                            }
                            .as_text(),
                        })
                        .unwrap_or_default();
                    Ok(Value::Str(text))
                }
                "row" => Ok(Value::Number((r1 + 1) as f64)),
                "column" => Ok(Value::Number((c1 + 1) as f64)),
                "address" => Ok(Value::Str(ExcelHost::address(r1, c1, r2, c2))),
                "count" => Ok(Value::Number(
                    ((r2 - r1 + 1) as f64) * ((c2 - c1 + 1) as f64),
                )),
                "rows" => Ok(Value::Number((r2 - r1 + 1) as f64)),
                "columns" => Ok(Value::Number((c2 - c1 + 1) as f64)),
                "worksheet" | "parent" => Ok(Value::Object(encode(Obj::Sheet(sheet)))),
                "entirecolumn" => {
                    let last = self
                        .wb
                        .sheets
                        .get(sheet)
                        .map(|s| s.row_count().saturating_sub(1))
                        .unwrap_or(r2)
                        .max(r2);
                    Ok(self.range_handle(sheet, 0, c1, last, c2))
                }
                "entirerow" => {
                    let last = self
                        .wb
                        .sheets
                        .get(sheet)
                        .map(|s| s.col_count().saturating_sub(1))
                        .unwrap_or(c2)
                        .max(c2);
                    Ok(self.range_handle(sheet, r1, 0, r2, last))
                }
                // `Range("A1:C1").Cells` is the range itself, re-enumerable.
                "cells" | "item" => Ok(Value::Object(encode(Obj::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                }))),
                "mergecells" | "merged" => {
                    let target = Merge::new(r1, c1, r2, c2);
                    Ok(Value::Bool(
                        self.wb
                            .sheets
                            .get(sheet)
                            .map(|s| s.merges.contains(&target))
                            .unwrap_or(false),
                    ))
                }
                _ => Err(format!("Range に {name} プロパティはありません")),
            },
        }
    }

    fn set_property(&mut self, obj: &str, name: &str, value: Value) -> Result<(), String> {
        let o = decode(obj)?;
        let lname = name.to_ascii_lowercase();
        match o {
            Obj::WorksheetFunction => Err("WorksheetFunction のプロパティは設定できません".into()),
            Obj::Range {
                sheet,
                r1,
                c1,
                r2,
                c2,
            } => match lname.as_str() {
                "value" | "value2" => {
                    let cell = Self::to_cell(value);
                    for r in r1..=r2 {
                        for c in c1..=c2 {
                            self.set_cell(sheet, r, c, cell.clone());
                        }
                    }
                    Ok(())
                }
                "formula" => {
                    let expr = value.as_str();
                    let cell = if expr.is_empty() {
                        Cell::empty()
                    } else {
                        Cell::formula(expr.trim_start_matches('=').to_string(), None)
                    };
                    self.set_cell(sheet, r1, c1, cell);
                    Ok(())
                }
                _ => Err(format!("Range.{name} への代入は未対応です")),
            },
            Obj::Sheet(i) => match lname.as_str() {
                "name" => {
                    let new_name = value.as_str();
                    if new_name.is_empty() {
                        return Err("シート名を空にはできません".into());
                    }
                    if let Some(s) = self.wb.sheets.get_mut(i) {
                        s.name = new_name;
                    }
                    Ok(())
                }
                _ => Err(format!("Worksheet.{name} への代入は未対応です")),
            },
            Obj::Workbook => Err(format!("Workbook.{name} への代入は未対応です")),
        }
    }

    fn invoke_object(&mut self, obj: &str, name: &str, args: Vec<Value>) -> Result<Value, String> {
        let o = decode(obj)?;
        let lname = name.to_ascii_lowercase();
        match (o, lname.as_str()) {
            (Obj::Sheet(i), "range") => {
                let addr = args.first().map(|v| v.as_str()).unwrap_or_default();
                let (r1, c1, r2, c2) = xlsx::parse_range(&addr)
                    .ok_or_else(|| format!("セル範囲が不正です: {addr:?}"))?;
                Ok(self.range_handle(i, r1, c1, r2, c2))
            }
            (Obj::Sheet(i), "cells") => {
                let r = args
                    .first()
                    .map(|v| v.as_number())
                    .transpose()?
                    .unwrap_or(1.0);
                let c = args
                    .get(1)
                    .map(|v| v.as_number())
                    .transpose()?
                    .unwrap_or(1.0);
                Ok(self.range_handle(
                    i,
                    (r.max(1.0) as u32) - 1,
                    (c.max(1.0) as u32) - 1,
                    (r.max(1.0) as u32) - 1,
                    (c.max(1.0) as u32) - 1,
                ))
            }
            (Obj::Sheet(i), "rows" | "columns") => {
                let (rows, cols) = self
                    .wb
                    .sheets
                    .get(i)
                    .map(|s| (s.row_count().max(1), s.col_count().max(1)))
                    .unwrap_or((1, 1));
                if name.eq_ignore_ascii_case("rows") {
                    Ok(self.range_handle(i, 0, 0, rows - 1, cols.saturating_sub(1)))
                } else {
                    Ok(self.range_handle(i, 0, 0, rows.saturating_sub(1), cols - 1))
                }
            }
            (Obj::Sheet(i), "activate" | "select") => {
                self.active = i;
                Ok(Value::Empty)
            }
            (Obj::Sheet(_), "calculate") => {
                self.wb.recalculate();
                Ok(Value::Empty)
            }
            (Obj::Workbook, "wait" | "run" | "close" | "save" | "calculate") => Ok(Value::Empty),
            (Obj::Workbook, "sheets" | "worksheets") => {
                let arg = args.first().cloned().unwrap_or(Value::Empty);
                let idx = match arg {
                    Value::Number(n) => (n as usize).saturating_sub(1),
                    Value::Str(s) => self
                        .wb
                        .sheet_index(&s)
                        .ok_or_else(|| format!("シートが存在しません: {s}"))?,
                    Value::Empty => self.active_sheet(),
                    other => {
                        return Err(format!("Sheets の引数が不正です ({})", other.type_name()))
                    }
                };
                if idx >= self.wb.sheets.len() {
                    return Err(format!("シート番号が範囲外です: {}", idx + 1));
                }
                Ok(Value::Object(encode(Obj::Sheet(idx))))
            }
            (
                Obj::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                },
                "offset",
            ) => {
                let dr = args
                    .first()
                    .map(|v| v.as_number())
                    .transpose()?
                    .unwrap_or(0.0) as i64;
                let dc = args
                    .get(1)
                    .map(|v| v.as_number())
                    .transpose()?
                    .unwrap_or(0.0) as i64;
                let shift = |v: u32, d: i64| (v as i64 + d).max(0) as u32;
                Ok(self.range_handle(
                    sheet,
                    shift(r1, dr),
                    shift(c1, dc),
                    shift(r2, dr),
                    shift(c2, dc),
                ))
            }
            (
                Obj::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                },
                "clear" | "clearcontents" | "clearformats",
            ) => {
                for r in r1..=r2 {
                    for c in c1..=c2 {
                        self.set_cell(sheet, r, c, Cell::empty());
                    }
                }
                Ok(Value::Empty)
            }
            (Obj::Range { sheet, .. }, "select" | "activate") => {
                self.active = sheet;
                Ok(Value::Empty)
            }
            // ---- range operations that map straight onto the document model
            (
                Obj::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                },
                "merge",
            ) => {
                if let Some(s) = self.wb.sheets.get_mut(sheet) {
                    let m = Merge::new(r1, c1, r2, c2);
                    if !s.merges.contains(&m) {
                        s.merges.push(m);
                    }
                }
                Ok(Value::Empty)
            }
            (
                Obj::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                },
                "unmerge",
            ) => {
                let target = Merge::new(r1, c1, r2, c2);
                if let Some(s) = self.wb.sheets.get_mut(sheet) {
                    s.merges.retain(|m| *m != target);
                }
                Ok(Value::Empty)
            }
            (
                Obj::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                },
                "resize",
            ) => {
                let rows = args
                    .first()
                    .map(|v| v.as_number())
                    .transpose()?
                    .unwrap_or((r2 - r1 + 1) as f64)
                    .max(1.0) as u32;
                let cols = args
                    .get(1)
                    .map(|v| v.as_number())
                    .transpose()?
                    .unwrap_or((c2 - c1 + 1) as f64)
                    .max(1.0) as u32;
                Ok(self.range_handle(sheet, r1, c1, r1 + rows - 1, c1 + cols - 1))
            }
            (
                Obj::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                },
                "entirerow",
            ) => {
                let _ = c1;
                let last = self
                    .wb
                    .sheets
                    .get(sheet)
                    .map(|s| s.col_count().saturating_sub(1))
                    .unwrap_or(c2)
                    .max(c2);
                Ok(self.range_handle(sheet, r1, 0, r2, last))
            }
            (
                Obj::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                },
                "entirecolumn",
            ) => {
                let _ = r1;
                let last = self
                    .wb
                    .sheets
                    .get(sheet)
                    .map(|s| s.row_count().saturating_sub(1))
                    .unwrap_or(r2)
                    .max(r2);
                Ok(self.range_handle(sheet, 0, c1, last, c2))
            }
            // `Range.End(xlDown)` and friends: walk to the last filled cell.
            (
                Obj::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                },
                "end",
            ) => {
                let dir = args
                    .first()
                    .map(|v| v.as_number())
                    .transpose()?
                    .unwrap_or(-4121.0) as i64;
                let (mut row, mut col) = (r1, c1);
                let filled = |host: &Self, r: u32, c: u32| {
                    host.wb
                        .sheets
                        .get(sheet)
                        .and_then(|s| s.get(r, c))
                        .map(|cell| !cell.is_empty())
                        .unwrap_or(false)
                };
                let max = |host: &Self| {
                    host.wb
                        .sheets
                        .get(sheet)
                        .map(|s| (s.row_count().max(1), s.col_count().max(1)))
                        .unwrap_or((1, 1))
                };
                // Excel: if the adjacent cell is filled we walk to the end of
                // that contiguous block; if it is empty we skip the gap and
                // stop on the next filled cell.
                let (rows, cols) = max(self);
                let (dr, dc): (i64, i64) = match dir {
                    -4162 => (-1, 0), // xlUp
                    -4159 => (0, -1), // xlToLeft
                    -4161 => (0, 1),  // xlToRight
                    _ => (1, 0),      // xlDown
                };
                let step = |r: u32, c: u32| -> Option<(u32, u32)> {
                    let nr = r as i64 + dr;
                    let nc = c as i64 + dc;
                    if nr < 0 || nc < 0 || nr >= rows as i64 || nc >= cols as i64 {
                        None
                    } else {
                        Some((nr as u32, nc as u32))
                    }
                };
                if let Some((nr, nc)) = step(row, col) {
                    if filled(self, nr, nc) {
                        // ride the block to its far end
                        while let Some((ar, ac)) = step(row, col) {
                            if !filled(self, ar, ac) {
                                break;
                            }
                            row = ar;
                            col = ac;
                        }
                    } else {
                        // skip empties, stop on the first filled cell
                        while let Some((ar, ac)) = step(row, col) {
                            row = ar;
                            col = ac;
                            if filled(self, row, col) {
                                break;
                            }
                        }
                    }
                }
                let _ = (r2, c2);
                Ok(self.range_handle(sheet, row, col, row, col))
            }
            // `Range.Find(value)` → the first matching cell, or Empty.
            (
                Obj::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                },
                "find",
            ) => {
                let needle = args.first().cloned().unwrap_or(Value::Empty);
                let needle_text = needle.as_str().to_lowercase();
                let mut hit = None;
                'outer: for r in r1..=r2 {
                    for c in c1..=c2 {
                        let v = self.cell_value(sheet, r, c);
                        if v.as_str().to_lowercase() == needle_text {
                            hit = Some((r, c));
                            break 'outer;
                        }
                    }
                }
                match hit {
                    Some((r, c)) => Ok(self.range_handle(sheet, r, c, r, c)),
                    None => Ok(Value::Empty),
                }
            }
            // `Range.Copy` / `Range.Paste` use an in-memory clipboard.
            (
                Obj::Range {
                    sheet,
                    r1,
                    c1,
                    r2,
                    c2,
                },
                "copy",
            ) => {
                let mut block = Vec::new();
                for r in r1..=r2 {
                    let mut row = Vec::new();
                    for c in c1..=c2 {
                        row.push(self.cell_value(sheet, r, c));
                    }
                    block.push(row);
                }
                self.clipboard = block;
                Ok(Value::Empty)
            }
            (
                Obj::Range {
                    sheet,
                    r1,
                    c1,
                    r2: _,
                    c2: _,
                },
                "paste",
            ) => {
                let block = self.clipboard.clone();
                for (dr, row) in block.iter().enumerate() {
                    for (dc, value) in row.iter().enumerate() {
                        self.set_cell(
                            sheet,
                            r1 + dr as u32,
                            c1 + dc as u32,
                            Self::to_cell(value.clone()),
                        );
                    }
                }
                Ok(Value::Empty)
            }
            (Obj::Range { .. }, "cells" | "item") => Ok(Value::Object(encode(o))),
            (Obj::Range { .. }, "autoformat" | "borderaround") => Ok(Value::Empty),
            (Obj::WorksheetFunction, fn_name) => self.call_worksheet_function(fn_name, &args),
            (_, other) => Err(format!("メソッド {other} は未対応です")),
        }
    }

    fn invoke_global(&mut self, name: &str, args: Vec<Value>) -> Result<Value, String> {
        let lname = name.to_ascii_lowercase();
        match lname.as_str() {
            "range" => {
                let addr = args.first().map(|v| v.as_str()).unwrap_or_default();
                let sheet = self.active_sheet();
                let (r1, c1, r2, c2) = xlsx::parse_range(&addr)
                    .ok_or_else(|| format!("セル範囲が不正です: {addr:?}"))?;
                Ok(self.range_handle(sheet, r1, c1, r2, c2))
            }
            "cells" => {
                let r = args
                    .first()
                    .map(|v| v.as_number())
                    .transpose()?
                    .unwrap_or(1.0);
                let c = args
                    .get(1)
                    .map(|v| v.as_number())
                    .transpose()?
                    .unwrap_or(1.0);
                let sheet = self.active_sheet();
                Ok(self.range_handle(
                    sheet,
                    (r.max(1.0) as u32) - 1,
                    (c.max(1.0) as u32) - 1,
                    (r.max(1.0) as u32) - 1,
                    (c.max(1.0) as u32) - 1,
                ))
            }
            "sheets" | "worksheets" => {
                let arg = args.first().cloned().unwrap_or(Value::Empty);
                match arg {
                    Value::Number(n) => {
                        let idx = (n as usize).saturating_sub(1);
                        if idx < self.wb.sheets.len() {
                            Ok(Value::Object(encode(Obj::Sheet(idx))))
                        } else {
                            Err(format!("シート番号が範囲外です: {}", idx + 1))
                        }
                    }
                    Value::Str(s) => match self.wb.sheet_index(&s) {
                        Some(idx) => Ok(Value::Object(encode(Obj::Sheet(idx)))),
                        None => Err(format!("シートが存在しません: {s}")),
                    },
                    _ => Err("Sheets には名前または番号を指定してください".into()),
                }
            }
            "activesheet" | "activeworksheet" => {
                Ok(Value::Object(encode(Obj::Sheet(self.active_sheet()))))
            }
            "thisworkbook" | "activeworkbook" | "application" | "workbook" => {
                Ok(Value::Object(encode(Obj::Workbook)))
            }
            // `WorksheetFunction.Sum(...)`, `.Average(...)`, … go through the
            // engine's own function library, so a macro and a formula agree.
            "worksheetfunction" | "wsf" => Ok(Value::Object(encode(Obj::WorksheetFunction))),
            "now" | "date" | "time" => {
                let secs = crate::now_seconds();
                Ok(Value::Str(poc_core::pkg::w3cdtf_from_unix(secs as u64)))
            }
            other => Err(format!("`{other}` はこのマクロ環境では未定義です")),
        }
    }

    fn enumerate(&mut self, obj: &str) -> Option<Vec<Value>> {
        match decode(obj).ok()? {
            Obj::Workbook => Some(
                (0..self.wb.sheets.len())
                    .map(|i| Value::Object(encode(Obj::Sheet(i))))
                    .collect(),
            ),
            Obj::WorksheetFunction => None,
            Obj::Sheet(i) => Some(vec![Value::Object(encode(Obj::Sheet(i)))]),
            Obj::Range {
                sheet,
                r1,
                c1,
                r2,
                c2,
            } => {
                let mut items = Vec::new();
                for r in r1..=r2 {
                    for c in c1..=c2 {
                        items.push(Value::Object(encode(Obj::Range {
                            sheet,
                            r1: r,
                            c1: c,
                            r2: r,
                            c2: c,
                        })));
                    }
                }
                Some(items)
            }
        }
    }

    fn print(&mut self, text: &str) -> Result<(), String> {
        self.printed.push(text.to_string());
        Ok(())
    }
}
