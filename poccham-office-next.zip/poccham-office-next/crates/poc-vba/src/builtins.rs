//! Built-in functions and constants of the supported VBA subset.
//!
//! Everything here is implemented in Rust; `MsgBox`/`InputBox` are handled by
//! the engine because they need access to the message log.

use crate::value::{number_to_string, Value};
use poc_core::date::DateTime;

/// Look up a VBA intrinsic constant.
pub fn constant(name: &str) -> Option<Value> {
    let v = match name.to_ascii_lowercase().as_str() {
        "vbcrlf" => Value::Str("\r\n".into()),
        "vbcr" => Value::Str("\r".into()),
        "vblf" => Value::Str("\n".into()),
        "vbnewline" => Value::Str("\r\n".into()),
        "vbtab" => Value::Str("\t".into()),
        "vbnullstring" => Value::Str(String::new()),
        "vbokonly" | "vbok" => Value::Number(0.0),
        "vbokcancel" => Value::Number(1.0),
        "vbyesno" => Value::Number(4.0),
        "vbyes" => Value::Number(6.0),
        "vbno" => Value::Number(7.0),
        "vbcancel" => Value::Number(2.0),
        "vbinformation" => Value::Number(64.0),
        "vbexclamation" => Value::Number(48.0),
        "vbcritical" => Value::Number(16.0),
        "vbquestion" => Value::Number(32.0),
        "vbuppercase" => Value::Number(1.0),
        "vblowercase" => Value::Number(2.0),
        "vbpropercase" => Value::Number(3.0),
        "vbbinarycompare" => Value::Number(0.0),
        "vbtextcompare" => Value::Number(1.0),
        "xlup" => Value::Number(-4162.0),
        "xldown" => Value::Number(-4121.0),
        "xltoleft" => Value::Number(-4159.0),
        "xltoright" => Value::Number(-4161.0),
        "xlcontinuous" => Value::Number(1.0),
        "xlmaximized" => Value::Number(-4137.0),
        "xlcenter" => Value::Number(-4108.0),
        "xlleft" => Value::Number(-4131.0),
        "xlright" => Value::Number(-4152.0),
        "msoffice" | "true" => return None,
        _ => return None,
    };
    Some(v)
}

/// Names of the intrinsic functions implemented below.
pub fn is_builtin(name: &str) -> bool {
    let n = name.to_ascii_lowercase();
    matches!(
        n.as_str(),
        "abs"
            | "array"
            | "asc"
            | "cbool"
            | "cbyte"
            | "ccur"
            | "cdbl"
            | "chr"
            | "cint"
            | "clng"
            | "csng"
            | "cstr"
            | "exp"
            | "fix"
            | "format"
            | "hex"
            | "iif"
            | "instr"
            | "int"
            | "isarray"
            | "isempty"
            | "isnull"
            | "isnumeric"
            | "join"
            | "lbound"
            | "lcase"
            | "left"
            | "len"
            | "log"
            | "ltrim"
            | "mid"
            | "replace"
            | "right"
            | "rnd"
            | "round"
            | "rtrim"
            | "sgn"
            | "space"
            | "split"
            | "sqr"
            | "str"
            | "string"
            | "strreverse"
            | "timer"
            | "trim"
            | "ubound"
            | "ucase"
            | "val"
            | "choose"
            | "date"
            | "dateadd"
            | "datediff"
            | "datepart"
            | "dateserial"
            | "day"
            | "formatcurrency"
            | "formatdatetime"
            | "formatnumber"
            | "formatpercent"
            | "hour"
            | "instrrev"
            | "isdate"
            | "isobject"
            | "minute"
            | "month"
            | "monthname"
            | "now"
            | "second"
            | "strcomp"
            | "switch"
            | "time"
            | "timeserial"
            | "typename"
            | "weekday"
            | "weekdayname"
            | "year"
    )
}

/// Call an intrinsic function.  Returns `None` when the name is not intrinsic.
pub fn call(name: &str, args: &[Value], rng: &mut u64) -> Option<Result<Value, String>> {
    if !is_builtin(name) {
        return None;
    }
    Some(eval(name, args, rng))
}

fn eval(name: &str, args: &[Value], rng: &mut u64) -> Result<Value, String> {
    let n = name.to_ascii_lowercase();
    let a = |i: usize| -> Value { args.get(i).cloned().unwrap_or(Value::Empty) };
    let num = |i: usize| -> Result<f64, String> { a(i).as_number() };
    let s = |i: usize| -> String { a(i).as_str() };

    match n.as_str() {
        "len" => Ok(Value::Number(s(0).chars().count() as f64)),
        "left" => {
            let count = num(1)?;
            Ok(Value::Str(
                s(0).chars().take(count.max(0.0) as usize).collect(),
            ))
        }
        "right" => {
            let count = num(1)?.max(0.0) as usize;
            let text: Vec<char> = s(0).chars().collect();
            let start = text.len().saturating_sub(count);
            Ok(Value::Str(text[start..].iter().collect()))
        }
        "mid" => {
            let start = (num(1)? as i64).max(1) as usize;
            let chars: Vec<char> = s(0).chars().collect();
            let len = if args.len() > 2 {
                (num(2)? as i64).max(0) as usize
            } else {
                chars.len()
            };
            let from = (start - 1).min(chars.len());
            let to = (from + len).min(chars.len());
            Ok(Value::Str(chars[from..to].iter().collect()))
        }
        "trim" => Ok(Value::Str(s(0).trim().to_string())),
        "ltrim" => Ok(Value::Str(s(0).trim_start().to_string())),
        "rtrim" => Ok(Value::Str(s(0).trim_end().to_string())),
        "ucase" => Ok(Value::Str(s(0).to_uppercase())),
        "lcase" => Ok(Value::Str(s(0).to_lowercase())),
        "strreverse" => Ok(Value::Str(s(0).chars().rev().collect())),
        "instr" => {
            // InStr([start,] haystack, needle)
            let (start, hay, needle) = if args.len() >= 3 {
                (num(0)?.max(1.0) as usize, s(1), s(2))
            } else {
                (1, s(0), s(1))
            };
            let hay_chars: Vec<char> = hay.chars().collect();
            let from = (start - 1).min(hay_chars.len());
            let tail: String = hay_chars[from..].iter().collect();
            Ok(Value::Number(match tail.find(&needle) {
                Some(byte_idx) => {
                    let char_idx = tail[..byte_idx].chars().count();
                    (from + char_idx + 1) as f64
                }
                None => 0.0,
            }))
        }
        "replace" => Ok(Value::Str(
            s(0).replace(&s(1), &if args.len() > 2 { s(2) } else { String::new() }),
        )),
        "split" => {
            let text = s(0);
            let delim = if args.len() > 1 {
                s(1)
            } else {
                " ".to_string()
            };
            let items: Vec<Value> = if delim.is_empty() {
                text.chars().map(|c| Value::Str(c.to_string())).collect()
            } else {
                text.split(delim.as_str())
                    .map(|p| Value::Str(p.to_string()))
                    .collect()
            };
            Ok(Value::Array { lower: 0, items })
        }
        "join" => match &a(0) {
            Value::Array { items, .. } => {
                let delim = if args.len() > 1 { s(1) } else { String::new() };
                Ok(Value::Str(
                    items
                        .iter()
                        .map(|v| v.as_str())
                        .collect::<Vec<_>>()
                        .join(&delim),
                ))
            }
            other => Err(format!(
                "Join には配列が必要です ({} が渡されました)",
                other.type_name()
            )),
        },
        "array" => Ok(Value::Array {
            lower: 0,
            items: args.to_vec(),
        }),
        "ubound" => match &a(0) {
            Value::Array { lower, items } => {
                Ok(Value::Number((lower + items.len() as i64 - 1) as f64))
            }
            other => Err(format!(
                "UBound には配列が必要です ({} が渡されました)",
                other.type_name()
            )),
        },
        "lbound" => match &a(0) {
            Value::Array { lower, .. } => Ok(Value::Number(*lower as f64)),
            other => Err(format!(
                "LBound には配列が必要です ({} が渡されました)",
                other.type_name()
            )),
        },
        "str" => {
            let v = num(0)?;
            Ok(Value::Str(if v >= 0.0 {
                format!(" {}", number_to_string(v))
            } else {
                number_to_string(v)
            }))
        }
        "val" => {
            let text = s(0);
            let mut out = String::new();
            let mut seen_dot = false;
            for (i, c) in text.trim().chars().enumerate() {
                if c.is_ascii_digit() {
                    out.push(c);
                } else if c == '.' && !seen_dot {
                    seen_dot = true;
                    out.push(c);
                } else if (c == '-' || c == '+') && i == 0 {
                    out.push(c);
                } else if c.is_whitespace() {
                    continue;
                } else {
                    break;
                }
            }
            Ok(Value::Number(out.parse().unwrap_or(0.0)))
        }
        "cstr" => Ok(Value::Str(s(0))),
        "cint" | "clng" => {
            let v = num(0)?;
            Ok(Value::Number(round_half_even(v)))
        }
        "cdbl" | "csng" | "ccur" => Ok(Value::Number(num(0)?)),
        "cbool" => Ok(Value::Bool(a(0).as_bool())),
        "cbyte" => Ok(Value::Number(num(0)? as i64 as f64)),
        "abs" => Ok(Value::Number(num(0)?.abs())),
        "int" => Ok(Value::Number(num(0)?.floor())),
        "fix" => Ok(Value::Number(num(0)?.trunc())),
        "sgn" => {
            let v = num(0)?;
            Ok(Value::Number(if v > 0.0 {
                1.0
            } else if v < 0.0 {
                -1.0
            } else {
                0.0
            }))
        }
        "sqr" => {
            let v = num(0)?;
            if v < 0.0 {
                Err("引数が無効です (Sqr)".into())
            } else {
                Ok(Value::Number(v.sqrt()))
            }
        }
        "exp" => Ok(Value::Number(num(0)?.exp())),
        "log" => {
            let v = num(0)?;
            if v <= 0.0 {
                Err("引数が無効です (Log)".into())
            } else {
                Ok(Value::Number(v.ln()))
            }
        }
        "rnd" => {
            // Deterministic xorshift so macro runs are reproducible in tests.
            let mut x = *rng;
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            *rng = x;
            Ok(Value::Number((x % 1_000_003) as f64 / 1_000_003.0))
        }
        "round" => {
            let v = num(0)?;
            let digits = if args.len() > 1 { num(1)? as i32 } else { 0 };
            let factor = 10f64.powi(digits);
            Ok(Value::Number(round_half_even(v * factor) / factor))
        }
        "format" => Ok(Value::Str(crate::format::format_value(&a(0), &s(1))?)),
        "isnumeric" => Ok(Value::Bool(match &a(0) {
            Value::Number(_) | Value::Bool(_) => true,
            Value::Str(text) => text.trim().parse::<f64>().is_ok(),
            _ => false,
        })),
        "isempty" => Ok(Value::Bool(a(0).is_empty())),
        "isnull" => Ok(Value::Bool(matches!(a(0), Value::Null))),
        "isarray" => Ok(Value::Bool(matches!(a(0), Value::Array { .. }))),
        "chr" => {
            let code = num(0)? as u32;
            Ok(Value::Str(
                char::from_u32(code)
                    .map(|c| c.to_string())
                    .unwrap_or_default(),
            ))
        }
        "asc" => Ok(Value::Number(
            s(0).chars().next().map(|c| c as u32).unwrap_or(0) as f64,
        )),
        "hex" => Ok(Value::Str(format!("{:X}", num(0)? as i64))),
        "space" => Ok(Value::Str(" ".repeat(num(0)?.max(0.0) as usize))),
        "string" => {
            let count = num(0)?.max(0.0) as usize;
            let ch = match &a(1) {
                Value::Str(s) => s.chars().next().unwrap_or(' '),
                other => char::from_u32(other.as_number()? as u32).unwrap_or(' '),
            };
            Ok(Value::Str(ch.to_string().repeat(count)))
        }
        "iif" => {
            if a(0).as_bool() {
                Ok(a(1))
            } else {
                Ok(a(2))
            }
        }
        // ---------------------------------------------------------- date & time
        "dateserial" => {
            let y = num(0)? as i32;
            let m = num(1)? as i32;
            let d = num(2)? as i32;
            let year = y + (m - 1).div_euclid(12);
            let month = ((m - 1).rem_euclid(12) + 1) as u32;
            let base = DateTime::new(year, month, 1);
            Ok(Value::Number(base.excel_serial() + (d - 1) as f64))
        }
        "timeserial" => {
            let h = num(0)?;
            let m = num(1)?;
            let sec = num(2)?;
            Ok(Value::Number(
                ((h * 3600.0 + m * 60.0 + sec) / 86_400.0).rem_euclid(1.0),
            ))
        }
        "date" => Ok(Value::Number(DateTime::today_utc().excel_serial().floor())),
        "time" => Ok(Value::Number(DateTime::now_utc().excel_serial().fract())),
        "now" => Ok(Value::Number(DateTime::now_utc().excel_serial())),
        "year" => Ok(Value::Number(part(0, num(0)?)? as f64)),
        "month" => Ok(Value::Number(part(1, num(0)?)? as f64)),
        "day" => Ok(Value::Number(part(2, num(0)?)? as f64)),
        "hour" => Ok(Value::Number(part(3, num(0)?)? as f64)),
        "minute" => Ok(Value::Number(part(4, num(0)?)? as f64)),
        "second" => Ok(Value::Number(part(5, num(0)?)? as f64)),
        "weekday" => {
            let dt = DateTime::from_serial(num(0)?);
            let first_day = if args.len() > 1 { num(1)? as u32 } else { 1 };
            let sun0 = dt.weekday_sun0();
            Ok(Value::Number(
                (((sun0 + 7 - (first_day + 6) % 7) % 7) + 1) as f64,
            ))
        }
        "dateadd" => {
            let unit = s(0).to_ascii_lowercase();
            let amount = num(1)?;
            let base = DateTime::from_serial(num(2)?);
            let serial = match unit.as_str() {
                "d" => base.excel_serial() + amount,
                "m" => base.add_months(amount as i32).excel_serial(),
                "yyyy" => base
                    .add_months((amount as i32).saturating_mul(12))
                    .excel_serial(),
                "h" => base.excel_serial() + amount / 24.0,
                "n" => base.excel_serial() + amount / 1440.0,
                "s" => base.excel_serial() + amount / 86_400.0,
                "q" => base
                    .add_months((amount as i32).saturating_mul(3))
                    .excel_serial(),
                _ => return Err(format!("DateAdd の単位が不正です: {unit}")),
            };
            Ok(Value::Number(serial))
        }
        "datediff" => {
            let unit = s(0).to_ascii_lowercase();
            let a0 = DateTime::from_serial(num(1)?);
            let b0 = DateTime::from_serial(num(2)?);
            let days = b0.excel_serial() - a0.excel_serial();
            let value = match unit.as_str() {
                "d" => days.floor(),
                "h" => (days * 24.0).floor(),
                "n" => (days * 1440.0).floor(),
                "s" => (days * 86_400.0).floor(),
                "m" | "yyyy" | "q" => {
                    let months = (b0.year - a0.year) as f64 * 12.0
                        + (b0.month as f64 - a0.month as f64)
                        + (b0.day as f64 - a0.day as f64) / 31.0;
                    let months = months.trunc();
                    match unit.as_str() {
                        "m" => months,
                        "q" => (months / 3.0).trunc(),
                        _ => (months / 12.0).trunc(),
                    }
                }
                _ => return Err(format!("DateDiff の単位が不正です: {unit}")),
            };
            Ok(Value::Number(value))
        }
        "datepart" => {
            let unit = s(0).to_ascii_lowercase();
            let serial = num(1)?;
            let v = match unit.as_str() {
                "yyyy" => part(0, serial)? as f64,
                "m" => part(1, serial)? as f64,
                "d" => part(2, serial)? as f64,
                "h" => part(3, serial)? as f64,
                "n" => part(4, serial)? as f64,
                "s" => part(5, serial)? as f64,
                "q" => ((part(1, serial)? - 1) / 3 + 1) as f64,
                "w" => DateTime::from_serial(serial).weekday_sun0() as f64 + 1.0,
                _ => return Err(format!("DatePart の単位が不正です: {unit}")),
            };
            Ok(Value::Number(v))
        }
        "monthname" => {
            let m = num(0)? as u32;
            const NAMES: [&str; 12] = [
                "1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月",
                "12月",
            ];
            Ok(Value::Str(
                NAMES
                    .get(m.saturating_sub(1) as usize)
                    .unwrap_or(&"")
                    .to_string(),
            ))
        }
        "weekdayname" => {
            let w = num(0)? as u32;
            const NAMES: [&str; 7] = [
                "日曜日",
                "月曜日",
                "火曜日",
                "水曜日",
                "木曜日",
                "金曜日",
                "土曜日",
            ];
            Ok(Value::Str(
                NAMES
                    .get((w.saturating_sub(1) % 7) as usize)
                    .unwrap_or(&"")
                    .to_string(),
            ))
        }
        "isdate" => Ok(Value::Bool(match &a(0) {
            Value::Number(n) => *n >= 0.0 && *n < 2_958_466.0,
            Value::Str(text) => DateTime::parse(text).is_some(),
            _ => false,
        })),
        "timer" => Ok(Value::Number(crate::now_seconds() % 86_400.0)),
        // ------------------------------------------------------------ misc
        "isobject" => Ok(Value::Bool(matches!(a(0), Value::Object(_)))),
        "typename" => Ok(Value::Str(
            match &a(0) {
                Value::Empty => "Empty",
                Value::Null => "Null",
                Value::Bool(_) => "Boolean",
                Value::Number(_) => "Double",
                Value::Str(_) => "String",
                Value::Object(_) => "Object",
                Value::Array { .. } => "Variant()",
            }
            .into(),
        )),
        "choose" => {
            let idx = num(0)?.max(0.0) as usize;
            if idx >= 1 && idx < args.len() {
                Ok(args[idx].clone())
            } else {
                Ok(Value::Null)
            }
        }
        "switch" => {
            let mut i = 0;
            while i + 1 < args.len() {
                if args[i].as_bool() {
                    return Ok(args[i + 1].clone());
                }
                i += 2;
            }
            Ok(Value::Null)
        }
        "instrrev" => {
            let hay = s(0);
            let needle = s(1);
            match hay.rfind(&needle) {
                Some(byte_pos) => {
                    let char_pos = hay[..byte_pos].chars().count() + 1;
                    Ok(Value::Number(char_pos as f64))
                }
                None => Ok(Value::Number(0.0)),
            }
        }
        "strcomp" => {
            let x = s(0);
            let y = s(1);
            Ok(Value::Number(match x.cmp(&y) {
                std::cmp::Ordering::Less => -1.0,
                std::cmp::Ordering::Equal => 0.0,
                std::cmp::Ordering::Greater => 1.0,
            }))
        }
        "formatdatetime" => {
            let serial = num(0)?;
            let dt = DateTime::from_serial(serial);
            let clock = format!("{}:{:02}", dt.hour, dt.minute);
            // Time-only serials print just the clock, like VBA.
            Ok(Value::Str(if serial < 1.0 {
                clock
            } else {
                format!("{}/{}/{} {clock}", dt.year, dt.month, dt.day)
            }))
        }
        "formatnumber" | "formatcurrency" | "formatpercent" => {
            let code = match name {
                "formatcurrency" => r#"¥#,##0.00"#,
                "formatpercent" => "0.00%",
                _ => "#,##0.00",
            };
            let fv = match &a(0) {
                Value::Number(n) => poc_core::numfmt::FormatValue::Number(*n),
                other => poc_core::numfmt::FormatValue::Text(other.as_str()),
            };
            Ok(Value::Str(poc_core::numfmt::format_value(code, &fv)))
        }
        other => Err(format!("内部エラー: 組み込み関数 {other} が未実装です")),
    }
}

/// Pull one component out of a date serial (0 = year … 5 = second).
fn part(which: usize, serial: f64) -> Result<i64, String> {
    let dt = DateTime::from_serial(serial);
    Ok(match which {
        0 => dt.year as i64,
        1 => dt.month as i64,
        2 => dt.day as i64,
        3 => dt.hour as i64,
        4 => dt.minute as i64,
        _ => dt.second as i64,
    })
}

/// VBA's `Round`/`CInt` use banker's rounding (round half to even).
fn round_half_even(v: f64) -> f64 {
    let floor = v.floor();
    let diff = v - floor;
    if (diff - 0.5).abs() < 1e-12 {
        if (floor as i64) % 2 == 0 {
            floor
        } else {
            floor + 1.0
        }
    } else {
        v.round()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn call1(name: &str, args: &[Value]) -> Value {
        let mut rng = 12345;
        call(name, args, &mut rng).unwrap().unwrap()
    }

    #[test]
    fn strings() {
        assert_eq!(call1("Len", &[Value::Str("日本語".into())]).as_str(), "3");
        assert_eq!(
            call1(
                "Mid",
                &[
                    Value::Str("abcdef".into()),
                    Value::Number(2.0),
                    Value::Number(3.0)
                ]
            )
            .as_str(),
            "bcd"
        );
        assert_eq!(call1("UCase", &[Value::Str("abc".into())]).as_str(), "ABC");
        assert_eq!(
            call1(
                "InStr",
                &[Value::Str("hello".into()), Value::Str("ll".into())]
            )
            .as_str(),
            "3"
        );
    }

    #[test]
    fn numbers_and_rounding() {
        assert_eq!(call1("CInt", &[Value::Number(2.5)]).as_str(), "2");
        assert_eq!(call1("CInt", &[Value::Number(3.5)]).as_str(), "4");
        assert_eq!(call1("Int", &[Value::Number(-1.2)]).as_str(), "-2");
        assert_eq!(call1("Fix", &[Value::Number(-1.2)]).as_str(), "-1");
        assert_eq!(call1("Val", &[Value::Str("12abc".into())]).as_str(), "12");
    }

    #[test]
    fn arrays() {
        let split = call1(
            "Split",
            &[Value::Str("a,b,c".into()), Value::Str(",".into())],
        );
        assert_eq!(call1("UBound", std::slice::from_ref(&split)).as_str(), "2");
        assert_eq!(
            call1("Join", &[split, Value::Str("-".into())]).as_str(),
            "a-b-c"
        );
    }

    #[test]
    fn constants_and_format() {
        assert_eq!(constant("vbCrLf").unwrap().as_str(), "\r\n");
        assert!(constant("unknown_thing").is_none());
        assert_eq!(
            call1(
                "Format",
                &[Value::Number(1234.5), Value::Str("#,##0.00".into())]
            )
            .as_str(),
            "1,234.50"
        );
        assert_eq!(
            call1("Format", &[Value::Number(0.256), Value::Str("0.0%".into())]).as_str(),
            "25.6%"
        );
    }
}
