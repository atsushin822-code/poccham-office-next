//! Tokeniser for the Visual Basic for Applications dialect used by Excel.
//!
//! Handles: identifiers with `$ % & ! # @` type suffixes, numbers (decimal,
//! exponent, `&H`, `&O`, type suffix), string literals with `""` escapes,
//! `'` and `Rem` comments, `_` line continuation and the full operator set.

use crate::VbaError;

#[derive(Debug, Clone, PartialEq)]
pub enum Tok {
    Ident(String),
    Num(f64),
    Str(String),
    Op(String),
    Newline,
    Eof,
}

impl Tok {
    pub fn is_ident(&self, keyword: &str) -> bool {
        matches!(self, Tok::Ident(s) if s.eq_ignore_ascii_case(keyword))
    }
    pub fn is_op(&self, op: &str) -> bool {
        matches!(self, Tok::Op(s) if s == op)
    }
    pub fn describe(&self) -> String {
        match self {
            Tok::Ident(s) => format!("`{s}`"),
            Tok::Num(n) => format!("number `{n}`"),
            Tok::Str(_) => "string literal".to_string(),
            Tok::Op(s) => format!("`{s}`"),
            Tok::Newline => "end of line".to_string(),
            Tok::Eof => "end of module".to_string(),
        }
    }
}

/// A token plus the 1-based source line it came from.
#[derive(Debug, Clone, PartialEq)]
pub struct Token {
    pub tok: Tok,
    pub line: u32,
}

pub fn tokenize(src: &str) -> Result<Vec<Token>, VbaError> {
    let chars: Vec<char> = src.chars().collect();
    let mut out = Vec::new();
    let mut i = 0usize;
    let mut line = 1u32;
    while i < chars.len() {
        let c = chars[i];
        if c == '\n' {
            out.push(Token {
                tok: Tok::Newline,
                line,
            });
            line += 1;
            i += 1;
            continue;
        }
        if c == '\r' || c == ' ' || c == '\t' || c == '\u{feff}' {
            i += 1;
            continue;
        }
        // Line continuation: `_` followed only by whitespace/comment.
        if c == '_' {
            let mut j = i + 1;
            while j < chars.len() && (chars[j] == ' ' || chars[j] == '\t') {
                j += 1;
            }
            if j >= chars.len() || chars[j] == '\n' || chars[j] == '\r' || chars[j] == '\'' {
                if j < chars.len() && chars[j] == '\'' {
                    while j < chars.len() && chars[j] != '\n' {
                        j += 1;
                    }
                }
                i = j;
                continue;
            }
        }
        // Comments
        if c == '\'' {
            while i < chars.len() && chars[i] != '\n' {
                i += 1;
            }
            continue;
        }
        if (c == 'R' || c == 'r')
            && chars
                .get(i + 1)
                .map(|c| *c == 'e' || *c == 'E')
                .unwrap_or(false)
            && chars
                .get(i + 2)
                .map(|c| *c == 'm' || *c == 'M')
                .unwrap_or(false)
            && chars.get(i + 3).map(|c| c.is_whitespace()).unwrap_or(true)
            && (i == 0 || !is_ident_char(chars[i - 1]))
        {
            while i < chars.len() && chars[i] != '\n' {
                i += 1;
            }
            continue;
        }
        // Strings
        if c == '"' {
            i += 1;
            let mut s = String::new();
            loop {
                match chars.get(i) {
                    None => {
                        return Err(VbaError::syntax("unterminated string literal", line));
                    }
                    Some('"') => {
                        if chars.get(i + 1) == Some(&'"') {
                            s.push('"');
                            i += 2;
                        } else {
                            i += 1;
                            break;
                        }
                    }
                    Some('\n') => {
                        return Err(VbaError::syntax("unterminated string literal", line));
                    }
                    Some(ch) => {
                        s.push(*ch);
                        i += 1;
                    }
                }
            }
            out.push(Token {
                tok: Tok::Str(s),
                line,
            });
            continue;
        }
        // Numbers
        if c.is_ascii_digit()
            || (c == '.'
                && chars
                    .get(i + 1)
                    .map(|c| c.is_ascii_digit())
                    .unwrap_or(false))
        {
            let start = i;
            if c == '&' {
                // handled below (hex/octal)
            }
            while i < chars.len() && is_number_char(chars[i]) {
                i += 1;
            }
            let text: String = chars[start..i].iter().collect();
            let cleaned = text.trim_end_matches(['%', '&', '!', '#', '@']);
            let value: f64 = cleaned
                .parse()
                .map_err(|_| VbaError::syntax(format!("bad number literal `{text}`"), line))?;
            out.push(Token {
                tok: Tok::Num(value),
                line,
            });
            continue;
        }
        // &H / &O literals
        if c == '&' {
            if let Some(next) = chars.get(i + 1) {
                let radix = match next.to_ascii_uppercase() {
                    'H' => Some(16),
                    'O' => Some(8),
                    _ => None,
                };
                if let Some(radix) = radix {
                    i += 2;
                    let start = i;
                    while i < chars.len() && (chars[i].is_ascii_alphanumeric()) && chars[i] != ' ' {
                        i += 1;
                    }
                    let text: String = chars[start..i]
                        .iter()
                        .collect::<String>()
                        .trim_end_matches(['&', '%'])
                        .to_string();
                    let value = i64::from_str_radix(&text, radix)
                        .map_err(|_| VbaError::syntax(format!("bad literal `&{text}`"), line))?;
                    out.push(Token {
                        tok: Tok::Num(value as f64),
                        line,
                    });
                    continue;
                }
            }
        }
        // Identifiers / keywords
        if is_ident_start(c) {
            let start = i;
            while i < chars.len() && is_ident_char(chars[i]) {
                i += 1;
            }
            let mut name: String = chars[start..i].iter().collect();
            // Type suffix is not part of the name for our purposes.
            if let Some(last) = name.chars().last() {
                if matches!(last, '$' | '%' | '&' | '!' | '#') && name.len() > 1 {
                    name.pop();
                }
            }
            out.push(Token {
                tok: Tok::Ident(name),
                line,
            });
            continue;
        }
        // Operators
        let two: String = chars[i..(i + 2).min(chars.len())].iter().collect();
        if matches!(two.as_str(), "<>" | "<=" | ">=" | "=<" | "=>" | ":=") {
            out.push(Token {
                tok: if two == ":=" {
                    Tok::Op("=".into())
                } else {
                    Tok::Op(two)
                },
                line,
            });
            i += 2;
            continue;
        }
        if "()=<>+-*/\\^&,.!:;".contains(c) {
            out.push(Token {
                tok: Tok::Op(c.to_string()),
                line,
            });
            i += 1;
            continue;
        }
        return Err(VbaError::syntax(
            format!("unexpected character `{c}`"),
            line,
        ));
    }
    out.push(Token {
        tok: Tok::Eof,
        line,
    });
    Ok(out)
}

fn is_ident_start(c: char) -> bool {
    c.is_alphabetic() || c == '_'
}

fn is_ident_char(c: char) -> bool {
    c.is_alphanumeric() || c == '_' || matches!(c, '$' | '%' | '&' | '!' | '#')
}

fn is_number_char(c: char) -> bool {
    c.is_ascii_digit()
        || c == '.'
        || c == 'e'
        || c == 'E'
        || matches!(c, '%' | '&' | '!' | '#' | '@')
}

#[cfg(test)]
mod tests {
    use super::*;

    fn idents(src: &str) -> Vec<String> {
        tokenize(src)
            .unwrap()
            .into_iter()
            .filter_map(|t| match t.tok {
                Tok::Ident(s) => Some(s),
                _ => None,
            })
            .collect()
    }

    #[test]
    fn comments_and_strings() {
        let toks = tokenize("x = \"a\"\"b\" ' comment\nRem another\ny = 1").unwrap();
        let strs: Vec<&String> = toks
            .iter()
            .filter_map(|t| match &t.tok {
                Tok::Str(s) => Some(s),
                _ => None,
            })
            .collect();
        assert_eq!(strs, vec!["a\"b"]);
        assert_eq!(idents("x = 1 ' c\ny = 2"), vec!["x", "y"]);
    }

    #[test]
    fn numbers() {
        let toks = tokenize("1.5 2E3 &H20 &O17 5%").unwrap();
        let nums: Vec<f64> = toks
            .iter()
            .filter_map(|t| match t.tok {
                Tok::Num(n) => Some(n),
                _ => None,
            })
            .collect();
        assert_eq!(nums, vec![1.5, 2000.0, 32.0, 15.0, 5.0]);
    }

    #[test]
    fn line_continuation() {
        assert_eq!(idents("x = 1 + _\n    2"), vec!["x"]);
    }

    #[test]
    fn comparison_operators() {
        let toks = tokenize("a <> b").unwrap();
        assert!(toks.iter().any(|t| t.tok.is_op("<>")));
    }

    #[test]
    fn type_suffixes_are_stripped() {
        assert_eq!(idents("Dim s$"), vec!["Dim", "s"]);
    }
}
