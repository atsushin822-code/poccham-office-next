//! `Format()` number patterns — the subset that real-world macros use
//! (`0`, `0.00`, `#,##0`, `0%`, `0.00%`, `¥#,##0`, and a few date tokens).

use crate::value::{number_to_string, Value};

/// Format a value with a VBA format string.
pub fn format_value(value: &Value, pattern: &str) -> Result<String, String> {
    if pattern.is_empty() {
        return Ok(value.as_str());
    }
    let lower = pattern.to_ascii_lowercase();
    // Date/time patterns are evaluated against a numeric serial date.
    if lower.contains("yyyy")
        || lower.contains("mm/")
        || lower.contains("dd")
        || lower.contains("hh:")
    {
        return match value {
            Value::Number(serial) => Ok(format_serial_date(*serial, pattern)),
            Value::Str(s) => Ok(s.clone()),
            other => Ok(other.as_str()),
        };
    }
    let n = value.as_number()?;
    let percent = pattern.contains('%');
    let n = if percent { n * 100.0 } else { n };
    let has_thousands = pattern.contains("#,##") || pattern.contains(",#");
    let decimals = pattern
        .split('.')
        .nth(1)
        .map(|frac| frac.chars().filter(|c| *c == '0' || *c == '#').count())
        .unwrap_or(0);
    let prefix: String = pattern
        .chars()
        .take_while(|c| !matches!(c, '0' | '#'))
        .filter(|c| *c != '"')
        .collect();
    let suffix: String = pattern
        .chars()
        .rev()
        .take_while(|c| !matches!(c, '0' | '#'))
        .collect::<Vec<_>>()
        .into_iter()
        .rev()
        .filter(|c| *c != '"')
        .collect();

    let mut body = if decimals == 0 {
        number_to_string(n.round())
    } else {
        let rounded = format!("{n:.decimals$}");
        // Trim trailing zeros only when the pattern used `#` for them.
        let frac_pattern = pattern.split('.').nth(1).unwrap_or("");
        let keep = frac_pattern.chars().take_while(|c| *c == '0').count();
        let (int_part, frac_part) = rounded.split_once('.').unwrap_or((&rounded, ""));
        let mut frac = frac_part.to_string();
        while frac.len() > keep && frac.ends_with('0') {
            frac.pop();
        }
        if frac.is_empty() {
            int_part.to_string()
        } else {
            format!("{int_part}.{frac}")
        }
    };
    if has_thousands {
        body = group_thousands(&body);
    }
    if n < 0.0 && body.starts_with('-') {
        body.remove(0);
        return Ok(format!("-{prefix}{body}{suffix}"));
    }
    Ok(format!("{prefix}{body}{suffix}"))
}

fn group_thousands(s: &str) -> String {
    let (int_part, frac) = match s.split_once('.') {
        Some((a, b)) => (a.to_string(), Some(b.to_string())),
        None => (s.to_string(), None),
    };
    let negative = int_part.starts_with('-');
    let digits: Vec<char> = int_part.trim_start_matches('-').chars().collect();
    let mut grouped = String::new();
    for (i, c) in digits.iter().enumerate() {
        if i > 0 && (digits.len() - i) % 3 == 0 {
            grouped.push(',');
        }
        grouped.push(*c);
    }
    let mut out = String::new();
    if negative {
        out.push('-');
    }
    out.push_str(&grouped);
    if let Some(frac) = frac {
        out.push('.');
        out.push_str(&frac);
    }
    out
}

/// Render an Excel serial date (1900 system) with `yyyy`/`mm`/`dd`/`hh`/`nn`/`ss`.
fn format_serial_date(serial: f64, pattern: &str) -> String {
    // Serial 1 = 1900-01-01; Excel's 1900 leap-year bug shifts everything
    // after 1900-02-28 by one day, which is folded into this offset.
    let days = serial.trunc() as i64 - 25569; // days since 1970-01-01
    let secs_of_day = ((serial.fract()) * 86_400.0).round() as i64;
    let unix = days * 86_400 + secs_of_day;
    let (y, mo, d, hh, mi, ss) = civil_from_unix(unix);
    let mut out = String::new();
    let mut rest = pattern.to_string();
    while !rest.is_empty() {
        let lower = rest.to_ascii_lowercase();
        if lower.starts_with("yyyy") {
            out.push_str(&format!("{y:04}"));
            rest = rest[4..].to_string();
        } else if lower.starts_with("yy") {
            out.push_str(&format!("{:02}", y % 100));
            rest = rest[2..].to_string();
        } else if lower.starts_with("mm") {
            out.push_str(&format!("{mo:02}"));
            rest = rest[2..].to_string();
        } else if lower.starts_with("dd") {
            out.push_str(&format!("{d:02}"));
            rest = rest[2..].to_string();
        } else if lower.starts_with("hh") {
            out.push_str(&format!("{hh:02}"));
            rest = rest[2..].to_string();
        } else if lower.starts_with("nn") {
            out.push_str(&format!("{mi:02}"));
            rest = rest[2..].to_string();
        } else if lower.starts_with("ss") {
            out.push_str(&format!("{ss:02}"));
            rest = rest[2..].to_string();
        } else {
            let c = rest.chars().next().unwrap();
            out.push(c);
            rest = rest[c.len_utf8()..].to_string();
        }
    }
    out
}

fn civil_from_unix(unix: i64) -> (i64, u32, u32, u32, u32, u32) {
    let days = unix.div_euclid(86_400);
    let rem = unix.rem_euclid(86_400);
    let z = days + 719_468;
    let era = if z >= 0 { z } else { z - 146_096 } / 146_097;
    let doe = (z - era * 146_097) as u64;
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let y = yoe as i64 + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = (doy - (153 * mp + 2) / 5 + 1) as u32;
    let m = if mp < 10 { mp + 3 } else { mp - 9 } as u32;
    let y = if m <= 2 { y + 1 } else { y };
    (
        y,
        m,
        d,
        (rem / 3600) as u32,
        ((rem % 3600) / 60) as u32,
        (rem % 60) as u32,
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn integer_and_decimal_patterns() {
        assert_eq!(format_value(&Value::Number(3.4), "0").unwrap(), "3");
        assert_eq!(format_value(&Value::Number(3.6), "0").unwrap(), "4");
        assert_eq!(
            format_value(&Value::Number(std::f64::consts::PI), "0.00").unwrap(),
            "3.14"
        );
        assert_eq!(format_value(&Value::Number(3.0), "0.00").unwrap(), "3.00");
        assert_eq!(format_value(&Value::Number(3.5), "0.##").unwrap(), "3.5");
    }

    #[test]
    fn thousands_and_currency() {
        assert_eq!(
            format_value(&Value::Number(1234567.0), "#,##0").unwrap(),
            "1,234,567"
        );
        assert_eq!(
            format_value(&Value::Number(-1234.5), "#,##0.00").unwrap(),
            "-1,234.50"
        );
        assert_eq!(
            format_value(&Value::Number(1200.0), "¥#,##0").unwrap(),
            "¥1,200"
        );
    }

    #[test]
    fn percent() {
        assert_eq!(format_value(&Value::Number(0.25), "0%").unwrap(), "25%");
        assert_eq!(
            format_value(&Value::Number(0.2567), "0.00%").unwrap(),
            "25.67%"
        );
    }

    #[test]
    fn dates() {
        // 45292 = 2024-01-01 in the Excel 1900 system
        assert_eq!(
            format_value(&Value::Number(45292.0), "yyyy-mm-dd").unwrap(),
            "2024-01-01"
        );
        assert_eq!(
            format_value(&Value::Number(45292.5), "yyyy/mm/dd hh:nn").unwrap(),
            "2024/01/01 12:00"
        );
    }
}
