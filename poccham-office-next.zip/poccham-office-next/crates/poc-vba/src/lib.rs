//! VBA-compatible macro engine (subset) for Poccham Office Next.
//!
//! # What this is
//!
//! A from-scratch Visual Basic for Applications interpreter that executes the
//! parts of the language used by the overwhelming majority of business
//! macros: procedures, `Dim`/arrays, `If`/`ElseIf`, `For`/`For Each`,
//! `Do`/`While`, `With`, `Exit`, `On Error Resume Next`, arithmetic/string
//! operators, `Like`, ~60 intrinsic functions, and the Excel object model
//! surface (`Range`, `Cells`, `Sheets`, `Value`, `Formula`, `Offset`, ...).
//!
//! # What this is not (yet)
//!
//! * `Select Case`, `GoTo` labels, `Declare` (Win32 API), class modules,
//!   events, `UserForm`s, `Collection`/`Dictionary`, `On Error GoTo <label>`.
//! * `ByRef` semantics for scalars (arguments are passed by value; arrays are
//!   copied back like `ByRef`).
//!
//! Unsupported constructs are rejected at parse time with a clear Japanese
//! message, never silently ignored — a macro that cannot run correctly must
//! not appear to succeed.
//!
//! # Example
//!
//! ```
//! use poc_vba::{parse_module, Engine, ExcelHost, Value};
//! use poc_core::xlsx::{Cell, Workbook};
//!
//! let src = r#"
//! Sub FillReport()
//!     Dim i As Long
//!     For i = 1 To 3
//!         Cells(i + 1, 1).Value = "Item " & i
//!         Cells(i + 1, 2).Value = i * 100
//!     Next i
//!     Range("C2").Formula = "=SUM(B2:B4)"
//! End Sub
//! "#;
//! let module = parse_module(src, "Module1").unwrap();
//! let mut wb = Workbook::new();
//! let mut host = ExcelHost::new(&mut wb);
//! Engine::new(&module, &mut host).run("FillReport", vec![]).unwrap();
//! assert_eq!(wb.sheet().get(1, 0).unwrap().as_text(), "Item 1");
//! assert_eq!(wb.sheet().get(1, 1).unwrap().as_number(), Some(100.0));
//! ```

#![forbid(unsafe_code)]

pub mod ast;
pub mod builtins;
pub mod excel;
pub mod format;
pub mod interp;
pub mod lexer;
pub mod parser;
pub mod value;

pub use ast::{Expr, Module, Proc, ProcKind, Stmt};
pub use excel::ExcelHost;
pub use interp::{Engine, Host, NullHost, RunOutcome};
pub use parser::parse_module;
pub use value::Value;

use std::fmt;

/// A syntax or runtime error, in the shape VBA reports them.
#[derive(Debug, Clone, PartialEq)]
pub struct VbaError {
    pub message: String,
    pub line: Option<u32>,
}

impl VbaError {
    pub fn syntax(message: impl Into<String>, line: u32) -> Self {
        VbaError {
            message: message.into(),
            line: Some(line),
        }
    }
    pub fn runtime(message: impl Into<String>, line: Option<u32>) -> Self {
        VbaError {
            message: message.into(),
            line,
        }
    }
}

impl fmt::Display for VbaError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.line {
            Some(line) => write!(f, "{} (行 {line})", self.message),
            None => write!(f, "{}", self.message),
        }
    }
}

impl std::error::Error for VbaError {}

/// Seconds since the Unix epoch as a float (used by `Timer`, `Now`).
pub fn now_seconds() -> f64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs_f64())
        .unwrap_or(0.0)
}
