//! Runtime values for the macro engine.

use std::fmt;

/// A VBA value.  `Object` holds an opaque handle that only the host can
/// interpret (for Excel this is a resolved sheet/range reference).
#[derive(Debug, Clone, PartialEq, Default)]
pub enum Value {
    #[default]
    Empty,
    Null,
    Bool(bool),
    Number(f64),
    Str(String),
    Object(String),
    /// One-dimensional array with an explicit lower bound (VB default 0).
    Array {
        lower: i64,
        items: Vec<Value>,
    },
}

impl Value {
    pub fn is_empty(&self) -> bool {
        matches!(self, Value::Empty)
    }

    /// VBA truthiness: 0 / Empty / "" / Null are false.
    pub fn as_bool(&self) -> bool {
        match self {
            Value::Empty | Value::Null => false,
            Value::Bool(b) => *b,
            Value::Number(n) => *n != 0.0,
            Value::Str(s) => s.eq_ignore_ascii_case("true") || s == "-1",
            Value::Object(_) => true,
            Value::Array { .. } => true,
        }
    }

    /// Numeric coercion (`CDbl`-like); strings that are not numeric are errors
    /// in VBA, and `Empty` is 0.
    pub fn as_number(&self) -> Result<f64, String> {
        match self {
            Value::Empty => Ok(0.0),
            Value::Null => Err("Invalid use of Null".into()),
            Value::Bool(b) => Ok(if *b { -1.0 } else { 0.0 }),
            Value::Number(n) => Ok(*n),
            Value::Str(s) => {
                let t = s.trim();
                if t.is_empty() {
                    return Ok(0.0);
                }
                if let Ok(n) = t.parse::<f64>() {
                    return Ok(n);
                }
                // Accept a leading currency symbol and thousands separators.
                let cleaned: String = t
                    .chars()
                    .filter(|c| !matches!(c, ',' | '¥' | '$' | ' '))
                    .collect();
                cleaned
                    .parse::<f64>()
                    .map_err(|_| format!("型が一致しません: `{s}` は数値ではありません"))
            }
            Value::Object(_) => Err("オブジェクトを数値に変換できません".into()),
            Value::Array { .. } => Err("配列を数値に変換できません".into()),
        }
    }

    /// String coercion (`CStr`-like).
    pub fn as_str(&self) -> String {
        match self {
            Value::Empty => String::new(),
            Value::Null => "Null".into(),
            Value::Bool(b) => {
                if *b {
                    "True".into()
                } else {
                    "False".into()
                }
            }
            Value::Number(n) => number_to_string(*n),
            Value::Str(s) => s.clone(),
            Value::Object(p) => p.clone(),
            Value::Array { items, .. } => items
                .iter()
                .map(|v| v.as_str())
                .collect::<Vec<_>>()
                .join(" "),
        }
    }

    pub fn as_object(&self) -> Result<&str, String> {
        match self {
            Value::Object(p) => Ok(p),
            other => Err(format!(
                "オブジェクトが要求されましたが {} が渡されました",
                other.type_name()
            )),
        }
    }

    pub fn type_name(&self) -> &'static str {
        match self {
            Value::Empty => "Empty",
            Value::Null => "Null",
            Value::Bool(_) => "Boolean",
            Value::Number(_) => "Double",
            Value::Str(_) => "String",
            Value::Object(_) => "Object",
            Value::Array { .. } => "Variant()",
        }
    }
}

/// VBA-style number to string: integers without a decimal part, `True`/`False`
/// handled by the caller.
pub fn number_to_string(n: f64) -> String {
    if !n.is_finite() {
        return if n.is_nan() {
            "NaN".into()
        } else if n > 0.0 {
            "∞".into()
        } else {
            "-∞".into()
        };
    }
    if n == n.trunc() && n.abs() < 1e15 {
        return format!("{}", n as i64);
    }
    // 15 significant digits, trailing zeros trimmed, like VBA's implicit CStr.
    let s = format!("{n:.15}");
    let s = s.trim_end_matches('0').trim_end_matches('.');
    s.to_string()
}

impl fmt::Display for Value {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.as_str())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn coercions() {
        assert_eq!(Value::Empty.as_number().unwrap(), 0.0);
        assert_eq!(Value::Str(" 12.5 ".into()).as_number().unwrap(), 12.5);
        assert_eq!(Value::Str("¥1,200".into()).as_number().unwrap(), 1200.0);
        assert!(Value::Str("abc".into()).as_number().is_err());
        assert_eq!(Value::Bool(true).as_str(), "True");
        assert!(!Value::Number(0.0).as_bool());
        assert!(Value::Str("TRUE".into()).as_bool());
    }

    #[test]
    fn number_formatting() {
        assert_eq!(number_to_string(3.0), "3");
        assert_eq!(number_to_string(-0.5), "-0.5");
        assert_eq!(number_to_string(1.25), "1.25");
        assert_eq!(number_to_string(1e20), "100000000000000000000");
    }
}
