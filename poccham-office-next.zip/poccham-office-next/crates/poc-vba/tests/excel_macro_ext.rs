//! Coverage for the extended Excel object model: range geometry helpers,
//! merge/unmerge, the in-memory clipboard, `WorksheetFunction` routing into
//! the engine, and the VBA date/inspection intrinsics.

use poc_core::xlsx::Workbook;
use poc_vba::{parse_module, Engine, ExcelHost};

fn run(src: &str, proc: &str) -> (Workbook, Vec<String>) {
    let module = parse_module(src, "M").expect("parse");
    let mut wb = Workbook::new();
    let printed;
    {
        let mut host = ExcelHost::new(&mut wb);
        let mut engine = Engine::new(&module, &mut host);
        engine.run(proc, vec![]).expect("run");
        printed = host.printed.clone();
    }
    (wb, printed)
}

#[test]
fn merge_and_unmerge_reach_the_worksheet_model() {
    let src = r##"
Sub Layout()
    With ActiveSheet
        .Range("A1:C1").Value = "四半期売上"
        .Range("A1:C1").Merge
        .Range("A2:C2").Merge
        .Range("A2:C2").UnMerge
    End With
End Sub
"##;
    let (wb, _) = run(src, "Layout");
    let sheet = &wb.sheets[0];
    assert_eq!(sheet.merges.len(), 1, "one merge should survive");
    assert_eq!(sheet.merges[0].r1, 0);
    assert_eq!(sheet.merges[0].c2, 2);
    assert_eq!(sheet.get(0, 0).unwrap().as_text(), "四半期売上");

    // The merge has to reach the file, not just the model.
    let bytes = wb.to_bytes().unwrap();
    let back = Workbook::from_bytes(&bytes).unwrap();
    assert_eq!(back.sheets[0].merges.len(), 1);
}

#[test]
fn copy_paste_duplicates_a_block() {
    let src = r##"
Public Sub Dup()
    Dim i As Long
    For i = 1 To 3
        Cells(i, 1).Value = i * 10
        Cells(i, 2).Value = "行" & i
    Next i
    Range("A1:B3").Copy
    Range("D1").Paste
End Sub
"##;
    let (wb, _) = run(src, "Dup");
    let sheet = &wb.sheets[0];
    assert_eq!(sheet.get(0, 3).unwrap().as_number(), Some(10.0));
    assert_eq!(sheet.get(2, 3).unwrap().as_number(), Some(30.0));
    assert_eq!(sheet.get(1, 4).unwrap().as_text(), "行2");
}

#[test]
fn geometry_helpers_resize_end_and_find() {
    let src = r##"
Public Sub Probe()
    Cells(1, 1).Value = 1
    Cells(2, 1).Value = 2
    Cells(3, 1).Value = 3
    Cells(5, 1).Value = "ここ"
    Cells(1, 2).Value = "x"
    Cells(1, 3).Value = "y"

    Debug.Print Cells(1, 1).Resize(2, 3).Address
    Debug.Print Range("A1").End(xlDown).Address
    Debug.Print Range("A1:A9").Find(3).Address
    Debug.Print Range("A5").End(xlUp).Address
    Debug.Print Range("A1").EntireColumn.Address
    Debug.Print Range("A1").EntireRow.Address
End Sub
"##;
    let (_, printed) = run(src, "Probe");
    assert_eq!(printed[0], "A1:C2");
    // Ctrl+Down stops at the end of the contiguous block, like Excel.
    assert_eq!(printed[1], "A3");
    assert_eq!(printed[2], "A3");
    assert_eq!(printed[3], "A3");
    // EntireColumn / EntireRow span the used range of the sheet.
    assert_eq!(printed[4], "A1:A5");
    assert_eq!(printed[5], "A1:C1");
}

#[test]
fn worksheet_function_routes_into_the_engine() {
    let src = r##"
Public Sub Calc()
    Dim total As Double
    total = Application.WorksheetFunction.Sum(10, 20, 30)
    Debug.Print total
    Debug.Print WorksheetFunction.RoundUp(2.1, 0)
    Debug.Print WorksheetFunction.Text(1234.5, "#,##0.0")
End Sub
"##;
    let (_, printed) = run(src, "Calc");
    assert_eq!(printed[0], "60");
    assert_eq!(printed[1], "3");
    assert_eq!(printed[2], "1,234.5");
}

#[test]
fn date_intrinsics_round_trip() {
    let src = r##"
Public Sub Dates()
    Dim d As Double
    d = DateSerial(2026, 11, 17)
    Debug.Print d                       ' serial for the report date
    Debug.Print Year(d) & "/" & Month(d) & "/" & Day(d)
    Debug.Print DateAdd("m", 1, d) - d  ' November has 30 days
    Debug.Print WeekdayName(Weekday(d))
    Debug.Print FormatDateTime(TimeSerial(9, 30, 0))
    Debug.Print IsDate("2026-11-17")
    Debug.Print TypeName(d)
End Sub
"##;
    let (_, printed) = run(src, "Dates");
    assert_eq!(printed[0], "46343");
    assert_eq!(printed[1], "2026/11/17");
    assert_eq!(printed[2], "30");
    assert_eq!(printed[3], "火曜日");
    assert_eq!(printed[4], "9:30");
    assert_eq!(printed[5], "True");
    assert_eq!(printed[6], "Double");
}

#[test]
fn choose_switch_and_strcomp() {
    let src = r##"
Public Sub Pick()
    Dim grade As String
    grade = Choose(2, "A", "B", "C")
    Debug.Print grade
    Debug.Print Switch(grade = "A", 1, grade = "B", 2, True, 99)
    Debug.Print StrComp("あ", "い")
    Debug.Print InStrRev("a/b/c", "/")
End Sub
"##;
    let (_, printed) = run(src, "Pick");
    assert_eq!(printed[0], "B");
    assert_eq!(printed[1], "2");
    assert_eq!(printed[2], "-1");
    assert_eq!(printed[3], "4");
}

#[test]
fn for_each_walks_sheets_and_cells() {
    let src = r##"
Public Sub Walk()
    Dim c As Object
    Dim total As Double
    Cells(1, 1).Value = 5
    Cells(1, 2).Value = 7
    Cells(1, 3).Value = 11
    For Each c In Range("A1:C1").Cells
        total = total + c.Value
    Next c
    Debug.Print total

    Dim s As Object
    Dim names As String
    For Each s In ThisWorkbook.Sheets
        names = names & s.Name & ","
    Next s
    Debug.Print names
End Sub
"##;
    let (_, printed) = run(src, "Walk");
    assert_eq!(printed[0], "23");
    assert_eq!(printed[1], "Sheet1,");
}
