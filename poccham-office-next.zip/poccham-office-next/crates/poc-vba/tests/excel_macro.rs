//! End-to-end test: a realistic business macro manipulating a workbook.

use poc_core::xlsx::{Cell, CellValue, Workbook};
use poc_vba::{parse_module, Engine, ExcelHost};

const MACRO: &str = r##"
Option Explicit

' 売上データを集計して報告シートを作る、よくある業務マクロ
Sub BuildReport()
    Dim i As Long
    Dim total As Double
    Dim name As String

    Dim ws As Object
    Set ws = Sheets("Data")

    For i = 2 To 5
        total = total + Cells(i, 2).Value
        If Cells(i, 2).Value >= 500 Then
            Cells(i, 3).Value = "重点"
        Else
            Cells(i, 3).Value = "通常"
        End If
    Next i

    Sheets("Report").Activate
    Range("A1").Value = "売上集計"
    Range("A2").Value = "合計"
    Range("B2").Value = total
    Range("B3").Formula = "=AVERAGE(Data!B2:B5)"
    Range("A4").Value = "件数"
    Range("B4").Value = 4

    With Range("A1")
        .Value = "売上集計レポート"
    End With

    Debug.Print "total=" & total
    MsgBox "集計が完了しました: " & Format(total, "#,##0") & " 円"
End Sub

Function Taxed(amount As Double) As Double
    Taxed = Round(amount * 1.1, 0)
End Function

Sub UseFunction()
    Range("C10").Value = Taxed(Range("B2").Value)
End Sub
"##;

fn sample() -> Workbook {
    let mut wb = Workbook::new();
    wb.sheets[0].name = "Data".into();
    wb.sheets[0].push_row(vec![Cell::text("商品"), Cell::text("売上")]);
    wb.sheets[0].push_row(vec![Cell::text("A"), Cell::num(1200)]);
    wb.sheets[0].push_row(vec![Cell::text("B"), Cell::num(300)]);
    wb.sheets[0].push_row(vec![Cell::text("C"), Cell::num(800)]);
    wb.sheets[0].push_row(vec![Cell::text("D"), Cell::num(400)]);
    wb.add_sheet("Report");
    wb
}

#[test]
fn macro_aggregates_and_writes_back() {
    let module = parse_module(MACRO, "Module1").expect("macro should parse");
    let mut wb = sample();
    let outcome = {
        let mut host = ExcelHost::new(&mut wb);
        let mut engine = Engine::new(&module, &mut host);
        let out = engine.run("BuildReport", vec![]).expect("macro should run");
        assert_eq!(host.printed, vec!["total=2700"]);
        out
    };
    assert_eq!(outcome.messages.len(), 1);
    assert_eq!(outcome.messages[0], "集計が完了しました: 2,700 円");
    assert!(outcome.warnings.is_empty(), "{:?}", outcome.warnings);

    // Flag column written by the loop (>= 500 gets 重点)
    let data = wb.sheet_index("Data").unwrap();
    assert_eq!(wb.sheets[data].get(1, 2).unwrap().as_text(), "重点");
    assert_eq!(wb.sheets[data].get(2, 2).unwrap().as_text(), "通常");
    assert_eq!(wb.sheets[data].get(3, 2).unwrap().as_text(), "重点");
    assert_eq!(wb.sheets[data].get(4, 2).unwrap().as_text(), "通常");

    // Report sheet content
    let report = wb.sheet_index("Report").unwrap();
    assert_eq!(
        wb.sheets[report].get(0, 0).unwrap().as_text(),
        "売上集計レポート"
    );
    assert_eq!(
        wb.sheets[report].get(1, 1).unwrap().as_number(),
        Some(2700.0)
    );
    assert_eq!(wb.sheets[report].get(3, 1).unwrap().as_number(), Some(4.0));
    match &wb.sheets[report].get(2, 1).unwrap().value {
        CellValue::Formula { expr, cached, .. } => {
            assert_eq!(expr, "AVERAGE(Data!B2:B5)");
            // The engine calculated the formula when the macro wrote it.
            assert_eq!(*cached, Some(675.0));
        }
        other => panic!("expected formula, got {other:?}"),
    }
}

#[test]
fn user_function_tax_rounds_like_vba() {
    let module = parse_module(MACRO, "Module1").unwrap();
    let mut wb = sample();
    {
        let mut host = ExcelHost::new(&mut wb);
        let mut engine = Engine::new(&module, &mut host);
        engine.run("BuildReport", vec![]).unwrap();
        engine.run("UseFunction", vec![]).unwrap();
    }
    let report = wb.sheet_index("Report").unwrap();
    // 2700 * 1.1 = 2970
    assert_eq!(
        wb.sheets[report].get(9, 2).unwrap().as_number(),
        Some(2970.0)
    );
}

#[test]
fn roundtrip_through_xlsx_keeps_macro_results() {
    let module = parse_module(MACRO, "Module1").unwrap();
    let mut wb = sample();
    {
        let mut host = ExcelHost::new(&mut wb);
        let mut engine = Engine::new(&module, &mut host);
        engine.run("BuildReport", vec![]).unwrap();
    }
    let bytes = wb.to_bytes().unwrap();
    let back = Workbook::from_bytes(&bytes).unwrap();
    let report = back.sheet_index("Report").unwrap();
    assert_eq!(
        back.sheets[report].get(0, 0).unwrap().as_text(),
        "売上集計レポート"
    );
    assert_eq!(
        back.sheets[report].get(1, 1).unwrap().as_number(),
        Some(2700.0)
    );
}

#[test]
fn unknown_method_reports_clear_error() {
    let src = r##"
Sub Bad()
    Range("A1").Value = 1
    Range("A1").Teleport
End Sub
"##;
    let module = parse_module(src, "M").unwrap();
    let mut wb = Workbook::new();
    let mut host = ExcelHost::new(&mut wb);
    let mut engine = Engine::new(&module, &mut host);
    let err = engine.run("Bad", vec![]).unwrap_err();
    assert!(err.to_string().contains("未対応"), "{err}");
}
