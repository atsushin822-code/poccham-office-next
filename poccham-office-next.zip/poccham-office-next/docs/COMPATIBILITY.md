# 対応状況

「Microsoft Office と互換」と言うとき、実際に何ができて何ができないのかを
正直にまとめます。**ファイル形式の読み書きは OOXML 仕様（ECMA-376 / ISO 29500）
に基づく独立実装**で、Excel / Word / PowerPoint が警告なく開けることを
`scripts/verify_ooxml.py` で継続的に検証しています。

## 形式

| 形式 | 読み込み | 書き出し | 備考 |
| --- | --- | --- | --- |
| `.xlsx` | ✅ | ✅ | 値・数式・キャッシュ値・数値書式・太字斜体・列幅・凍結ペイン・オートフィルタ・結合・条件付き書式・入力規則・グラフ・ピボット・画像・コメント・**セルのハイパーリンク**（`<hyperlinks>` + 外部リレーション） |
| `.xlsm` | ✅ | — | マクロ有効ブックとして読む（VBA は別途 .bas として実行） |
| `.docx` | ✅ | ✅ | 段落スタイル（タイトル/見出し/引用/コード/箇条書き/番号付き）、表、改ページ、画像、脚注、目次、ヘッダー/フッター、変更履歴、コメント |
| `.docm` | ✅ | — | 読むのみ |
| `.pptx` | ✅ | ✅ | 16:9 / 4:3、タイトル + 3 階層の箇条書き、図形、画像、**画面切り替え**（`p:transition`: フェード/プッシュ/ワイプ/分割/カバー）、**アニメーション**（`p:timing` + 箇条書きは段落単位の `p:bldP build="p"`）、**図形・画像・行のリンク**（`a:hlinkClick`）、発表者ノート、テーマ |
| `.pptm` | ✅ | — | 読むのみ |
| `.ods` | ✅ | ✅ | OpenFormula → A1 変換、繰り返し行/列、型付きセル、日付 |
| `.csv` / `.tsv` | ✅ | ✅ | RFC 4180、BOM 付き UTF-8 出力 |
| `.md` | ✅ | ✅ | 文書・スライドの相互変換 |
| `.txt` | ✅ | ✅ | 文書からプレーンテキストへ |
| `.odt` / `.odp` | ❌ | ❌ | 読み込み未対応（ODS と OOXML を推奨） |
| `.xls` / `.doc` / `.ppt` | ❌ | ❌ | 旧バイナリ形式。検出して「OOXML に変換してください」と案内します |

## 表計算

| 機能 | 状態 |
| --- | --- |
| 値・文字列・真偽値・エラー値 | ✅ |
| 数式（再計算・キャッシュ値の保存） | ✅ |
| 数値書式 | 標準 / 太字 / 斜体 / 小数 2 桁 / % / 日付 / 折返し / 見出し / 通貨（¥） |
| 列幅・ウィンドウ枠の固定・オートフィルタ | ✅ |
| シートの追加・名前変更・切り替え | ✅ |
| 並べ替え（昇順/降順）・行の挿入削除 | ✅（UI） |
| セルの結合 | ✅ |
| 条件付き書式（値の比較・データバー） | ✅ |
| 入力規則（リスト） | ✅ |
| グラフ（棒・折れ線・円） | ✅ 系列参照とキャッシュ値を保存 |
| ピボットテーブル（行/列/値・合計） | ✅ ピボットキャッシュ付き |
| 画像の挿入 | ✅ `xl/media` に元データをそのまま保存 |
| セルのリンク挿入 | ✅ リボン「挿入 → リンク」/ 解除 / Ctrl+クリックで開く |
| セルコメント | ✅ 旧 VML 注釈付き |
| セルのハイパーリンク | ✅ `<hyperlinks>` + 外部リレーション。URL / `mailto:` / 内部リンク (`#Sheet!A1`)。Ctrl+クリックで開く |
| 共有文字列・インライン文字列・`t="str"` | ✅ |
| 他実装が書いたファイルの読み込み | ✅ openpyxl の絶対パス関係（`Target="/xl/..."`）、インライン文字列、空の `<v></v>`（未計算の数式）に対応 |
| 1,048,576 行 × 16,384 列の上限 | ✅（上限値を超える参照はエラーに） |

### 数式関数（270）

数学/統計（`SUM` `SUMIFS` `SUMPRODUCT` `MEDIAN` `STDEV.S` `PERCENTILE` …）、
検索/参照（`VLOOKUP` `XLOOKUP` `INDEX` `MATCH` `OFFSET` `INDIRECT` …）、
文字列（`TEXTJOIN` `SUBSTITUTE` `REGEX*` `UNICHAR` …）、日付（`EDATE` `EOMONTH` `NETWORKDAYS` `WEEKNUM` …）、
財務（`PMT` `IRR` `NPV` `XNPV` …）、エンジニアリング（`DEC2BIN` `CONVERT` `COMPLEX` …）、
情報（`ISERROR` `TYPE` `SHEET` `CELL` …）の **270 関数**を実装しています。
全関数の一覧は `python3 scripts/count_functions.py --list` で出力できます。

範囲参照、シート参照、絶対参照、文字列連結 `&`、比較演算子に対応します。
上記以外の関数を含むファイルを開いた場合、そのセルは `#NAME?` となり、
**他のセルの値と数式はそのまま保持**されます（壊して保存することはありません）。

## 文書

| 機能 | 状態 |
| --- | --- |
| タイトル / 見出し 1〜3 / 本文 / 引用 / コード / 箇条書き / 番号付き | ✅ |
| 左・中央・右・両端揃え | ✅ |
| 太字・斜体・下線・取り消し線・文字色・等幅 | ✅（モデルとファイル） |
| 表（ヘッダ行付き）・改ページ | ✅ |
| 画像（インライン、mm 単位のサイズ指定） | ✅ |
| 脚注（本文参照 + 脚注パート） | ✅ |
| 目次（`TOC` フィールド） | ✅ 見出しから UI 側で生成 |
| ヘッダー / フッター | ✅ |
| 変更履歴（挿入・削除の記録） | ✅ `w:ins` / `w:del` |
| コメント（範囲 + 参照 + 著者） | ✅ `comments.xml` |

## プレゼンテーション

| 機能 | 状態 |
| --- | --- |
| タイトル + 本文（3 階層） | ✅ |
| 16:9 / 4:3 | ✅（既定は 16:9） |
| スライドの追加・削除・並べ替え | ✅ |
| 画像（mm 配置） | ✅ |
| 図形（四角/角丸/楕円/三角/ひし形/矢印/星/線） | ✅ 塗り・枠線・文字入り |
| 画面切り替え（フェード/プッシュ/ワイプ/分割/カバー） | ✅ |
| アニメーション（クリックで順にフェードイン） | ✅ `p:timing` |
| 発表者ノート | ✅ `notesSlide` + ノートマスター |
| テーマ（配色 6 色 + フォント） | ✅ テーマパーツに反映 |

## VBA

Excel VBA の**サブセット**を実行します。実務でよく使う「集計・整形・転記」は
動きますが、Excel の全オブジェクトモデルを実装したものではありません。

| 分類 | 対応 |
| --- | --- |
| 制御構文 | `If/ElseIf/Else`、`For/Next`、`For Each`、`Do/Loop (While/Until)`、`While/Wend`、`Select Case`、`With`、`Exit Sub/For/Do`、`On Error Resume Next`、`GoTo` |
| 変数 | `Dim`/`Const`/`Static`、型指定（`As Long` など）、配列（`Dim a(10)`）、`ReDim`、`Erase` |
| 手続き | `Sub`/`Function`、引数（`ByVal`/`ByRef`/`Optional`）、戻り値、再帰 |
| 演算子 | 算術・比較・`&`・`And/Or/Not/Xor/Imp/Eqv`・`Like` |
| Excel | `Range`、`Cells`、`Value`/`Value2`、`Formula`、`Text`、`Offset`、`Resize`、`End(xlUp/xlDown/xlToLeft/xlToRight)`、`EntireRow`/`EntireColumn`、`Rows`/`Columns`、`Count`、`Address`、`Clear`/`ClearContents`、`Merge`/`UnMerge`/`MergeCells`、`Copy`/`Paste`（アプリ内クリップボード）、`Find`、`Worksheets`/`Sheets`（`For Each` 可）、`ActiveSheet`、`UsedRange`、`Name`、`Count` |
| 数式連携 | `Application.WorksheetFunction.Sum(...)` など — 数式エンジンと同じ実装を呼び出すため、マクロと数式の結果が一致 |
| 入出力 | `MsgBox`、`Debug.Print`（UI のマクロダイアログに表示） |
| 組み込み関数 | `Len/Mid/Left/Right/InStr/InStrRev/Replace/Split/Join/Trim/LTrim/RTrim/UCase/LCase/StrReverse`、`CStr/CLng/CDbl/CInt/CBool/CByte/CSng/CCur`、`Abs/Int/Fix/Round/Sgn/Sqr/Exp/Log/Rnd`、`Format`/`FormatNumber`/`FormatCurrency`/`FormatPercent`/`FormatDateTime`、`Val/Hex/Asc/Chr/Space/String`、`IsNumeric/IsDate/IsEmpty/IsNull/IsArray/IsObject/TypeName`、`Choose/Switch/StrComp`、`Date/Time/Now/DateSerial/TimeSerial/DateAdd/DateDiff/DatePart/Year/Month/Day/Hour/Minute/Second/Weekday/MonthName/WeekdayName/Timer`、`UBound/LBound`、定数（`vbCrLf`、`xlUp`、`xlDown` など） |
| 未対応 | `CreateObject`/`GetObject`（COM）、`Application.Run` の外部参照、ユーザーフォーム、`On Error GoTo` のラベル処理（`Resume Next` のみ）、イベントハンドラ（`Worksheet_Change` など）、`Declare`（Win32 API） |

### マクロの実行方法

```bash
# ファイルに含まれる VBA ではなく、.bas を明示的に渡して実行します
# （マクロ有効ブックの vbaProject.bin は解析せず、意図しない実行を防ぎます）
poc macro run report.xlsx --module rules.bas --call BuildReport --out report_done.xlsx
```

UI の「マクロ」タブでは、ソースを貼り付けて**構文チェック → 実行**ができます。
実行結果（`Debug.Print` の出力、`MsgBox` の内容、ステップ数、所要時間）が
ダイアログに表示されます。

## 「100% 互換」の意味

私たちが目標にしているのは次の 3 点で、現時点の達成状況も併記します。

1. **ファイルを壊さない** — 読み書きしたファイルを Excel / Word / PowerPoint /
   LibreOffice が警告なく開ける。→ `verify_ooxml.py` 79 項目 + 3 つの独立実装で検証済み。
2. **値と数式が一致する** — 再計算結果が Excel と一致し、計算済みの値も保存される。
   → 対応関数の範囲では一致。未対応関数は `#NAME?` を返し、元の数式文字列は保持。
3. **マクロが動く** — 実務で使われる VBA のパターンが動く。→ 上表のサブセット。

未対応領域（グラフ、ピボット、画像、COM、イベント）は[ロードマップ](#ロードマップ)
の順で拡張します。互換性の検証に使えるファイルや再現手順があれば、
`scripts/verify_ooxml.py` にケースを足して回帰させてください。

## 検証の実行

```bash
python3 scripts/verify_ooxml.py    # 79 項目: 値・数式・書式・凍結・フィルタ・結合・条件付き書式・
                                   #   グラフ・ピボット・画像・脚注・目次・変更履歴・図形・ノート・テーマ・ODS
cargo test --workspace             # 154 テスト (+ ネイティブ egui 7 テスト): 往復変換、CoW、リンク、画面切り替え、他実装が書いたファイルの読み込み、VBA、JSON 契約
node scripts/ui_smoke_test.js      # 119 項目: UI の計算・編集・モード切替・CoW undo・フォント/リンク/画像/目次/図形/ノート/発表者モード/アプリ連携
```

### 未対応（正直な記載）

- **egui / wgpu への UI 移行は未実施**。判断と段階案は `docs/PERFORMANCE.md` に記載しています。
- セルの書式設定ダイアログ（罫線・フォント個別指定）、改ページプレビュー。
- スライドの切り替え音・`p:transition` の `advTm`（自動送り）。

## ロードマップ

1. 数式関数の拡張（`VLOOKUP`/`INDEX`/`MATCH`/`SUMIF`/`COUNTIF`/`TEXT`/`DATE` 系）
2. セルの結合・条件付き書式・入力規則
3. グラフ（棒・折線・円）の読み書き
4. `vbaProject.bin` の読み込みと、ブック内マクロの実行
5. 画像と図形（文書・スライド）
6. ODT / ODP の読み込み
