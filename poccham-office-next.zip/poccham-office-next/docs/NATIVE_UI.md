# ネイティブ UI (egui) — 構成と段階移行の記録

`crates/poc-egui/` は、WebView を使わずに OS のウィンドウへ直接描く
**ネイティブ画面**です。`poc-core` と `poc-vba` を WebView 版と共有します。

```bash
# 既定 (OpenGL / glow)
cargo run --manifest-path crates/poc-egui/Cargo.toml --release

# wgpu (Vulkan / Metal / DX12) を試す
POC_EGUI_RENDERER=wgpu \
  cargo run --manifest-path crates/poc-egui/Cargo.toml --release --features wgpu

# 画面なしで検証 (CI / サンドボックス)
cargo run --manifest-path crates/poc-egui/Cargo.toml --release -- --selftest
```

## 1. なぜ別クレートなのか

ルートの `Cargo.toml` は `crates/poc-egui` を `exclude` しています。
egui/eframe は依存が重く (ビルドだけで数百 MB)、CLI やブリッジの
「軽さ」を保ちたいためです。ネイティブ画面を作る人は明示的に
`--manifest-path crates/poc-egui/Cargo.toml` を指定します。
CI も同じコマンドでビルド・テストします (`.github/workflows/build.yml`)。

## 2. 画面

| タブ | できること |
| --- | --- |
| **シート** | `poc-core::xlsx::Workbook` を直接読み書きする表。クリック選択、矢印キー、ホイールスクロール (Shift で横)、数式バー、数値/文字列/`=数式` の入力と再計算、`.xlsx` を開く / 上書き保存、シート切り替え |
| 設定 | テーマ (`system`/`light`/`dark`)、`grid_renderer` (`auto`/`gpu`/`2d`)、フォントサイズ、ズーム、最近のファイル。設定は `theme` `grid_renderer` `font_size` `zoom` `recent` の JSON で、WebView 版と同じキー名 |
| マクロ | `poc-vba` の構文チェックと実行、`Debug.Print` / `MsgBox` の出力 |
| 情報 | バージョン、バックエンド、この画面の役割 |

設定ファイルの場所:

- Windows: `%APPDATA%\poccham-office-next\settings.json`
- macOS / Linux: `$XDG_CONFIG_HOME/poccham-office-next/settings.json`
  (無ければ `~/.config/...`)

## 3. 描画

- バックエンド: eframe の **glow (OpenGL)** が既定。`--features wgpu` +
  `POC_EGUI_RENDERER=wgpu` で **wgpu** を選べます。どちらも GPU 描画です。
- 表は **見えている範囲だけ**を走査します (`grid_view::visible_range`)。
  200 行 × 26 列 = 5,200 セルのうち、900×620 px では 384 セル (7.4%)。
- 罫線は `egui::Shape` の束にして 1 回で流し、文字は可視セルぶんだけ
  `layout_no_wrap` で galley 化します。数値セルは右揃え。
- 日本語表示のため、OS の CJK フォントを実行時に読み込みます (`src/font.rs`)。
  読み込んだ書体数はステータスバーに出ます。

## 4. 検証

| 手段 | 内容 |
| --- | --- |
| `--selftest` | 設定 JSON の往復・キー名の一致・VBA 実行・表の編集と連鎖再計算・表示範囲の走査量・3,000 セルの再計算を 9 項目で確認 |
| `cargo test --manifest-path crates/poc-egui/Cargo.toml` | 7 テスト (表示範囲・A1 番地・サンプル数式・編集) |
| `cargo clippy ... -- -D warnings` | 既定 / `--features wgpu` の両方で警告ゼロ |

## 5. 段階移行の現在地

| 段階 | 状態 |
| --- | --- |
| 1. 編集を伴わない画面 (設定・マクロ・情報) | **完了** (egui) |
| 2. 表 (数値・数式・スクロール・保存) | **完了** (egui) |
| 3. 文章編集 (Writer) | **未着手** — 日本語 IME の検証が前提 |
| 4. スライド / 発表者モード | **未着手** |

理由: このアプリの差別化は「1 ファイルに 3 アプリ・OOXML 互換」であり、
文章編集体験 (IME・コピー/貼り付け・アクセシビリティ・印刷) は WebView が
現状は上です。ネイティブ化は「速くなるが打ちにくくなる」リスクと隣り合わせなので、
**検証できる範囲から順に**進めています。表は日本語入力がほぼ数値と数式で、
IME の未確定文字列の影響が小さいため先に移しました。
