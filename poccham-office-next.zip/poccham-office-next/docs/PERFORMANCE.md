# 性能設計 — CoW・部分描画・GPU・ネイティブ UI

このドキュメントは「速く・軽く」のための実装と、その実測値の記録です。
数字はすべてこのリポジトリ同梱のスクリプトで再現できます。

```bash
node scripts/ui_perf_probe.js                 # WebView 版の描画・描画方式・CoW の実測
cargo test -p poc-core cow                    # CoW のユニットテスト
cargo run --manifest-path crates/poc-egui/Cargo.toml --release -- --selftest
                                              # ネイティブ (egui) 版のセルフテスト
cargo run -p poc-cli -- bench                 # エンジンのスループット
```

3 つの施策はすべて**実装済み**です。できること・できないことは章ごとに
明記します（誇張しません）。

---

## 1. Copy-on-Write (CoW) — 実装済み

### 1.1 ねらい

編集のたびに文書全体を複製すると、コストは文書サイズに比例します。
3,000 セルのシートを 1 文字変えるたびに 3,000 セル分を複製するのは無駄なので、
**「スナップショットは参照を共有し、書き込み時にその部分だけ複製する」** 方式です。

### 1.2 シート (UI / JavaScript)

`crates/poc-ui/ui/index.html`:

| 変更前 | 変更後 |
| --- | --- |
| `JSON.parse(JSON.stringify([...map.entries()]))` で毎回ディープコピー | `new Map(map)` + **書き込み時にセル 1 個だけ複製** |
| セルはすべて新しいオブジェクト (3,000 個の割り当て) | 変更していないセルは同一オブジェクトを共有 |
| undo のコスト = O(全セル) × 定数 (JSON 変換) | undo のコスト = O(セル数) の Map 走査のみ、割り当ては 0 |

セルには版番号 `__v` を持たせ、`writableCell(r, c)` が
「スナップショットと共有しているセル (= 版が古いセル)」だけを複製します。
`d` (計算結果) は派生値なので複製対象外 — undo 後の `recalcAll()` が作り直します。

実測 (`node scripts/ui_perf_probe.js`, 3,000 セル):

```
undo スナップショット (3,000 セル):
  JSON ディープコピー : 3.32 ms / 回
  CoW (参照共有)      : 0.43 ms / 回  → 7.7x 高速
  編集 1 回 (undo 込み): 4.72 ms
```

### 1.3 テストの落とし穴 (CI で落ちた話)

`unshared_write_does_not_copy` は当初「`Vec::as_ptr()` が書き込み前後で
変わらないこと」を CoW の証拠にしていました。これは**誤り**でした:

- `vec![1, 2, 3]` の容量は 3 なので `push(4)` は必ず再割り当てを起こします。
- glibc の `realloc` はその場で拡張できることがあり、ローカル (Linux) では
  アドレスが変わらずテストが通っていました。
- MSVC のヒープや、CI ランナーの別のアロケータでは移動するため、
  **Windows / Linux の CI でだけ落ちる**という再現性の悪い失敗になりました。

いまは「要素が `clone()` された回数」を直接数える方式に変えています
(`Counted` というテスト用の型)。アロケータの気まぐれに依存せず、
CoW を壊すと確実に落ちます (変異テストで確認: `current_mut()` を毎回
ディープコピーに変えると `チェックポイント前の書き込みで要素を複製してはいけない`
で失敗する)。同じ理由で、時間のしきい値も「O(1) が O(n) に退行したことだけを
捕まえる」緩さにしています。

### 1.4 文書エンジン (Rust)

`crates/poc-core/src/cow.rs` — `Arc` ベースの CoW バッファ:

```rust
let mut buf = CowBuffer::new(vec![1, 2, 3]);
let snapshot = buf.snapshot();  // O(1) — Arc の複製 1 回だけ
buf.push(4);                    // ここで初めて複製される
assert_eq!(snapshot.len(), 3);
```

- `CowBuffer<T>`: `snapshot()` は `Arc::clone` のみ。書き込みは
  `Arc::make_mut` なので、**共有されていなければ複製しない**。
- `History<T>`: undo/redo スタック。`checkpoint()` は O(1)。
- テスト: `snapshots_of_big_buffers_allocate_nothing` は 100 万要素のバッファに
  対して 1,000 回のスナップショットが 10 ms 未満であることを検証します。

---

## 2. Canvas の部分再描画 (dirty rect) — 実装済み

### 2.1 しくみ

`crates/poc-ui/ui/index.html` の `Paint` オブジェクトが「描き直す必要がある
矩形」を貯め、`flushPaint()` がまとめて 1 回だけ `drawGrid(region)` を呼びます。

| API | 用途 |
| --- | --- |
| `Paint.all()` | 全面描画 (スクロール・シート切替・ズーム・undo) |
| `Paint.cell(r, c)` | 1 セル (編集・再計算の結果が変わったセル) |
| `Paint.range(r0, c0, r1, c1)` | 矩形範囲 (書式設定・並べ替え・貼り付け) |
| `Paint.add(x, y, w, h)` | 任意の矩形 |
| `mergeRects()` | 重なる矩形をまとめる。**40 枚を超えたら全面描画に切り替え** |

`drawGrid(region)` はその矩形に `clip` してから、重なるセルだけをループします
(`loR/hiR/loC/hiC` で範囲を絞り、行番号・列名の帯に触れていないときは帯を描かない)。
`resizeGrid()` はピクセルサイズが変わったときだけ `canvas.width` に代入します
(代入はキャンバスを消去するため、毎回やると全損になります)。

`recalcLocal()` は値が変わったセルだけを `Paint.cell()` で無効化し、
`setSel()` は旧選択と新選択の矩形だけを描き直します。スクロールが起きたときは
自動的に全面描画へ戻ります。

### 2.2 実測

`node scripts/ui_perf_probe.js` (jsdom、セル 1 個を描くコスト):

```
2D 全面描画         : 13.987 ms
2D 部分描画 (1 セル) : 1.648 ms  → 8.5x 軽い
```

> jsdom にはレイアウトも GPU も無いため、絶対値ではなく**比**を見てください。

---

## 3. GPU グリッド (WebGL2 インスタンス描画) — 実装済み

### 3.1 構成

`#gridgl` (WebGL2) を 2D の `#gridcanvas` の**下**に重ねます。

- **GPU レイヤ**: セル背景・見出し色・罫線・選択範囲・アクティブセル枠。
  すべて同じ形の矩形なので、インスタンス属性 `(x, y, w, h, r, g, b, a)` を
  1 本の `Float32Array` に詰めて `drawArraysInstanced` **1 回**で流します。
- **2D レイヤ**: 文字とリンクの下線だけ。`clearRect` した透明キャンバスに描くので、
  下の GPU レイヤが透けます。

部分再描画は GPU 側でも維持されます: `flushPaint()` の dirty rect は
`gl.scissor()` に渡り、矩形の外は再描画しません。

### 3.2 設定とフォールバック

ステータスバーの「描画」セレクタ (`自動` / `GPU` / `2D`) で切り替えます。
設定は `localStorage` の `poccham.grid_renderer` に保存され、
egui 版の設定 JSON と同じ `grid_renderer` キーを持ちます。

- `webgl2` コンテキストが取れない / GLSL 3.0 ES をコンパイルできない /
  `webglcontextlost` が起きたときは、**黙って 2D 描画に戻ります** (見た目は同じ)。
- jsdom や古い WebView でもクラッシュしません（スモークテストで検証）。

### 3.3 実測

`node scripts/ui_perf_probe.js` (偽の WebGL2 で呼び出しを記録):

```
GPU 全面描画        : 13.213 ms (909 矩形 / 1 draw call)
GPU 部分描画 (1 セル): 1.731 ms (78 矩形 / scissor 指定)
GPU 呼び出し        : draw call 121 回 / scissor 60 回
```

**正直な限界**: jsdom には本物の GL が無いため、この数字は
「矩形を積んで 1 回の draw call にまとめられている」ことの確認であって、
GPU の実時間ではありません。実機の効果測定には WebView2 / WKWebView 上での
計測が必要で、この環境では行えていません。また文字は 2D レイヤのままなので、
グリフのアトラス化までは踏み込んでいません。

---

## 4. ネイティブ UI (egui) — 実装済み

### 4.1 なにが動くか

`crates/poc-egui/` は WebView を使わない **eframe/egui** のネイティブ画面です
(ルートの workspace からは `exclude` してあり、既定ビルドに GUI 依存を持ち込みません)。

```bash
cargo run --manifest-path crates/poc-egui/Cargo.toml --release
cargo run --manifest-path crates/poc-egui/Cargo.toml --release -- --selftest
# wgpu (Vulkan/Metal/DX12) で動かす場合:
POC_EGUI_RENDERER=wgpu cargo run --manifest-path crates/poc-egui/Cargo.toml --release --features wgpu
```

| タブ | 中身 |
| --- | --- |
| **シート** | `poc-core::xlsx` を直接読み書きする表。クリック選択・矢印キー・ホイールスクロール・数式バー・数値/数式入力・`再計算`・`.xlsx` の開く/上書き保存 |
| 設定 | テーマ・`grid_renderer`・フォントサイズ・ズーム・最近のファイル（WebView 版と同じ JSON キー） |
| マクロ | `poc-vba` の構文チェックと実行（Debug.Print / MsgBox の出力表示） |
| 情報 | バージョン・バックエンド |

描画は egui のペインタ = GPU の頂点バッファです。罫線は `Shape` の束にして
1 回で流し、文字は `layout_no_wrap` の galley を可視範囲ぶんだけ作り、
数値は右揃えにしています。

**部分描画**: `visible_range(scroll, view)` が見えている行・列だけを返します
(200×26 = 5,200 セルのうち 900×620 px では 384 セル = **7.4%** の走査)。
スクロールしても走査量は画面サイズに比例したままです。

### 4.2 セルフテスト (`--selftest`)

画面の無い環境 (CI・サンドボックス) でも検証できるよう、`--selftest` を用意しました。

```
[OK  ] 設定 JSON の往復 — 81 バイト
[OK  ] 設定キーが WebView 版と一致 — theme/grid_renderer/font_size/zoom/recent
[OK  ] VBA マクロの実行 — 15 ステップ / 0.02 ms / 出力 total=150
[OK  ] グリッドのサンプル表 — 合計 465600 / 税込 512160
[OK  ] 数値の入力 — B2 = 2000
[OK  ] 数式の入力と連鎖再計算 — D2 = 8000 (数式バー =B2*4)
[OK  ] 合計行の再計算 — D5 = 157600 (D2 を =B2*4 = 8000 にした)
[OK  ] 表示範囲の走査量 — 384 セル (全体 5200 セルの 7.4%)
[OK  ] 3000 セルの生成と再計算 — 生成 0.5 ms / 再計算 1.2 ms
poc-egui セルフテスト: すべて合格
```

ユニットテスト 7 本 (`cargo test --manifest-path crates/poc-egui/Cargo.toml`) は
表示範囲の計算・A1 番地・サンプルの数式・編集と連鎖再計算を検証します。

### 4.3 できないこと (正直な線引き)

- **日本語 IME の検証はまだ**。egui のテキスト編集は WebView ほど成熟しておらず、
  未確定文字列・変換候補ウィンドウの確認が済むまで、文章編集の主画面は
  WebView 版に残しています。ネイティブ側は**表の数値と数式**までを担当します。
- ネイティブ側に **Writer / Slides / リッチテキスト / 発表者モードは未実装**。
- 既定のバックエンドは **glow (OpenGL)**。`wgpu` は任意フィーチャで、
  `cargo check --features wgpu` が通ることは確認済みですが、実行時の確認は
  GPU のある実機で行う必要があります（このサンドボックスには GPU がありません）。
- リリースビルドは `lto = "thin"` で 1 プロセスあたり 1 GB 以上を使います。
  2 GB しかない環境では `--config 'profile.release.lto=false' --config
  'profile.release.opt-level=2'` で回避できます（このリポジトリの実測はその設定）。

---

## 5. まとめ

| 施策 | 状態 | 実測 |
| --- | --- | --- |
| CoW (undo スナップショット) | 実装済み | 3.32 ms → 0.43 ms (**7.7x**) |
| Canvas 部分再描画 | 実装済み | 13.99 ms → 1.65 ms (**8.5x**) |
| GPU グリッド (WebGL2) | 実装済み (自動フォールバック付き) | 909 矩形を **1 draw call**、部分描画は 78 矩形 + scissor |
| ネイティブ egui 画面 | 実装済み (表・設定・マクロ・情報) | 走査セル 7.4%、3,000 セル再計算 1.2 ms、バイナリ 8.6 MB |
| IME・文章編集のネイティブ化 | **未着手** | WebView 版が担当 (理由は 4.3) |

「速く・軽く」の残りの課題は、実機 GPU での描画時間測定と、
ローマ字入力以外の IME 検証です。どちらも CI では代替できません。
