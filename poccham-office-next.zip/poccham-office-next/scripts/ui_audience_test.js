#!/usr/bin/env node
/**
 * スクリーン (観客用) ウィンドウの検証。
 *
 * 発表者モードは 2 つのウィンドウに分かれる:
 *   ・手元   … 通常の編集画面 + 右下の発表者ドック (scripts/ui_smoke_test.js が検証)
 *   ・スクリーン … `#audience` 付きで開いたウィンドウ。スライドだけを全画面表示
 *
 * このスクリプトは **スクリーン側** を検証する:
 *   - 起動すると観客用モードになる (UI が出ない)
 *   - 受け取ったスライドを全画面で描く
 *   - 見出し / 箇条書き / 表 / 図形 / リンク / アニメーション (reveal) が反映される
 *   - 手元のウィンドウから届く前は何も描かない (黒いスクリーンのまま)
 *
 *   node scripts/ui_audience_test.js
 */
const fs = require("fs");
const path = require("path");

let JSDOM;
try {
  ({ JSDOM } = require("jsdom"));
} catch {
  try {
    ({ JSDOM } = require("/tmp/uitest/node_modules/jsdom"));
  } catch {
    console.error("jsdom が必要です: npm install jsdom");
    process.exit(2);
  }
}

const htmlPath = path.join(__dirname, "..", "crates", "poc-ui", "ui", "index.html");
const html = fs.readFileSync(htmlPath, "utf8");

const failures = [];
function check(name, cond, detail) {
  console.log(`${cond ? "[OK  ]" : "[FAIL]"} ${name}${detail ? " — " + detail : ""}`);
  if (!cond) failures.push(name);
}

function fakeCtx() {
  const noop = () => {};
  return new Proxy(
    {
      measureText: (s) => ({ width: String(s).length * 6.2 }),
      canvas: { width: 1280, height: 800 },
      setTransform: noop, save: noop, restore: noop, beginPath: noop, clip: noop,
      rect: noop, moveTo: noop, lineTo: noop, stroke: noop, fill: noop,
      clearRect: noop, fillRect: noop, strokeRect: noop, fillText: noop,
    },
    {
      get: (t, p) => (p in t ? t[p] : typeof p === "string" ? () => {} : undefined),
      set: (t, p, v) => ((t[p] = v), true),
    }
  );
}

const dom = new JSDOM(html, {
  runScripts: "dangerously",
  pretendToBeVisual: true,
  // スクリーン側として起動する
  url: "file:///app/index.html#audience",
  beforeParse(window) {
    window.__fakeGL = null;
    window.HTMLCanvasElement.prototype.getContext = (type) =>
      String(type).startsWith("webgl") ? window.__fakeGL : fakeCtx();
    window.navigator.clipboard = { writeText: async () => {}, readText: async () => "" };
    Object.defineProperty(window.HTMLElement.prototype, "clientWidth", { get: () => 1920, configurable: true });
    Object.defineProperty(window.HTMLElement.prototype, "clientHeight", { get: () => 1080, configurable: true });
    window.HTMLElement.prototype.getBoundingClientRect = () => ({
      left: 0, top: 0, right: 1920, bottom: 1080, width: 1920, height: 1080, x: 0, y: 0,
    });
    window.HTMLElement.prototype.showModal = function () { this.open = true; };
    window.HTMLElement.prototype.close = function () { this.open = false; };
  },
});

setTimeout(() => {
  const win = dom.window;
  const doc = win.document;
  const P = win.__POC__;

  check("スクリーン側として起動する", P.isAudienceWindow() === true);
  check("観客用モードのクラスが付く", doc.body.classList.contains("audience"));
  const stage = doc.getElementById("audstage");
  check("全画面の受け皿がある", !!stage, stage ? stage.id : "なし");
  check("受け取る前は何も描かない (黒いスクリーン)", !!stage && stage.childNodes.length === 0);

  // 発表者ドックや UI は出さない
  const dock = doc.getElementById("presenter");
  check("スクリーン側に発表者ドックを出さない", !dock || dock.hidden === true);
  const rail = doc.getElementById("apprail");
  const railHidden = !rail || win.getComputedStyle(rail).display === "none";
  check("スクリーン側にアプリ切り替えを出さない", railHidden,
        rail ? win.getComputedStyle(rail).display : "要素なし");

  // 手元のウィンドウから届く内容を描く
  const payload = {
    type: "slide",
    theme: "ocean",
    index: 1,
    total: 3,
    reveal: 2,
    slide: {
      title: "第 2 四半期の結果",
      animate: true,
      bullets: [
        { t: "売上は前年比 +12%", level: 0 },
        { t: "解約率は 1.8% に低下", level: 0 },
        { t: "詳細はこちら", level: 1, link: "https://example.com/report" },
      ],
      table: [["項目", "値"], ["売上", "1,240"]],
      shapes: [{ kind: "roundedRect", text: "重点", fill: "2E75B6" }],
      notes: "ここはスクリーンには出ない",
    },
  };
  const node = P.renderAudience(payload);
  check("スライドを描ける", !!node && stage.childNodes.length === 1);
  check("見出しが出る",
        stage.querySelector(".pres-title").textContent === "第 2 四半期の結果",
        stage.querySelector(".pres-title").textContent);
  check("アニメーション (reveal) の行数だけ出る",
        stage.querySelectorAll(".pres-bullets li").length === 2,
        String(stage.querySelectorAll(".pres-bullets li").length));
  check("表が出る", stage.querySelectorAll(".pres-table td").length === 4,
        String(stage.querySelectorAll(".pres-table td").length));
  check("図形が出る", stage.querySelectorAll(".pres-sh").length === 1);
  check("まだ出していない行は描かない", !/詳細はこちら/.test(stage.textContent || ""),
        stage.textContent.slice(0, 30));

  // 全部出した状態
  payload.reveal = 3;
  P.renderAudience(payload);
  const linkLi = [...stage.querySelectorAll(".pres-bullets li")].find((li) => /詳細/.test(li.textContent));
  check("3 行目まで出るとリンク付きの行も描かれる", !!linkLi && linkLi.style.cursor === "pointer",
        linkLi ? linkLi.title : "なし");
  check("発表者メモはスクリーンに出ない",
        !/スクリーンには出ない/.test(stage.textContent || ""),
        stage.textContent.slice(0, 24));

  // テーマの切り替え
  payload.theme = "dusk";
  P.renderAudience(payload);
  const themed = stage.querySelector(".pres-slide");
  check("テーマが反映される", themed.dataset.theme === "dusk", themed.dataset.theme);

  // 終了メッセージ相当: 何も描かない状態に戻せる
  P.renderAudience({ type: "slide", theme: "dusk", slide: null });
  check("スライドが無い通知では描き替えない", stage.childNodes.length === 1);

  console.log();
  if (failures.length) {
    console.log(`失敗 ${failures.length} 件: ${failures.join(", ")}`);
    process.exit(1);
  }
  console.log("スクリーン (観客用) テスト: すべて合格");
  process.exit(0);
}, 400);
