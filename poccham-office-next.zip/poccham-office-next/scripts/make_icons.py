#!/usr/bin/env python3
"""Generate the Poccham Office Next icon set.

The mark is deliberately geometric — a rounded square (the "cell"), a white
"P" stem and bowl, and an amber baseline bar.  No AI-style imagery, no robot
heads, no gradients-on-gradients: it has to survive being rendered at 16 px in
a taskbar and printed in one colour on a quotation.

    python3 scripts/make_icons.py

Outputs (all in assets/icons/):
    logo.svg              vector master (hand written, no editor metadata)
    16..1024 PNG          raster sizes
    icon.ico              Windows (16/32/48/64/128/256)
    icon.icns             macOS (ic07..ic14)
    32x32.png, 128x128.png, 128x128@2x.png, icon.png   (Tauri names)
"""

from __future__ import annotations

import os
import struct
from pathlib import Path

from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parent.parent / "assets" / "icons"
S = 4096  # master render size

INK = (22, 35, 74, 255)        # #16234A deep indigo
INK_SOFT = (31, 56, 100, 255)  # #1F3864
PAPER = (255, 255, 255, 255)
ACCENT = (224, 138, 46, 255)   # #E08A2E amber


def rounded_rect(draw: ImageDraw.ImageDraw, box, radius: int, fill) -> None:
    draw.rounded_rectangle(box, radius=radius, fill=fill)


def render_master() -> Image.Image:
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    margin = int(S * 0.055)
    size = S - margin * 2
    radius = int(size * 0.215)

    # Base tile
    rounded_rect(d, (margin, margin, margin + size, margin + size), radius, INK)

    # Subtle inner panel: the "sheet" area, drawn as a lighter inset
    inset = int(size * 0.14)
    inner_radius = int(radius * 0.72)
    rounded_rect(
        d,
        (margin + inset, margin + inset, margin + size - inset, margin + size - inset),
        inner_radius,
        INK_SOFT,
    )

    # "P" built from a stem and a ring, so the geometry stays crisp at 16 px
    u = size
    stem_x0 = margin + int(u * 0.300)
    stem_x1 = margin + int(u * 0.405)
    stem_y0 = margin + int(u * 0.235)
    stem_y1 = margin + int(u * 0.715)
    rounded_rect(d, (stem_x0, stem_y0, stem_x1, stem_y1), int(u * 0.026), PAPER)

    bowl_cx = margin + int(u * 0.492)
    bowl_cy = margin + int(u * 0.386)
    bowl_r = int(u * 0.164)
    d.ellipse(
        (bowl_cx - bowl_r, bowl_cy - bowl_r, bowl_cx + bowl_r, bowl_cy + bowl_r),
        fill=PAPER,
    )
    hole_r = int(u * 0.073)
    d.ellipse(
        (bowl_cx - hole_r, bowl_cy - hole_r, bowl_cx + hole_r, bowl_cy + hole_r),
        fill=INK_SOFT,
    )

    # Amber baseline: the "cell" the P is written on
    bar_h = int(u * 0.044)
    bar_y = margin + int(u * 0.762)
    rounded_rect(
        d,
        (margin + int(u * 0.238), bar_y, margin + int(u * 0.700), bar_y + bar_h),
        bar_h // 2,
        ACCENT,
    )
    return img


def write_svg() -> str:
    """Hand written SVG master, sharing the geometry above (0..512 user units)."""
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" role="img" aria-label="Poccham Office Next">
  <title>Poccham Office Next</title>
  <rect x="28" y="28" width="456" height="456" rx="98" fill="#16234A"/>
  <rect x="92" y="92" width="328" height="328" rx="70" fill="#1F3864"/>
  <rect x="165" y="121" width="54" height="245" rx="13" fill="#FFFFFF"/>
  <circle cx="264" cy="198" r="84" fill="#FFFFFF"/>
  <circle cx="264" cy="198" r="37" fill="#1F3864"/>
  <rect x="150" y="390" width="237" height="23" rx="11" fill="#E08A2E"/>
</svg>
"""


def write_icns(path: Path, pngs: dict[int, Path]) -> None:
    """Write an .icns container (PNG payloads, modern types only)."""
    types = {
        16: b"icp4",
        32: b"icp5",
        64: b"icp6",
        128: b"ic07",
        256: b"ic08",
        512: b"ic09",
        1024: b"ic10",
    }
    chunks = b""
    for size, png in pngs.items():
        if size not in types:
            continue
        data = png.read_bytes()
        chunks += types[size] + struct.pack(">I", len(data) + 8) + data
    path.write_bytes(b"icns" + struct.pack(">I", len(chunks) + 8) + chunks)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    master = render_master()

    (OUT / "logo.svg").write_text(write_svg(), encoding="utf-8")

    sizes = [16, 24, 32, 48, 64, 128, 256, 512, 1024]
    pngs: dict[int, Path] = {}
    for size in sizes:
        img = master.resize((size, size), Image.LANCZOS)
        path = OUT / f"{size}.png"
        img.save(path, "PNG", optimize=True)
        pngs[size] = path

    # Tauri's conventional names
    master.resize((32, 32), Image.LANCZOS).save(OUT / "32x32.png", "PNG", optimize=True)
    master.resize((128, 128), Image.LANCZOS).save(OUT / "128x128.png", "PNG", optimize=True)
    master.resize((256, 256), Image.LANCZOS).save(OUT / "128x128@2x.png", "PNG", optimize=True)
    master.resize((512, 512), Image.LANCZOS).save(OUT / "icon.png", "PNG", optimize=True)
    # Windows Store / installer tiles
    master.resize((310, 310), Image.LANCZOS).save(OUT / "StoreLogo.png", "PNG", optimize=True)

    # Windows .ico (multi-resolution)
    master.resize((256, 256), Image.LANCZOS).save(
        OUT / "icon.ico",
        sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
    )
    # macOS .icns
    write_icns(OUT / "icon.icns", pngs)

    # Linux desktop icon + .desktop entry used by the .deb / .rpm / AppImage
    master.resize((512, 512), Image.LANCZOS).save(OUT / "poccham-office-next.png", "PNG")
    (OUT / "poccham-office-next.desktop").write_text(
        """[Desktop Entry]
Type=Application
Name=Poccham Office Next
GenericName=Office Suite
Comment=超軽量オフィススイート
Exec=poccham-office-next %F
Icon=poccham-office-next
Terminal=false
Categories=Office;Spreadsheet;WordProcessor;Presentation;
MimeType=application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;application/vnd.openxmlformats-officedocument.wordprocessingml.document;application/vnd.openxmlformats-officedocument.presentationml.presentation;application/vnd.oasis.opendocument.spreadsheet;text/csv;
StartupWMClass=poccham-office-next
""",
        encoding="utf-8",
    )

    total = sum(p.stat().st_size for p in OUT.iterdir() if p.is_file())
    print(f"{len(list(OUT.iterdir()))} ファイルを書き出しました ({total / 1024:.1f} KB) -> {OUT}")


if __name__ == "__main__":
    main()
