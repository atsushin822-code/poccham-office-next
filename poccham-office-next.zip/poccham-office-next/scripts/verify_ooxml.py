#!/usr/bin/env python3
"""Cross-implementation verification for files produced by Poccham Office Next.

Generates documents with `poc` and opens them with three *independent*
implementations (openpyxl, python-docx, python-pptx).  If those libraries can
read everything we write, the files are structurally valid OOXML — the same
thing Excel / Word / PowerPoint check first when they open a file.

Exit code is non-zero if any check fails, so this can run in CI.

    pip install openpyxl python-docx python-pptx
    python3 scripts/verify_ooxml.py
"""

import os
import subprocess
import sys
import tempfile
import zipfile
from xml.etree import ElementTree

# Windows の既定コードページ (cp1252 / cp932) でも日本語を出せるようにする。
# GitHub Actions の Windows ランナーは UTF-8 ではないため、これが無いと
# print() の時点で UnicodeEncodeError になります。
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

FAILURES: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    status = "OK  " if condition else "FAIL"
    print(f"[{status}] {name}{(' — ' + detail) if detail else ''}")
    if not condition:
        FAILURES.append(name)


def poc() -> str:
    candidates = [
        os.environ.get("POC_BIN", ""),
        "./target/release/poc",
        "./target/release/poc.exe",
        "./target/debug/poc",
        "./target/debug/poc.exe",
        "poc",
    ]
    for path in candidates:
        if not path:
            continue
        if path == "poc" or os.path.exists(path):
            try:
                subprocess.run([path, "version"], capture_output=True, check=True)
                return path
            except Exception:
                continue
    sys.exit("`poc` が見つかりません。`cargo build --release` を実行してください。")


def well_formed(path: str) -> None:
    """Every XML part must parse; every part must be listed in [Content_Types]."""
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        for name in names:
            if name.endswith((".xml", ".rels")):
                try:
                    ElementTree.fromstring(z.read(name))
                except ElementTree.ParseError as e:
                    check(f"{os.path.basename(name)} の XML 妥当性", False, str(e))
                    return
        check(f"{os.path.basename(path)}: XML パーツがすべて整形式", True, f"{len(names)} パーツ")
        if "[Content_Types].xml" in names:
            ct = z.read("[Content_Types].xml").decode()
            missing = [
                n
                for n in names
                if n.endswith(".xml")
                and f'PartName="/{n}"' not in ct
                and 'Extension="xml"' not in ct
            ]
            check("[Content_Types].xml が全パーツを宣言", not missing, ", ".join(missing[:3]))



def cargo_rich(tmp: str) -> dict[str, str]:
    """Run the feature demos (merges, charts, pivots, notes, TOC …).

    They live in `crates/poc-core/examples`, so a checkout that can run
    `verify_ooxml.py` can normally build them too.  When that is not possible
    the feature checks are skipped instead of failed.
    """
    out = {}
    for name, ext in (("rich_sheet", "xlsx"), ("rich_doc", "docx"), ("rich_deck", "pptx")):
        target = os.path.join(tmp, f"rich_{name}.{ext}")
        try:
            subprocess.run(
                ["cargo", "run", "-q", "-p", "poc-core", "--example", name, "--", target],
                check=True,
                capture_output=True,
                timeout=600,
            )
            out[name] = target
        except Exception:
            pass
    return out

def verify_xlsx(path: str) -> None:
    import openpyxl

    wb = openpyxl.load_workbook(path)
    ws = wb.active
    check("openpyxl: ブックを開ける", wb.sheetnames == ["売上"], str(wb.sheetnames))
    check("openpyxl: 見出しが読める", ws["A1"].value == "月", str(ws["A1"].value))
    check("openpyxl: 数値が読める", ws["B2"].value == 1_820_000, str(ws["B2"].value))
    check("openpyxl: 数式が読める", ws["B6"].value == "=SUM(B2:B5)", str(ws["B6"].value))
    check("openpyxl: 表示形式", ws["B2"].number_format == '"¥"#,##0', ws["B2"].number_format)
    check("openpyxl: 太字スタイル", bool(ws["A1"].font.b))
    check("openpyxl: 固定ペイン", ws.freeze_panes == "A2", str(ws.freeze_panes))
    check("openpyxl: オートフィルタ", ws.auto_filter.ref == "A1:D5", str(ws.auto_filter.ref))

    cached = openpyxl.load_workbook(path, data_only=True).active
    check("openpyxl: 計算済みの値", cached["B6"].value == 8_120_000, str(cached["B6"].value))
    check("openpyxl: 文字列を返す数式", cached["D4"].value == "達成", str(cached["D4"].value))


def verify_docx(path: str) -> None:
    import docx

    d = docx.Document(path)
    styles = [p.style.name for p in d.paragraphs]
    check("python-docx: 段落が読める", len(d.paragraphs) > 5, f"{len(d.paragraphs)} 段落")
    check("python-docx: 見出しスタイル", "Heading 1" in styles, str(styles[:4]))
    check("python-docx: 箇条書き", "List Paragraph" in styles)
    check("python-docx: 表が読める", len(d.tables) == 1 and d.tables[0].rows[1].cells[0].text == ".xlsx")
    check("python-docx: 等幅コード段落", any(p.text.startswith("let mut wb") for p in d.paragraphs))
    check("python-docx: 引用スタイル", any(p.style.name in ("Quote", "Intense Quote") for p in d.paragraphs))


def verify_pptx(path: str) -> None:
    import pptx

    p = pptx.Presentation(path)
    check("python-pptx: スライド数", len(p.slides) == 3, str(len(p.slides)))
    titles = [s.shapes[0].text_frame.text for s in p.slides]
    check("python-pptx: タイトル", titles[0] == "現状の課題", str(titles))
    bullets = p.slides[0].shapes[1].text_frame.text
    check("python-pptx: 本文", "起動" in bullets)
    check("python-pptx: スライドサイズ 16:9", p.slide_width == 12_192_000, str(p.slide_width))


def verify_ods(path: str) -> None:
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        info = z.getinfo("mimetype")
        check("ODS: mimetype が先頭・無圧縮", names[0] == "mimetype" and info.compress_type == 0)
        check(
            "ODS: 正しい MIME タイプ",
            z.read("mimetype") == b"application/vnd.oasis.opendocument.spreadsheet",
        )
        content = z.read("content.xml").decode()
        check("ODS: テーブル要素", "<table:table " in content)
        check("ODS: 数式", "table:formula" in content)


def verify_rich_xlsx(path: str) -> None:
    """セルの結合 / 条件付き書式 / グラフ / ピボット / 画像."""
    import openpyxl

    wb = openpyxl.load_workbook(path)
    ws = wb["売上"]
    check("openpyxl: セルの結合", len(list(ws.merged_cells.ranges)) >= 1,
          ", ".join(str(r) for r in ws.merged_cells.ranges))
    check("openpyxl: 条件付き書式", len(list(ws.conditional_formatting)) >= 1,
          str(len(list(ws.conditional_formatting))))
    check("openpyxl: データ検証", len(ws.data_validations.dataValidation) >= 1,
          str(len(ws.data_validations.dataValidation)))
    check("openpyxl: グラフ", len(ws._charts) >= 1, str(len(ws._charts)))
    check("openpyxl: 画像", len(ws._images) >= 1, str(len(ws._images)))
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        check("xlsx: ピボットテーブルのパーツ", any("pivotTable" in n for n in names),
              ", ".join(n for n in names if "pivot" in n)[:80])
        check("xlsx: コメントのパーツ", any("comments" in n for n in names))
        check("xlsx: グラフの XML", any(n.startswith("xl/charts/chart") for n in names))
        check("xlsx: メディア", any(n.startswith("xl/media/") for n in names))
        chart = z.read(next(n for n in names if n.startswith("xl/charts/chart"))).decode()
        check("xlsx: グラフに系列参照", "c:f" in chart and "!$" in chart)
        check("xlsx: グラフにキャッシュ値", "<c:pt " in chart)


def verify_rich_docx(path: str) -> None:
    """画像 / 脚注 / 目次 / ヘッダ・フッタ / 変更履歴 / コメント."""
    import docx

    d = docx.Document(path)
    check("python-docx: 図が読める", len(d.inline_shapes) >= 1, str(len(d.inline_shapes)))
    header = " ".join(p.text for section in d.sections for p in section.header.paragraphs)
    footer = " ".join(p.text for section in d.sections for p in section.footer.paragraphs)
    check("python-docx: ヘッダー", bool(header.strip()), header.strip()[:40])
    check("python-docx: フッター", bool(footer.strip()), footer.strip()[:40])
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        check("docx: 脚注パーツ", "word/footnotes.xml" in names)
        check("docx: コメントパーツ", "word/comments.xml" in names)
        check("docx: メディア", any(n.startswith("word/media/") for n in names))
        body = z.read("word/document.xml").decode()
        check("docx: 目次フィールド", "TOC" in body and "fldChar" in body)
        check("docx: 変更履歴 (挿入/削除)", "<w:ins " in body and "<w:del " in body)
        check("docx: 脚注参照", "footnoteReference" in body)
        check("docx: コメント範囲", "commentRangeStart" in body)
        notes = z.read("word/footnotes.xml")
        root = ElementTree.fromstring(notes)
        ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
        ids = [n.get(ns + "id") for n in root.iter(ns + "footnote")]
        check("docx: 脚注の区切り記号", "-1" in ids and "0" in ids, str(ids))


def verify_rich_sheet_links(path: str) -> None:
    """セルのハイパーリンクが openpyxl (= Excel と同じ解釈) で読めること."""
    import openpyxl

    wb = openpyxl.load_workbook(path)
    targets = []
    for sheet in wb.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if cell.hyperlink and cell.hyperlink.target:
                    targets.append(cell.hyperlink.target)
    check("openpyxl: セルのリンク (URL)", any("example.com" in t for t in targets), str(targets))
    check("openpyxl: セルのリンク (mailto)", any(t.startswith("mailto:") for t in targets), str(targets))
    with zipfile.ZipFile(path) as z:
        sheet_xml = None
        for name in z.namelist():
            if name.startswith("xl/worksheets/sheet") and name.endswith(".xml"):
                text = z.read(name).decode()
                if "<hyperlinks>" in text:
                    sheet_xml = (name, text)
                    break
        check("xlsx: <hyperlinks> 要素", sheet_xml is not None and '<hyperlink ref="A1"' in sheet_xml[1],
              sheet_xml[0] if sheet_xml else "not found")
        rel_name = sheet_xml[0].replace("xl/worksheets/", "xl/worksheets/_rels/") + ".rels"
        rels = z.read(rel_name).decode()
        check("xlsx: リンクの外部リレーション", 'TargetMode="External"' in rels)


def verify_rich_pptx(path: str) -> None:
    """画像 / 図形 / アニメーション / 発表者ノート / テーマ."""
    import pptx
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    p = pptx.Presentation(path)
    first = p.slides[0]
    kinds = {sh.shape_type for sh in first.shapes}
    check("python-pptx: 図形が読める", any(k == MSO_SHAPE_TYPE.AUTO_SHAPE for k in kinds),
          str(sorted(str(k) for k in kinds)))
    check("python-pptx: 画像が読める", any(k == MSO_SHAPE_TYPE.PICTURE for k in kinds))
    notes = " ".join(
        shape.text_frame.text
        for slide in p.slides
        if slide.has_notes_slide
        for shape in slide.notes_slide.shapes
        if shape.has_text_frame
    )
    check("python-pptx: 発表者ノート", bool(notes.strip()), notes.strip()[:40])
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        check("pptx: ノートスライド", any(n.startswith("ppt/notesSlides/notesSlide") for n in names))
        check("pptx: ノートマスター", "ppt/notesMasters/notesMaster1.xml" in names)
        check("pptx: テーマ", any(n.startswith("ppt/theme/theme") for n in names))
        check("pptx: メディア", any(n.startswith("ppt/media/") for n in names))
        slide1 = z.read("ppt/slides/slide1.xml").decode()
        check("pptx: 画面切り替え", "<p:transition" in slide1)
        check("pptx: アニメーション", "<p:timing>" in slide1 and "animEffect" in slide1)
        check("pptx: 図形の塗り", "srgbClr" in slide1)
        theme = z.read("ppt/theme/theme1.xml").decode()
        check("pptx: テーマの配色", "Poccham" in theme and "srgbClr" in theme)
        # ハイパーリンクは 3 種類 (図形 / 画像 / 行) すべてに載る
        check("pptx: 図形・画像・行のリンク", slide1.count("<a:hlinkClick ") >= 2,
              f"{slide1.count('<a:hlinkClick ')} 個の hlinkClick")
        slide_rels = z.read("ppt/slides/_rels/slide1.xml.rels").decode()
        check("pptx: リンクの外部リレーション",
              'TargetMode="External"' in slide_rels and "https://example.com/poccham" in slide_rels)
        check("pptx: 段落単位のビルド", 'build="p"' in slide1 and "<p:pRg" in slide1)
    # python-pptx からリンクが読める (= PowerPoint と同じ解釈)
    links = []
    for shape in p.slides[0].shapes:
        try:
            addr = shape.click_action.hyperlink.address
        except Exception:
            addr = None
        if addr:
            links.append(addr)
    check("python-pptx: 図形のリンク", any("example.com" in (a or "") for a in links), str(links))
    runs = [
        run
        for slide in p.slides
        for shape in slide.shapes
        if shape.has_text_frame
        for para in shape.text_frame.paragraphs
        for run in para.runs
    ]
    run_links = []
    for run in runs:
        try:
            if run.hyperlink.address:
                run_links.append(run.hyperlink.address)
        except Exception:
            pass
    check("python-pptx: 行 (run) のリンク", any("example.com" in a for a in run_links), str(run_links))


def main() -> None:
    binary = poc()
    with tempfile.TemporaryDirectory() as tmp:
        xlsx = os.path.join(tmp, "report.xlsx")
        docx = os.path.join(tmp, "memo.docx")
        pptx = os.path.join(tmp, "deck.pptx")
        ods = os.path.join(tmp, "report.ods")
        for target, kind in ((xlsx, "xlsx"), (docx, "docx"), (pptx, "pptx"), (ods, "ods")):
            subprocess.run([binary, "new", target], check=True, capture_output=True)
            well_formed(target)

        # Recalculate so cached values exist, like the GUI does on save.
        subprocess.run([binary, "calc", xlsx], check=True, capture_output=True)

        verify_xlsx(xlsx)
        verify_docx(docx)
        verify_pptx(pptx)
        verify_ods(ods)

        # 追加機能 (結合・条件付き書式・グラフ・ピボット・画像・脚注・目次・
        # ヘッダー/フッター・変更履歴・コメント・図形・ノート・テーマ)
        rich = cargo_rich(tmp)
        if not rich:
            print("[SKIP] 追加機能のサンプルをビルドできませんでした (cargo が必要)")
        if "rich_sheet" in rich:
            well_formed(rich["rich_sheet"])
            verify_rich_xlsx(rich["rich_sheet"])
            verify_rich_sheet_links(rich["rich_sheet"])
        if "rich_doc" in rich:
            well_formed(rich["rich_doc"])
            verify_rich_docx(rich["rich_doc"])
        if "rich_deck" in rich:
            well_formed(rich["rich_deck"])
            verify_rich_pptx(rich["rich_deck"])

    print()
    if FAILURES:
        print(f"失敗: {len(FAILURES)} 件 -> {FAILURES}")
        sys.exit(1)
    print("すべての検証に合格しました。")


if __name__ == "__main__":
    main()
