#!/usr/bin/env node
/**
 * Performance probe for crates/poc-ui/ui/index.html (jsdom, headless).
 *
 * Measures wall-clock cost of the operations a user feels:
 *   • 起動 (スクリプト解析 + 初期描画)
 *   • アプリ切り替え (Writer ⇄ Slides)
 *   • 文書の再描画 (長い文書)
 *
 * jsdom にはレイアウトが無いので「レイアウト時間」は含まないが、
 * DOM 構築・JS 実行コストの相対比較には十分。
 *
 *   node scripts/ui_perf_probe.js
 */
const fs = require("fs");
const path = require("path");

let JSDOM;
try {
  ({ JSDOM } = require("jsdom"));
} catch {
  ({ JSDOM } = require("/tmp/uitest/node_modules/jsdom"));
}

const htmlPath = path.join(__dirname, "..", "crates", "poc-ui", "ui", "index.html");
const html = fs.readFileSync(htmlPath, "utf8");

function fakeCtx() {
  const noop = () => {};
  return new Proxy(
    {
      measureText: (s) => ({ width: String(s).length * 6.2 }),
      canvas: { width: 1280, height: 800 },
      setTransform: noop, save: noop, restore: noop, beginPath: noop, clip: noop,
      rect: noop, moveTo: noop, lineTo: noop, stroke: noop, fill: noop,
      clearRect: noop, fillRect: noop, strokeRect: noop, fillText: noop,
    },
    {
      get: (t, p) => (p in t ? t[p] : typeof p === "string" ? () => {} : undefined),
      set: (t, p, v) => ((t[p] = v), true),
    }
  );
}

/* WebGL2 の代役 (呼び出し回数だけ数える) */
function fakeGL() {
  const gl = {
    calls: 0, lastCount: 0, scissors: 0,
    VERTEX_SHADER: 1, FRAGMENT_SHADER: 2, COMPILE_STATUS: 3, LINK_STATUS: 4,
    ARRAY_BUFFER: 5, STATIC_DRAW: 6, DYNAMIC_DRAW: 7, FLOAT: 8, TRIANGLE_STRIP: 9,
    BLEND: 10, SRC_ALPHA: 11, ONE_MINUS_SRC_ALPHA: 12, DEPTH_TEST: 13,
    SCISSOR_TEST: 14, COLOR_BUFFER_BIT: 15,
    createShader: () => ({}), shaderSource() {}, compileShader() {},
    getShaderParameter: () => true, getShaderInfoLog: () => "",
    createProgram: () => ({}), attachShader() {}, linkProgram() {},
    getProgramParameter: () => true, useProgram() {}, getUniformLocation: () => ({}),
    uniform2f() {}, createBuffer: () => ({}), bindBuffer() {}, bufferData() {},
    getAttribLocation: (p, n) => (n === "a_corner" ? 0 : n === "a_rect" ? 1 : 2),
    enableVertexAttribArray() {}, vertexAttribPointer() {}, vertexAttribDivisor() {},
    enable() {}, disable() {}, blendFunc() {}, viewport() {},
    scissor() { gl.scissors++; }, clearColor() {}, clear() {},
    drawArraysInstanced(m, f, c, n) { gl.calls++; gl.lastCount = n; },
  };
  return gl;
}

const t0 = process.hrtime.bigint();
const dom = new JSDOM(html, {
  runScripts: "dangerously",
  pretendToBeVisual: true,
  url: "file:///app/index.html",
  beforeParse(window) {
    window.__fakeGL = null;
    window.HTMLCanvasElement.prototype.getContext = (type) =>
      String(type).startsWith("webgl") ? window.__fakeGL : fakeCtx();
    window.navigator.clipboard = { writeText: async () => {}, readText: async () => "" };
    Object.defineProperty(window.HTMLElement.prototype, "clientWidth", { get: () => 1280, configurable: true });
    Object.defineProperty(window.HTMLElement.prototype, "clientHeight", { get: () => 760, configurable: true });
    window.HTMLElement.prototype.getBoundingClientRect = () => ({
      left: 0, top: 0, right: 1280, bottom: 760, width: 1280, height: 760, x: 0, y: 0,
    });
    window.HTMLElement.prototype.showModal = function () { this.open = true; };
    window.HTMLElement.prototype.close = function () { this.open = false; };
  },
});
const bootMs = Number(process.hrtime.bigint() - t0) / 1e6;

setTimeout(() => {
  const P = dom.window.__POC__;
  const S = P.state;
  const ms = (fn, n) => {
    const start = process.hrtime.bigint();
    for (let i = 0; i < n; i++) fn(i);
    return Number(process.hrtime.bigint() - start) / 1e6 / n;
  };

  P.openApp("document");
  const switchMs = ms((i) => P.openApp(i % 2 ? "presentation" : "document"), 20);

  // 長い文書 (120 段落) の描画
  S.doc = P.suite.document;
  S.doc.blocks = [];
  for (let i = 0; i < 120; i++) {
    S.doc.blocks.push({ type: "p", style: "Normal", align: "left", text: `段落 ${i} のテキストです。` });
  }
  P.openApp("document");
  const renderMs = ms(() => { P.renderDoc(); P.decorateDoc(); }, 10);

  // ---- CoW (copy-on-write) vs JSON ディープコピー ------------------------
  // 3,000 セルのシートで「undo 用スナップショット」のコストを比較する。
  P.openApp("workbook");
  P.applyWorkbookPayload({
    kind: "workbook", title: "計測", path: null,
    sheets: [{ name: "S", freeze: null, filter: null, cells: (() => {
      const out = [];
      for (let r = 0; r < 300; r++) {
        for (let c = 0; c < 10; c++) {
          const addr = `${String.fromCharCode(65 + c)}${r + 1}`;
          out.push([addr, `値 ${r}-${c}`, "", 0, `値 ${r}-${c}`, ""]);
        }
      }
      return out;
    })() }],
  }, true);
  const map = S.doc.sheets[0].map;
  const N = 50;
  const legacyMs = ms(() => JSON.parse(JSON.stringify([...map.entries()])), N);
  const cowMs = ms(() => new Map(map), N);
  // 編集 1 回ぶんの実測 (pushUndo + 書き込み + 再計算)
  P.setSel(0, 0);
  const editMs = ms((i) => P.commitEdit(`編集 ${i}`, 0, 0), N);
  console.log(`undo スナップショット (3,000 セル):`);
  console.log(`  JSON ディープコピー : ${legacyMs.toFixed(2)} ms / 回`);
  console.log(`  CoW (参照共有)      : ${cowMs.toFixed(2)} ms / 回  → ${(legacyMs / cowMs).toFixed(1)}x 高速`);
  console.log(`  編集 1 回 (undo 込み): ${editMs.toFixed(2)} ms`);

  // ---- 部分描画 (dirty rect) vs 全面描画 --------------------------------
  // 「描く」コストだけを測るため、編集はせず Paint に矩形を積んで flush する。
  const drawFull2d = ms(() => { P.Paint.all(); P.flushPaint(); }, 60);
  const drawCell2d = ms(() => { P.Paint.cell(3, 3); P.flushPaint(); }, 60);
  const cellsFull = (() => {
    P.Paint.all();
    P.flushPaint();
    const q = P.Paint.rects.length;
    return q;
  })();

  // ---- GPU レイヤ (WebGL2 インスタンス描画) ----------------------------
  dom.window.__fakeGL = fakeGL();
  P.setRenderer("gpu");
  const drawFullGpu = ms(() => { P.Paint.all(); P.flushPaint(); }, 60);
  const fullQuads = P.rendererState().quads;
  const drawCellGpu = ms(() => { P.Paint.cell(3, 3); P.flushPaint(); }, 60);
  const partialQuads = P.rendererState().quads;
  const gpuCalls = dom.window.__fakeGL.calls;
  const gpuScissors = dom.window.__fakeGL.scissors;
  dom.window.__fakeGL = null;
  P.setRenderer("2d");

  console.log();
  console.log("描画 1 回のコスト (jsdom = レイアウト/GPU 無しの JS 実行時間):");
  console.log(`  2D 全面描画        : ${drawFull2d.toFixed(3)} ms`);
  console.log(`  2D 部分描画 (1 セル): ${drawCell2d.toFixed(3)} ms  → ${(drawFull2d / drawCell2d).toFixed(1)}x 軽い`);
  console.log(`  GPU 全面描画       : ${drawFullGpu.toFixed(3)} ms (${fullQuads} 矩形 / 1 draw call)`);
  console.log(`  GPU 部分描画 (1 セル): ${drawCellGpu.toFixed(3)} ms (${partialQuads} 矩形 / scissor 指定)`);
  console.log(`  GPU 呼び出し       : draw call ${gpuCalls} 回 / scissor ${gpuScissors} 回`);

  const perf = S.perf || {};
  console.log(`起動            : ${bootMs.toFixed(1)} ms`);
  console.log(`アプリ切り替え  : ${switchMs.toFixed(2)} ms / 回 (Writer ⇄ Slides)`);
  console.log(`120 段落の描画  : ${renderMs.toFixed(2)} ms / 回`);
  console.log(`ツールバー構築  : ${perf.toolbarBuilds} 回 / フォント一覧構築 ${perf.fontBuilds} 回`);
  console.log(`ツールバー DOM  : ${(dom.window.document.getElementById("suitebar").innerHTML.length / 1024).toFixed(1)} KB`);
  process.exit(0);
}, 300);
