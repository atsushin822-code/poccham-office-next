#!/usr/bin/env node
/**
 * Headless smoke test for the desktop UI (crates/poc-ui/ui/index.html).
 *
 * Runs the real page in jsdom with a stubbed 2D canvas context, then exercises
 * the spreadsheet model: formula evaluation, editing, undo/redo, sheet
 * operations and the document/slide editors.
 *
 *   npm install jsdom       (or: npm install jsdom --prefix /tmp/uitest)
 *   node scripts/ui_smoke_test.js
 */
const fs = require("fs");
const path = require("path");

let JSDOM;
try {
  ({ JSDOM } = require("jsdom"));
} catch {
  try {
    ({ JSDOM } = require("/tmp/uitest/node_modules/jsdom"));
  } catch {
    console.error("jsdom が必要です: npm install jsdom");
    process.exit(2);
  }
}

const htmlPath = path.join(__dirname, "..", "crates", "poc-ui", "ui", "index.html");
if (!fs.existsSync(htmlPath)) {
  console.error(`UI が見つかりません: ${htmlPath}`);
  console.error("crates/poc-ui/ui/index.html がコミットされているか確認してください。");
  console.error("（.gitignore で dist/ や ui/ を丸ごと除外していると、CI のチェックアウトに含まれません）");
  process.exit(2);
}
const html = fs.readFileSync(htmlPath, "utf8");

const failures = [];
function check(name, cond, detail) {
  console.log(`${cond ? "[OK  ]" : "[FAIL]"} ${name}${detail ? " — " + detail : ""}`);
  if (!cond) failures.push(name);
}

/* ---- canvas 2D context stub (jsdom has no canvas) ---- */
function fakeCtx() {
  const noop = () => {};
  return new Proxy(
    {
      measureText: (s) => ({ width: String(s).length * 6.2 }),
      canvas: { width: 1280, height: 800 },
      setTransform: noop,
      save: noop,
      restore: noop,
      beginPath: noop,
      clip: noop,
      rect: noop,
      moveTo: noop,
      lineTo: noop,
      stroke: noop,
      fill: noop,
      clearRect: noop,
      fillRect: noop,
      strokeRect: noop,
      fillText: noop,
    },
    {
      get(target, prop) {
        if (prop in target) return target[prop];
        return typeof prop === "string" ? () => {} : undefined;
      },
      set(target, prop, value) {
        target[prop] = value;
        return true;
      },
    }
  );
}

/* ---- WebGL2 の代役 -------------------------------------------------------
   jsdom には GL が無いので、呼び出しを記録するだけのコンテキストを差し込む。
   インスタンス数・draw call 数・scissor (部分描画) を確認できる。 */
function fakeGL() {
  const gl = {
    calls: 0,
    lastCount: 0,
    scissors: 0,
    scissorRect: null,
    cleared: 0,
    VERTEX_SHADER: 1, FRAGMENT_SHADER: 2, COMPILE_STATUS: 3, LINK_STATUS: 4,
    ARRAY_BUFFER: 5, STATIC_DRAW: 6, DYNAMIC_DRAW: 7, FLOAT: 8, TRIANGLE_STRIP: 9,
    BLEND: 10, SRC_ALPHA: 11, ONE_MINUS_SRC_ALPHA: 12, DEPTH_TEST: 13,
    SCISSOR_TEST: 14, COLOR_BUFFER_BIT: 15,
    createShader: () => ({}), shaderSource() {}, compileShader() {},
    getShaderParameter: () => true, getShaderInfoLog: () => "",
    createProgram: () => ({}), attachShader() {}, linkProgram() {},
    getProgramParameter: () => true, useProgram() {}, getUniformLocation: () => ({}),
    uniform2f() {}, createBuffer: () => ({}), bindBuffer() {}, bufferData() {},
    getAttribLocation: (prog, name) => (name === "a_corner" ? 0 : name === "a_rect" ? 1 : 2),
    enableVertexAttribArray() {}, vertexAttribPointer() {}, vertexAttribDivisor() {},
    enable() {}, disable() {}, blendFunc() {}, viewport() {},
    scissor(x, y, w, h) { gl.scissors++; gl.scissorRect = [x, y, w, h]; },
    clearColor() {}, clear() { gl.cleared++; },
    drawArraysInstanced(mode, first, count, instances) { gl.calls++; gl.lastCount = instances; },
  };
  return gl;
}

const dom = new JSDOM(html, {
  runScripts: "dangerously",
  pretendToBeVisual: true,
  url: "file:///app/index.html",
  beforeParse(window) {
    window.__fakeGL = null;
    window.HTMLCanvasElement.prototype.getContext = (type) =>
      String(type).startsWith("webgl") ? window.__fakeGL : fakeCtx();
    window.navigator.clipboard = { writeText: async () => {}, readText: async () => "" };
    // jsdom has no layout: give elements a plausible size.
    Object.defineProperty(window.HTMLElement.prototype, "clientWidth", { get: () => 1280, configurable: true });
    Object.defineProperty(window.HTMLElement.prototype, "clientHeight", { get: () => 760, configurable: true });
    window.HTMLElement.prototype.getBoundingClientRect = function () {
      return { left: 0, top: 0, right: 1280, bottom: 760, width: 1280, height: 760, x: 0, y: 0 };
    };
    window.HTMLElement.prototype.showModal = function () { this.open = true; };
    window.HTMLElement.prototype.close = function () { this.open = false; };
  },
});

const { window } = dom;
const doc = window.document;

setTimeout(async () => {
  const P = window.__POC__;
  const S = P.state;
  check("UI が例外なく起動する", !!P && !!S && !!S.doc, S && S.doc && S.doc.kind);
  if (!S || !S.doc) { console.log("起動に失敗したため中断します"); process.exit(1); }
  // 起動時は「白紙」— 見本のファイルは同梱しない
  check("起動時は白紙のブックを開く",
        S.doc.sheets.length === 1 && S.doc.sheets[0].name === "Sheet1" && S.doc.sheets[0].map.size === 0,
        `${S.doc.sheets[0].name} / ${S.doc.sheets[0].map.size} セル`);
  check("ファイル名にサンプルの文字を出さない",
        !/サンプル/.test(doc.getElementById("docname").textContent || ""),
        doc.getElementById("docname").textContent);
  // ここから先は計算まわりを見たいので、見本データを明示的に読み込む
  P.loadPayload(P.demoWorkbook());
  check("見本データを明示的に読み込める",
        S.doc.sheets.length === 1 && S.doc.sheets[0].name === "売上", S.doc.sheets[0].name);

  const sh = S.doc.sheets[0];
  const cell = (a) => {
    const m = /^([A-Z]+)(\d+)$/.exec(a);
    let col = 0;
    for (const ch of m[1]) col = col * 26 + (ch.charCodeAt(0) - 64);
    return sh.map.get(`${parseInt(m[2], 10) - 1},${col - 1}`);
  };
  check("見出しセルのスタイル", cell("A1").s === 8 && cell("A1").raw === "月");
  check("SUM の計算結果", cell("B6").d === "8120000", cell("B6").d);
  check("AVERAGE の計算結果", cell("B8").d === "2030000", cell("B8").d);
  check("COUNT の計算結果", cell("B9").d === "4", cell("B9").d);
  check("IF の計算結果 (未達)", cell("D2").d === "未達", cell("D2").d);
  check("IF の計算結果 (達成)", cell("D4").d === "達成", cell("D4").d);
  check("前月比 (比率)", cell("C3").d === "0.06593406593406594" || Math.abs(parseFloat(cell("C3").d) - 0.065934) < 1e-5, cell("C3").d);

  // editing + undo
  P.setSel(0, 0, false);
  const before = sh.map.size;
  P.commitEdit("テスト", 0, 0);
  check("セル編集が反映される", cell("A1").raw === "テスト", cell("A1").raw);
  P.undo();
  check("元に戻す", S.doc.sheets[0].map.get("0,0").raw === "月", S.doc.sheets[0].map.get("0,0").raw);
  P.redo();
  check("やり直す", S.doc.sheets[0].map.get("0,0").raw === "テスト", S.doc.sheets[0].map.get("0,0").raw);

  // formula entry through the formula bar path
  P.setSel(10, 0, false);
  P.commitEdit("=SUM(B2:B5)*2", 0, 0);
  const f = S.doc.sheets[0].map.get("10,0");
  check("数式の入力と計算", f.f === "SUM(B2:B5)*2" && f.d === "16240000", f.f + " -> " + f.d);

  // number formatting through the ribbon command
  P.setSel(1, 1, false);
  P.commitEdit("0.256", 0, 0);
  P.COMMANDS.percent();
  check("パーセント書式", S.doc.sheets[0].map.get("1,1").s === 5 && P.displayValue(S.doc.sheets[0].map.get("1,1")) === "25.6%",
        P.displayValue(S.doc.sheets[0].map.get("1,1")));
  P.COMMANDS.currency();
  check("通貨書式", /^¥/.test(P.displayValue(S.doc.sheets[0].map.get("1,1"))), P.displayValue(S.doc.sheets[0].map.get("1,1")));

  // new sheet
  const n = S.doc.sheets.length;
  P.COMMANDS.newsheet();
  check("シート追加", S.doc.sheets.length === n + 1);

  // document mode
  P.loadPayload({
    kind: "document",
    title: "テスト文書",
    blocks: [
      { type: "p", style: "Heading1", align: "left", text: "見出し" },
      { type: "p", style: "Normal", align: "left", text: "本文" },
    ],
  });
  check("文書モードに切り替わる", S.mode === "document" && S.doc.blocks.length === 2, S.mode);
  check("段落が描画される", doc.querySelectorAll("#page .block").length === 2,
        String(doc.querySelectorAll("#page .block").length));
  P.COMMANDS.addpara();
  check("段落を追加できる", S.doc.blocks.length === 3);

  // --- 文書のリッチ機能: 目次 / 画像 / ヘッダー・フッター ---
  P.COMMANDS.inserttoc();
  const toc = doc.querySelector("#page .block.toc");
  check("目次を挿入できる", !!toc && /見出し/.test(toc.textContent), toc && toc.textContent.trim());
  P.COMMANDS.picture();
  const img = doc.querySelector("#page .block.img img");
  check("文書に画像を挿入できる", !!img && /^data:image\/png/.test(img.getAttribute("src") || ""),
        img && (img.getAttribute("src") || "").slice(0, 22));
  P.loadPayload({
    kind: "document",
    title: "テスト文書",
    header: "社外秘 / 2026 年度",
    footer: "Poccham Office Next",
    footnotes: 2,
    comments: [{ author: "山田", text: "要確認" }],
    blocks: [
      { type: "p", style: "Heading1", align: "left", text: "見出し" },
      { type: "p", style: "Normal", align: "left", text: "本文" },
    ],
  });
  check("エンジンのヘッダー/フッターが引き継がれる", S.doc.header === "社外秘 / 2026 年度" && S.doc.footer === "Poccham Office Next",
        `${S.doc.header} / ${S.doc.footer}`);
  check("注釈の件数がステータスバーに出る", /注釈 3/.test(doc.getElementById("stat").textContent), doc.getElementById("stat").textContent);
  P.COMMANDS.inserttoc(); P.COMMANDS.picture();
  const head = doc.querySelector("#page .dochead");
  const foot = doc.querySelector("#page .docfoot");
  check("ヘッダーとフッターが描画される", !!head && !!foot && head.textContent === S.doc.header,
        head && head.textContent);
  // 目次は見出しの一覧になっている
  check("目次に見出しが並ぶ", doc.querySelectorAll("#page .block.toc .li").length >= 1,
        String(doc.querySelectorAll("#page .block.toc .li").length));

  // presentation mode
  P.loadPayload({
    kind: "presentation",
    title: "テスト資料",
    slides: [{ title: "スライド1", bullets: [{ t: "要点", level: 0 }] }],
  });
  check("プレゼンモードに切り替わる", S.mode === "presentation");
  P.COMMANDS["slide-add"]();
  check("スライド追加", S.doc.slides.length === 2);
  check("サムネイルが描画される", doc.querySelectorAll("#thumbcol .thumb").length === 2,
        String(doc.querySelectorAll("#thumbcol .thumb").length));

  // --- スライドのリッチ機能: 図形 / 画像 / ノート / 画面切り替え ---
  P.addSlideShape("roundedRect");
  P.addSlideShape("star5");
  const shapes = doc.querySelectorAll("#slidecard .slideviz .sh");
  check("スライドに図形を追加できる", shapes.length === 2 && shapes[0].classList.contains("roundedRect"),
        String(shapes.length));
  P.COMMANDS["slide-image"]();
  const slimg = doc.querySelector("#slidecard .slideviz img.si");
  check("スライドに画像を追加できる", !!slimg, slimg ? slimg.getAttribute("alt") : "");
  const notes = doc.querySelector("#slidecard .notes textarea");
  check("発表者ノートの入力欄がある", !!notes, notes ? notes.value : "");
  if (notes) { notes.value = "最初に結論を述べる"; notes.dispatchEvent(new window.Event("input")); }
  check("ノートの編集が状態に反映される", S.doc.slides[1].notes === "最初に結論を述べる", S.doc.slides[1].notes);
  const trans = doc.querySelector("#slidecard .slidemeta select");
  check("画面切り替え効果を選べる", !!trans && trans.options.length === 6, trans && String(trans.options.length));
  if (trans) { trans.value = "fade"; trans.dispatchEvent(new window.Event("change")); }
  check("画面切り替えの設定が保存される", S.doc.slides[1].transition === "fade", S.doc.slides[1].transition);

  // back to spreadsheet + ribbon rendering
  P.loadPayload(P.demoWorkbook());
  check("ブックに戻れる", S.mode === "workbook" && S.doc.kind === "workbook");
  const ribbonButtons = doc.querySelectorAll("#ribbonBody .btn").length;
  check("リボンが描画される", ribbonButtons > 5, String(ribbonButtons));
  const tabs = doc.querySelectorAll("#sheettabs .tab").length;
  check("シートタブが描画される", tabs === 1, String(tabs));

  // serialisation round trip
  const payload = P.serializeWorkbook();
  check("シリアライズできる", payload.sheets[0].cells.length > 10, String(payload.sheets[0].cells.length));
  const sumCell = payload.sheets[0].cells.find((c) => c[0] === "B6");
  check("数式が保存される", sumCell && sumCell[2] === "SUM(B2:B5)", sumCell && sumCell[2]);

  // 数式の表示 toggle must round-trip without destroying cached results
  P.setSel(5, 1, false);
  const before5 = P.displayValue(S.doc.sheets[0].map.get("5,1"));
  P.COMMANDS.showformulas();
  const shown = P.displayValue(S.doc.sheets[0].map.get("5,1"));
  P.COMMANDS.showformulas();
  const after5 = P.displayValue(S.doc.sheets[0].map.get("5,1"));
  check("数式の表示 → 元に戻す", shown === "=SUM(B2:B5)" && after5 === before5, `${shown} / ${after5}`);

  /* =====================================================================
     Suite layer: 3 アプリ統合 / Writer の書式・リンク・画像 /
     Slides の発表者モード・テーマ・レイアウト / Sheet との連携
     ===================================================================== */

  // --- 統合シェル ---------------------------------------------------------
  P.loadPayload({ kind: "document", title: "追従テスト", blocks: [{ type: "p", style: "Normal", align: "left", text: "本文" }] });
  check("コア経路のモード変更にツールバーが追従する",
        doc.getElementById("suitebar").dataset.app === "writer",
        doc.getElementById("suitebar").dataset.app);
  check("レールの選択状態も追従する",
        (doc.querySelector('#apprail .appbtn.active') || {}).dataset?.kind === "document",
        (doc.querySelector('#apprail .appbtn.active') || {}).dataset?.kind);

  check("3 つのアプリを 1 画面に持つ", !!doc.getElementById("apprail"));
  check("アプリ切り替えボタンが 3 つ", doc.querySelectorAll("#apprail .appbtn").length === 3,
        String(doc.querySelectorAll("#apprail .appbtn").length));
  check("モジュールバーに 3 アプリが並ぶ", doc.querySelectorAll("#tabstrip .modchip").length === 3,
        String(doc.querySelectorAll("#tabstrip .modchip").length));
  check("フォントが 100 種類以上", P.FONTS.length >= 100, String(P.FONTS.length));
  check("コマンドパレットが存在する", !!doc.getElementById("palette"));
  check("発表者モードの器がある", !!doc.getElementById("presenter"));

  // --- Writer: 書式 -------------------------------------------------------
  P.openApp("document");
  check("Writer に切り替わる", S.mode === "document" && S.doc.kind === "document", S.mode);
  check("Writer のツールバーにフォント一覧",
        !!doc.getElementById("fontsel") && doc.querySelectorAll("#fontsel option").length > 100,
        String(doc.querySelectorAll("#fontsel option").length));
  P.applyFont("Yu Gothic");
  check("フォントを段落に適用", S.doc.blocks[0].fmt && S.doc.blocks[0].fmt.font === "Yu Gothic",
        S.doc.blocks[0].fmt && S.doc.blocks[0].fmt.font);
  const styledBlock = doc.querySelector('#page [data-idx="0"]');
  check("適用したフォントが描画に反映される",
        !!styledBlock && /Yu Gothic/.test(styledBlock.style.fontFamily || ""),
        styledBlock && styledBlock.style.fontFamily);
  P.applySize(18);
  P.applyFormat({ bold: true });
  check("サイズと太字が反映される",
        S.doc.blocks[0].fmt.size === 18 && S.doc.blocks[0].fmt.bold === true,
        `${S.doc.blocks[0].fmt.size}pt / bold ${S.doc.blocks[0].fmt.bold}`);
  P.applyColor("#c0392b");
  check("文字色を設定できる", S.doc.blocks[0].fmt.color === "#c0392b");

  // --- Writer: リンク・画像・置換 -----------------------------------------
  P.insertLink("Poccham 公式", "https://example.com/poccham");
  const anchor = doc.querySelector('#page a[href="https://example.com/poccham"]');
  check("リンクを挿入できる", !!anchor, anchor && anchor.textContent);
  check("リンクが段落の runs に残る",
        (S.doc.blocks[0].runs || []).some((r) => r.link === "https://example.com/poccham"));
  P.insertImageUrl("data:image/png;base64,iVBORw0KGgoAAAANSUhEUg==", 100, 60);
  const wImg = doc.querySelector('#page .block.img img');
  check("Writer に画像を挿入できる",
        !!wImg && /^data:image\/png/.test(wImg.getAttribute("src") || ""),
        wImg && (wImg.getAttribute("src") || "").slice(0, 24));
  const words = P.wordCount();
  check("文字数を数えられる", words > 0, String(words));
  S.doc.blocks.push({ type: "p", style: "Normal", align: "left", text: "置換テスト 置換テスト" });
  P.renderDoc();
  const replaced = P.findReplace("置換テスト", "REPLACED");
  check("検索と置換ができる",
        replaced >= 1 && S.doc.blocks.some((b) => b.text === "REPLACED REPLACED"),
        String(replaced));
  P.COMMANDS.footnote();
  P.COMMANDS.comment();
  check("脚注とコメントを追加できる",
        S.doc.footnotes >= 1 && (S.doc.comments || []).length >= 1,
        `${S.doc.footnotes} / ${(S.doc.comments || []).length}`);
  check("Writer のステータスに文字数が出る",
        /文字数/.test(doc.getElementById("stat").textContent || ""),
        doc.getElementById("stat").textContent);

  // --- 改ページの前後を行き来できる --------------------------------------
  // (改ページを入れたあと、その前の段落へ戻れない / 消せない、を直した)
  P.openApp("document");
  S.doc.blocks = [
    { type: "p", style: "Normal", align: "left", text: "前半の段落" },
    { type: "p", style: "Normal", align: "left", text: "" },
  ];
  S.activeBlock = 0;
  P.renderDoc();
  const pageEl = doc.getElementById("page");
  const blockAt = (i) => pageEl.querySelector(`.block[data-idx="${i}"]`);
  blockAt(0).focus();

  P.COMMANDS.pagebreak();
  check("改ページで改ページと受け皿の段落が入る",
        S.doc.blocks.length === 4 &&
          S.doc.blocks[1].type === "pagebreak" &&
          S.doc.blocks[2].type === "p",
        S.doc.blocks.map((b) => b.type).join(","));
  const after = blockAt(2);
  check("改ページの直後の段落へキャレットが移る",
        !!after && doc.activeElement === after, doc.activeElement && doc.activeElement.className);
  check("改ページは選べるブロックになっている",
        !!blockAt(1) && blockAt(1).getAttribute("tabindex") === "-1" &&
          blockAt(1).getAttribute("role") === "separator");

  // 改ページより上へ戻る: 先頭で ↑ / ←
  const key = (el2, k) => el2.dispatchEvent(new window.KeyboardEvent("keydown", { key: k, bubbles: true }));
  P.placeCaretStart(after);
  key(after, "ArrowUp");
  check("改ページの上の段落へ戻れる",
        doc.activeElement === blockAt(0), doc.activeElement && doc.activeElement.textContent);

  // キャレットが末尾にあれば ↑ は奪わない (普通の行移動を邪魔しない)
  P.placeCaretEnd(blockAt(0));
  key(blockAt(0), "ArrowUp");
  check("末尾での ↑ は横取りしない", doc.activeElement === blockAt(0));

  // 下へ戻る: 末尾で ↓
  key(blockAt(0), "ArrowDown");
  check("↓ で改ページを飛び越えて次の段落へ進める",
        doc.activeElement === after, doc.activeElement && doc.activeElement.textContent);

  // Backspace で改ページを削除
  P.placeCaretStart(after);
  key(after, "Backspace");
  check("段落の先頭で Backspace すると改ページが消える",
        !S.doc.blocks.some((b) => b.type === "pagebreak"),
        S.doc.blocks.map((b) => b.type).join(","));
  check("削除後は前の段落の末尾にキャレットが戻る",
        doc.activeElement === blockAt(0), doc.activeElement && doc.activeElement.textContent);

  // 改ページをクリックして Delete でも消せる
  S.doc.blocks.splice(1, 0, { type: "pagebreak" });
  P.renderDoc();
  const pbEl = pageEl.querySelector(".block.pb");
  pbEl.focus();
  key(pbEl, "Delete");
  check("改ページを選んで Delete でも消せる",
        !S.doc.blocks.some((b) => b.type === "pagebreak"));

  // 段落同士もつながる (Backspace / Delete で結合)
  S.doc.blocks = [
    { type: "p", style: "Normal", align: "left", text: "あい" },
    { type: "p", style: "Normal", align: "left", text: "うえお" },
  ];
  P.renderDoc();
  P.placeCaretStart(blockAt(1));
  key(blockAt(1), "Backspace");
  check("先頭の Backspace で前の段落とつながる",
        S.doc.blocks.length === 1 && S.doc.blocks[0].text === "あいうえお",
        S.doc.blocks[0] && S.doc.blocks[0].text);
  check("つなぎ目にキャレットが残る",
        doc.activeElement === blockAt(0) &&
          (() => { const s = window.getSelection(); return s && s.rangeCount && s.getRangeAt(0).startOffset === 2; })(),
        "offset 2");

  S.doc.blocks = [{ type: "p", style: "Normal", align: "left", text: "本文" }];
  P.renderDoc();

  // --- Sheet ↔ Writer / Slides の連携 ------------------------------------
  P.openApp("workbook");
  check("Sheet に戻れる", S.mode === "workbook" && S.doc.kind === "workbook");
  P.setSel(0, 0, false);
  P.setSel(4, 2, true);          // A1:C5 を選択
  const tableBlock = P.insertSheetTable(4, 3);
  check("Sheet の範囲を Writer の表にできる",
        !!tableBlock && tableBlock.rows.length >= 2 && tableBlock.rows[0][0] === "月",
        tableBlock && JSON.stringify(tableBlock.rows[0]));
  const sheetSlide = P.sendRangeToSlides(4, 3);
  check("Sheet の範囲をスライドにできる",
        !!sheetSlide && sheetSlide.table[0].length === 3 && sheetSlide.table[0][0] === "月",
        sheetSlide && JSON.stringify(sheetSlide.table[0]));

  // --- Slides: テーマ・レイアウト・複製・並べ替え -------------------------
  P.openApp("presentation");
  check("Slides に切り替わる", S.mode === "presentation" && S.doc.kind === "presentation");
  check("Slides のツールバーにレイアウトとテーマ",
        !!doc.getElementById("layoutsel") && !!doc.getElementById("themesel"));
  P.setTheme("dusk");
  check("テーマを変更できる",
        S.doc.theme === "dusk" && doc.getElementById("slidecard").dataset.theme === "dusk",
        S.doc.theme);
  P.setSlideLayout("section");
  const curSlide = S.doc.slides[S.active];
  check("レイアウトを変更できる", curSlide.layout === "section" && doc.getElementById("slidecard").dataset.layout === "section",
        curSlide.layout);
  const beforeDup = S.doc.slides.length;
  P.slideDuplicate();
  check("スライドを複製できる", S.doc.slides.length === beforeDup + 1, String(S.doc.slides.length));
  const dupIdx = S.active;
  P.slideMove(-1);
  check("スライドを並べ替えできる", S.active === dupIdx - 1, String(S.active));
  S.doc.slides[S.active].notes = "最初に結論を述べる";
  S.doc.slides[S.active].title = "発表者モードのテスト";

  // --- 発表者モード (手元 = ドック / スクリーン = 別ウィンドウ) -------------
  // window.open は jsdom に無いので、開けたことにする代役を差し込む。
  let audienceOpened = null;
  window.open = (url, name, features) => {
    audienceOpened = { url, name, features };
    return { closed: false, focus() {}, close() { this.closed = true; } };
  };
  P.startPresent();
  const pres = doc.getElementById("presenter");
  check("発表者モードを開始できる", S.presenting === true && pres.hidden === false);
  check("スクリーン用の別ウィンドウを開く",
        !!audienceOpened && /#audience$/.test(audienceOpened.url),
        audienceOpened && audienceOpened.url);

  // 手元: 次のスライドが右下に「スライドとして」描かれる
  const nextBox = doc.getElementById("presNext");
  const nextSlideEl = nextBox.querySelector(".pres-slide");
  check("右下に次のスライドのプレビューが描かれる",
        !!nextSlideEl && !!nextSlideEl.querySelector(".pres-title"),
        nextSlideEl ? nextSlideEl.querySelector(".pres-title").textContent : "なし");
  check("次のスライドの番号が出る",
        /\d+ 枚目|なし/.test(doc.getElementById("presNextNo").textContent),
        doc.getElementById("presNextNo").textContent);
  check("発表者メモがドックに出る",
        doc.getElementById("presNotes").value === "最初に結論を述べる",
        doc.getElementById("presNotes").value);

  // 手元では編集できる (ドックはスライド編集をブロックしない)
  const editable = doc.querySelector("#slidecard .bullets textarea");
  check("発表者モードでもスライドを編集できる",
        !!editable && !editable.disabled && !editable.readOnly,
        editable ? "編集可" : "見つからない");
  const noteField = doc.getElementById("presNotes");
  noteField.value = "ドックで書き換えたメモ";
  noteField.oninput = noteField.oninput || null;
  noteField.dispatchEvent(new window.Event("input", { bubbles: true }));
  check("ドックのメモ編集がスライドに保存される",
        S.doc.slides[S.active].notes === "ドックで書き換えたメモ",
        S.doc.slides[S.active].notes);

  // スクリーンへ送る内容
  const presMsg = P.presPayload();
  check("スクリーンへ送る内容が揃っている",
        presMsg.type === "slide" && !!presMsg.slide && presMsg.total === S.doc.slides.length,
        `${presMsg.index + 1}/${presMsg.total} ${presMsg.theme}`);

  const presIdx = S.active;
  P.presentNext();
  check("発表者モードで次へ進める", S.active === Math.min(presIdx + 1, S.doc.slides.length - 1),
        `${presIdx} -> ${S.active}`);
  check("スライド番号が更新される", /\d+ \/ \d+/.test(doc.getElementById("presCount").textContent),
        doc.getElementById("presCount").textContent);
  P.presentPrev();
  check("発表者モードで前へ戻れる", S.active === presIdx, String(S.active));
  P.endPresent();
  check("発表者モードを終了できる", S.presenting === false && pres.hidden === true);
  check("終了時にスクリーンのウィンドウを閉じる",
        !!S.audienceWindow === false, String(S.audienceWindow));

  // --- コマンドパレット ---------------------------------------------------
  P.openPalette();
  check("コマンドパレットを開ける", doc.getElementById("palette").hidden === false);
  const hits = P.renderPalette("フォント");
  check("パレットでコマンドを検索できる", hits.length >= 1, String(hits.length));
  check("パレットから実行できる", P.runPalette("wordcount") >= 0);
  P.closePalette();

  // --- 絵文字アイコンの全廃 (SVG のみ) ------------------------------------
  const emoji = /[\u{1F300}-\u{1FAFF}\u{2190}-\u{21FF}\u{25A0}-\u{2BFF}\u{FE0F}\u{FF0B}]/u;
  const visibleText = [];
  doc.querySelectorAll("#suitebar, .apprail, .modchip, #presenter button").forEach((n) => {
    visibleText.push(n.textContent || "");
    n.querySelectorAll("[title]").forEach((m) => visibleText.push(m.getAttribute("title") || ""));
  });
  const emojiHits = visibleText.filter((t) => emoji.test(t));
  check("UI に絵文字アイコンが残っていない", emojiHits.length === 0,
        emojiHits.length ? emojiHits.slice(0, 2).join(" / ") : `${visibleText.length} 箇所を走査`);
  check("ツールバーのアイコンはインライン SVG",
        doc.querySelectorAll("#suitebar .tb svg").length >= 6,
        String(doc.querySelectorAll("#suitebar .tb svg").length) + " 個");

  // --- 画面切り替えの実再生 -----------------------------------------------
  P.openApp("presentation");
  const deck2 = S.doc;
  const s1 = deck2.slides[0];
  s1.transition = "wipe";
  S.active = 0;
  P.renderSlideView();
  const stage = doc.querySelector("#slidecard .slideviz");
  check("スライドに切り替え効果を設定できる", s1.transition === "wipe");
  check("切り替えを再生すると CSS クラスが付く",
        P.playTransition() === "wipe" && stage.classList.contains("tr-wipe"),
        stage.className);
  P.applyTransition(stage, "none");
  check("切り替えなしではクラスが付かない", !/tr-/.test(stage.className) && stage.dataset.transition === "none");

  // --- 箇条書きを 1 行ずつ出すアニメーション -------------------------------
  s1.animate = true;
  s1.bullets = [{ t: "一行目" }, { t: "二行目" }, { t: "三行目" }];
  S.active = 0;
  P.startPresent();
  // スクリーン (観客用) に描かれる内容を調べる。発表者ドックではなく、
  // 別ウィンドウが受け取るのと同じ payload を描画して確認する。
  const screenStage = () => {
    let st = doc.getElementById("audstage");
    if (!st) { st = doc.createElement("div"); st.id = "audstage"; doc.body.appendChild(st); }
    P.renderAudience(P.presPayload());
    return st;
  };
  const bulletsShown = () => screenStage().querySelectorAll(".pres-bullets li").length;
  check("アニメーション有効時は箇条書きが隠れている", bulletsShown() === 0, String(bulletsShown()));
  const step = P.presentNext();
  check("次へで 1 行目が出る", step === "reveal" && bulletsShown() === 1, `${step} / ${bulletsShown()}`);
  const step2 = P.presentNext();
  check("次へで 2 行目が出る", step2 === "reveal" && bulletsShown() === 2, `${step2} / ${bulletsShown()}`);
  P.presentNext();
  check("最後の行まで出る", bulletsShown() === 3, String(bulletsShown()));
  const step3 = P.presentNext();
  check("行を出し切ったらスライドが進む", step3 === "slide", String(step3));
  P.endPresent();
  s1.animate = false;
  s1.transition = "fade";

  // --- 速度: ツールバー再構築でフォント一覧を作り直さない -----------------
  P.openApp("document");
  P.openApp("presentation");
  P.openApp("document");
  const perf = S.perf || {};
  check("フォント一覧は 1 度だけ構築される (高速化)", perf.fontBuilds === 1, String(perf.fontBuilds));
  const fontCount = doc.querySelectorAll("#fontsel option").length;
  check("書体数は 100 種類以上", P.FONTS.length >= 100 && fontCount >= 101, `${fontCount} 件`);

  // --- Copy-on-Write undo --------------------------------------------------
  S.active = 0;
  P.openApp("workbook");
  const cowSheet = S.doc.sheets[0];
  const baseVal = (cowSheet.map.get("0,0") || { raw: "" }).raw;
  P.setSel(0, 0);
  P.commitEdit("メモ A", 0, 0);
  P.commitEdit("メモ B", 0, 0);
  const afterB = cowSheet.map.get("0,0").raw;
  P.undo();
  const afterUndo1 = S.doc.sheets[0].map.get("0,0").raw;
  P.undo();
  const afterUndo2 = S.doc.sheets[0].map.get("0,0").raw;
  P.redo();
  const afterRedo1 = S.doc.sheets[0].map.get("0,0").raw;
  P.redo();
  const afterRedo2 = S.doc.sheets[0].map.get("0,0").raw;
  check("CoW: 編集が入る", afterB === "メモ B", afterB);
  check("CoW: 1 回戻すと前の値", afterUndo1 === "メモ A", afterUndo1);
  check("CoW: 2 回戻すと元の値", afterUndo2 === baseVal, `"${afterUndo2}"`);
  check("CoW: やり直しは 1 段ずつ進む", afterRedo1 === "メモ A" && afterRedo2 === "メモ B",
        `${afterRedo1} -> ${afterRedo2}`);

  // 参照共有の確認: 書き込み前のセル実体はスナップショット側に残り、
  // ライブ側は別オブジェクトに差し替わる (これが CoW の証拠)。
  const liveCell = S.doc.sheets[0].map.get("0,0");
  P.commitEdit("メモ C", 0, 0);
  const top = S.undoStack[S.undoStack.length - 1];
  check("CoW: 旧セル実体はスナップショットが保持",
        top.cells.get("0,0") === liveCell && S.doc.sheets[0].map.get("0,0") !== liveCell,
        "shared snapshot / cloned live cell");

  // --- Rust から戻ってきた runs / リンクを UI が描ける ---------------------
  P.openApp("document");
  S.doc.blocks = [
    { type: "p", style: "Normal", align: "left", text: "詳しくは こちら をご覧ください。",
      fmt: { font: "Yu Gothic", size: 11 },
      runs: [
        { t: "詳しくは " },
        { t: "こちら", u: true, c: "#0563c1", link: "https://example.com/poccham" },
        { t: " をご覧ください。" },
      ] },
  ];
  P.renderDoc();
  P.decorateDoc();
  const linkEl = doc.querySelector('#page a[href="https://example.com/poccham"]');
  check("読み込んだ文書のリンクがクリック可能な <a> になる", !!linkEl, linkEl && linkEl.textContent);
  check("リンクの書式 (下線・色) も復元される",
        !!linkEl && linkEl.style.textDecoration === "underline" &&
          /(0563c1|5,\s*99,\s*193)/i.test(linkEl.style.color),
        linkEl && `${linkEl.style.textDecoration} / ${linkEl.style.color}`);
  check("段落の書式 (フォント) が反映される",
        /Yu Gothic/.test((doc.querySelector('#page [data-idx="0"]') || {}).style.fontFamily || ""),
        (doc.querySelector('#page [data-idx="0"]') || {}).style.fontFamily);

  // --- セルのハイパーリンク (Excel のリンク挿入) ---------------------------
  P.openApp("workbook");
  P.applyWorkbookPayload({
    kind: "workbook",
    title: "リンク",
    path: null,
    sheets: [{ name: "S", freeze: null, filter: null,
      cells: [["A1", "Poccham", "", 0, "Poccham", "https://example.com/poccham"],
              ["A2", "メール", "", 0, "メール", "mailto:info@example.com"],
              ["A3", "素のセル", "", 0, "素のセル", ""]] }],
  }, true);
  check("セルのリンクを読み込める", P.cellLinkAt(0, 0) === "https://example.com/poccham", P.cellLinkAt(0, 0));
  const savedWb = P.serializeWorkbook();
  const savedCells = savedWb.sheets[0].cells;
  check("セルのリンクを保存データに含める",
        savedCells.find((c) => c[0] === "A1")[5] === "https://example.com/poccham",
        String(savedCells.find((c) => c[0] === "A1")[5]));
  P.setSel(1, 0);
  check("セルのリンクを解除できる", P.COMMANDS.cellunlink() === 1 && P.cellLinkAt(1, 0) === "",
        `残り ${P.cellLinkAt(1, 0) || "なし"}`);
  check("解除は A1 に影響しない", P.cellLinkAt(0, 0) === "https://example.com/poccham");
  P.setSel(1, 0);
  P.undo();
  check("セルのリンク解除は元に戻せる",
        P.cellLinkAt(1, 0) === "mailto:info@example.com", P.cellLinkAt(1, 0));

  // --- スライドのリンク ---------------------------------------------------
  P.openApp("presentation");
  S.active = 0;
  const sl = S.doc.slides[0];
  sl.shapes = [{ kind: "roundedRect", xMm: 20, yMm: 40, wMm: 60, hMm: 30, text: "詳細", fill: "2E75B6",
                 link: "https://example.com/shape" }];
  sl.bullets = [{ t: "資料", level: 0, link: "https://example.com/doc" }];
  P.renderSlideView();
  const linkedShape = doc.querySelector("#slidecard .slideviz .sh");
  check("スライド図形のリンクがクリック可能になる",
        !!linkedShape && linkedShape.style.cursor === "pointer" && /example\.com\/shape/.test(linkedShape.title),
        linkedShape && linkedShape.title);
  const linkedBullet = doc.querySelector("#slidecard .bullets textarea");
  check("箇条書きのリンクも表示される",
        !!linkedBullet && /example\.com\/doc/.test(linkedBullet.title), linkedBullet && linkedBullet.title);
  const removed = P.COMMANDS.slideunlink();
  check("スライドのリンクを一括解除できる",
        removed === 2 && !S.doc.slides[0].shapes[0].link && !S.doc.slides[0].bullets[0].link,
        String(removed));

  // --- 描画方式 (GPU / 2D) ------------------------------------------------
  P.openApp("workbook");
  check("GPU が無い環境では 2D に戻る",
        P.renderer === "auto" && P.rendererState().active === false,
        `mode=${P.renderer} active=${P.rendererState().active}`);

  window.__fakeGL = fakeGL();
  P.setRenderer("gpu");
  const gpuState = P.rendererState();
  check("GPU レイヤが有効になる", gpuState.active === true, `mode=${gpuState.mode}`);
  check("背景・罫線・選択を 1 draw call にまとめる",
        window.__fakeGL.calls === 1 && gpuState.calls === 1,
        `${window.__fakeGL.calls} call / ${window.__fakeGL.lastCount} インスタンス`);
  check("可視セルぶんの矩形をインスタンス描画している",
        window.__fakeGL.lastCount > 200,
        `${window.__fakeGL.lastCount} 矩形`);

  // 部分描画: 1 セルの編集は全面より少ない矩形 + scissor になる
  const fullQuads = P.rendererState().quads;
  const scissorsBefore = window.__fakeGL.scissors;
  P.setSel(2, 2, false);
  P.commitEdit("1234", 0, 0);
  const partial = P.rendererState();
  check("部分描画では矩形数が減る (GPU でも dirty rect が効く)",
        partial.quads > 0 && partial.quads < fullQuads,
        `全面 ${fullQuads} → 部分 ${partial.quads}`);
  check("部分描画は scissor で範囲を限定する",
        window.__fakeGL.scissors > scissorsBefore,
        `scissor ${window.__fakeGL.scissors - scissorsBefore} 回`);

  // --- クリックしても黒くならない (GL レイヤの不透明な黒を出さない) -------
  const rectsAfterClick = P.lastRects();
  const quadsOf = (arr) => {
    const out = [];
    for (let i = 0; i + 7 < arr.length; i += 8) {
      out.push({
        x: arr[i], y: arr[i + 1], w: arr[i + 2], h: arr[i + 3],
        r: arr[i + 4], g: arr[i + 5], b: arr[i + 6], a: arr[i + 7],
      });
    }
    return out;
  };
  const clickQuads = quadsOf(rectsAfterClick);
  const blackQuads = clickQuads.filter((q) => q.a > 0 && q.r === 0 && q.g === 0 && q.b === 0);
  check("クリック後の再描画に黒い矩形が無い", blackQuads.length === 0,
        `${clickQuads.length} 矩形中 ${blackQuads.length} 個が黒`);
  // 部分描画では「傷んだ範囲だけ」を下地色で塗り直している (scissor + clear)。
  // ここが抜けると、クリックした周辺が黒や前の内容のまま残る。
  const region = P.GLlastRegion();
  const sc = window.__fakeGL.scissorRect;
  const dpr = doc.defaultView.devicePixelRatio || 1;
  check("部分描画でも傷んだ範囲を下地で塗り直している",
        !!region && !!sc && sc[2] >= Math.ceil(region.w * dpr) && sc[3] >= Math.ceil(region.h * dpr),
        region && sc ? `region ${Math.round(region.w)}x${Math.round(region.h)} / scissor ${sc[2]}x${sc[3]}` : "不明");
  // 色の解釈: 未知の色は黒ではなく null
  check("解釈できない色は黒にしない",
        P.parseColor("not-a-color") === null && P.parseColor("") === null,
        String(P.parseColor("not-a-color")));
  const alphaCol = P.parseColor("rgba(46,84,150,.10)");
  check("小数の不透明度を読める (選択色)",
        !!alphaCol && Math.abs(alphaCol[3] - 0.1) < 0.01,
        alphaCol ? String(alphaCol[3]) : "null");
  const hexCol = P.parseColor("#2E75B6");
  check("#RRGGBB を読める",
        !!hexCol && hexCol[2] > 0.6 && Math.abs(hexCol[3] - 1) < 0.001,
        hexCol ? hexCol.map((v) => v.toFixed(2)).join(",") : "null");

  // 環境によっては GL のクリアが黒くなる。初回全面描画で色を読み戻して
  // 合わなければ 2D に切り替える (「クリックすると黒くなる」の保険)。
  const brokenGL = fakeGL();
  brokenGL.NO_ERROR = 0;
  brokenGL.getError = () => 0;
  brokenGL.readPixels = (x, y, w, h, fmt, type, out) => {
    out[0] = 0; out[1] = 0; out[2] = 0; out[3] = 255;   // 期待は白系の背景
  };
  window.__fakeGL = brokenGL;
  P.setRenderer("gpu");
  check("色が合わない GPU では自動で 2D に戻る",
        P.rendererState().active === false,
        `active=${P.rendererState().active}`);
  check("2D に戻ってもシートは描けている",
        !!doc.querySelector("#gridcanvas") && P.state.doc.kind === "workbook");

  window.__fakeGL = fakeGL();
  P.setRenderer("gpu");
  check("色が合う GPU なら使い続ける", P.rendererState().active === true);

  P.setRenderer("2d");
  check("2D を選ぶと GPU を使わない", P.rendererState().active === false);
  P.setRenderer("auto");
  check("自動に戻すと GPU を再選択する", P.rendererState().active === true);
  window.__fakeGL = null;

  // --- 統合ファイル -------------------------------------------------------
  const suite = P.serializeSuite();
  // 「1 つのファイルに 3 つのアプリ」という説明は UI から外した
  const strip = doc.getElementById("tabstrip");
  check("アプリの並びに説明文を出さない",
        !!strip && !strip.querySelector(".modnote") &&
          !/3 つのアプリ/.test(strip.textContent || ""),
        strip ? strip.textContent.replace(/\s+/g, " ").trim().slice(0, 40) : "なし");
  check("画面のどこにも「3 つのアプリ」と書いていない",
        !/3 つのアプリ|1 つのファイルに/.test(doc.body.textContent || ""));

  check("3 アプリを 1 つのファイルにまとめられる",
        suite.kind === "suite" && !!suite.document && !!suite.presentation && !!suite.workbook,
        `${suite.kind} / ${suite.document ? "W" : "-"}${suite.workbook ? "S" : "-"}${suite.presentation ? "P" : "-"}`);
  check("統合ファイルを読み戻せる",
        P.loadSuite(JSON.parse(JSON.stringify(suite))) === true);

  // --- シートの全選択 (左上の角 / Ctrl+A) --------------------------------
  P.openApp("workbook");
  const gridWrap = doc.getElementById("gridwrap");
  const corner = new window.MouseEvent("mousedown", { bubbles: true, clientX: 4, clientY: 4 });
  gridWrap.dispatchEvent(corner);
  check("左上の角をクリックするとシート全体が選ばれる",
        S.sel.r === 0 && S.sel.c === 0 && S.sel.ar === 399 && S.sel.ac === 59,
        `${S.sel.r},${S.sel.c} - ${S.sel.ar},${S.sel.ac}`);
  P.setSel(3, 2, false);
  doc.dispatchEvent(new window.KeyboardEvent("keydown", { key: "a", ctrlKey: true, bubbles: true }));
  check("Ctrl+A でもシート全体を選べる", S.sel.ar === 399 && S.sel.ac === 59,
        `${S.sel.ar},${S.sel.ac}`);
  check("全選択の件数がステータスに出る", /〜/.test(doc.getElementById("selinfo").textContent || ""),
        doc.getElementById("selinfo").textContent);
  P.setSel(0, 0, false);

  // --- ショートカット ------------------------------------------------------
  const keys = P.shortcutList();
  check("ショートカットが 60 件以上ある", keys.length >= 60, `${keys.length} 件`);
  const dupes = {};
  keys.forEach((k) => {
    const sig = `${k.keys}|${k.group}`;
    dupes[sig] = (dupes[sig] || 0) + 1;
  });
  check("同じキーの重複登録が無い",
        Object.values(dupes).every((n) => n === 1),
        Object.entries(dupes).filter(([, n]) => n > 1).map(([k]) => k).join(" / ") || "重複なし");
  check("キーの組み合わせを判定できる",
        P.keySpecMatches("Ctrl+Shift+L", { key: "L", ctrlKey: true, shiftKey: true, altKey: false }) === true &&
          P.keySpecMatches("Ctrl+Shift+L", { key: "l", ctrlKey: true, shiftKey: false, altKey: false }) === false);
  // 一覧が開き、絞り込める
  P.openShortcuts();
  check("ショートカット一覧を開ける", doc.getElementById("dlgKeys").open === true ||
        doc.getElementById("dlgKeys").hasAttribute("open"));
  const rows = doc.querySelectorAll("#keysBody .keyrow").length;
  check("一覧にすべて並ぶ", rows === keys.length, `${rows} / ${keys.length}`);
  P.renderShortcuts("Ctrl+Shift");
  const filtered = doc.querySelectorAll("#keysBody .keyrow").length;
  check("キーで絞り込める", filtered > 0 && filtered < rows, `${filtered} 件`);
  P.renderShortcuts("存在しないコマンド");
  check("該当なしを表示できる", /一致するショートカットはありません/.test(doc.getElementById("keysBody").textContent));
  P.closeTopDialog();

  // 実際にキーで動くか (Writer: 見出し 1 / Slides: 新規スライド)
  P.suite.document = {
    kind: "document", title: "キー操作のテスト", path: null,
    blocks: [{ type: "p", style: "Normal", align: "left", text: "本文" }],
    comments: [], footnotes: 0,
  };
  P.openApp("document");
  S.activeBlock = 0;
  doc.dispatchEvent(new window.KeyboardEvent("keydown", { key: "1", ctrlKey: true, shiftKey: true, bubbles: true }));
  check("Ctrl+Shift+1 で見出しになる",
        S.doc.blocks[0].style === "Heading1", S.doc.blocks[0].style);
  P.openApp("presentation");
  const beforeSlides = S.doc.slides.length;
  doc.dispatchEvent(new window.KeyboardEvent("keydown", { key: "m", ctrlKey: true, bubbles: true }));
  check("Ctrl+M でスライドが増える", S.doc.slides.length === beforeSlides + 1,
        `${beforeSlides} -> ${S.doc.slides.length}`);
  P.openApp("workbook");
  P.setSel(0, 0, false);
  doc.dispatchEvent(new window.KeyboardEvent("keydown", { key: ";", ctrlKey: true, bubbles: true }));
  check("Ctrl+; で今日の日付が入る", /\d{4}\/\d{2}\/\d{2}/.test((P.cellAt(0, 0) || {}).raw || ""),
        (P.cellAt(0, 0) || {}).raw);
  const fillSrc = { raw: "5", f: "", s: 0, d: "" };
  S.doc.sheets[0].map.set("0,1", fillSrc);
  S.sel = { r: 0, c: 1, ar: 3, ac: 1 };
  doc.dispatchEvent(new window.KeyboardEvent("keydown", { key: "d", ctrlKey: true, bubbles: true }));
  check("Ctrl+D で下のセルへコピーされる",
        ((P.cellAt(3, 1) || {}).raw || "") === "5", (P.cellAt(3, 1) || {}).raw);

  // --- ファイルのドラッグ＆ドロップ ---------------------------------------
  const pngBytes = Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const pngFile = () => new window.File([pngBytes], "図.png", { type: "image/png" });

  P.openApp("workbook");
  P.setSel(2, 1, false);
  const beforeImgs = (S.doc.sheets[0].images || []).length;
  const noteImg = await P.importFile(pngFile());
  check("画像を落とすとシートに貼られる",
        (S.doc.sheets[0].images || []).length === beforeImgs + 1 && /貼りました/.test(noteImg || ""),
        noteImg);
  const im = S.doc.sheets[0].images[S.doc.sheets[0].images.length - 1];
  check("画像は選んでいたセルの位置に置かれる", im.col === 1 && im.row === 2, `${im.row},${im.col}`);
  check("画像は保存データに含まれる",
        (P.serializeWorkbook().sheets[0].images || []).length === beforeImgs + 1);

  const csv = new window.File(["品名,数量\nりんご,3\nみかん,5\n"], "在庫.csv", { type: "text/csv" });
  await P.importFile(csv);
  const csvSheet = S.doc.sheets[S.doc.sheets.length - 1];
  check("CSV を落とすとセルに入る",
        csvSheet.name === "在庫" && (csvSheet.map.get("0,0") || {}).raw === "品名" &&
          (csvSheet.map.get("2,1") || {}).raw === "5",
        `${csvSheet.name} / ${(csvSheet.map.get("2,1") || {}).raw}`);

  const md = new window.File(["# 見出し\n本文です\n- 箇条書き\n"], "メモ.md", { type: "text/markdown" });
  await P.importFile(md);
  check("テキストを落とすと Writer に読み込まれる",
        S.doc.kind === "document" && S.doc.blocks[0].style === "Heading1" &&
          S.doc.blocks[2].style === "Bullet",
        S.doc.blocks.map((b) => b.style).join(","));

  const beforeDocImgs = S.doc.blocks.filter((b) => b.type === "image").length;
  await P.importFile(pngFile());
  check("Writer に画像を落とすと挿入される",
        S.doc.blocks.filter((b) => b.type === "image").length === beforeDocImgs + 1);

  P.openApp("presentation");
  const beforeSlideImgs = ((S.doc.slides[S.active] || {}).images || []).length;
  await P.importFile(pngFile());
  check("Slides に画像を落とすとスライドに入る",
        (((S.doc.slides[S.active] || {}).images || []).length) === beforeSlideImgs + 1);

  const dropNotes = await P.handleDroppedFiles([pngFile(), csv]);
  check("複数ファイルをまとめて取り込める", dropNotes.length === 2, String(dropNotes.length));
  const unsupported = await P.importFile(new window.File(["x"], "謎.bin", { type: "" }));
  check("未対応の形式はその旨を返す", /未対応/.test(unsupported || ""), unsupported);

  console.log();
  if (failures.length) {
    console.log(`失敗 ${failures.length} 件: ${failures.join(", ")}`);
    process.exit(1);
  }
  console.log("UI スモークテスト: すべて合格");
  process.exit(0);
}, 200);
