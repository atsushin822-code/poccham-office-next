# Poccham Office Next

表計算・文書・プレゼンテーションを扱うデスクトップアプリです。`xlsx` / `docx` /
`pptx`（Office Open XML）を自前のエンジンで読み書きし、Excel VBA マクロの
サブセットを実行します。UI は 1 枚の HTML、処理は Rust 側にあります。

![表計算](docs/images/sheet.png)

| 文書 | プレゼンテーション |
| --- | --- |
| ![文書](docs/images/document.png) | ![スライド](docs/images/slides.png) |

---

## 画面

左上のレール（`Ctrl+1` / `Ctrl+2` / `Ctrl+3`）で Sheet / Writer / Slides を
切り替えます。起動時は白紙のブックで、見本のファイルは同梱していません。
編集中のものは切り替えても残り、`全データを書き出す` で 3 つぶんをまとめて
書き出せます。

| | 主な機能 |
| --- | --- |
| Sheet（Excel 相当） | 270 関数、数式バー、書式、並べ替えと絞り込み、ピボット、グラフ、**画像の貼り付け**（セル位置に固定し .xlsx の drawing として保存）、左上クリック / `Ctrl+A` の全選択、セルのリンク挿入（`<hyperlinks>` と外部リレーションとして .xlsx に保存・再読込、Ctrl+クリックで開く）、VBA 互換マクロ、xlsx / ods / CSV の相互変換 |
| Writer（Word 相当） | 170 書体のフォント、サイズ・太字・斜体・下線・文字色、行揃え、リンク挿入（`<w:hyperlink>` と外部リレーションとして .docx に保存・再読込）、画像挿入（ローカル / URL）、表、目次、ヘッダーとフッター（往復）、脚注、コメント、検索と置換、文字数、改ページ、Markdown 書き出し |
| Slides（PowerPoint 相当） | 発表者モード（手元と投影を分け、投影側はスライドだけ・手元は編集したまま右下に次のスライドとメモ）、画面切り替えの実再生（フェード / プッシュ / ワイプ / スプリット / カバー、`prefers-reduced-motion` 対応）、箇条書きの 1 行ずつ表示（スライド単位で on/off）、画像挿入、図形・画像・箇条書きのリンク挿入（`<a:hlinkClick>` と外部リレーションとして .pptx に保存）、.pptx への `p:transition` とアニメーション書き出し（箇条書きは段落単位の `p:bldP build="p"` + `pRg`）、5 レイアウト、6 テーマ、9 種類の図形、複製と並べ替え |

### アプリをまたぐ連携

- Sheet で範囲を選び、Writer の「表」でその場に表として挿入
- Sheet の範囲から表スライドを作る
- Sheet のグラフを画像として Writer / Slides へ
- Writer の目次は見出しから自動生成し、Slides の発表者メモは本番画面に出す

### ファイルのドラッグ＆ドロップ

画像・`.csv`・`.md` / `.txt`・`.json`（このアプリの書き出し）をウィンドウへ放り込めます。

| 落としたもの | 入る先 |
| --- | --- |
| 画像（png / jpg / gif / webp / svg） | Writer は本文へ、Slides はスライド上へ、Sheet は選択中のセル位置へ |
| `.csv` | 新しいシート（1 行目からそのまま） |
| `.md` / `.txt` | Writer（`#` は見出し、`-` は箇条書き） |
| `.json` | ブック / 文書 / スライド、またはまとめて書き出したデータ |

`.xlsx` / `.docx` / `.pptx` / `.ods` はデスクトップ版の「開く」から読みます
（ブラウザだけでは OOXML を解析できないため）。

### キーボード

ショートカットは 63 個あり、`Ctrl+/` または `F1` で一覧を検索できます。
`Ctrl+K` のコマンド検索と合わせると、マウスを使わずに全機能へ届きます。

| 例 | 動作 |
| --- | --- |
| `Ctrl+1` / `Ctrl+2` / `Ctrl+3` | Sheet / Writer / Slides |
| `Ctrl+Shift+1〜3` | 見出し 1〜3 |
| `Ctrl+M` / `Ctrl+Shift+D` | スライド追加 / 複製 |
| `F5` | 発表者モード |
| `Ctrl+D` / `Ctrl+R` | 上のセルを下へ / 左のセルを右へ（数式は参照をずらす） |
| `Ctrl+;` / `Ctrl+Shift+;` | 日付 / 時刻 |
| `Ctrl+Arrow` / `Ctrl+Shift+Arrow` | データの端へ / 端まで範囲選択 |
| `Ctrl+PageDown` / `Ctrl+PageUp` | 次のシート / 前のシート |
| `Ctrl+Alt+R` | 描画方式（自動 / GPU / 2D）を切り替え |

### コマンドパレット

`Ctrl+K`（⌘K）で全アプリのコマンドを横断検索して実行できます。

## できること

- リボンと表示は、いま開いている文書の種類に合わせて切り替わります。
- 20 万セルのブックを書き込み 46 ms / 読み込み 134 ms / 再計算 35 ms（下記ベンチマーク）。
- VBA マクロ — `Sub`/`Function`・`With`・`For Each`・配列・`Range`/`Cells`・結合とコピー&ペースト・`WorksheetFunction`（数式エンジンへ委譲）・日付関数・`MsgBox`/`Debug.Print` を解釈します。
- 表計算はセルの結合・条件付き書式・入力規則・グラフ・ピボットテーブル・画像・コメント、文書は画像・脚注・目次・ヘッダー/フッター・変更履歴・コメント、プレゼンは図形・画像・画面切り替え・アニメーション・発表者ノート・テーマまで。
- 関数は 270 種（数学/統計/検索/文字列/日付/財務/エンジニアリング/情報）。数は `python3 scripts/count_functions.py` で数えられます。
- UI は日本語。インストーラは日本語 / English を選べます。
- 外部クレートは `zip` と `serde_json` だけ。UI はフレームワークもビルドツールも使わない単一 HTML です。
- CLI・GUI・テストは同じ `poc-core` / `poc-vba` を使います。
- リンクはどのアプリでも入れられます。Writer は段落の run、Sheet はセル、Slides は図形・画像・箇条書き。
  どれも OOXML の標準要素（`w:hyperlink` / `hyperlinks` / `a:hlinkClick`）として保存され、
  他社アプリで開いてもリンクとして機能します。
- Copy-on-Write — 編集のたびに文書全体を複製しません。undo のスナップショットは
  参照を共有し、変更したセルだけを複製します（3,000 セルで 7.7 倍、
  `docs/PERFORMANCE.md`）。エンジン側も `CowBuffer` / `History` で O(1) のチェックポイントを持ちます。
- 部分再描画 (dirty rect) — 変更されたセルの矩形だけを描き直します。全面描画
  13.99 ms → 1 セル 1.65 ms。スクロール・シート切替は全面へ戻します。
- GPU グリッド — セル背景・罫線・選択範囲を WebGL2 のインスタンス描画で
  1 draw call にまとめます（909 矩形/フレーム）。GL が使えない環境、色が合わない
  環境では 2D 描画に戻ります。ステータスバーの「描画」で `自動 / GPU / 2D` を選べます。
- ネイティブ画面 (egui) — `crates/poc-egui` に、WebView を使わない egui 版の
  表・設定・マクロ・情報画面があります（`cargo run --manifest-path crates/poc-egui/Cargo.toml --release`）。
  文章編集のネイティブ化は日本語 IME の検証待ちで、まだ WebView 版が担当します。

## パフォーマンス

20 万セル（うち 2.5 万が数式）のブックでの実測値です（2 vCPU / 2 GB の Linux コンテナ、`cargo build --release`）。

| 処理 | Poccham Office Next | openpyxl | 倍率 |
| --- | --- | --- | --- |
| 書き込み | 45.4 ms（4,400 セル/ms） | 138.3 ms | 3.0x |
| 読み込み | 136.6 ms（683 ns/セル） | 2.40 s | 17.6x |
| 再計算 | 35.8 ms | — | — |
| ファイルサイズ | 1.45 MB | 1.04 MB | 1.40x（大きい） |

ファイルサイズが大きいのは、速度を優先して DEFLATE の圧縮レベルを 1 に固定しているためです
（`poc-core/src/pkg.rs`）。サイズを優先したい場合はレベルを上げるだけで切り替わります。

UI の起動と大きなブックを開く時間（5 万セル、Chromium 実測の中央値）:

| 処理 | 時間 |
| --- | --- |
| 起動（cold boot） | 107 ms |
| ブックを開く（計算結果キャッシュあり） | 103 ms |
| ブックを開く（全数式を再計算） | 229 ms |

ファイルを開くときに計算結果が入っていれば再計算を省略するため、この差が出ます
（`python3 scripts/ui_boot_bench.py` で再現、Playwright + Chromium が必要）。

計測は `python3 scripts/bench_compare.py` で再現できます。

## クイックスタート

```bash
# 1. ビルド（Rust 1.82 以降）
cargo build --release

# 2. CLI
./target/release/poc new report.xlsx          # サンプルブックを作成
./target/release/poc info report.xlsx         # 構造を表示
./target/release/poc calc report.xlsx         # 再計算
./target/release/poc convert report.xlsx report.ods
./target/release/poc macro run report.xlsx --module report.bas --call BuildReport
./target/release/poc bench --cells 200000     # スループット測定

# 3. デスクトップアプリ（要 WebView2 / WKWebView / WebKitGTK）
cargo install tauri-cli --version "^2" --locked
cd crates/poc-ui/src-tauri && cargo tauri dev
```

UI だけを確認したい場合は `crates/poc-ui/ui/index.html` をブラウザで開いてください。
デスクトップ版が無い環境では自動的に**デモモード**（サンプルの四半期売上レポート）で起動し、
保存やマクロ実行だけが無効になります。

## GitHub Actions で配布物を作る

このリポジトリをそのまま GitHub に push すると `.github/workflows/build.yml` が動き、
次の成果物が作られます（タグ `v*` を push するとドラフトリリースに添付）。

| プラットフォーム | 成果物 |
| --- | --- |
| Windows | `*-setup.exe`（NSIS インストーラ、日本語/英語）と `*-portable.zip`（単体 exe） |
| macOS (Intel x86_64) | `*.dmg` |
| macOS (Apple Silicon) | `*.dmg` |
| Linux | `*.AppImage` / `*.deb` / `*.rpm` |
| 共通 | `SHA256SUMS.txt` |

テスト（3 OS でのユニット/統合テスト、clippy、整形、OOXML 相互検証、UI スモークテスト）が
すべて通った場合のみパッケージが作られます。

> **置き場所に注意**: `Cargo.toml` と `.github/workflows/build.yml` はリポジトリの
> **直下**に必要です。配布 zip はアーカイブ直下に `Cargo.toml` が入る形で作ってあります。
> サブフォルダごと push した／zip をそのままコミットした場合も、ワークフローの
> 最初のステップ「ソースのルートを解決」が深さ 4 まで探して自動でルートへ移動します
> （zip はその場で展開されます）。

## リポジトリ構成

```
crates/
  poc-core/        OOXML / ODF / CSV の読み書き、数式エンジン、ZIP コンテナ
  poc-vba/         VBA の字句解析・構文解析・インタプリタ・Excel ホスト
  poc-bridge/      UI ⇄ エンジンの JSON 境界（テスト対象の中心）
  poc-cli/         poc コマンド
  poc-ui/
    ui/index.html    デスクトップ UI 本体（単一ファイル、ビルド不要）
    src-tauri/       Tauri v2 の薄いシェル
assets/icons/      アイコン一式（純粋な幾何形状から生成）
scripts/           相互検証・ベンチマーク・アイコン生成・UI スモークテスト
docs/              設計・互換性・ビルド・権利関係のドキュメント
```

## テスト

```bash
cargo test --workspace          # 155 テスト（ユニット + 統合 + doctest）
cargo test --manifest-path crates/poc-egui/Cargo.toml   # ネイティブ (egui) 7 テスト
cargo run --manifest-path crates/poc-egui/Cargo.toml --release -- --selftest  # 9 項目
cargo clippy --workspace --all-targets -- -D warnings
cargo fmt --all -- --check
python3 scripts/verify_ooxml.py # 79 項目の相互運用性チェック（3 つの独立実装で検証）
node scripts/ui_smoke_test.js   # 170 項目の UI スモークテスト（要 jsdom）
node scripts/ui_audience_test.js # 16 項目のスクリーン (観客用) ウィンドウのテスト
node scripts/ui_perf_probe.js   # 描画・CoW の実測（部分描画 / GPU / 2D の内訳つき）
python3 scripts/ui_boot_bench.py  # 起動時間の計測（要 Playwright + Chromium）
```

## ドキュメント

- [docs/BUILD.md](docs/BUILD.md) — 各 OS でのビルドと配布物の作り方
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) — クレート構成・JSON 契約・設計判断
- [docs/PERFORMANCE.md](docs/PERFORMANCE.md) — Copy-on-Write・部分再描画・GPU グリッド・ネイティブ egui の実測
- [docs/NATIVE_UI.md](docs/NATIVE_UI.md) — ネイティブ (egui) 画面の構成と段階移行の現在地
- [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md) — 対応形式・関数・VBA の範囲と限界
- [docs/IP_NOTES.md](docs/IP_NOTES.md) — 実装方針とライセンス

## ライセンス

MIT（[LICENSE](LICENSE)）。同梱の依存クレートは `zip`（MIT）と `serde_json`（MIT / Apache-2.0）のみです。
「Microsoft Office」「Excel」「Word」「PowerPoint」は Microsoft Corporation の商標です。
本プロダクトは独立実装であり、Microsoft による認定・提携を受けたものではありません。
