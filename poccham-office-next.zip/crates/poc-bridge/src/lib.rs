//! Bridge between the web UI and the document engine.
//!
//! The desktop shell (`crates/poc-ui/src-tauri`) is a thin Tauri wrapper around
//! this crate: everything that understands documents lives here, so the same
//! code is exercised by `cargo test` on every platform without a webview SDK.
//!
//! Every entry point speaks the JSON contract documented in `docs/ARCHITECTURE.md`:
//!
//! * document model — `{ kind, title, path, sheets|blocks|slides }`
//! * cell — `[address, raw, formula, styleIndex, cachedText]`
#![forbid(unsafe_code)]

use std::path::Path;

use serde_json::{json, Value};

use poc_core::detect::{self, Format};
use poc_core::docx::Picture;
use poc_core::docx::{Align, Block, Document, ParaStyle, Paragraph, Run, Table};
use poc_core::pptx::{Bullet, Presentation, Shape, ShapeKind, Slide};
use poc_core::xlsx::{self, Cell, CellValue, Sheet, Workbook};
use poc_vba::{parse_module, Engine, ExcelHost, Value as VbaValue};

// ---------------------------------------------------------------- helpers

fn err<E: std::fmt::Display>(e: E) -> String {
    e.to_string()
}

/// Minimal base64 so pictures can travel through the JSON contract as
/// `data:` URIs (the UI shows them without touching the disk).
fn b64_encode(data: &[u8]) -> String {
    const TABLE: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::with_capacity(data.len().div_ceil(3) * 4);
    for chunk in data.chunks(3) {
        let b = [
            chunk[0],
            *chunk.get(1).unwrap_or(&0),
            *chunk.get(2).unwrap_or(&0),
        ];
        let n = ((b[0] as u32) << 16) | ((b[1] as u32) << 8) | b[2] as u32;
        out.push(TABLE[(n >> 18) as usize & 63] as char);
        out.push(TABLE[(n >> 12) as usize & 63] as char);
        out.push(if chunk.len() > 1 {
            TABLE[(n >> 6) as usize & 63] as char
        } else {
            '='
        });
        out.push(if chunk.len() > 2 {
            TABLE[n as usize & 63] as char
        } else {
            '='
        });
    }
    out
}

fn b64_decode(text: &str) -> Vec<u8> {
    let val = |c: u8| -> Option<u32> {
        Some(match c {
            b'A'..=b'Z' => c - b'A',
            b'a'..=b'z' => c - b'a' + 26,
            b'0'..=b'9' => c - b'0' + 52,
            b'+' => 62,
            b'/' => 63,
            _ => return None,
        } as u32)
    };
    let mut out = Vec::new();
    let mut acc = 0u32;
    let mut bits = 0u32;
    for byte in text.bytes() {
        let Some(v) = val(byte) else { continue };
        acc = (acc << 6) | v;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            out.push((acc >> bits) as u8);
        }
    }
    out
}

/// `data:image/png;base64,…` in, bytes + extension out.
fn split_data_uri(uri: &str) -> Option<(Vec<u8>, String)> {
    let rest = uri.strip_prefix("data:")?;
    let (meta, payload) = rest.split_once(',')?;
    let ext = if meta.contains("jpeg") || meta.contains("jpg") {
        "jpeg"
    } else {
        "png"
    };
    Some((b64_decode(payload), ext.to_string()))
}

fn workbook_to_json(wb: &Workbook, path: Option<&str>) -> Value {
    let sheets: Vec<Value> = wb
        .sheets
        .iter()
        .map(|sheet| {
            let mut cells: Vec<Value> = Vec::with_capacity(sheet.rows.len() * 8);
            for (r, row) in sheet.rows.iter().enumerate() {
                for (c, cell) in row.iter().enumerate() {
                    let addr = format!("{}{}", xlsx::col_letters(c as u32), r + 1);
                    let (raw, formula) = match &cell.value {
                        CellValue::Formula { expr, .. } => (String::new(), expr.clone()),
                        CellValue::Empty => continue,
                        other => (
                            Cell {
                                value: other.clone(),
                                style: cell.style,
                            }
                            .as_text(),
                            String::new(),
                        ),
                    };
                    if raw.is_empty() && formula.is_empty() {
                        continue;
                    }
                    cells.push(json!([addr, raw, formula, cell.style, cell.as_text()]));
                }
            }
            json!({
                "name": sheet.name,
                "freeze": sheet.freeze.map(|(r, c)| json!([r, c])).unwrap_or(Value::Null),
                "filter": sheet.autofilter,
                "widths": sheet.col_widths,
                "cells": cells,
            })
        })
        .collect();
    json!({
        "kind": "workbook",
        "title": wb.title,
        "path": path,
        "sheets": sheets,
    })
}

fn json_to_workbook(payload: &Value) -> Result<Workbook, String> {
    let mut wb = Workbook::new();
    wb.title = payload
        .get("title")
        .and_then(|v| v.as_str())
        .unwrap_or_default()
        .to_string();
    let Some(sheets) = payload.get("sheets").and_then(|v| v.as_array()) else {
        return Err("シート情報がありません".into());
    };
    wb.sheets.clear();
    for sheet in sheets {
        let mut s = Sheet::new(
            sheet
                .get("name")
                .and_then(|v| v.as_str())
                .unwrap_or("Sheet1"),
        );
        if let Some(f) = sheet.get("freeze").and_then(|v| v.as_array()) {
            let r = f.first().and_then(|v| v.as_u64()).unwrap_or(0) as u32;
            let c = f.get(1).and_then(|v| v.as_u64()).unwrap_or(0) as u32;
            if r > 0 || c > 0 {
                s.freeze = Some((r, c));
            }
        }
        s.autofilter = sheet
            .get("filter")
            .and_then(|v| v.as_str())
            .map(|v| v.to_string());
        if let Some(cells) = sheet.get("cells").and_then(|v| v.as_array()) {
            for cell in cells {
                let Some(arr) = cell.as_array() else { continue };
                let addr = arr.first().and_then(|v| v.as_str()).unwrap_or("");
                let raw = arr.get(1).and_then(|v| v.as_str()).unwrap_or("");
                let formula = arr.get(2).and_then(|v| v.as_str()).unwrap_or("");
                let style = arr.get(3).and_then(|v| v.as_u64()).unwrap_or(0) as u16;
                let Some((r, c)) = xlsx::parse_ref(addr) else {
                    continue;
                };
                let value = if !formula.trim().is_empty() {
                    Cell::formula(formula.trim().trim_start_matches('=').to_string(), None)
                } else {
                    let t = raw.trim();
                    if t.is_empty() {
                        Cell::empty()
                    } else if let Ok(n) = t.parse::<f64>() {
                        Cell::num(n)
                    } else if t.eq_ignore_ascii_case("true") {
                        Cell::boolean(true)
                    } else if t.eq_ignore_ascii_case("false") {
                        Cell::boolean(false)
                    } else {
                        Cell::text(raw)
                    }
                };
                s.set(r, c, value.styled(style));
            }
        }
        wb.sheets.push(s);
    }
    if wb.sheets.is_empty() {
        wb.sheets.push(Sheet::new("Sheet1"));
    }
    Ok(wb)
}

fn document_to_json(doc: &Document, path: Option<&str>) -> Value {
    let blocks: Vec<Value> = doc
        .blocks
        .iter()
        .map(|b| match b {
            Block::Paragraph(p) => {
                let style = match &p.style {
                    ParaStyle::Normal => "Normal",
                    ParaStyle::Title => "Title",
                    ParaStyle::Heading(1) => "Heading1",
                    ParaStyle::Heading(2) => "Heading2",
                    ParaStyle::Heading(_) => "Heading3",
                    ParaStyle::Quote => "Quote",
                    ParaStyle::Code => "Code",
                    ParaStyle::Bullet => "Bullet",
                    ParaStyle::Numbered => "Numbered",
                };
                let align = match p.align {
                    Align::Left => "left",
                    Align::Center => "center",
                    Align::Right => "right",
                    Align::Justify => "justify",
                };
                json!({
                    "type": "p",
                    "style": style,
                    "align": align,
                    "text": p.text(),
                })
            }
            Block::Table(t) => json!({ "type": "table", "rows": t.rows, "header": t.header }),
            Block::PageBreak => json!({ "type": "pagebreak" }),
            Block::Image(pic) => json!({
                "type": "image",
                "name": pic.name,
                "ext": pic.ext,
                "widthMm": pic.width_mm,
                "heightMm": pic.height_mm,
                "data": format!("data:image/{};base64,{}", pic.ext, b64_encode(&pic.data)),
            }),
            Block::Toc => json!({ "type": "toc" }),
        })
        .collect();
    let header = doc
        .header
        .as_ref()
        .map(|h| h.text.clone())
        .unwrap_or_default();
    let footer = doc
        .footer
        .as_ref()
        .map(|f| f.text.clone())
        .unwrap_or_default();
    json!({
        "kind": "document",
        "title": doc.title,
        "path": path,
        "blocks": blocks,
        "header": header,
        "footer": footer,
        "footnotes": doc.footnotes.len(),
        "comments": doc.comments.iter().map(|c| json!({
            "author": c.author,
            "text": c.text,
        })).collect::<Vec<_>>(),
    })
}

fn shape_name(kind: ShapeKind) -> &'static str {
    match kind {
        ShapeKind::Rect => "rect",
        ShapeKind::RoundedRect => "roundedRect",
        ShapeKind::Ellipse => "ellipse",
        ShapeKind::Triangle => "triangle",
        ShapeKind::RightArrow => "rightArrow",
        ShapeKind::Line => "line",
        ShapeKind::Star5 => "star5",
        ShapeKind::Chevron => "chevron",
        ShapeKind::Diamond => "diamond",
    }
}

fn shape_from_name(name: &str) -> ShapeKind {
    match name {
        "roundedRect" => ShapeKind::RoundedRect,
        "ellipse" => ShapeKind::Ellipse,
        "triangle" => ShapeKind::Triangle,
        "rightArrow" => ShapeKind::RightArrow,
        "line" => ShapeKind::Line,
        "star5" => ShapeKind::Star5,
        "chevron" => ShapeKind::Chevron,
        "diamond" => ShapeKind::Diamond,
        _ => ShapeKind::Rect,
    }
}

fn transition_name(t: &poc_core::pptx::Transition) -> &'static str {
    use poc_core::pptx::Transition as T;
    match t {
        T::None => "none",
        T::Fade => "fade",
        T::Push => "push",
        T::Wipe => "wipe",
        T::Split => "split",
        T::Cover => "cover",
    }
}

fn transition_from_name(name: &str) -> poc_core::pptx::Transition {
    use poc_core::pptx::Transition as T;
    match name {
        "fade" => T::Fade,
        "push" => T::Push,
        "wipe" => T::Wipe,
        "split" => T::Split,
        "cover" => T::Cover,
        _ => T::None,
    }
}

fn json_to_document(payload: &Value) -> Document {
    let mut doc = Document::new();
    doc.title = payload
        .get("title")
        .and_then(|v| v.as_str())
        .unwrap_or_default()
        .to_string();
    if let Some(blocks) = payload.get("blocks").and_then(|v| v.as_array()) {
        for b in blocks {
            let kind = b.get("type").and_then(|v| v.as_str()).unwrap_or("p");
            match kind {
                "table" => {
                    let mut rows: Vec<Vec<String>> = Vec::new();
                    if let Some(arr) = b.get("rows").and_then(|v| v.as_array()) {
                        for row in arr {
                            rows.push(
                                row.as_array()
                                    .map(|cells| {
                                        cells
                                            .iter()
                                            .map(|c| c.as_str().unwrap_or_default().to_string())
                                            .collect()
                                    })
                                    .unwrap_or_default(),
                            );
                        }
                    }
                    if !rows.is_empty() {
                        doc.push(Block::Table(Table {
                            rows,
                            header: b.get("header").and_then(|v| v.as_bool()).unwrap_or(true),
                        }));
                    }
                }
                "pagebreak" => {
                    doc.push(Block::PageBreak);
                }
                "toc" => {
                    doc.push(Block::Toc);
                }
                "image" => {
                    let data = b.get("data").and_then(|v| v.as_str()).unwrap_or("");
                    if let Some((bytes, ext)) = split_data_uri(data) {
                        doc.push(Block::Image(Picture {
                            data: bytes,
                            ext,
                            width_mm: b.get("widthMm").and_then(|v| v.as_f64()).unwrap_or(120.0)
                                as f32,
                            height_mm: b.get("heightMm").and_then(|v| v.as_f64()).unwrap_or(80.0)
                                as f32,
                            name: b
                                .get("name")
                                .and_then(|v| v.as_str())
                                .unwrap_or("画像")
                                .to_string(),
                        }));
                    }
                }
                _ => {
                    let text = b.get("text").and_then(|v| v.as_str()).unwrap_or("");
                    let style = match b.get("style").and_then(|v| v.as_str()).unwrap_or("Normal") {
                        "Title" => ParaStyle::Title,
                        "Heading1" => ParaStyle::Heading(1),
                        "Heading2" => ParaStyle::Heading(2),
                        "Heading3" => ParaStyle::Heading(3),
                        "Quote" => ParaStyle::Quote,
                        "Code" => ParaStyle::Code,
                        "Bullet" => ParaStyle::Bullet,
                        "Numbered" => ParaStyle::Numbered,
                        _ => ParaStyle::Normal,
                    };
                    let mut p = Paragraph {
                        style,
                        runs: vec![Run::new(text)],
                        ..Default::default()
                    };
                    p.align = match b.get("align").and_then(|v| v.as_str()).unwrap_or("left") {
                        "center" => Align::Center,
                        "right" => Align::Right,
                        "justify" => Align::Justify,
                        _ => Align::Left,
                    };
                    doc.push(Block::Paragraph(p));
                }
            }
        }
    }
    doc
}

fn presentation_to_json(p: &Presentation, path: Option<&str>) -> Value {
    let slides: Vec<Value> = p
        .slides
        .iter()
        .map(|s| {
            json!({
                "title": s.title,
                "bullets": s.bullets.iter().map(|b| json!({ "t": b.text, "level": b.level })).collect::<Vec<_>>(),
                "images": s.images.iter().map(|img| json!({
                    "name": img.name,
                    "xMm": img.x as f64 / 36_000.0,
                    "yMm": img.y as f64 / 36_000.0,
                    "wMm": img.cx as f64 / 36_000.0,
                    "hMm": img.cy as f64 / 36_000.0,
                    "data": format!("data:image/{};base64,{}", img.ext, b64_encode(&img.data)),
                })).collect::<Vec<_>>(),
                "shapes": s.shapes.iter().map(|sh| json!({
                    "kind": shape_name(sh.kind),
                    "xMm": sh.x as f64 / 36_000.0,
                    "yMm": sh.y as f64 / 36_000.0,
                    "wMm": sh.cx as f64 / 36_000.0,
                    "hMm": sh.cy as f64 / 36_000.0,
                    "text": sh.text,
                    "fill": sh.fill,
                    "line": sh.line,
                })).collect::<Vec<_>>(),
                "notes": s.notes,
                "transition": transition_name(&s.transition),
                "animate": s.animate,
            })
        })
        .collect();
    json!({ "kind": "presentation", "title": p.title, "path": path, "slides": slides })
}

fn json_to_presentation(payload: &Value) -> Presentation {
    let mut pres = Presentation::new();
    pres.title = payload
        .get("title")
        .and_then(|v| v.as_str())
        .unwrap_or_default()
        .to_string();
    if let Some(slides) = payload.get("slides").and_then(|v| v.as_array()) {
        for s in slides {
            let mut slide = Slide::new(s.get("title").and_then(|v| v.as_str()).unwrap_or(""));
            if let Some(bullets) = s.get("bullets").and_then(|v| v.as_array()) {
                for b in bullets {
                    let level = b.get("level").and_then(|v| v.as_u64()).unwrap_or(0) as u8;
                    slide.bullets.push(Bullet {
                        text: b
                            .get("t")
                            .and_then(|v| v.as_str())
                            .unwrap_or("")
                            .to_string(),
                        level,
                    });
                }
            }
            // Pictures, shapes, notes and the transition survive a round trip.
            if let Some(images) = s.get("images").and_then(|v| v.as_array()) {
                for img in images {
                    let data = img.get("data").and_then(|v| v.as_str()).unwrap_or("");
                    let Some((bytes, _ext)) = split_data_uri(data) else {
                        continue;
                    };
                    let mm = |field: &str, default: f32| {
                        img.get(field)
                            .and_then(|v| v.as_f64())
                            .map(|v| v as f32)
                            .unwrap_or(default)
                    };
                    let mut placed = poc_core::pptx::SlideImage::new(
                        bytes,
                        mm("xMm", 20.0),
                        mm("yMm", 40.0),
                        mm("wMm", 80.0),
                        mm("hMm", 60.0),
                    );
                    if let Some(ext) = img.get("ext").and_then(|v| v.as_str()) {
                        placed.ext = ext.to_string();
                    }
                    placed.name = img
                        .get("name")
                        .and_then(|v| v.as_str())
                        .unwrap_or("画像")
                        .to_string();
                    slide.images.push(placed);
                }
            }
            if let Some(shapes) = s.get("shapes").and_then(|v| v.as_array()) {
                for sh in shapes {
                    let mut a_shape = Shape::new(
                        shape_from_name(sh.get("kind").and_then(|v| v.as_str()).unwrap_or("rect")),
                        sh.get("xMm").and_then(|v| v.as_f64()).unwrap_or(20.0) as f32,
                        sh.get("yMm").and_then(|v| v.as_f64()).unwrap_or(20.0) as f32,
                        sh.get("wMm").and_then(|v| v.as_f64()).unwrap_or(40.0) as f32,
                        sh.get("hMm").and_then(|v| v.as_f64()).unwrap_or(20.0) as f32,
                    );
                    a_shape.text = sh
                        .get("text")
                        .and_then(|v| v.as_str())
                        .unwrap_or("")
                        .to_string();
                    a_shape.fill = sh
                        .get("fill")
                        .and_then(|v| v.as_str())
                        .map(|v| v.to_string());
                    a_shape.line = sh
                        .get("line")
                        .and_then(|v| v.as_str())
                        .map(|v| v.to_string());
                    slide.shapes.push(a_shape);
                }
            }
            if let Some(notes) = s.get("notes").and_then(|v| v.as_str()) {
                slide.notes = notes.to_string();
            }
            if let Some(t) = s.get("transition").and_then(|v| v.as_str()) {
                slide.transition = transition_from_name(t);
            }
            slide.animate = s.get("animate").and_then(|v| v.as_bool()).unwrap_or(false);
            pres.add(slide);
        }
    }
    pres
}

/// Static information about the running product (shown in the about box).
pub fn app_info(ui_version: &str) -> Value {
    json!({
        "name": "Poccham Office Next",
        "version": ui_version,
        "engine": poc_core::VERSION,
        "os": std::env::consts::OS,
        "arch": std::env::consts::ARCH,
        "formulaEngine": true,
        "vba": true,
    })
}

pub fn open_document(path: String) -> Result<Value, String> {
    let bytes = std::fs::read(&path).map_err(err)?;
    let mut format = detect::sniff(&bytes);
    if format == Format::Unknown {
        format = detect::from_path(&path);
    }
    match format {
        Format::Xlsx | Format::Xlsm => {
            let mut wb = Workbook::from_bytes(&bytes).map_err(err)?;
            wb.recalculate();
            Ok(workbook_to_json(&wb, Some(&path)))
        }
        Format::Docx | Format::Docm => {
            let doc = Document::from_bytes(&bytes).map_err(err)?;
            Ok(document_to_json(&doc, Some(&path)))
        }
        Format::Pptx | Format::Pptm => {
            let pres = Presentation::from_bytes(&bytes).map_err(err)?;
            Ok(presentation_to_json(&pres, Some(&path)))
        }
        Format::Ods => {
            let mut wb = Workbook::from_bytes(&bytes).map_err(err)?;
            wb.recalculate();
            Ok(workbook_to_json(&wb, Some(&path)))
        }
        Format::Csv | Format::Tsv | Format::PlainText => {
            let text = String::from_utf8_lossy(&bytes).to_string();
            let delimiter = if format == Format::Tsv { '\t' } else { ',' };
            let mut wb = Workbook::new();
            for row in poc_core::csv::parse_with_delimiter(&text, delimiter) {
                wb.sheets[0].push_row(row.into_iter().map(|field| {
                    let t = field.trim();
                    match t.parse::<f64>() {
                        Ok(n) if !t.is_empty() => Cell::num(n),
                        _ if t.is_empty() => Cell::empty(),
                        _ => Cell::text(field),
                    }
                }));
            }
            wb.sheets[0].name = Path::new(&path)
                .file_stem()
                .map(|s| s.to_string_lossy().to_string())
                .unwrap_or_else(|| "Sheet1".into());
            Ok(workbook_to_json(&wb, Some(&path)))
        }
        Format::Unknown if bytes.starts_with(&[0xD0, 0xCF, 0x11, 0xE0]) => Err(
            "旧形式の Office ファイル（.xls / .doc / .ppt）は未対応です。\
             .xlsx / .docx / .pptx に変換してから開いてください。"
                .into(),
        ),
        Format::Odt | Format::Odp => Err(format!(
            "{} の読み込みは未対応です（ODS / OOXML は読み込めます）",
            format.label()
        )),
        other => Err(format!("この形式はまだ開けません: {}", other.label())),
    }
}

pub fn save_workbook(path: String, payload: Value) -> Result<Value, String> {
    let mut wb = json_to_workbook(&payload)?;
    wb.recalculate();
    if path.to_ascii_lowercase().ends_with(".ods") {
        std::fs::write(&path, wb.to_ods_bytes().map_err(err)?).map_err(err)?;
    } else if path.to_ascii_lowercase().ends_with(".csv") {
        std::fs::write(&path, wb.to_csv(0).map_err(err)?).map_err(err)?;
    } else {
        wb.save(&path).map_err(err)?;
    }
    Ok(workbook_to_json(&wb, Some(&path)))
}

pub fn save_document(path: String, payload: Value) -> Result<Value, String> {
    let doc = json_to_document(&payload);
    doc.save(&path).map_err(err)?;
    Ok(document_to_json(&doc, Some(&path)))
}

pub fn save_presentation(path: String, payload: Value) -> Result<Value, String> {
    let pres = json_to_presentation(&payload);
    pres.save(&path).map_err(err)?;
    Ok(presentation_to_json(&pres, Some(&path)))
}

pub fn recalculate(payload: Value) -> Result<Value, String> {
    let mut wb = json_to_workbook(&payload)?;
    wb.recalculate();
    Ok(workbook_to_json(
        &wb,
        payload.get("path").and_then(|v| v.as_str()),
    ))
}

pub fn run_macro(path: String, source: String, proc_name: String) -> Result<Value, String> {
    let module = parse_module(&source, "Module1").map_err(err)?;
    let mut wb = Workbook::open(&path).map_err(err)?;
    let started = std::time::Instant::now();
    let (outcome, printed) = {
        let mut host = ExcelHost::new(&mut wb);
        let mut engine = Engine::new(&module, &mut host);
        let outcome = engine
            .run(&proc_name, Vec::<VbaValue>::new())
            .map_err(err)?;
        (outcome, host.printed.clone())
    };
    wb.recalculate();
    wb.save(&path).map_err(err)?;
    Ok(json!({
        "messages": outcome.messages,
        "warnings": outcome.warnings,
        "printed": printed,
        "steps": outcome.steps,
        "returnValue": outcome.return_value.as_str(),
        "elapsedMs": started.elapsed().as_secs_f64() * 1000.0,
        "document": workbook_to_json(&wb, Some(&path)),
    }))
}

pub fn macro_procedures(source: String) -> Result<Value, String> {
    let module = parse_module(&source, "Module1").map_err(err)?;
    let procs: Vec<Value> = module
        .procs
        .iter()
        .map(|p| {
            json!({
                "name": p.name,
                "kind": if p.kind == poc_vba::ProcKind::Sub { "Sub" } else { "Function" },
                "params": p.params.len(),
            })
        })
        .collect();
    Ok(json!(procs))
}

pub fn check_macro(source: String) -> Result<Value, String> {
    match parse_module(&source, "Module1") {
        Ok(m) => Ok(json!({ "ok": true, "procedures": m.proc_names() })),
        Err(e) => Ok(json!({ "ok": false, "error": e.to_string() })),
    }
}
