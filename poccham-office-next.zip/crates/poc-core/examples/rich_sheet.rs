//! Write a workbook that exercises merges, conditional formatting, pictures,
//! charts, pivot tables and comments — handy for eyeballing a file in Excel.
use poc_core::style::{Dxf, Rgb};
use poc_core::xlsx::{
    Cell, CellComment, Chart, ChartKind, ChartSeries, ConditionalFormat, DataValidation, Image,
    Merge, PivotAgg, PivotTable, Workbook,
};

/// An 8×8 PNG for the "画像の挿入" demo (no external asset needed).
const PNG: &[u8] = &[
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
    0x00, 0x00, 0x00, 0x30, 0x00, 0x00, 0x00, 0x20, 0x08, 0x02, 0x00, 0x00, 0x00, 0xDB, 0xB6, 0x6C,
    0x4B, 0x00, 0x00, 0x00, 0x60, 0x49, 0x44, 0x41, 0x54, 0x78, 0xDA, 0x63, 0x94, 0xB7, 0x48, 0x61,
    0x18, 0x4C, 0x80, 0x89, 0x61, 0x90, 0x81, 0x51, 0x07, 0x8D, 0x3A, 0x88, 0x52, 0xC0, 0x42, 0x3B,
    0xA3, 0x6B, 0x9A, 0xBF, 0xE2, 0x92, 0x6A, 0xA9, 0xE5, 0x1E, 0x8D, 0xB2, 0x51, 0x07, 0x8D, 0xE6,
    0x32, 0xFC, 0xC0, 0xC0, 0x33, 0x12, 0x97, 0xD4, 0x85, 0xED, 0xCB, 0x47, 0xA3, 0x6C, 0xD4, 0x41,
    0xA3, 0x0E, 0x1A, 0x75, 0x10, 0x65, 0xE5, 0x90, 0x80, 0x79, 0x3B, 0x2E, 0xD5, 0x1F, 0x4E, 0x56,
    0x8E, 0x46, 0xD9, 0xA8, 0x83, 0x46, 0x1D, 0x34, 0xEA, 0xA0, 0xE1, 0xEE, 0x20, 0xC6, 0xD1, 0xC1,
    0x86, 0xA1, 0xE6, 0x20, 0x00, 0x18, 0x07, 0x0A, 0xBB, 0x20, 0x12, 0x26, 0x45, 0x00, 0x00, 0x00,
    0x00, 0x49, 0x45, 0x4E, 0x44, 0xAE, 0x42, 0x60, 0x82,
];

fn main() -> poc_core::Result<()> {
    let mut wb = Workbook::new();
    wb.title = "売上サマリー".into();
    let dxf = wb.styles.intern_dxf(Dxf {
        font_color: Some(Rgb::hex(0x9C_0006)),
        fill: Some(Rgb::hex(0xFF_C7CE)),
        bold: true,
        ..Default::default()
    });
    let header = wb.styles.intern(
        poc_core::style::Xf::default()
            .bold()
            .fill(Rgb::hex(0x1F_3864))
            .border(poc_core::style::Border::grid()),
    );
    {
        let sheet = &mut wb.sheets[0];
        sheet.name = "売上".into();
        sheet.push_row(vec![
            Cell::text("地域").styled(header),
            Cell::text("商品").styled(header),
            Cell::text("金額").styled(header),
        ]);
        let rows = [
            ("東", "A", 1200.0),
            ("東", "B", 800.0),
            ("西", "A", 1500.0),
            ("西", "B", 900.0),
            ("東", "A", 700.0),
        ];
        for (region, item, amount) in rows {
            sheet.push_row(vec![
                Cell::text(region),
                Cell::text(item),
                Cell::num(amount),
            ]);
        }
        sheet.merges.push(Merge::new(0, 0, 0, 2));
        sheet
            .cf
            .push(ConditionalFormat::greater_than("C2:C6", 1000.0, dxf));
        sheet
            .cf
            .push(ConditionalFormat::data_bar("C2:C6", Rgb::hex(0x63_8E_C6)));
        sheet
            .validations
            .push(DataValidation::list("A2:A6", "東,西"));
        sheet
            .comments
            .push(CellComment::new(1, 2, "山田", "金額は税抜きです"));
        let mut logo = Image::new(PNG.to_vec(), 4, 0, 96, 96);
        logo.name = "logo.png".into();
        sheet.images.push(logo);
        sheet.charts.push(
            Chart::new(ChartKind::Bar, "金額", 0)
                .with_categories(1, 0, 5, 0)
                .with_series(ChartSeries::new("金額", 1, 2, 5, 2)),
        );
        sheet.pivots.push(
            PivotTable::new("ピボット1", 0, (0, 0, 5, 2))
                .rows(&[0])
                .cols(&[1])
                .values(&[(2, PivotAgg::Sum)])
                .at(0, 5),
        );
    }
    let bytes = wb.to_bytes()?;
    let out = std::env::args()
        .nth(1)
        .unwrap_or_else(|| "/tmp/rich.xlsx".to_string());
    std::fs::write(&out, &bytes)?;
    println!("wrote {out} ({} bytes)", bytes.len());
    Ok(())
}
