//! Write a deck with pictures, shapes, transitions, speaker notes and a theme.
use poc_core::pptx::{Presentation, Shape, ShapeKind, Slide, SlideImage, Theme, Transition};

const PNG: &[u8] = &[
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
    0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0x15, 0xC4,
    0x89, 0x00, 0x00, 0x00, 0x0A, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9C, 0x63, 0x00, 0x01, 0x00, 0x00,
    0x05, 0x00, 0x01, 0x0D, 0x0A, 0x2D, 0xB4, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4E, 0x44, 0xAE,
    0x42, 0x60, 0x82,
];

fn main() -> poc_core::Result<()> {
    let mut pres = Presentation::new();
    pres.title = "機能サンプル".into();
    pres.theme = Theme::from_accents(["1F3864", "2E75B6", "C55A11", "2F7D6D", "7C4DA0", "B8902B"])
        .name("Poccham Blue")
        .font("Yu Gothic UI");
    pres.add(
        Slide::new("図形と画像")
            .bullet("画像を埋め込む")
            .bullet("図形を描く")
            .shape(
                Shape::new(ShapeKind::RoundedRect, 20.0, 110.0, 60.0, 30.0)
                    .text("図形")
                    .fill("2E75B6"),
            )
            .shape(Shape::new(ShapeKind::RightArrow, 90.0, 115.0, 50.0, 20.0).fill("C55A11"))
            .image(SlideImage::new(PNG.to_vec(), 160.0, 100.0, 40.0, 40.0))
            .notes("発表者ノートのサンプルです。")
            .transition(Transition::Fade)
            .animate(),
    );
    pres.add(
        Slide::new("アニメーション")
            .bullet("クリックで順に表示")
            .shape(Shape::new(ShapeKind::Star5, 30.0, 120.0, 40.0, 40.0).fill("B8902B"))
            .animate(),
    );
    let bytes = pres.to_bytes()?;
    let out = std::env::args()
        .nth(1)
        .unwrap_or_else(|| "/tmp/rich.pptx".to_string());
    std::fs::write(&out, &bytes)?;
    println!("wrote {out} ({} bytes)", bytes.len());
    Ok(())
}
