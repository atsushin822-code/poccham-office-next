//! Spreadsheet features that live outside `sheetData`: merges, conditional
//! formatting, data validation, comments, pictures, charts and pivot tables.
//!
//! These tests assert two things at once: that the model round-trips through
//! our own reader, and that the parts we emit are present, well-formed XML in
//! the places OOXML requires — which is what makes Excel/Sheets open the file
//! without a repair dialog.

use poc_core::pkg::Package;
use poc_core::style::{Rgb, Xf};
use poc_core::xlparts;
use poc_core::xlsx::{
    Cell, CellComment, Chart, ChartKind, ChartSeries, ConditionalFormat, DataValidation, Image,
    Merge, PivotAgg, PivotTable, Workbook,
};
use poc_core::xml::{Event, Reader};

/// A 1×1 transparent PNG.
const PNG: &[u8] = &[
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
    0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0x15, 0xC4,
    0x89, 0x00, 0x00, 0x00, 0x0A, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9C, 0x63, 0x00, 0x01, 0x00, 0x00,
    0x05, 0x00, 0x01, 0x0D, 0x0A, 0x2D, 0xB4, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4E, 0x44, 0xAE,
    0x42, 0x60, 0x82,
];

fn sample_workbook() -> Workbook {
    let mut wb = Workbook::new();
    wb.title = "機能テスト".into();
    {
        let sheet = &mut wb.sheets[0];
        sheet.name = "売上".into();
        sheet.push_row(vec![
            Cell::text("地域"),
            Cell::text("商品"),
            Cell::text("金額"),
        ]);
        sheet.push_row(vec![Cell::text("東"), Cell::text("A"), Cell::num(100)]);
        sheet.push_row(vec![Cell::text("東"), Cell::text("B"), Cell::num(200)]);
        sheet.push_row(vec![Cell::text("西"), Cell::text("A"), Cell::num(300)]);
        sheet.push_row(vec![Cell::text("西"), Cell::text("B"), Cell::num(400)]);
        // merged title across A1:C1
        sheet.merges.push(Merge::new(0, 0, 0, 2));
    }
    // conditional formats need the workbook stylesheet, so intern their format next
    let dxf = wb.styles.intern_dxf(poc_core::style::Dxf {
        font_color: Some(Rgb::hex(0x9C_0006)),
        fill: Some(Rgb::hex(0xFF_C7CE)),
        ..Default::default()
    });
    let sheet = &mut wb.sheets[0];
    sheet
        .cf
        .push(ConditionalFormat::greater_than("C2:C5", 250.0, dxf));
    sheet
        .cf
        .push(ConditionalFormat::data_bar("C2:C5", Rgb::hex(0x63_8E_C6)));
    sheet
        .validations
        .push(DataValidation::list("A2:A5", "東,西"));
    sheet
        .validations
        .push(DataValidation::whole_between("C2:C5", 0.0, 10_000.0));
    sheet
        .comments
        .push(CellComment::new(0, 0, "山田", "全社合計です"));
    sheet.images.push(Image::new(PNG.to_vec(), 4, 0, 120, 90));
    sheet.charts.push(
        Chart::new(ChartKind::Bar, "地域別金額", 0)
            .with_categories(1, 0, 4, 0)
            .with_series(ChartSeries::new("金額", 1, 2, 4, 2)),
    );
    sheet.pivots.push(
        PivotTable::new("ピボット1", 0, (0, 0, 4, 2))
            .rows(&[0])
            .cols(&[1])
            .values(&[(2, PivotAgg::Sum)])
            .at(0, 5),
    );
    wb
}

#[test]
fn rich_sheet_round_trips_through_the_reader() {
    let wb = sample_workbook();
    let bytes = wb.to_bytes().unwrap();
    let back = Workbook::from_bytes(&bytes).unwrap();
    let sheet = &back.sheets[0];

    assert_eq!(sheet.merges, vec![Merge::new(0, 0, 0, 2)]);
    assert_eq!(sheet.cf.len(), 2, "{:?}", sheet.cf);
    assert!(matches!(
        sheet.cf[0].kind,
        poc_core::xlsx::CfKind::CellIs { .. }
    ));
    assert!(matches!(
        sheet.cf[1].kind,
        poc_core::xlsx::CfKind::DataBar { .. }
    ));
    assert_eq!(sheet.comments.len(), 1);
    assert_eq!(sheet.comments[0].text, "全社合計です");
    assert_eq!(sheet.comments[0].author, "山田");
    assert_eq!(sheet.validations.len(), 2);
    // the stylesheet (with its differential formats) survives
    assert!(!back.styles.dxfs.is_empty());
    assert_eq!(back.styles.dxfs[0].fill, Some(Rgb::hex(0xFF_C7CE)));
}

#[test]
fn parts_are_present_and_well_formed() {
    let wb = sample_workbook();
    let bytes = wb.to_bytes().unwrap();
    let pkg = Package::from_bytes(&bytes).unwrap();
    for part in [
        "xl/worksheets/sheet1.xml",
        "xl/worksheets/_rels/sheet1.xml.rels",
        "xl/drawings/drawing1.xml",
        "xl/drawings/_rels/drawing1.xml.rels",
        "xl/drawings/vmlDrawing1.vml",
        "xl/charts/chart1.xml",
        "xl/comments1.xml",
        "xl/pivotCache/pivotCacheDefinition1.xml",
        "xl/pivotCache/pivotCacheRecords1.xml",
        "xl/pivotTables/pivotTable1.xml",
        "xl/styles.xml",
        "[Content_Types].xml",
    ] {
        assert!(pkg.contains(part), "missing part {part}: {:?}", pkg.names());
    }
    // media
    assert!(
        pkg.names()
            .iter()
            .any(|n| n.starts_with("xl/media/image1.")),
        "{:?}",
        pkg.names()
    );

    // every emitted XML part must parse to EOF without a parse error
    for name in pkg.names() {
        if !name.ends_with(".xml") {
            continue;
        }
        let src = pkg.get_str(name).expect("utf-8 xml");
        let mut r = Reader::new(src);
        let mut events = 0;
        loop {
            match r.next_event() {
                Event::Eof => break,
                _ => events += 1,
            }
            assert!(events < 200_000, "{name} looks truncated");
        }
        assert!(src.starts_with("<?xml"), "{name} lacks a declaration");
    }

    // content types must declare the new extensions and parts
    let ct = pkg.get_str("[Content_Types].xml").unwrap();
    assert!(ct.contains(r#"Extension="png""#), "{ct}");
    assert!(ct.contains("spreadsheetml.pivotCacheDefinition+xml"));
    assert!(ct.contains("drawingml.chart+xml"));
    assert!(ct.contains("vmlDrawing"));
    let wb_xml = pkg.get_str("xl/workbook.xml").unwrap();
    assert!(wb_xml.contains("<pivotCaches>"), "{wb_xml}");
}

#[test]
fn chart_references_the_data_it_draws() {
    let wb = sample_workbook();
    let bytes = wb.to_bytes().unwrap();
    let pkg = Package::from_bytes(&bytes).unwrap();
    let chart = pkg.get_str("xl/charts/chart1.xml").unwrap();
    assert!(chart.contains("<c:barChart>"), "{chart}");
    assert!(chart.contains("'売上'!$C$2:$C$5"), "{chart}");
    assert!(chart.contains("'売上'!$A$2:$A$5"), "{chart}");
    // cached values so a non-calculating viewer still draws bars
    assert!(
        chart.contains("<c:pt idx=\"0\"><c:v>100</c:v></c:pt>"),
        "{chart}"
    );
}

#[test]
fn pivot_layout_aggregates_by_row_and_column() {
    let wb = sample_workbook();
    let layout = xlparts::pivot_layout(&wb.sheets[0].pivots[0], &wb);
    assert_eq!(layout.row_keys, vec!["東", "西"]);
    assert_eq!(layout.col_keys, vec!["A", "B"]);
    let cells: Vec<Vec<f64>> = layout
        .cells
        .iter()
        .map(|row| row.iter().map(|c| c.unwrap_or_default()).collect())
        .collect();
    assert_eq!(cells, vec![vec![100.0, 200.0], vec![300.0, 400.0]]);
}

#[test]
fn conditional_format_xml_matches_the_schema_shape() {
    let dxf = 3;
    let rules = vec![
        ConditionalFormat::greater_than("A1:A10", 100.0, dxf),
        ConditionalFormat::color_scale("B1:B10"),
        ConditionalFormat::top10("C1:C10", 5, dxf),
    ];
    let xml = xlparts::conditional_formatting_xml(&rules);
    assert!(
        xml.contains(r#"<conditionalFormatting sqref="A1:A10">"#),
        "{xml}"
    );
    assert!(xml.contains(r#"type="cellIs""#), "{xml}");
    assert!(xml.contains(r#"operator="greaterThan""#), "{xml}");
    assert!(xml.contains("<formula>100</formula>"), "{xml}");
    assert!(xml.contains(r#"type="colorScale""#), "{xml}");
    assert!(xml.contains(r#"type="top10""#), "{xml}");
    assert!(xml.contains("<top10Rank val=\"5\"/>"), "{xml}");
}

#[test]
fn merged_cells_cover_their_range() {
    let m = Merge::parse("A1:C2").unwrap();
    assert_eq!(m.to_a1(), "A1:C2");
    assert!(m.contains(1, 2));
    assert!(!m.contains(2, 0));
    let single = Merge::parse("B2").unwrap();
    assert_eq!(single.to_a1(), "B2:B2");
    let wb = sample_workbook();
    let pkg_bytes = wb.to_bytes().unwrap();
    let pkg = Package::from_bytes(&pkg_bytes).unwrap();
    let sheet = pkg.get_str("xl/worksheets/sheet1.xml").unwrap();
    assert!(sheet.contains(r#"<mergeCells count="1">"#), "{sheet}");
    assert!(sheet.contains(r#"<mergeCell ref="A1:C1"/>"#), "{sheet}");
}

#[test]
fn style_pool_is_shared_between_cells() {
    let mut wb = Workbook::new();
    let style = wb.styles.intern(Xf::default().bold());
    wb.sheets[0].push_row(vec![Cell::text("合計").styled(style)]);
    wb.sheets[0].push_row(vec![Cell::num(1.0).styled(style)]);
    let bytes = wb.to_bytes().unwrap();
    let pkg = Package::from_bytes(&bytes).unwrap();
    let styles = pkg.get_str("xl/styles.xml").unwrap();
    assert!(styles.contains("<b/>"), "{styles}");
    let back = Workbook::from_bytes(&bytes).unwrap();
    assert!(
        back.styles
            .xf(back.sheets[0].get(0, 0).unwrap().style)
            .font
            .bold
    );
    assert_eq!(
        back.sheets[0].get(0, 0).unwrap().style,
        back.sheets[0].get(1, 0).unwrap().style
    );
}
