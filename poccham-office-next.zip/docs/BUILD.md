# ビルドと配布物

## 必要なもの

| 用途 | 要件 |
| --- | --- |
| CLI・ライブラリ・テスト | Rust 1.82 以降（`rustup default stable`） |
| デスクトップアプリ | 上記 + 各 OS の WebView 開発キット（下記） |
| 検証スクリプト | Python 3.9 以降、`openpyxl` / `python-docx` / `python-pptx` |
| UI スモークテスト | Node.js 18 以降、`jsdom` |

ワークスペースは `crates/poc-core` `poc-vba` `poc-bridge` `poc-cli` の 4 つです。
Tauri シェル（`crates/poc-ui/src-tauri`）は WebView の SDK を必要とするため
意図的にワークスペースから除外しており、`cargo test --workspace` は
デスクトップシェルの無い環境でも通ります。

## 1. ライブラリと CLI

```bash
cargo build --release
cargo test --workspace
./target/release/poc help
```

## 2. デスクトップアプリ（開発）

```bash
cargo install tauri-cli --version "^2" --locked
cd crates/poc-ui/src-tauri
cargo tauri dev        # dist/index.html をそのまま読み込みます（フロントのビルド工程なし）
```

UI は `crates/poc-ui/dist/index.html` の単一ファイルです。CSS・JS・SVG をすべて
インラインで持つため、`npm install` もバンドラも不要で、オフラインでも壊れません。

## 3. 配布物の作成（ローカル）

### Windows

```powershell
# Visual Studio Build Tools（C++ デスクトップ開発）と WebView2 が必要
cd crates/poc-ui/src-tauri
cargo tauri build --bundles nsis
# → target/release/bundle/nsis/Poccham Office Next_0.9.0_x64-setup.exe

# ポータブル版（インストーラを使わない単体 exe）
copy target\release\poccham-office-next.exe "Poccham Office Next.exe"
```

`webviewInstallMode: downloadBootstrapper` のため、WebView2 が無い端末では
インストーラが Microsoft の配布元から取得します（オフライン配布にしたい場合は
`embedBootstrapper` か `offlineInstaller` に変更してください）。

### macOS

```bash
rustup target add x86_64-apple-darwin aarch64-apple-darwin
cd crates/poc-ui/src-tauri

cargo tauri build --target aarch64-apple-darwin --bundles dmg   # Apple Silicon
cargo tauri build --target x86_64-apple-darwin  --bundles dmg   # Intel
```

署名と公証（配布する場合）:

```bash
export APPLE_SIGNING_IDENTITY="Developer ID Application: ..."
export APPLE_ID="..." APPLE_PASSWORD="app-specific-password" APPLE_TEAM_ID="..."
cargo tauri build --bundles dmg
```

### Linux

```bash
sudo apt-get install -y libwebkit2gtk-4.1-dev libgtk-3-dev librsvg2-dev \
  patchelf libayatana-appindicator3-dev rpm file
cd crates/poc-ui/src-tauri
cargo tauri build --bundles appimage,deb,rpm
```

`.deb` は `libwebkit2gtk-4.1-0` と `libgtk-3-0` に依存します（`tauri.conf.json` に記載）。

## 4. GitHub Actions

`.github/workflows/build.yml` のみで完結します。

1. リポジトリを作り、このディレクトリの中身を push する（`main` ブランチ）。
2. 何も設定せずに `build` ワークフローが走り、3 OS でテストが実行されます。
3. テストが通ると 4 つのジョブが並列で配布物を作り、`actions/upload-artifact` に
   チェックサム付きで保存されます。
4. `v0.9.0` のようなタグを push すると、`release` ジョブがドラフトリリースを作成し、
   すべてのインストーラと `SHA256SUMS.txt` を添付します。

ランナーの内訳:

| ジョブ | ランナー | 生成物 |
| --- | --- | --- |
| `test` | `ubuntu-22.04` / `windows-latest` / `macos-15` | テストのみ |
| `bundle` (windows-x64) | `windows-latest` | setup.exe / portable.zip |
| `bundle` (macos-intel) | `macos-15-intel` | dmg（x86_64） |
| `bundle` (macos-apple-silicon) | `macos-15` | dmg（arm64） |
| `bundle` (linux-x64) | `ubuntu-22.04` | AppImage / deb / rpm |
| `release` | `ubuntu-latest` | リリース添付 |

補足:

- macOS の Intel 用 GitHub ホステッドランナーは `macos-15-intel` のみです
  （`macos-13` / `macos-14` は 2025〜2026 年に廃止）。将来 Intel ランナーが
  無くなった場合は、Apple Silicon ランナーで
  `--target x86_64-apple-darwin` を指定するか、`--target universal-apple-darwin`
  で Universal バイナリを作ってください。
- Linux は glibc の下限を抑えるため `ubuntu-22.04`（glibc 2.35）でビルドしています。
- キャッシュには `Swatinem/rust-cache` を使用。Tauri シェルはワークスペース外なので
  `workspaces: crates/poc-ui/src-tauri -> target` を指定しています。

## 5. 検証コマンド

```bash
cargo test --workspace                                   # 139 テスト
cargo clippy --workspace --all-targets -- -D warnings    # 静的解析（警告ゼロ）
cargo fmt --all -- --check                                # 整形
python3 scripts/verify_ooxml.py                           # 70 項目の相互運用チェック
python3 scripts/bench_compare.py                          # openpyxl との速度比較
npm install --no-save jsdom && node scripts/ui_smoke_test.js   # UI 40 項目
python3 scripts/make_icons.py                             # アイコン再生成
```

## トラブルシューティング

| 症状 | 対処 |
| --- | --- |
| `cargo tauri build` が `webkit2gtk` で失敗 | `libwebkit2gtk-4.1-dev` を入れる（Ubuntu 22.04 以降） |
| AppImage が起動しない | `libfuse2` を入れる、または `--appimage-extract-and-run` |
| rpm のビルドで失敗 | `rpm` パッケージ（`rpmbuild`）を入れる |
| macOS で「開発元を確認できません」 | 署名＋公証を行うか、右クリック→開くで実行 |
| `poc` が見つからない（CI） | `cargo build --release -p poc-cli` を先に実行 |

## トラブルシューティング

### `could not find Cargo.toml in .../poccham-office-next/poccham-office-next`

ソースが 1 階層深いフォルダに入ったまま push されています（配布 zip を展開して
そのフォルダごとコミットした場合に起こります）。対処はどちらか:

1. リポジトリ直下に `Cargo.toml` / `crates/` / `scripts/` が来るように置き直す
   （`build.yml` の先頭ステップ「ソースのルートを解決」が自動で移動するので、
   そのまま再実行しても直ります）。
2. 手元で直す場合:

```bash
git mv poccham-office-next/* . && rmdir poccham-office-next
git commit -m "リポジトリ直下にソースを移動"
```

### ワークフローがまったく動かない

`.github/workflows/build.yml` がリポジトリ直下にあるか確認してください
（`poccham-office-next/.github/...` の下にあると GitHub は認識しません）。

### ローカルで CI と同じ検査をしたい

```bash
cargo test --workspace --all-targets        # CI と同じ（doctest を含む場合は --all-targets を外す）
cargo fmt --all -- --check
cargo clippy --workspace --all-targets -- -D warnings
python3 scripts/verify_ooxml.py
npm install --no-save jsdom && node scripts/ui_smoke_test.js
```
