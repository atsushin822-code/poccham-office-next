# アーキテクチャ

## 全体像

```
┌───────────────────────────────────────────────────────────────┐
│ UI (crates/poc-ui/dist/index.html)                            │
│   単一 HTML。リボン / キャンバス製グリッド / 文書・スライド編集 │
│   数式とマクロは、デスクトップ版では Rust、ブラウザでは JS で計算 │
└───────────────────────────┬───────────────────────────────────┘
                            │ Tauri invoke (JSON)
┌───────────────────────────▼───────────────────────────────────┐
│ crates/poc-ui/src-tauri  — 9 コマンドの薄いアダプタ             │
└───────────────────────────┬───────────────────────────────────┘
                            │ Rust 関数呼び出し
┌───────────────────────────▼───────────────────────────────────┐
│ crates/poc-bridge  — JSON ⇄ 文書モデルの変換（テスト対象）      │
└───────┬───────────────────────────────────────┬───────────────┘
        │                                       │
┌───────▼──────────────────┐        ┌───────────▼───────────────┐
│ crates/poc-core          │        │ crates/poc-vba            │
│  xlsx / docx / pptx      │        │  lexer → parser → interp  │
│  formula / csv / detect  │◄───────┤  ExcelHost（Range, Cells） │
│  pkg（ZIP）/ xml（自前）  │        │  builtins / format        │
└──────────────────────────┘        └───────────────────────────┘
        ▲                                       ▲
        └──────────── crates/poc-cli ───────────┘
```

設計上の要点は **「文書を理解するコードは 1 箇所だけ」** です。CLI も GUI もテストも
`poc-core` / `poc-vba` を直接呼びます。Tauri 側にはロジックが無いため、
GUI が動かない環境（CI の Linux ランナー、WebView の無いコンテナ）でも
同じコードをテストできます。

## クレートの責務

| クレート | 行数 | 責務 |
| --- | --- | --- |
| `poc-core` | 約 5,600 | OOXML/ODF/CSV の読み書き、数式エンジン、ZIP、XML リーダ/ライタ |
| `poc-vba` | 約 3,600 | VBA の字句解析・構文解析・実行、Excel オブジェクトモデル |
| `poc-bridge` | 約 500 | UI とエンジンの境界（JSON 変換と 9 コマンド） |
| `poc-cli` | 約 900 | `poc` コマンド（new / info / parts / convert / calc / macro / bench） |
| UI | 約 2,000 | 単一 HTML（CSS/JS/SVG インライン） |

外部クレートは `zip`（DEFLATE）と `serde_json`（JSON）のみです。
ZIP コンテナ、XML パーサ、数式評価器、VBA インタプリタはすべて自前実装で、
`#![forbid(unsafe_code)]` を全クレートに適用しています。

## データモデル

```rust
Workbook { sheets: Vec<Sheet>, title, creator, created }
Sheet    { name, rows: Vec<Vec<Cell>>, col_widths, freeze, autofilter }
Cell     { value: CellValue, style: u16 }
CellValue::Empty | Number(f64) | Text(String) | Bool(bool)
         | Formula { expr, cached: Option<f64>, text: Option<String> }
         | Error(String)
```

行優先の `Vec<Vec<Cell>>` は、セル単位の `HashMap` より桁違いに速く、
`rows[r][c]` で直接アクセスできます。末尾の空セルは `Sheet::trim` で捨てます。

## JSON 契約（UI ⇄ Rust）

9 つのコマンドはすべて JSON を返します。UI 側の `invoke()` と 1 対 1 対応です。

| コマンド | 引数 | 戻り値 |
| --- | --- | --- |
| `app_info` | — | `{name, version, engine, os, arch, formulaEngine, vba}` |
| `open_document` | `path` | 文書モデル |
| `save_workbook` | `path`, `payload` | 再計算済みの文書モデル |
| `save_document` | `path`, `payload` | 文書モデル |
| `save_presentation` | `path`, `payload` | 文書モデル |
| `recalculate` | `payload` | 文書モデル |
| `run_macro` | `path`, `source`, `procName` | `{printed, messages, warnings, returnValue, steps, elapsedMs, document}` |
| `macro_procedures` | `source` | `[{name, kind, params}]` |
| `check_macro` | `source` | `{ok, procedures}` または `{ok:false, error}` |

文書モデル:

```json
{ "kind": "workbook", "title": "...", "path": "...",
  "sheets": [{ "name": "売上", "freeze": [1,0], "filter": "A1:D5",
               "widths": [null, 12.0], "cells": [["B2","1820000","",9,"1820000"]] }] }

{ "kind": "document", "header": "社外秘", "footer": "1 ページ", "blocks": [
    { "type": "p", "style": "Heading1", "align": "left", "text": "..." },
    { "type": "table", "rows": [["a","b"]], "header": true },
    { "type": "pagebreak" },
    { "type": "toc" },
    { "type": "image", "name": "グラフ画像", "ext": "png",
      "widthMm": 120, "heightMm": 75, "data": "data:image/png;base64,..." } ],
  "footnotes": 1, "comments": [{ "author": "山田", "text": "要確認" }] }

{ "kind": "presentation", "slides": [
    { "title": "...", "bullets": [{ "t": "要点", "level": 0 }],
      "images": [{ "name": "画像", "xMm": 150, "yMm": 60, "wMm": 150, "hMm": 94,
                   "data": "data:image/png;base64,..." }],
      "shapes": [{ "kind": "roundedRect", "xMm": 24, "yMm": 24, "wMm": 78, "hMm": 34,
                   "text": "", "fill": "2F6FEB", "line": null }],
      "notes": "発表者ノート", "transition": "fade", "animate": true } ] }
```

画像は `data:` URI で往復するので、UI とエンジンの間でファイルパスを
受け渡す必要がありません（サンドボックス化されたプレビューでも表示できます）。

セルは `[番地, 表示用の生値, 数式, スタイル番号, 計算済みの値]` の 5 要素です。
スタイル番号は `poc-core::xlsx::styles` の定数と UI の `STYLE` が同じ値を使います
（0 標準 / 1 太字 / 2 斜体 / 3 太字+斜体 / 4 小数2桁 / 5 % / 6 日付 / 7 折返し /
8 見出し / 9 通貨）。

数式セルは**計算済みの値を必ず添えて**保存します。Excel も LibreOffice も
「再計算しない設定」で開くことがあるため、キャッシュ値が無いと空欄に見えます。

## 数式エンジン

`poc-core/src/formula.rs` は再帰下降パーサ + 直接評価です。AST を作らずに
評価するため、2.5 万数式の再計算が 35 ms で済みます。

- 参照: `A1`、`$A$1`、`A1:B20`、`Sheet2!A1`、`'シート 2'!A1`
- 演算子: `+ - * / ^ &`、比較 `= <> < <= > >=`、括弧、単項 `-`/`+`
- 関数: **270 種**（`poc-core/src/funcs.rs`、カテゴリは
  `python3 scripts/count_functions.py --list` で一覧表示）。数学・統計・検索/参照・
  文字列・日付・財務・エンジニアリング・情報の各カテゴリをカバーし、
  テストは `crates/poc-core/tests/function_surface.rs` が全関数の呼び出しを実行します。
- VBA の `WorksheetFunction.Sum(...)` は同じ実装へ委譲されるため、
  マクロと数式で結果が食い違うことはありません。
- 参照の循環は訪問フラグで検出し、`#REF!` を返します（無限ループしません）。

## VBA エンジン

`lexer → parser (AST) → interp`。Excel ホスト（`ExcelHost`）が
`Range`/`Cells`/`Worksheets`/`Workbook` を不透明なハンドル（`Value::Object`）として
提供し、インタプリタはその値を通り抜けるだけです。この分離により、
VBA の言語仕様と Excel のオブジェクトモデルを独立に拡張できます。

- 文: `Dim`/`Const`/`Set`、`If`/`ElseIf`/`Else`、`For`/`For Each`/`Next`、
  `Do`/`Loop`（While/Until）、`While`/`Wend`、`Select Case`、`With`、
  `Sub`/`Function`、`Exit`、`On Error Resume Next`、`Erase`、`ReDim`
- 式: 算術・比較・論理（`And`/`Or`/`Not`/`Xor`/`Imp`/`Eqv`）、文字列連結 `&`、
  配列、プロパティ/メソッド呼び出し、名前付き引数
- 組み込み: `MsgBox`、`Debug.Print`、`Format`、`CStr`/`CLng`/`CDbl`/`CInt`、
  `Len`/`Mid`/`Left`/`Right`/`InStr`/`Replace`/`Split`/`Join`/`Trim`、
  `UBound`/`LBound`、`Val`、`Hex`、`Abs`/`Int`/`Fix`/`Round`/`Sgn`/`Rnd`、
  `IsNumeric`/`IsEmpty`/`IsArray` ほか

UI には構文チェック（`check_macro`）と手続き一覧（`macro_procedures`）があり、
実行前にエラー位置を確認できます。

## UI

- **ビルド工程なし**: `dist/index.html` をそのまま `frontendDist` に指定。
  CSP は `default-src 'self'`（`img-src 'self' data:`）で、外部通信は一切しません。
- **グリッド**: `<canvas>` に仮想スクロールで描画（400 行 × 60 列）。スクロールは
  透明な `<div>` が持ち、再描画は `scroll` イベントで行うため、行数が増えても
  描画コストは画面内のセル数に比例します。ウィンドウ枠の固定（凍結ペイン）と
  ズーム（70〜160%）に対応。
- **数式バー / 名前ボックス / インライン編集**、塗りつぶしハンドル、シートタブ、
  Sum/Average/Count のステータス表示。
- **文書ビュー**: A4（210mm）ページ、`contentEditable` のブロック編集、
  スタイル（タイトル / 見出し 1〜3 / 引用 / コード / 箇条書き / 番号付き）、
  表、改ページ。
- **プレゼンビュー**: 16:9 のスライド、3 階層の箇条書き、Tab / Shift+Tab で
  レベル変更、サムネイル一覧。
- **オフライン前提**: 外部フォント・画像・スクリプトを参照しないため、
  閉域網やサンドボックス内でも同じ見た目になります。

## 性能の作り方

1. **アロケーションを避ける writer** — `sheetData` は再利用可能な `String` に
   桁・列名を直接書き込みます（`push_col_letters` / `push_u32` / `push_number`）。
2. **自前の XML リーダ** — `quick-xml` を使わず、`&str` 上のバイト走査で
   `Start / End / Text` イベントを返します。アロケーションは属性のみ。
3. **DEFLATE レベル 1** — 圧縮率より速度を優先（`compression_level(Some(1))`）。
   書き込み 45 ms のうち ZIP 圧縮が支配的でした。圧縮レベルを上げればサイズは
   小さくなりますが、書き込み時間がそのまま増えます（レベル 6 で約 1.4 倍）。
4. **行優先の密配列** — セル参照は `rows[r][c]`。`parse_ref` もアロケーションなし。
5. **段階的な再計算** — 変更セルのみ再評価する `recalculate_dirty` を用意し、
   マクロ実行後は書き込みのあったシートだけを対象にできます。
6. **遅延初期化 UI** — 画面外のセルは描画しません（`cellRect` による可視判定）。

## 決定事項と理由

| 決定 | 理由 |
| --- | --- |
| OnlyOffice / LibreOffice のコードを使わない | AGPL / MPL の混入を避け、商用配布を自由にするため（[IP_NOTES](IP_NOTES.md)） |
| XML パーサを自作 | 依存を 2 クレートに抑え、OOXML 固有の高速パスを書ける |
| UI を単一 HTML に | バンドラ・npm・外部 CDN を排除し、監査とオフライン動作を容易にする |
| Tauri を選ぶ | Electron 比でメモリ 1/10 程度、Rust と同一プロセスで会話できる |
| ブリッジを別クレートに | WebView SDK 無しで境界のロジックをテストするため |
| 計算済みの値を常に保存 | 再計算しないビューアでも値が見える（Excel と同じ挙動） |
