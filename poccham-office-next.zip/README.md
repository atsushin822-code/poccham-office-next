# Poccham Office Next

Rust で書かれた超軽量オフィススイート（表計算 / 文書 / プレゼンテーション）。
`xlsx` / `docx` / `pptx`（Office Open XML）を**自前のエンジンで直接読み書き**し、
Excel VBA マクロを実行できます。Office の代替品として実用に耐える互換性と、
桁違いの起動・計算速度を両立することを目標にしています。

![表計算](docs/images/sheet.png)

| 文書 | プレゼンテーション |
| --- | --- |
| ![文書](docs/images/document.png) | ![スライド](docs/images/slides.png) |

---

## 特長

- **1 つのアプリで 3 種類の文書** — リボンと表示が文書種別に応じて切り替わります。
- **ネイティブ速度** — 20 万セルのブックを書き込み 46 ms / 読み込み 134 ms / 再計算 35 ms（下記ベンチマーク）。
- **VBA 実行** — `Sub`/`Function`・`With`・`For Each`・配列・`Range`/`Cells`・結合/コピー&ペースト・`WorksheetFunction`（数式エンジンへ委譲）・日付関数・`MsgBox`/`Debug.Print` を解釈する独自インタプリタ。
- **業務で使う機能を一通り** — 表計算: セルの結合・条件付き書式・入力規則・グラフ・ピボットテーブル・画像・コメント。文書: 画像・脚注・目次・ヘッダー/フッター・変更履歴・コメント。プレゼン: 図形・画像・画面切り替え・アニメーション・発表者ノート・テーマ。
- **関数 270 種** — 数学/統計/検索/文字列/日付/財務/エンジニアリング/情報の各カテゴリを網羅（`python3 scripts/count_functions.py` で数えられます）。
- **日本語 UI** — リボン、ダイアログ、エラーメッセージまで日本語。インストーラも日本語 / English を選択可能。
- **依存がほぼ無い** — 外部クレートは `zip` と `serde_json` のみ。UI はフレームワークもビルドツールも使わない単一 HTML。
- **どこでも同じコード** — CLI・GUI・テストが同じ `poc-core` / `poc-vba` を共有します。

## パフォーマンス

20 万セル（うち 2.5 万が数式）のブックでの実測値です（2 vCPU / 2 GB の Linux コンテナ、`cargo build --release`）。

| 処理 | Poccham Office Next | openpyxl | 倍率 |
| --- | --- | --- | --- |
| 書き込み | **45.4 ms**（4,400 セル/ms） | 138.3 ms | **3.0x 速い** |
| 読み込み | **136.6 ms**（683 ns/セル） | 2.40 s | **17.6x 速い** |
| 再計算 | **35.8 ms** | — | — |
| ファイルサイズ | 1.45 MB | 1.04 MB | 1.40x（大きい） |

ファイルサイズが大きいのは、速度を優先して DEFLATE の圧縮レベルを 1 に固定しているためです
（`poc-core/src/pkg.rs`）。サイズを優先したい場合はレベルを上げるだけで切り替わります。

UI の起動と大きなブックを開く時間（5 万セル、Chromium 実測の中央値）:

| 処理 | 時間 |
| --- | --- |
| 起動（cold boot） | **107 ms** |
| ブックを開く（計算結果キャッシュあり） | **103 ms** |
| ブックを開く（全数式を再計算） | 229 ms |

ファイルを開くときに計算結果が入っていれば再計算を省略するため、**2.2x 高速**です
（`python3 scripts/ui_boot_bench.py` で再現、Playwright + Chromium が必要）。

計測は `python3 scripts/bench_compare.py` で再現できます。

## クイックスタート

```bash
# 1. ビルド（Rust 1.82 以降）
cargo build --release

# 2. CLI
./target/release/poc new report.xlsx          # サンプルブックを作成
./target/release/poc info report.xlsx         # 構造を表示
./target/release/poc calc report.xlsx         # 再計算
./target/release/poc convert report.xlsx report.ods
./target/release/poc macro run report.xlsx --module report.bas --call BuildReport
./target/release/poc bench --cells 200000     # スループット測定

# 3. デスクトップアプリ（要 WebView2 / WKWebView / WebKitGTK）
cargo install tauri-cli --version "^2" --locked
cd crates/poc-ui/src-tauri && cargo tauri dev
```

UI だけを確認したい場合は `crates/poc-ui/ui/index.html` をブラウザで開いてください。
デスクトップ版が無い環境では自動的に**デモモード**（サンプルの四半期売上レポート）で起動し、
保存やマクロ実行だけが無効になります。

## GitHub Actions で配布物を作る

このリポジトリをそのまま GitHub に push すると `.github/workflows/build.yml` が動き、
次の成果物が作られます（タグ `v*` を push するとドラフトリリースに添付）。

| プラットフォーム | 成果物 |
| --- | --- |
| Windows | `*-setup.exe`（NSIS インストーラ、日本語/英語）と `*-portable.zip`（単体 exe） |
| macOS (Intel x86_64) | `*.dmg` |
| macOS (Apple Silicon) | `*.dmg` |
| Linux | `*.AppImage` / `*.deb` / `*.rpm` |
| 共通 | `SHA256SUMS.txt` |

テスト（3 OS でのユニット/統合テスト、clippy、整形、OOXML 相互検証、UI スモークテスト）が
すべて通った場合のみパッケージが作られます。

> **置き場所に注意**: `Cargo.toml` と `.github/workflows/build.yml` はリポジトリの
> **直下**に必要です。配布 zip はアーカイブ直下に `Cargo.toml` が入る形で作ってあります。
> サブフォルダごと push した／zip をそのままコミットした場合も、ワークフローの
> 最初のステップ「ソースのルートを解決」が深さ 4 まで探して自動でルートへ移動します
> （zip はその場で展開されます）。

## リポジトリ構成

```
crates/
  poc-core/        OOXML / ODF / CSV の読み書き、数式エンジン、ZIP コンテナ
  poc-vba/         VBA の字句解析・構文解析・インタプリタ・Excel ホスト
  poc-bridge/      UI ⇄ エンジンの JSON 境界（テスト対象の中心）
  poc-cli/         poc コマンド
  poc-ui/
    ui/index.html    デスクトップ UI 本体（単一ファイル、ビルド不要）
    src-tauri/       Tauri v2 の薄いシェル
assets/icons/      アイコン一式（純粋な幾何形状から生成）
scripts/           相互検証・ベンチマーク・アイコン生成・UI スモークテスト
docs/              設計・互換性・ビルド・権利関係のドキュメント
```

## テスト

```bash
cargo test --workspace          # 139 テスト（ユニット + 統合 + doctest）
cargo clippy --workspace --all-targets -- -D warnings
cargo fmt --all -- --check
python3 scripts/verify_ooxml.py # 70 項目の相互運用性チェック（3 つの独立実装で検証）
node scripts/ui_smoke_test.js   # 40 項目の UI スモークテスト（要 jsdom）
python3 scripts/ui_boot_bench.py  # 起動時間の計測（要 Playwright + Chromium）
```

## ドキュメント

- [docs/BUILD.md](docs/BUILD.md) — 各 OS でのビルドと配布物の作り方
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) — クレート構成・JSON 契約・設計判断
- [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md) — 対応形式・関数・VBA の範囲と限界
- [docs/IP_NOTES.md](docs/IP_NOTES.md) — クリーンルーム実装の方針とライセンス

## ライセンス

MIT（[LICENSE](LICENSE)）。同梱の依存クレートは `zip`（MIT）と `serde_json`（MIT / Apache-2.0）のみです。
「Microsoft Office」「Excel」「Word」「PowerPoint」は Microsoft Corporation の商標です。
本プロダクトは独立実装であり、Microsoft による認定・提携を受けたものではありません。
