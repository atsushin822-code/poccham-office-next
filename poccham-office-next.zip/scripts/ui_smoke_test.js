#!/usr/bin/env node
/**
 * Headless smoke test for the desktop UI (crates/poc-ui/dist/index.html).
 *
 * Runs the real page in jsdom with a stubbed 2D canvas context, then exercises
 * the spreadsheet model: formula evaluation, editing, undo/redo, sheet
 * operations and the document/slide editors.
 *
 *   npm install jsdom       (or: npm install jsdom --prefix /tmp/uitest)
 *   node scripts/ui_smoke_test.js
 */
const fs = require("fs");
const path = require("path");

let JSDOM;
try {
  ({ JSDOM } = require("jsdom"));
} catch {
  try {
    ({ JSDOM } = require("/tmp/uitest/node_modules/jsdom"));
  } catch {
    console.error("jsdom が必要です: npm install jsdom");
    process.exit(2);
  }
}

const htmlPath = path.join(__dirname, "..", "crates", "poc-ui", "dist", "index.html");
const html = fs.readFileSync(htmlPath, "utf8");

const failures = [];
function check(name, cond, detail) {
  console.log(`${cond ? "[OK  ]" : "[FAIL]"} ${name}${detail ? " — " + detail : ""}`);
  if (!cond) failures.push(name);
}

/* ---- canvas 2D context stub (jsdom has no canvas) ---- */
function fakeCtx() {
  const noop = () => {};
  return new Proxy(
    {
      measureText: (s) => ({ width: String(s).length * 6.2 }),
      canvas: { width: 1280, height: 800 },
      setTransform: noop,
      save: noop,
      restore: noop,
      beginPath: noop,
      clip: noop,
      rect: noop,
      moveTo: noop,
      lineTo: noop,
      stroke: noop,
      fill: noop,
      clearRect: noop,
      fillRect: noop,
      strokeRect: noop,
      fillText: noop,
    },
    {
      get(target, prop) {
        if (prop in target) return target[prop];
        return typeof prop === "string" ? () => {} : undefined;
      },
      set(target, prop, value) {
        target[prop] = value;
        return true;
      },
    }
  );
}

const dom = new JSDOM(html, {
  runScripts: "dangerously",
  pretendToBeVisual: true,
  url: "file:///app/index.html",
  beforeParse(window) {
    window.HTMLCanvasElement.prototype.getContext = () => fakeCtx();
    window.navigator.clipboard = { writeText: async () => {}, readText: async () => "" };
    // jsdom has no layout: give elements a plausible size.
    Object.defineProperty(window.HTMLElement.prototype, "clientWidth", { get: () => 1280, configurable: true });
    Object.defineProperty(window.HTMLElement.prototype, "clientHeight", { get: () => 760, configurable: true });
    window.HTMLElement.prototype.getBoundingClientRect = function () {
      return { left: 0, top: 0, right: 1280, bottom: 760, width: 1280, height: 760, x: 0, y: 0 };
    };
    window.HTMLElement.prototype.showModal = function () { this.open = true; };
    window.HTMLElement.prototype.close = function () { this.open = false; };
  },
});

const { window } = dom;
const doc = window.document;

setTimeout(() => {
  const P = window.__POC__;
  const S = P.state;
  check("UI が例外なく起動する", !!P && !!S && !!S.doc, S && S.doc && S.doc.kind);
  if (!S || !S.doc) { console.log("起動に失敗したため中断します"); process.exit(1); }
  check("サンプルブックを読み込む", S.doc.sheets.length === 1 && S.doc.sheets[0].name === "売上", S.doc.sheets[0].name);

  const sh = S.doc.sheets[0];
  const cell = (a) => {
    const m = /^([A-Z]+)(\d+)$/.exec(a);
    let col = 0;
    for (const ch of m[1]) col = col * 26 + (ch.charCodeAt(0) - 64);
    return sh.map.get(`${parseInt(m[2], 10) - 1},${col - 1}`);
  };
  check("見出しセルのスタイル", cell("A1").s === 8 && cell("A1").raw === "月");
  check("SUM の計算結果", cell("B6").d === "8120000", cell("B6").d);
  check("AVERAGE の計算結果", cell("B8").d === "2030000", cell("B8").d);
  check("COUNT の計算結果", cell("B9").d === "4", cell("B9").d);
  check("IF の計算結果 (未達)", cell("D2").d === "未達", cell("D2").d);
  check("IF の計算結果 (達成)", cell("D4").d === "達成", cell("D4").d);
  check("前月比 (比率)", cell("C3").d === "0.06593406593406594" || Math.abs(parseFloat(cell("C3").d) - 0.065934) < 1e-5, cell("C3").d);

  // editing + undo
  P.setSel(0, 0, false);
  const before = sh.map.size;
  P.commitEdit("テスト", 0, 0);
  check("セル編集が反映される", cell("A1").raw === "テスト", cell("A1").raw);
  P.undo();
  check("元に戻す", S.doc.sheets[0].map.get("0,0").raw === "月", S.doc.sheets[0].map.get("0,0").raw);
  P.redo();
  check("やり直す", S.doc.sheets[0].map.get("0,0").raw === "テスト", S.doc.sheets[0].map.get("0,0").raw);

  // formula entry through the formula bar path
  P.setSel(10, 0, false);
  P.commitEdit("=SUM(B2:B5)*2", 0, 0);
  const f = S.doc.sheets[0].map.get("10,0");
  check("数式の入力と計算", f.f === "SUM(B2:B5)*2" && f.d === "16240000", f.f + " -> " + f.d);

  // number formatting through the ribbon command
  P.setSel(1, 1, false);
  P.commitEdit("0.256", 0, 0);
  P.COMMANDS.percent();
  check("パーセント書式", S.doc.sheets[0].map.get("1,1").s === 5 && P.displayValue(S.doc.sheets[0].map.get("1,1")) === "25.6%",
        P.displayValue(S.doc.sheets[0].map.get("1,1")));
  P.COMMANDS.currency();
  check("通貨書式", /^¥/.test(P.displayValue(S.doc.sheets[0].map.get("1,1"))), P.displayValue(S.doc.sheets[0].map.get("1,1")));

  // new sheet
  const n = S.doc.sheets.length;
  P.COMMANDS.newsheet();
  check("シート追加", S.doc.sheets.length === n + 1);

  // document mode
  P.loadPayload({
    kind: "document",
    title: "テスト文書",
    blocks: [
      { type: "p", style: "Heading1", align: "left", text: "見出し" },
      { type: "p", style: "Normal", align: "left", text: "本文" },
    ],
  });
  check("文書モードに切り替わる", S.mode === "document" && S.doc.blocks.length === 2, S.mode);
  check("段落が描画される", doc.querySelectorAll("#page .block").length === 2,
        String(doc.querySelectorAll("#page .block").length));
  P.COMMANDS.addpara();
  check("段落を追加できる", S.doc.blocks.length === 3);

  // --- 文書のリッチ機能: 目次 / 画像 / ヘッダー・フッター ---
  P.COMMANDS.inserttoc();
  const toc = doc.querySelector("#page .block.toc");
  check("目次を挿入できる", !!toc && /見出し/.test(toc.textContent), toc && toc.textContent.trim());
  P.COMMANDS.picture();
  const img = doc.querySelector("#page .block.img img");
  check("文書に画像を挿入できる", !!img && /^data:image\/png/.test(img.getAttribute("src") || ""),
        img && (img.getAttribute("src") || "").slice(0, 22));
  P.loadPayload({
    kind: "document",
    title: "テスト文書",
    header: "社外秘 / 2026 年度",
    footer: "Poccham Office Next",
    footnotes: 2,
    comments: [{ author: "山田", text: "要確認" }],
    blocks: [
      { type: "p", style: "Heading1", align: "left", text: "見出し" },
      { type: "p", style: "Normal", align: "left", text: "本文" },
    ],
  });
  check("エンジンのヘッダー/フッターが引き継がれる", S.doc.header === "社外秘 / 2026 年度" && S.doc.footer === "Poccham Office Next",
        `${S.doc.header} / ${S.doc.footer}`);
  check("注釈の件数がステータスバーに出る", /注釈 3/.test(doc.getElementById("stat").textContent), doc.getElementById("stat").textContent);
  P.COMMANDS.inserttoc(); P.COMMANDS.picture();
  const head = doc.querySelector("#page .dochead");
  const foot = doc.querySelector("#page .docfoot");
  check("ヘッダーとフッターが描画される", !!head && !!foot && head.textContent === S.doc.header,
        head && head.textContent);
  // 目次は見出しの一覧になっている
  check("目次に見出しが並ぶ", doc.querySelectorAll("#page .block.toc .li").length >= 1,
        String(doc.querySelectorAll("#page .block.toc .li").length));

  // presentation mode
  P.loadPayload({
    kind: "presentation",
    title: "テスト資料",
    slides: [{ title: "スライド1", bullets: [{ t: "要点", level: 0 }] }],
  });
  check("プレゼンモードに切り替わる", S.mode === "presentation");
  P.COMMANDS["slide-add"]();
  check("スライド追加", S.doc.slides.length === 2);
  check("サムネイルが描画される", doc.querySelectorAll("#thumbcol .thumb").length === 2,
        String(doc.querySelectorAll("#thumbcol .thumb").length));

  // --- スライドのリッチ機能: 図形 / 画像 / ノート / 画面切り替え ---
  P.addSlideShape("roundedRect");
  P.addSlideShape("star5");
  const shapes = doc.querySelectorAll("#slidecard .slideviz .sh");
  check("スライドに図形を追加できる", shapes.length === 2 && shapes[0].classList.contains("roundedRect"),
        String(shapes.length));
  P.COMMANDS["slide-image"]();
  const slimg = doc.querySelector("#slidecard .slideviz img.si");
  check("スライドに画像を追加できる", !!slimg, slimg ? slimg.getAttribute("alt") : "");
  const notes = doc.querySelector("#slidecard .notes textarea");
  check("発表者ノートの入力欄がある", !!notes, notes ? notes.value : "");
  if (notes) { notes.value = "最初に結論を述べる"; notes.dispatchEvent(new window.Event("input")); }
  check("ノートの編集が状態に反映される", S.doc.slides[1].notes === "最初に結論を述べる", S.doc.slides[1].notes);
  const trans = doc.querySelector("#slidecard .slidemeta select");
  check("画面切り替え効果を選べる", !!trans && trans.options.length === 6, trans && String(trans.options.length));
  if (trans) { trans.value = "fade"; trans.dispatchEvent(new window.Event("change")); }
  check("画面切り替えの設定が保存される", S.doc.slides[1].transition === "fade", S.doc.slides[1].transition);

  // back to spreadsheet + ribbon rendering
  P.loadPayload(P.demoWorkbook());
  check("ブックに戻れる", S.mode === "workbook" && S.doc.kind === "workbook");
  const ribbonButtons = doc.querySelectorAll("#ribbonBody .btn").length;
  check("リボンが描画される", ribbonButtons > 5, String(ribbonButtons));
  const tabs = doc.querySelectorAll("#sheettabs .tab").length;
  check("シートタブが描画される", tabs === 1, String(tabs));

  // serialisation round trip
  const payload = P.serializeWorkbook();
  check("シリアライズできる", payload.sheets[0].cells.length > 10, String(payload.sheets[0].cells.length));
  const sumCell = payload.sheets[0].cells.find((c) => c[0] === "B6");
  check("数式が保存される", sumCell && sumCell[2] === "SUM(B2:B5)", sumCell && sumCell[2]);

  // 数式の表示 toggle must round-trip without destroying cached results
  P.setSel(5, 1, false);
  const before5 = P.displayValue(S.doc.sheets[0].map.get("5,1"));
  P.COMMANDS.showformulas();
  const shown = P.displayValue(S.doc.sheets[0].map.get("5,1"));
  P.COMMANDS.showformulas();
  const after5 = P.displayValue(S.doc.sheets[0].map.get("5,1"));
  check("数式の表示 → 元に戻す", shown === "=SUM(B2:B5)" && after5 === before5, `${shown} / ${after5}`);

  console.log();
  if (failures.length) {
    console.log(`失敗 ${failures.length} 件: ${failures.join(", ")}`);
    process.exit(1);
  }
  console.log("UI スモークテスト: すべて合格");
  process.exit(0);
}, 200);
