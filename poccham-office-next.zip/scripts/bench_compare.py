#!/usr/bin/env python3
"""Compare Poccham Office Next (`poc`) with openpyxl on the same grid.

This is *not* a benchmark against Microsoft Excel.  It is an honest comparison
against the most common Python-side implementation, which is what server-side
tooling and many "Office-compatible" web products use today.

Usage: python3 scripts/bench_compare.py [cells]
"""

import json
import os
import subprocess
import sys
import tempfile
import time

CELLS = int(sys.argv[1]) if len(sys.argv) > 1 else 200_000
ROWS, COLS = CELLS // 8, 8


def poc_binary() -> str:
    for path in (
        os.environ.get("POC_BIN"),
        "./target/release/poc",
        "./target/debug/poc",
        "poc",
    ):
        if not path:
            continue
        if path == "poc" or os.path.exists(path):
            try:
                subprocess.run([path, "version"], capture_output=True, check=True)
                return path
            except Exception:
                continue
    sys.exit("`poc` が見つかりません。先に `cargo build --release` を実行してください。")


def bench_poc(binary: str) -> dict:
    out = subprocess.run(
        [binary, "bench", "--cells", str(CELLS), "--json"],
        capture_output=True,
        text=True,
        check=True,
    )
    return json.loads(out.stdout)


def bench_openpyxl() -> dict:
    try:
        import openpyxl
    except ImportError:
        sys.exit("openpyxl が必要です: pip install openpyxl")
    from openpyxl import Workbook

    t0 = time.perf_counter()
    wb = Workbook(write_only=True)
    ws = wb.create_sheet("Bench")
    for r in range(ROWS):
        row = [f"row {r}"]
        row.extend(((r * 7 + c * 13) % 1000) for c in range(1, COLS - 1))
        row.append(f"=SUM(B{r + 1}:G{r + 1})")
        ws.append(row)
    build = time.perf_counter() - t0

    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "bench.xlsx")
        t0 = time.perf_counter()
        wb.save(path)
        write = time.perf_counter() - t0
        size_kb = os.path.getsize(path) / 1024

        t0 = time.perf_counter()
        back = openpyxl.load_workbook(path, read_only=True)
        counted = sum(1 for row in back.active.iter_rows() for _ in row)
        read = time.perf_counter() - t0
        back.close()

    per = lambda ms: ms * 1e6 / (ROWS * COLS)  # noqa: E731
    return {
        "cells": ROWS * COLS,
        "rows": ROWS,
        "cols": COLS,
        "build_ms": build * 1e3,
        "write_ms": write * 1e3,
        "read_ms": read * 1e3,
        "file_kb": size_kb,
        "write_ns_per_cell": per(write * 1e3),
        "read_ns_per_cell": per(read * 1e3),
        "read_cells": counted,
    }


def main() -> None:
    binary = poc_binary()
    print(f"グリッド: {ROWS} 行 × {COLS} 列 = {ROWS * COLS:,} セル (数式 {ROWS:,} 個)\n")
    poc = bench_poc(binary)
    print("Poccham Office Next (Rust, release)")
    print(f"  書き込み : {poc['write_ms']:8.1f} ms")
    print(f"  読み込み : {poc['read_ms']:8.1f} ms")
    print(f"  再計算   : {poc['calc_ms']:8.1f} ms")
    print(f"  サイズ   : {poc['file_kb']:8.1f} KB")

    py = bench_openpyxl()
    print("\nopenpyxl (Python, write_only + read_only)")
    print(f"  書き込み : {py['write_ms']:8.1f} ms")
    print(f"  読み込み : {py['read_ms']:8.1f} ms")
    print(f"  サイズ   : {py['file_kb']:8.1f} KB")
    if py["read_cells"] != py["cells"]:
        print(f"  注意     : 読み込めたセル数 {py['read_cells']:,} (期待 {py['cells']:,})")

    print("\n比較 (Poccham が何倍速いか)")
    print(f"  書き込み : {py['write_ms'] / poc['write_ms']:5.1f}x")
    print(f"  読み込み : {py['read_ms'] / poc['read_ms']:5.1f}x")
    ratio = poc["file_kb"] / py["file_kb"]
    note = "小さい" if ratio < 1.0 else "大きい"
    print(f"  ファイル : {ratio:5.2f}x (Poccham / openpyxl, 1.0 未満なら Poccham が小さい → {note})")


if __name__ == "__main__":
    main()
