#!/usr/bin/env python3
"""Sanity-check `.github/workflows/build.yml`.

The workflow ships its "move the sources to the repository root" step inside
both the `test` and `bundle` jobs.  Those two copies must stay byte-identical:
when they drifted apart once, the `test` job recovered from a nested source
tree while the `bundle` job failed with "Cargo.toml が見つかりません".

This script fails the build if that happens again, and checks a few other
invariants that are easy to break by hand.

    python3 scripts/ci/check_workflow.py
"""

from __future__ import annotations

import sys
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

WORKFLOW = Path(".github/workflows/build.yml")
RESOLVER_NAME = "ソースのルートを解決"
REQUIRED_JOBS = ("test", "bundle")


def fail(message: str) -> None:
    print(f"[FAIL] {message}")
    sys.exit(1)


def main() -> None:
    text = WORKFLOW.read_text(encoding="utf-8")

    try:
        import yaml  # type: ignore
    except ImportError:
        # PyYAML が無い環境でも、せめて「2 つの run ブロックが同じか」を見る
        yaml = None

    if yaml is not None:
        data = yaml.safe_load(text)
        jobs = data.get("jobs", {})
        for job in REQUIRED_JOBS:
            if job not in jobs:
                fail(f"ジョブ `{job}` がありません")
        resolvers: dict[str, str] = {}
        for job in REQUIRED_JOBS:
            steps = jobs[job].get("steps", [])
            names = [step.get("name", step.get("uses")) for step in steps]
            if names[:2] != ["actions/checkout@v4", RESOLVER_NAME]:
                fail(f"{job}: checkout の直後に「{RESOLVER_NAME}」が必要です (実際: {names[:3]})")
            step = next(s for s in steps if s.get("name") == RESOLVER_NAME)
            resolvers[job] = step.get("run", "")
    else:
        # フォールバック: テキストとして数えるだけ
        resolvers = {"a": text, "b": text}

    values = list(resolvers.values())
    if len(set(values)) != 1:
        fail("「ソースのルートを解決」の定義がジョブ間で一致していません")
    if "ソース解決ステップ" not in values[0]:
        fail("「ソースのルートを解決」にバージョン表示がありません")
    if "find . -maxdepth 6" not in values[0]:
        fail("「ソースのルートを解決」が深さ 6 まで探索していません")
    for needle in ("PYTHONUTF8", "PYTHONIOENCODING"):
        if needle not in text:
            fail(f"env に {needle} がありません（Windows で日本語ログが出せません）")
    if ".ci-venv" not in text:
        fail("OOXML 検証が venv を使っていません（macOS の PEP 668 で失敗します）")

    print("[OK  ] ワークフロー定義は一貫しています")


if __name__ == "__main__":
    main()
