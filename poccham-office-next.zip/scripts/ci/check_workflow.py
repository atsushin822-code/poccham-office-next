#!/usr/bin/env python3
"""Sanity-check `.github/workflows/build.yml`.

The workflow ships its "move the sources to the repository root" step inside
both the `test` and `bundle` jobs.  Those two copies must stay byte-identical:
when they drifted apart once, the `test` job recovered from a nested source
tree while the `bundle` job failed with "Cargo.toml が見つかりません".

This script fails the build if that happens again, and checks a few other
invariants that are easy to break by hand.

    python3 scripts/ci/check_workflow.py
"""

from __future__ import annotations

import sys
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

WORKFLOW = Path(".github/workflows/build.yml")
RESOLVER_NAME = "ソースのルートを解決"
REQUIRED_JOBS = ("test", "bundle")


def fail(message: str) -> None:
    print(f"[FAIL] {message}")
    sys.exit(1)


# パッケージ ジョブで踏んだ地雷を二度と踏まないための検査。
#  - `--target <triple>` を付けると Tauri の出力は target/<triple>/release/bundle に
#    変わる。パスを決め打ちすると out/ が空になり `sha256sum *` が
#    "No such file or directory" で落ちる。
#  - Windows ランナーの既定シェルは pwsh なので、bash 構文のステップには
#    `shell: bash` を明示する必要がある。
BASH_BUNDLE_STEPS = ("ソースのルートを解決", "成果物を集約", "チェックサム")


def _check_bundle_steps(text: str) -> None:
    try:
        import yaml  # type: ignore
    except ImportError:
        return
    data = yaml.safe_load(text)
    steps = {s.get("name"): s for s in data["jobs"]["bundle"].get("steps", []) if s.get("name")}

    for name in BASH_BUNDLE_STEPS:
        step = steps.get(name)
        if step is None:
            fail(f"bundle ジョブに「{name}」ステップがありません")
        if step.get("shell") != "bash":
            fail(f"「{name}」に shell: bash がありません（Windows では pwsh で動いてしまいます）")

    for name in ("成果物を集約", "チェックサム"):
        run = steps[name].get("run", "")
        if "target/release/bundle" in run:
            fail(f"「{name}」が target/release/bundle を決め打ちしています")
        if "ls -A" not in run:
            fail(f"「{name}」が空ディレクトリを検査していません")
    # Windows ポータブル版: Copy-Item は必ず -Path/-Destination を明示する。
    # `Copy-Item README.md, LICENSE docs -Destination stage` のようにパスを
    # 位置引数で並べると "A positional parameter cannot be found" で落ちる。
    win = steps.get("Windows ポータブル版を作成")
    if win is not None:
        if win.get("shell") != "pwsh":
            fail("「Windows ポータブル版を作成」に shell: pwsh がありません")
        for line in win.get("run", "").splitlines():
            if "Copy-Item" in line and "-Path" not in line:
                fail(f"Copy-Item に -Path がありません: {line.strip()}")
        if "Test-Path" not in win.get("run", ""):
            fail("「Windows ポータブル版を作成」が同梱ファイルの存在確認をしていません")

    if "portable.zip" not in steps["成果物を集約"].get("run", ""):
        fail("「成果物を集約」が Windows ポータブル版を拾っていません")
    if "find . " not in steps["成果物を集約"].get("run", ""):
        fail("「成果物を集約」がリポジトリ全体を探索していません")


def main() -> None:
    text = WORKFLOW.read_text(encoding="utf-8")

    try:
        import yaml  # type: ignore
    except ImportError:
        # PyYAML が無い環境でも、せめて「2 つの run ブロックが同じか」を見る
        yaml = None

    if yaml is not None:
        data = yaml.safe_load(text)
        jobs = data.get("jobs", {})
        for job in REQUIRED_JOBS:
            if job not in jobs:
                fail(f"ジョブ `{job}` がありません")
        resolvers: dict[str, str] = {}
        for job in REQUIRED_JOBS:
            steps = jobs[job].get("steps", [])
            names = [step.get("name", step.get("uses")) for step in steps]
            if names[:2] != ["actions/checkout@v4", RESOLVER_NAME]:
                fail(f"{job}: checkout の直後に「{RESOLVER_NAME}」が必要です (実際: {names[:3]})")
            step = next(s for s in steps if s.get("name") == RESOLVER_NAME)
            resolvers[job] = step.get("run", "")
    else:
        # フォールバック: テキストとして数えるだけ
        resolvers = {"a": text, "b": text}

    values = list(resolvers.values())
    if len(set(values)) != 1:
        fail("「ソースのルートを解決」の定義がジョブ間で一致していません")
    if "ソース解決ステップ" not in values[0]:
        fail("「ソースのルートを解決」にバージョン表示がありません")
    if "find . -maxdepth 6" not in values[0]:
        fail("「ソースのルートを解決」が深さ 6 まで探索していません")
    _check_bundle_steps(text)

    for needle in ("PYTHONUTF8", "PYTHONIOENCODING"):
        if needle not in text:
            fail(f"env に {needle} がありません（Windows で日本語ログが出せません）")
    if ".ci-venv" not in text:
        fail("OOXML 検証が venv を使っていません（macOS の PEP 668 で失敗します）")

    print("[OK  ] ワークフロー定義は一貫しています")


if __name__ == "__main__":
    main()
