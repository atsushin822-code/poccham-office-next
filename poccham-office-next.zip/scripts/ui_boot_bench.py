#!/usr/bin/env python3
"""Measure how fast the UI starts and how fast it opens a large workbook.

    pip install playwright && playwright install chromium
    python3 scripts/ui_boot_bench.py            # 既定: 50,000 セル
    python3 scripts/ui_boot_bench.py 20000      # セル数を指定

Reported figures (median of `RUNS` runs):

* cold boot — navigation start → first frame where the window is interactive
* open / cached — loading a workbook whose formulas already carry results
  (what happens when you open a file saved by Excel or by this app)
* open / recalc — the same workbook with the cached results stripped, i.e. the
  worst case where every formula has to be evaluated again

The difference between the last two is the payoff of the lazy recalculation in
`applyWorkbookPayload`.
"""

import asyncio
import pathlib
import statistics
import sys

from playwright.async_api import async_playwright

RUNS = 3
HTML = pathlib.Path(__file__).resolve().parent.parent / "crates/poc-ui/dist/index.html"


def synthetic_payload(rows: int, cached: bool) -> dict:
    """`rows`×`cols` grid where every 4th cell is a formula."""
    cols = 10
    cells = []
    for r in range(rows):
        for c in range(cols):
            addr = f"{chr(65 + c)}{r + 1}"
            if c % 4 == 3 and r > 0:
                cells.append([addr, "", f"SUM({chr(65 + c - 2)}{r + 1}:{chr(65 + c - 1)}{r + 1})",
                              0, "0" if cached else ""])
            else:
                cells.append([addr, f"値{r}-{c}", "", 0, ""])
    return {"kind": "workbook", "title": "ベンチ", "sheets": [{"name": "Data", "cells": cells}]}


async def measure(pw, cells: int) -> dict:
    payload_cached = synthetic_payload(cells // 10, cached=True)
    payload_recalc = synthetic_payload(cells // 10, cached=False)
    boots, opens_cached, opens_recalc = [], [], []

    for _ in range(RUNS):
        browser = await pw.chromium.launch(args=["--no-sandbox"])
        page = await browser.new_page(viewport={"width": 1440, "height": 900})
        t0 = asyncio.get_event_loop().time()
        await page.goto(HTML.as_uri())
        await page.wait_for_function("() => !!window.__POC__ && document.body.classList.contains('ready')")
        boots.append((asyncio.get_event_loop().time() - t0) * 1000)

        opens_cached.append(
            await page.evaluate(
                """async (payload) => {
                    const t = performance.now();
                    window.__POC__.loadPayload(payload);
                    await new Promise((r) => requestAnimationFrame(r));
                    return performance.now() - t;
                }""",
                payload_cached,
            )
        )
        opens_recalc.append(
            await page.evaluate(
                """async (payload) => {
                    const t = performance.now();
                    window.__POC__.loadPayload(payload);
                    await new Promise((r) => requestAnimationFrame(r));
                    return performance.now() - t;
                }""",
                payload_recalc,
            )
        )
        await browser.close()

    return {
        "boot": statistics.median(boots),
        "cached": statistics.median(opens_cached),
        "recalc": statistics.median(opens_recalc),
    }


async def main() -> None:
    cells = int(sys.argv[1]) if len(sys.argv) > 1 else 50_000
    async with async_playwright() as pw:
        result = await measure(pw, cells)
    print(f"セル数 {cells:,} / {RUNS} 回の中央値")
    print(f"  起動 (cold boot)         : {result['boot']:.0f} ms")
    print(f"  ブックを開く (計算済み)  : {result['cached']:.0f} ms")
    print(f"  ブックを開く (要再計算)  : {result['recalc']:.0f} ms")
    if result["recalc"] > 0:
        print(f"  → キャッシュ済みなら {result['recalc'] / max(result['cached'], 0.01):.1f}× 速い")


if __name__ == "__main__":
    asyncio.run(main())
